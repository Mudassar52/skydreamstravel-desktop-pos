import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// Electron loads files via file:// in production, so base must be relative.
export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  },
  server: {
    port: 5173,
    strictPort: true
  }
});
