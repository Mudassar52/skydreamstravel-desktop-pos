# Travel Agency Manager — All 18 Phases Complete

Premium Electron + React + Vite + SQLite desktop app for a travel agency
(Umrah, Hajj, Tours, Bookings, Invoicing, Payments, Ledger, Expenses...).

This delivery covers, from the full 18‑phase plan:

- **Phase 1 — App shell & premium UI**: collapsible sidebar with every module
  from the spec, top header (global search UI, notifications, profile menu),
  routing, and a fully designed **Dashboard** (stat cards, charts, upcoming
  lists, quick actions) in a blue + white design system.
- **Phase 2 — SQLite database architecture**: `src/database/schema.sql`
  creates every table from the spec (customers, bookings, umrah/hajj/tours,
  flights, hotels, visa, transportation, invoices + invoice_templates,
  payments, ledger_entries, expenses, documents, settings, audit_logs, users/
  roles/permissions) with foreign keys and indexes, plus a real IPC round‑trip:
  the Dashboard's stat cards and charts are wired to actual SQL queries in
  `electron/services/dashboardService.js` — not hard‑coded numbers.

- **Phase 3 — Authentication, Users & Permissions**: a real login screen
  gates the whole app; passwords are hashed with bcrypt (`bcryptjs`, pure JS —
  no native build step beyond `better-sqlite3`); a default `admin` / `admin123`
  account is seeded on first run (change it from Staff & Users → Reset
  Password). **Staff & Users** is now a fully working screen: list/add users,
  enable/disable accounts, reset passwords, and a per-role **permissions
  matrix** (view/create/edit/delete × all 20 modules) that an Admin can edit
  live. The sidebar and routes filter themselves by the logged-in user's
  actual permissions — a Staff user simply doesn't see modules they can't
  view, and direct navigation to a blocked route shows "Access denied"
  instead of the page. Manager and Staff roles get sensible default grants
  out of the box (see `electron/services/permissionModules.js`), fully
  editable afterwards.

- **Phase 4 — Customer Management**: full CRUD wired to the real database —
  searchable, paginated list (won't choke on 1,000+ customers — server-side
  `LIMIT`/`OFFSET`, indexed search columns), Add/Edit form covering every
  field from your spec (Personal + Passport sections), a customer profile
  drawer with a live Bookings/Invoices/Outstanding summary strip, validation
  (required name, email format, passport expiry-after-issue-date), and a
  delete safeguard that refuses to delete a customer with existing bookings
  (tells you to mark them Inactive instead). The Dashboard's "New Customer"
  quick action is now real too — it takes you to Customers and opens the
  form, rather than sitting there as a dead button.

- **Phase 5 — Umrah, Hajj & Tour packages/groups**: full CRUD for Umrah
  packages (all the fields in your spec — inclusions, Makkah/Madinah hotel
  and nights, cost vs. selling price) and Umrah groups; Hajj packages and
  groups; and fully custom Tours (no hard-coded destinations — add any
  country/city). Groups and tours get a **passenger/pilgrim list**, not just
  a headcount: a searchable customer picker adds people to a group, and the
  headcount column updates itself automatically — no separate step to keep
  it in sync. Tours specifically track **available seats vs. total seats**
  and refuse to add a passenger once a tour is full. A generic CRUD/
  membership layer (`electron/services/genericCrud.js`,
  `membershipService.js`) backs all three modules so Umrah/Hajj/Tours don't
  each reimplement the same list/create/update/delete/add-member/remove-
  member logic — that pattern will also speed up later phases (Flights,
  Hotels, Visa, Transportation are structurally similar).

- **Phase 6 — Booking Management**: the module that actually ties everything
  together. A booking links a customer to a booking type (Umrah/Hajj/Tour/
  Flight/Hotel/Visa/Transportation/Custom), auto-generates a sequential
  booking code (`BK-000001`, `BK-000002`, ...), and — for Umrah/Hajj/Tour —
  lets you pick the actual package/tour from a live dropdown pulled from
  those modules. Total/paid/remaining amounts are validated (paid can't
  exceed total, nothing negative) and remaining is always computed
  server-side, never trusted from the form. Bookings get their own
  passenger list (same auto-syncing pattern as Umrah/Hajj groups), a
  searchable paginated list with status/type filters, and a delete
  safeguard that blocks deleting a booking once an invoice references it
  (tells you to cancel instead). The customer profile drawer's Bookings tab
  and the Dashboard's "New Booking" quick action — both placeholders until
  now — are wired to this and fully working.

- **Phase 7 — Flights, Hotels, Visa & Transportation**: four more real
  modules, each optionally linked to a booking via a live dropdown. Flights
  carry a multi-passenger manifest (reusing the same drawer pattern from
  Umrah/Hajj/Tours). Hotels validate that check-out isn't before check-in.
  Visa applications are linked to a customer, track the full status
  pipeline from your spec (Documents Pending → ... → Approved/Rejected/
  Expired), and flag anything **expiring within 30 days** right in the list
  — with a `getExpiringSoon()` query ready for the Dashboard or a
  notifications feature to consume later. Transportation tracks vehicle/
  driver/pickup-drop assignments with their own status pipeline.

- **Phase 8 — Invoice System + Invoice Template Engine + PDF Engine**: this
  is the phase you were most explicit about, so here's exactly how the
  separation works. An invoice template (`invoice_templates` table) is
  nothing but an HTML string with tokens like `{{invoice_number}}` and
  `{{{line_items_html}}}` (triple braces = pre-rendered HTML, used only for
  the line-items table body; everything else is HTML-escaped automatically
  — verified against a real XSS-style string in testing). The **Invoice
  Templates** screen lets you create, edit, and set-default as many designs
  as you want, with a token cheat-sheet built in; a seeded "Default
  Template" ships so the system works out of the box, but it's just a
  normal row — delete-guarded only while it's the active default, not
  hard-coded anywhere in the invoice/customer/payment code. **Invoices**
  get full CRUD, a dynamic line-item editor, **Create from Booking** (pulls
  the booking's price and paid amount straight in), **Duplicate** (resets
  paid to 0, status to Unpaid), **Cancel** (soft status, keeps the record),
  and a delete guard that blocks removing an invoice once a payment is
  recorded against it. Status (Unpaid/Partially Paid/Paid) is always
  derived from paid vs. total server-side, never trusted from the form.
  **PDF and Print** use Electron's own Chromium engine
  (`webContents.printToPDF` / `webContents.print`) to render the selected
  template as a real A4 PDF or send it to the native Windows print dialog —
  no extra PDF library needed, and it's the same rendering engine either
  way, so what you preview is what prints.

  **Testing note on this phase specifically:** everything except the actual
  PDF/print calls was verified against a real SQLite database in this
  environment (template CRUD, default-template delete-guard, invoice
  validation, sequential numbering, duplicate, from-booking, cancel, delete
  guard, and the full HTML template rendering with escaping). The
  `printToPDF`/native print dialog calls need a running Electron window
  with a display to execute, which this sandbox doesn't have — please try
  Generate PDF and Print on a real invoice once you're running the app, and
  let me know if anything doesn't render as expected.

- **Phase 9 — Payments + Customer Ledger**: recording a payment updates the
  linked invoice or booking's paid/remaining amounts and status **and**
  appends a customer ledger entry, all in one atomic transaction — tested
  against a real database including partial payments, a payment that fully
  settles an invoice, a **refund** (correctly modeled as increasing what the
  customer owes again, not a negative payment), a booking-only payment with
  no invoice, and a general/advance payment tied to neither. Payments are
  never edited after the fact — they're **voided**, which reverses the
  exact effect on the invoice/booking and adds an offsetting ledger entry,
  so the ledger stays trustworthy instead of silently rewriting history.
  Invoices automatically get a debit ledger entry when created, and a
  reversing credit when cancelled or deleted, so raising, paying, and
  cancelling invoices all keep the running balance correct — confirmed by
  cancelling an invoice mid-test and checking the balance returned to
  exactly where it started. The **Customer Ledger** screen shows the full
  running balance for a chosen customer, and the customer profile drawer
  now links straight to it, plus its Payments tab shows real records instead
  of the earlier placeholder.

  **Bug I caught and fixed during testing, worth knowing about:** my first
  version of "void a payment" deleted the payment row while an earlier
  ledger entry still referenced it, which the database correctly rejected
  (a foreign key constraint) rather than leaving an inconsistent record.
  Fixed by detaching that reference before deleting — re-ran the full test
  suite afterward and everything passed, including voiding both a refund
  and a normal payment.

- **Phase 10 — Expenses + Profit**: customizable expense categories (nine
  common ones seeded, add/remove your own — delete is blocked once a
  category has expenses against it), full expense CRUD optionally linked to
  a booking, and a **Profit Overview** tab with a summary, a 6-month
  revenue/expenses/profit chart, and a breakdown by booking type (Umrah,
  Hajj, Tour, ...). **Important correction while building this**: your spec
  is explicit that Sales, Payments, Expenses, and Profit must stay separate
  concepts, and profit must be Revenue − Expenses — but the Dashboard I
  built back in Phase 2, before Expenses existed as a real feature, had
  quietly computed "Estimated Profit" as *Payments received* − Expenses.
  That's wrong (an invoice is a real sale whether or not it's been paid
  yet, and a refund shouldn't retroactively have "used to count" as
  profit), so I fixed both the Dashboard's stat card and its monthly chart
  to use Sales instead, and verified with a real test that a booking with
  Rs. 100,000 in sales and zero payments still shows the correct profit
  once expenses are subtracted from *sales*, not from the zero received so
  far.

- **Phase 11 — Documents**: real file management, not just a database row.
  Uploading opens the native Windows file picker (multi-select supported),
  and each selected file is **copied** into the app's own per-user storage
  folder (`%APPDATA%/.../storage/documents`) — not just referenced where it
  sat, so it survives the source file being moved or deleted, and so
  Backup & Restore (Phase 14) can back up one folder and get everything. A
  document attaches to a customer, a booking, or both. Open acts as
  preview/view (hands the file to the OS's default app — PDF viewer, image
  viewer, whatever's installed); Download lets you Save As anywhere; Rename
  renames the actual file on disk, not just the database label, and is
  guarded against silently overwriting another file that happens to share
  the new name. The Customer profile drawer's Documents tab — the last
  placeholder tab from Phase 4 — now shows real uploaded documents.

  **Testing note, same shape as Phase 8's**: storage folder creation,
  listing, get, rename (including the name-collision guard), and delete
  were all tested directly against real files on disk in this environment.
  The upload dialog itself and "Open"/"Download As" go through Electron's
  native file/save dialogs, which need an actual running window — please
  try uploading a real file once you're running the app and let me know if
  anything's off.

- **Phase 12 — Reports**: all 14 reports from your spec — Sales, Booking,
  Customer, Payment, Outstanding, Expense, Profit, Umrah, Hajj, Tour,
  Flight, Hotel, Visa, and Customer Ledger — built on one generic
  columns/rows engine rather than 14 separate one-off screens, so adding a
  15th report later is small. Each report only shows the filters that
  actually apply to it (date range, customer, status, type), pulls live
  data with real SQL joins across the tables built in every earlier phase,
  and totals footer rows where a sum makes sense (Sales, Payments,
  Outstanding, Profit). **Export is generic too**: CSV, PDF, and Print all
  work off the same columns+rows+totals shape, so they work identically for
  any report without per-report export code. The Customer Ledger Report
  is worth calling out: with no customer selected it shows every
  customer's current balance at a glance; pick a customer and it switches
  to their full transaction-by-transaction ledger.

  **Testing note**: I populated a realistic dataset (customers, bookings
  across types, invoices, a payment, an expense, Umrah/Hajj groups, a tour,
  a flight, a hotel, a visa application) and ran all 14 reports against it,
  checked filtered results (by customer, status), verified totals footers
  compute correctly, and specifically tested CSV escaping with a value
  containing both a quote and a comma. All correct. As with Phases 8 and
  11, the CSV/PDF file-save dialogs and native print go through Electron's
  dialog APIs, which need a real running window — the report *data* is
  fully verified, the export dialogs themselves are the one piece to
  confirm once you're running the app.

- **Phase 13 — Settings**: agency info (name, address, phone, WhatsApp,
  email, website), business info, bank details, default currency, invoice
  prefix/next-number, an optional tax rate, and default terms & conditions
  — all editable, and all of it feeds the invoice engine's tokens from
  Phase 8, which were rendering as blanks until now. I also closed a real
  gap while building this: your spec explicitly lists **Logo, Signature,
  and Stamp** as things the invoice template must be able to show, but the
  Phase 8 template engine never actually had a way to set them. Settings
  now has a **Branding** section with native image upload for all three
  (stored as data URIs, 2 MB size-checked, PNG/JPG/GIF/WEBP), and I added
  `{{{logo_html}}}`, `{{{signature_html}}}`, and `{{{stamp_html}}}` tokens
  to the template engine and wired them into the seeded default template's
  header and footer — verified end-to-end with a test that sets a logo and
  confirms it actually appears embedded in a rendered invoice.

  **Testing note**: settings save/load, rejection of unrecognized keys (so
  a stray field can't pollute the table), the invoice numbering picking up
  a changed prefix/counter immediately, and the logo/signature wiring into
  rendered invoice HTML were all tested directly. The image *upload*
  dialog itself needs a running window like the other native-dialog
  features from Phases 8/11/12 — try replacing the logo once you're
  running the app.

Only Backup & Restore is left as **"Not built yet — Phase N"** now, per your
Section 42 rule. That's the next and final application-feature phase.

- **Phase 14 — Backup & Restore**: one .zip file holds everything — the
  full SQLite database (via SQLite's own backup API, a consistent snapshot
  even while the app has it open, not a raw file copy that could catch it
  mid-write) plus every uploaded document. **Backup Now** lets you choose
  where to save it (for moving to another Windows computer, exactly per
  your Section 27 requirement). **Restore** replaces everything currently
  in the app with the backup's contents and then restarts the app cleanly
  (`app.relaunch()`) rather than trying to hot-swap the live database
  connection underneath an active session — safer and simpler. **Automatic
  Backup** is a due-check on launch (once enabled and a folder is chosen,
  it silently backs up once a day, the first time the app opens that day)
  rather than a background scheduler daemon, since a desktop app has no
  way to run code while it's closed.

  **A real bug I hit and fixed while testing this**: my first version of
  document restoration extracted files to the wrong folder because of a
  zip-library flag I had backwards (`maintainEntryPath`) — it would have
  silently dropped every restored document outside the documents folder
  entirely. I caught this by testing with an actual file end-to-end rather
  than just checking the database side, fixed the flag, and reran the full
  test with two documents to confirm exact restoration this time.

  **What I actually verified**: since this sandbox can't run a real
  Electron window, I mocked just the `electron` module (`app.getPath`,
  `dialog`) so the *real* `backupService.js` code runs unmodified against
  real files and a real SQLite database. That test: created data, backed
  it up, added more data and files, restored, and confirmed the extra data
  vanished while the original data and exact document set came back byte-
  for-byte — plus confirmed an invalid (non-backup) zip is rejected, and
  that automatic backup correctly runs once and then skips on an immediate
  second check. The two things that still need a real running app to
  confirm are `app.relaunch()` actually restarting the window, and the
  native save/open dialogs themselves — same category of limitation as
  Phases 8, 11, and 12.

## Why the dashboard sometimes shows sample numbers

On a brand-new install the database is empty, so all the real queries return
zero. Rather than show a dashboard full of zeros, it falls back to clearly
labelled sample data until you have real customers/bookings/invoices in the
database. As soon as real records exist, real numbers take over automatically
— nothing to configure.

## Requirements

- **Windows 10/11** (or Linux/Mac for development — Electron is
  cross‑platform; only the final packaged installer targets Windows via
  `electron-builder`'s `nsis` target).
- **Node.js 18 or 20 LTS** installed.
- Node's build tools available for `better-sqlite3`'s native binding
  (on Windows this normally just works with a current Node LTS + Python;
  if it fails, install the "Desktop development with C++" workload via
  Visual Studio Build Tools).

## Setup

```bash
npm install
```

## Run in development (hot reload)

```bash
npm run dev:electron
```

This starts the Vite dev server and opens the Electron window pointed at it.

## Run automated tests

```bash
npm test
```

414 tests across 34 files (Vitest), covering every service module —
customers, bookings, Umrah/Hajj/Tours, Flights/Hotels/Visa/Transportation,
the invoice engine (including template token escaping), payments/ledger
(including refunds and voids), expenses/profit, auth/RBAC, documents,
reports/export, and backup/restore (with `electron`'s native dialogs faked
so the tests run without a real window — see the comment at the top of
`backupService.test.js` if you're curious how). Run this after changing
anything in `electron/services/` to catch a regression immediately.

## Build a production Windows installer

```bash
npm run build:win
```

Output goes to `dist_electron/` (or wherever `electron-builder` places it —
check the terminal output). This step must be run on Windows, or via
electron-builder's cross-build support.

## Where things live

```
electron/
  main.js              Electron entry point — creates the window, inits the DB
  preload.js            Safe contextBridge API exposed to React (window.api.*)
  ipc/handlers.js        All ipcMain.handle(...) registrations, one per module
  services/              Business logic, one file per module (dashboardService.js so far)
src/
  database/
    schema.sql           Full table definitions for the whole app
    db.js                 Opens the SQLite file (in Electron's userData folder), runs schema, seeds defaults
  components/             Reusable UI: Sidebar, Header, StatCard, ...
  layouts/MainLayout.jsx   Sidebar + header + routed content
  pages/                   One file per screen (Dashboard.jsx is real; others are ComingSoon placeholders)
  utils/navConfig.js       Single source of truth for the sidebar menu + which phase builds each screen
  styles/globals.css       Design tokens (blue + white premium theme), shared classes
```

## Database location

The SQLite file is created at Electron's per-user `userData` path (e.g.
`%APPDATA%/travel-agency-manager/database/agency.db` on Windows) — not inside
the project folder — so it survives app updates and reinstalls, and is the
right place to point the future Backup & Restore module (Phase 14) at.

- **Phase 15 — Audit Logs + Validation polish**: a real **Audit Log** viewer
  (added as a third tab under Staff & Users, alongside Users and
  Permissions — it's a security/admin feature, not one of the top-level
  sidebar items in your own spec's Section 4 list, so that's where it
  naturally belongs) with search, and filters by action and record type.
  The logging itself has quietly been running since Phase 3 — every
  create/update/delete across every module writes to `audit_logs` — this
  phase just gives you a screen to actually see it. Also closed six
  validation gaps in one pass: booking departure/return dates, tour start/
  end dates, Umrah package and group dates, Hajj package and group dates,
  and flight departure/arrival dates now all reject an end date before a
  start date, matching the "Valid dates" requirement from your Section 29
  more completely than before (hotels already had this check from Phase 7;
  the others didn't).

  **Testing note**: all six new date validations were tested individually
  (each correctly rejects a backwards date range) and I specifically also
  tested that records with dates in the correct order, and records with no
  dates at all (since these fields are optional), still save correctly —
  it's easy to add a validation that's too strict and breaks the normal
  case, so I checked for that specifically. The audit log viewer was
  tested with real data: search by keyword, filter by record type, and
  confirmed the distinct-actions/record-types lists used to populate the
  filter dropdowns come back correctly.

- **Phase 16 — Performance**: two real gaps closed, then load-tested rather
  than assumed fast. First, **indexes**: several foreign-key/join columns
  that earlier phases queried constantly (flights/hotels/visa/
  transportation/documents/payments/expenses → their booking or customer,
  invoice_items → invoice, etc.) had no index — 25 were added, all
  additive (`CREATE INDEX IF NOT EXISTS`), so they apply automatically to a
  database created by any earlier phase. Second, **pagination**: Flights,
  Hotels, Visa, Transportation, and Documents were the five lists still
  doing an unbounded `SELECT *` — every other list already paginated back
  in the phase that built it, these five were the gap. All five now
  paginate and search server-side, matching the pattern from Customers/
  Bookings/Invoices, and their pages got real search bars and pagination
  controls to match.

  **Then I actually load-tested it** rather than assuming the fix worked.
  Seeded a dataset *exceeding* every number your spec names in Section 38
  (1,200 customers, 5,200 bookings, 10,500 invoices, ~2,800 flights/hotels/
  visa/transportation records combined, 2,000 documents, ~7,000 payments)
  and timed every list, filter, and report query through the real service
  functions: every single one completed in under 30ms, the slowest being
  the unpaginated Sales report (25ms for all 10,500 rows, which is correct
  since report exports need the full dataset). Then, to make sure the new
  indexes were actually doing something rather than SQLite just being fast
  regardless at this scale, I ran the same point-lookup queries with the
  new indexes dropped: **4–8x slower** without them. Small in absolute
  terms at 10,000 rows, but confirms the indexes are real, working
  optimizations and not just decoration - and the gap would keep widening
  as an agency's data grows over years of use.

- **Phase 17 — Testing**: rather than more one-off verification scripts
  like I'd been running at each phase, this phase converts that manual
  testing into a **permanent, rerunnable suite** — 93 automated tests
  across 11 files using Vitest (pure JS, no native deps, and it fits
  naturally since the project already uses Vite). Every service module has
  real coverage: validation rules, the sequential invoice/booking numbering,
  seat/passenger auto-sync, the template engine's HTML escaping, refund and
  void logic in payments, RBAC defaults, and backup/restore's actual file
  operations. `npm test` runs the whole thing in a few seconds.

  **The trickiest part, worth explaining**: `backupService.js` needs
  Electron's `app`/`dialog`, which don't exist outside a real Electron
  process, so they have to be faked in tests. My first attempt used
  Vitest's standard mocking tool (`vi.mock`), which works by intercepting
  Vite's own module graph — but it turned out that only works reliably for
  `import` statements, not the plain `require()` calls this CommonJS
  codebase uses throughout. When I required `backupService.js` that way,
  its whole dependency chain (`db.js`, `customerService.js`, etc.) loaded
  through a *different* module instance than the one my test had
  initialized, so the database appeared "not initialized" even though it
  clearly had been. I fixed it by loading that entire dependency chain
  through Node's actual native `require()` (via `createRequire`, bypassing
  Vite's transform) so it shares one real module cache — the same
  mechanism the app itself relies on — and faked `electron` by patching
  Node's own module loader directly, the same technique I'd used to verify
  this service manually back in Phase 14. It's a good example of why an
  Electron app's tests need to actually understand Node's module system,
  not just call a mocking library and assume it works.

- **Phase 18 — Windows Production Build**: I said in the last message that
  this phase "genuinely cannot happen in this sandbox" — that turned out to
  be wrong, and I want to walk through what actually happened rather than
  just claim success.

  This container's network allowlist includes GitHub and Ubuntu's package
  archives, which is everything `electron-builder` actually needs: it
  downloaded Electron's **real Windows binary** (not a Linux one) from
  GitHub, rebuilt `better-sqlite3` as a genuine Windows DLL, and packaged
  the whole app. It only stopped at the resource-signing step, which needs
  `wine` — so I installed `wine` (and then `wine32:i386`, once wine's own
  error message told me it needed 32-bit support for `rcedit`) via `apt-get`,
  and reran it. **It produced a real Windows installer**: `file` confirms
  it's a genuine `PE32 executable ... Nullsoft Installer`, and the
  `better_sqlite3.node` bundled inside is confirmed as a genuine
  `PE32+ ... x86-64, for MS Windows` DLL, not the Linux binary this
  container natively produces.

  **A real bug this caught**: the first build's `app.asar` was 164 MB and,
  on inspection, contained a full nested copy of a previous `dist/win-
  unpacked` build *inside itself*. The cause: Vite's renderer output and
  electron-builder's default output directory are **both named `dist/`**,
  so electron-builder's own prior output was getting swept up by its
  `files: ["dist/**/*"]` config and bundled into the next build. I fixed
  it by setting `directories.output` to `release/` in `package.json`,
  rebuilt clean, and confirmed the duplication was gone — the installer
  dropped to 83 MB with identical functional contents. This would have
  shipped a bloated, self-referential installer to anyone who built it
  more than once without noticing.

  **Then I tried to actually run it**: I installed `Xvfb` (a virtual
  display) and launched the real Windows `.exe` under Wine. The Electron/
  Chromium process genuinely starts — it gets through network
  initialization — before crashing with `FATAL:hwnd_util.cc(65): 1400`
  (`ERROR_INVALID_WINDOW_HANDLE`), a well-documented category of Chromium-
  under-Wine incompatibility in window-management API coverage, unrelated
  to this app's code. I tried the standard `--disable-gpu`/`--no-sandbox`
  flags used to work around exactly this class of issue; same crash. This
  is a Wine limitation, not a build defect — Wine reimplements the Win32
  API and doesn't cover everything Chromium calls, which is precisely why
  real Windows testing exists as its own step. I'm flagging this plainly
  rather than glossing over it: **the installer is now the single most
  important thing to actually test on real Windows once you have it**,
  since a Wine-only smoke test can't be the final word.

  **The built installer itself is included in this delivery** (see the
  file card), alongside the usual updated source zip. Skip straight to
  running the installer if you just want to try the app; use the source
  zip if you want to keep developing it.


---

## ERP upgrade (Customer/Supplier/Booking/Package 360, advances, report builder, dashboard calendar, capabilities)

This project was upgraded in place - nothing that existed was removed or replaced. **Read `UPGRADE_LOG.md`**: it lists
every phase's changes, what was verified and how, and an honest list of known limits.

Quick checks after `npm install`:

```
npm test                       # backend tests, including the acceptance test and the upgrade-from-original-database test
node scripts/check-wiring.js   # preload/IPC/service/import wiring - catches blank-screen bugs unit tests can't see
npm run dev:electron           # then follow the manual click-through list in UPGRADE_LOG.md (Phase 11)
```

New entry points: customer drawer -> "Open Complete Travel Dossier"; Suppliers / Packages -> folder icon; booking drawer ->
"Open Complete Travel Dossier"; Finance -> Customer Advances / Supplier Advances; Reports -> Custom Report Builder, Report
History, Report Templates; Staff & Users -> Permissions -> "Financial visibility by role".


## Phase 21 - Agents, Commissions, Exchange Rates, Financial Statements, server-side permissions

- **Agents & Commissions** (Partners): agent master with default Percentage/Fixed commission; pick an agent on a booking and a Pending
  commission appears; approve, pay (creates a real expense + bank/cash movement) or reverse/cancel.
- **Exchange Rates** (Finance): admin-entered rates with history; Customer 360, report notices and the Commissions summary convert to the
  base currency when rates exist and say exactly which rate is missing when they don't.
- **General Ledger / Trial Balance / Balance Sheet** (Finance): derived live from your real records, balanced and cross-checked against the
  bank/cash account balances.
- **Permissions are now enforced in the main process**, not just the UI. See UPGRADE_LOG.md > Phase 21 for the exact rules and the few
  actions whose required permission changed.

Run `npm test` (414 tests) and `node scripts/check-wiring.js` after `npm install`.
