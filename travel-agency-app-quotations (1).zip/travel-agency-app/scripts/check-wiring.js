#!/usr/bin/env node
// Wiring check - catches the mistakes unit tests can't see, because they live in the glue between
// layers and only show up as a blank screen or "No handler registered" at runtime:
//
//   1. every channel preload.js exposes has an ipcMain handler (and vice versa)
//   2. every <service>.<function>() that handlers.js calls really exists on that service
//   3. every window.api.<namespace>.<method>() a page calls is exposed by preload.js
//   4. every relative import in src/ resolves to a file, and named imports are really exported
//   5. every relative require() in electron/ resolves, and registerIpcHandlers() registers every handler
//
// Run from the project root:   node scripts/check-wiring.js
// (Only Electron itself is stubbed, so the handlers can be loaded outside the app.)
// Exits non-zero on any problem, so it can be added to CI or run before packaging.
const fs = require('fs'), path = require('path'), os = require('os');
const ROOT = process.argv[2] && !process.argv[2].startsWith('--') ? path.resolve(process.argv[2]) : path.resolve(__dirname, '..');
const STUB_NATIVE = process.argv.includes('--stub-native'); // used only where the native SQLite driver is unavailable
const Module = require('module'); const origLoad = Module._load;
let registered = 0;
const ELECTRON = { app: { getPath: () => os.tmpdir() }, dialog: {}, ipcMain: { handle() { registered++; } }, BrowserWindow: class {}, shell: {}, contextBridge: {}, ipcRenderer: {} };
Module._load = function (r) {
  if (STUB_NATIVE && r === 'better-sqlite3') return class {};
  if (r === 'electron') return ELECTRON;
  if (STUB_NATIVE && r === 'bcryptjs') return {};
  if (STUB_NATIVE && (r === 'adm-zip' || r === 'archiver')) return class {};
  return origLoad.apply(this, arguments);
};
let problems = 0;
const bad = (msg) => { problems++; console.log('  FAIL', msg); };
const rd = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');

// 1. preload <-> handlers channel agreement
console.log('\n1. IPC channels: every channel the renderer can invoke has a handler (and vice versa)');
const handlers = new Set([...rd('electron/ipc/handlers.js').matchAll(/ipcMain\.handle\('([^']+)'/g)].map((m) => m[1]));
const invokes = new Set([...rd('electron/preload.js').matchAll(/ipcRenderer\.invoke\('([^']+)'/g)].map((m) => m[1]));
for (const c of invokes) if (!handlers.has(c)) bad(`preload invokes '${c}' but no handler is registered`);
for (const c of handlers) if (!invokes.has(c)) bad(`handler '${c}' exists but preload never exposes it`);
console.log(`   ${invokes.size} preload channels, ${handlers.size} handlers`);

// 2. every service function called from handlers.js exists
console.log('\n2. handlers.js: every <service>.<function>() it calls exists');
const hsrc = rd('electron/ipc/handlers.js');
const vars = {};
for (const m of hsrc.matchAll(/const (\w+) = require\('\.\.\/services\/(\w+)'\)/g)) vars[m[1]] = m[2];
let calls = 0;
for (const m of hsrc.matchAll(/\b(\w+Service|\w+Crud)\.(\w+)\(/g)) {
  const [, v, fn] = m; if (!vars[v]) continue; calls++;
  const mod = require(path.join(ROOT, 'electron/services', vars[v]));
  if (typeof mod[fn] !== 'function') bad(`handlers.js calls ${v}.${fn}() but ${vars[v]}.js does not export it`);
}
console.log(`   checked ${calls} service calls across ${Object.keys(vars).length} services`);

// 3. renderer calls window.api.<ns>.<fn>: must exist in preload
console.log('\n3. renderer code: every window.api.<namespace>.<method> it uses is exposed by preload');
const pre = rd('electron/preload.js');
const api = {};
{ const m = pre.match(/exposeInMainWorld\('api',\s*\{([\s\S]*)\}\s*\);?\s*$/m); const body = m ? m[1] : pre;
  for (const ns of body.matchAll(/^  (\w+): \{([\s\S]*?)^  \}/gm)) api[ns[1]] = new Set([...ns[2].matchAll(/^\s{4}(\w+):/gm)].map((x) => x[1])); }
const files = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (f !== 'node_modules') walk(p); } else if (/\.jsx?$/.test(f)) files.push(p); } })(path.join(ROOT, 'src'));
let uses = 0;
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/window\.api\.(\w+)\.(\w+)\(/g)) {
    uses++; const [, ns, fn] = m;
    if (!api[ns]) bad(`${path.relative(ROOT, f)}: window.api.${ns} is not exposed by preload`);
    else if (!api[ns].has(fn)) bad(`${path.relative(ROOT, f)}: window.api.${ns}.${fn}() is not exposed by preload`);
  }
}
console.log(`   checked ${uses} window.api calls in ${files.length} source files against ${Object.keys(api).length} namespaces`);

// 4. every relative import in src/ resolves, and named imports exist
console.log('\n4. src/: every relative import resolves to a file (and named imports exist in it)');
const tryResolve = (from, spec) => {
  const base = path.resolve(path.dirname(from), spec);
  for (const c of [base, base + '.js', base + '.jsx', base + '.css', path.join(base, 'index.js'), path.join(base, 'index.jsx')]) if (fs.existsSync(c) && fs.statSync(c).isFile()) return c;
  return null;
};
let imports = 0;
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/^import\s+(?:([\w$]+)\s*,?\s*)?(?:\{([^}]*)\})?\s*(?:from\s*)?['"](\.[^'"]+)['"]/gm)) {
    imports++;
    const target = tryResolve(f, m[3]);
    if (!target) { bad(`${path.relative(ROOT, f)}: cannot resolve '${m[3]}'`); continue; }
    if (!/\.jsx?$/.test(target) || !m[2]) continue;
    const tsrc = fs.readFileSync(target, 'utf8');
    for (const raw of m[2].split(',').map((s) => s.trim()).filter(Boolean)) {
      const name = raw.split(/\s+as\s+/)[0].trim();
      const exported = new RegExp(`export\\s+(?:async\\s+)?(?:function\\*?|const|let|var|class)\\s+${name}\\b`).test(tsrc) || new RegExp(`export\\s*\\{[^}]*\\b${name}\\b[^}]*\\}`).test(tsrc);
      if (!exported) bad(`${path.relative(ROOT, f)}: '${name}' is not exported by ${path.relative(ROOT, target)}`);
    }
  }
}
console.log(`   checked ${imports} relative imports`);

// 5. electron/: every relative require() resolves and handlers register cleanly
console.log('\n5. electron/: relative require() targets exist; registerIpcHandlers() runs');
const ef = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (f !== '__tests__' && f !== 'node_modules') walk(p); } else if (f.endsWith('.js')) ef.push(p); } })(path.join(ROOT, 'electron'));
let reqs = 0;
for (const f of ef) for (const m of fs.readFileSync(f, 'utf8').matchAll(/require\('(\.[^']+)'\)/g)) { reqs++; if (!tryResolve(f, m[1])) bad(`${path.relative(ROOT, f)}: require('${m[1]}') does not resolve`); }
console.log(`   checked ${reqs} requires in ${ef.length} files`);
try {
  const h = require(path.join(ROOT, 'electron/ipc/handlers.js'));
  const reg = h.registerIpcHandlers || h.registerHandlers || Object.values(h).find((v) => typeof v === 'function');
  if (!reg) bad('could not find the register function exported by handlers.js');
  else {
    reg();
    console.log(`   registerIpcHandlers() ran and registered ${registered} handlers`);
    if (registered !== handlers.size) bad(`registered ${registered} handlers but the file declares ${handlers.size} - a handler is skipped or registered twice`);
  }
} catch (e) { bad('registerIpcHandlers() threw: ' + e.message.split('\n')[0]); }

console.log(problems ? `\nRESULT: ${problems} wiring problem(s)` : '\nRESULT: all wiring checks passed');
process.exit(problems ? 1 : 0);
