# ERP Upgrade Log (FINAL_MASTER_PROMPT_COMPLETE_TRAVEL_ERP)

Upgrade, not rebuild. Additive changes only; existing routes, tables, invoice template untouched.

**STATUS: all 11 phases complete.** 335 automated backend tests pass (incl. a 20-point acceptance test and an
upgrade-from-the-original-database test), `package.json` is byte-identical to the original, and nothing the original
had was removed (see Phase 11). What has NOT been verified is the running Electron UI - see "Known limits" and the
manual check-list at the end of the Phase 11 section. Start there.

## Phase 1 - Inspection (done)
Existing: Electron+React+Vite+better-sqlite3, 60+ services, RBAC, audit, invoices+templates,
payments+customer ledger, suppliers (+invoices/payments/ledger), packages+components
(booking-from-package with frozen snapshot already exists), reports, dashboard, backup.

Gaps vs master prompt (build order):
- Phase 2: Customer 360 dossier ............ DONE; invoice logo width/height ... DONE
- Phase 3: Supplier 360 + Package 360 ...... DONE
- Phase 4: Booking 360 (20 tabs) + Hotel/Transport Voucher Generator ... DONE
- Phase 5: Customer + Supplier Advances (apply/reverse, traceable) + Ledger filters/exports ... DONE (this drop)
- Phase 6: Custom Report Builder (9 report types) + Report History + Report Templates ... DONE (this drop)
- Phase 7: PDF / Excel (real multi-sheet) / Print for reports, ledgers and all four 360 dossiers ... DONE (this drop)
- Phase 8: Dashboard calendar + missing stats + sidebar reorganisation (existing items kept) ... DONE (this drop)
- Phase 9: Permissions (view profit / supplier costs / export reports) + audit coverage ... DONE (this drop)
- Phase 10: Performance + validation + duplicate-transaction prevention + error-state pass ... DONE (this drop)
- Phase 11: Full regression + acceptance test (spec 60-A.20) ... DONE (this drop)

## Phase 2 changes
- electron/services/customer360Service.js  (header, summary, bookingHistory, timeline, getDossier)
- IPC: customer360:dossier|bookings|timeline (+ preload api.customer360)
- src/pages/CustomerDossier.jsx, route /customers/:customerId/360, "Open Complete Travel Dossier" button in customer drawer
- db.js additive columns: flights(cost, selling_price, baggage, seat, booking_reference), hotels(location_type, room_number,
  bed_type, meal_plan, number_of_guests, confirmation_number, status), transportation(transport_type),
  visa_applications(visa_number, passport_number, issue_date, cost, selling_price), bookings(currency)
- Logo: Settings > Branding width/height (10-600px, independent). Blank = original size, so invoice look is unchanged.
- Tests: customer360.test.js (18), logoSizing.test.js (6). Whole suite: 185 pass under a node:sqlite shim.

## Phase 3 changes
- electron/services/supplier360Service.js (header, summary, serviceUsage, bookings, invoices, payments, timeline, getDossier)
- electron/services/package360Service.js (header, bookings, summary, getDossier)
- IPC: supplier360:dossier|services|bookings|invoices|payments|timeline, package360:dossier (+ preload api.supplier360 / api.package360)
- src/pages/SupplierDossier.jsx (route /suppliers/:supplierId/360, tabs: Overview/Services/Bookings/Invoices/Payments/Timeline),
  new folder icon button on Suppliers list
- src/pages/PackageDossier.jsx (route /packages/:packageId/360, incl. components, sold-from bookings, "Book This Package" reusing
  the existing package->booking flow), new folder icon button in PackageManager (used by Packages/Umrah/Hajj/Tours pages)
- flightService/visaService/hotelService/transportationService: whitelisted the new cost/selling_price/detail columns from Phase 2
  so they actually save (previously only hotels/transportation accepted cost); package->booking now carries cost/selling_price
  into flights and visa too (previously only hotels/transportation/other_services got them)
- Tests: supplierPackage360.test.js (12). Whole suite: 197 pass under the node:sqlite shim.

## Phase 4 changes
- electron/services/bookingDossierService.js (header incl. package snapshot, travellers, flights, hotels, visa, transport,
  ziyarat/other_services, suppliers directory, invoices, payments, advances received/used, outstanding, supplier costs
  ledger, estimated-vs-actual profit, documents, combined timeline+activity, getDossier)
- electron/services/voucherService.js (Hotel Voucher + Transport Voucher HTML generator - a separate simple document type,
  does NOT reuse the invoice template engine, so it can never affect invoice design)
- electron/services/pdfService.js: added a generic `savePdf(html, name, title)`; saveInvoicePdf now calls it (no behaviour change)
- IPC: bookingDossier:get, vouchers:available|hotel:preview|hotel:print|hotel:pdf|transport:preview|transport:print|transport:pdf
  (+ preload api.bookingDossier / api.vouchers)
- src/pages/BookingDossier.jsx (route /bookings/:bookingId/360, 20 tabs: Overview, Customer, Travellers, Package, Flights,
  Visa, Hotels, Transport, Ziyarat, Suppliers, Invoices, Payments, Advances, Outstanding, Supplier Costs, Profit, Documents,
  Vouchers, Timeline & Activity, Notes), "Open Complete Travel Dossier" button in the booking detail drawer
- Vouchers tab lists every hotel/transport row on the booking with Print / Save PDF actions
- Tests: bookingDossier.test.js (17, covers dossier service + voucherService). Whole suite: 214 pass under the node:sqlite shim.

## Phase 5 changes
- schema.sql: two new additive tables - advance_applications (payment_id, invoice_id, amount) and
  supplier_advance_applications (supplier_payment_id, supplier_invoice_id, amount). The source payment/supplier_payment
  row is NEVER edited; these tables are the traceable, re-queryable record of how much of an advance has been allocated
  and where, so one advance can be split across several invoices over time without ever being double counted.
- electron/services/advanceService.js: availableAdvances, applyToInvoice, reverseApplication, applicationsForInvoice,
  summary. Only STANDALONE advances (no booking_id) are offered for manual application - a booking-tied advance is
  already absorbed automatically the moment invoiceService.createFromBooking runs, so offering it again would double
  count it (explicitly guarded against, with a test).
- electron/services/supplierAdvanceService.js: mirrors the above for supplier_payments / supplier_invoices.
- electron/services/ledgerService.js + supplierLedgerService.js: added filteredView() (date range / booking / invoice /
  payment / transaction-type filters, classified per row as Invoice/Advance/Partial/Full/Refund/Payment/Adjustment, with
  opening balance, total debit, total credit, closing balance) and transactionTypes(). list()/getBalance() unchanged.
- electron/services/exportService.js reused (no changes) for Ledger PDF/CSV/Print - CSV stands in for "Excel" until the
  real multi-sheet .xlsx exporter is built in Phase 7.
- electron/services/pdfService.js's generic savePdf() (added in Phase 4) reused for consistency.
- IPC: ledger:filteredView|transactionTypes|exportPdf|exportCsv|print, advances:available|applicationsForInvoice|
  applyToInvoice|reverseApplication|summary, and the supplier-side mirrors (+ preload api.advances / api.supplierAdvances,
  and the extra methods on api.ledger / api.supplierLedger)
- src/pages/Ledger.jsx and SupplierLedger.jsx rebuilt with the filter bar, opening/closing/totals cards, and PDF/Excel/
  Print buttons. src/pages/Invoices.jsx: new "Customer Advance" panel in the invoice drawer (apply/reverse, shows
  available balance per advance). src/pages/SupplierInvoices.jsx: new wallet icon action opening an Apply Supplier
  Advance modal.
- Consistency fix found while building this: customer360Service and supplier360Service's per-booking "paid"/"advance"/
  "payable" figures previously summed only raw payment rows, so an advance applied via the new services wouldn't show up
  there. Both now also add the relevant advance_applications / supplier_advance_applications amounts, with a regression
  test for each (Customer 360 and Supplier 360 bookings tab).
- Tests: advancesLedger.test.js (19, covers advanceService, supplierAdvanceService, both filteredViews, and the
  Customer 360 / Supplier 360 consistency fixes). Whole suite: 233 pass under the node:sqlite shim.

## Phase 6 changes
- schema.sql: two new additive tables - report_history (spec JSON, date range, generated format, related customer/supplier/
  booking, file reference) and report_templates (saved spec JSON for reuse). Neither ever stores a rendered result, only
  the configuration, so "reopen/regenerate" always re-derives fresh numbers.
- electron/services/customReportService.js: the report engine. 9 report types (Customer, Supplier, Booking, Service,
  Financial, Profitability, Travel Operations, Payment, Ledger), each composed from the EXISTING 360/ledger services
  (customer360Service, supplier360Service, bookingDossierService, ledgerService, supplierLedgerService) rather than new
  SQL duplicating their logic - so a Custom Report can never show a different number than the matching 360 dossier.
  Customer/Supplier/Booking reports support an "all / specific / multiple" selection plus a checkbox list of sections to
  include (reusing the same section names as their dossiers). Ledger reports run the existing filteredView per selected
  customer or supplier. Service/Financial/Profitability/Travel-Ops/Payment reports are flat, date-ranged tables.
- electron/services/reportHistoryService.js and reportTemplateService.js: record/list/get/remove, plus
  reportHistoryService.regenerate(id) which re-runs the stored spec through customReportService.run().
- electron/services/exportService.js: added buildMultiSectionReportHtml/exportMultiSectionPdf/printMultiSectionReport -
  one PDF/print document with a title, date-range label, filters summary, one table per section (with its own subtotal
  row), and grand totals, matching the master prompt's "Professional Report Table" spec. The existing single-table
  exportCsv/exportPdf/printReport (used by the pre-existing fixed Reports page) are untouched.
- IPC: customReports:meta|dateFields|sections|run|exportPdf|exportCsv|print, reportHistory:record|list|get|regenerate|
  remove, reportTemplates:create|list|get|remove (+ preload api.customReports / api.reportHistory / api.reportTemplates)
- src/pages/ReportBuilder.jsx (route /custom-reports) and src/pages/ReportHistory.jsx (route /report-history), both
  under the existing 'reports' permission module; new sidebar entries for both. ReportBuilder: report type picker, entity
  selection (all/specific/multiple via the existing customer/supplier search pickers), the existing DateRangeFilter
  component for presets + custom range, section checkboxes with Select All/Unselect All, live preview grouped by record,
  Save as Template / Load Template, and PDF/Print/Excel export (export also logs a Report History entry).
- Known, documented scope limits: Excel export for the Custom Report Builder's multi-section reports (customer/supplier/
  booking/ledger) is CSV-only for flat report types for now - true per-section multi-sheet .xlsx is still Phase 7's job,
  alongside the rest of the Excel work. Reopening a report from History restores its report type, selection mode and
  filters but not its exact historical section checkboxes (resets to that type's full section list) - a minor UI polish
  item, not a data-correctness issue, since regenerate() itself always uses the exact stored spec.
- Tests: customReportBuilder.test.js (16, covers every report type plus history/templates) and 2 new exportService
  tests for the multi-section HTML builder. Whole suite: 250 pass under the node:sqlite shim.

## Phase 7 changes
- electron/services/xlsxWriter.js: a hand-built, ZERO-dependency .xlsx writer (pure Node - just Buffer + the built-in
  zlib.crc32). Why hand-rolled rather than exceljs/xlsx: this build environment has no network access to add and
  actually exercise a new npm dependency, so code built on a library here would be an unverified guess; this writer is
  instead fully testable with Node alone. It builds a real ZIP (STORE method - the report files here are small, so no
  need for a hand-written deflate) containing the standard OOXML spreadsheet parts (Content_Types, workbook.xml,
  relationships, styles.xml, one worksheetN.xml per sheet, inline-string text cells, a money number format). Verified
  three independent ways: a from-scratch test-only ZIP reader (xlsxWriter.test.js, checks every CRC-32 and signature),
  Python's stdlib zipfile.testzip(), and openpyxl actually loading the generated file and reading back every cell value
  correctly (sheet names, numbers, escaped special characters, totals row) - as strong a correctness signal as this
  environment can give short of opening it in real Excel.
- electron/services/excelExportService.js: generic saveWorkbook(sheets, suggestedName) - builds + shows the native save
  dialog, same pattern as pdfService.
- electron/services/exportService.js: buildMultiSectionReportHtml now takes an `orientation` ('portrait'|'landscape',
  default landscape) that sets the PDF's @page size, covering the "A4 Portrait / A4 Landscape" spec bullet.
- IPC: new shared reportExport:exportExcel|exportPdf|print endpoints (generic - take a {sheets}/{reportData} payload,
  used by every page below) alongside the existing customReports:* ones from Phase 6, which still work unchanged.
- Custom Report Builder (ReportBuilder.jsx): the Excel button now produces a REAL multi-sheet workbook instead of CSV,
  for every report type - for Customer/Supplier/Booking reports that means one sheet per section AGGREGATED ACROSS every
  selected record (e.g. one "Bookings" sheet listing every booking from every selected customer, with a leading column
  saying whose), plus a "Summary" sheet - matching the master prompt's Sheet1 Summary / Sheet2 Customers / Sheet3
  Bookings example, with only the sheets relevant to what was actually selected. Ledger reports get a Summary + one
  combined Ledger sheet. This is a deliberately different shape from the PDF/Print export (which keeps the previous
  per-record grouping, better for reading one record's full picture at a time) - both read from the same preview result,
  so the numbers always agree. Added an A4 Portrait/Landscape selector next to the export buttons.
- Ledger.jsx / SupplierLedger.jsx: "Excel" button now saves a real one-sheet .xlsx instead of CSV.
- All four 360 dossiers (CustomerDossier.jsx, SupplierDossier.jsx, BookingDossier.jsx, PackageDossier.jsx) gained
  PDF / Excel / Print buttons in the page header that export the WHOLE dossier (every tab's data, not just the one
  currently open) as one multi-section document / workbook - Customer and Supplier dossiers fetch their tab data fresh
  on export (they load lazily per-tab normally); Booking and Package dossiers already hold everything in memory, so
  their export is instant.
- Tests: xlsxWriter.test.js (7) plus 2 more exportService tests (already counted in Phase 6's total touch point for
  buildMultiSectionReportHtml). Whole suite: 257 pass under the node:sqlite shim.
- Scope note: a literal "PDF preview" pane (spec section 34) was not built as a separate always-visible preview widget -
  the in-app Preview (table view) plus the Print button's native print-preview dialog cover the same need without adding
  a second rendering pipeline. Section 39's deeper accounting statements (Trial Balance, Balance Sheet, General Ledger)
  remain out of scope, as noted in Phase 6 - the Financial Report already covers revenue/cost/expense/profit from real
  transactions, and a full GL system is a materially larger, separate effort.

## Phase 8 changes
- electron/services/dashboardService.js: getStats() gained always-current figures that don't move with the dashboard's
  own date filter (todayPayments, thisMonthSales, thisMonthProfit, pendingPaymentsCount, pendingSupplierPaymentsCount) -
  same idea as the existing cashBalance/bankBalance. New getCalendarEvents(year, month) aggregates real departures,
  arrivals, hotel check-ins/outs, visa expiry, payments and follow-ups for one month, grouped by day.
- src/components/DashboardCalendar.jsx (new): a month-grid calendar on the Dashboard - color-coded dots per event type,
  click a day to see that day's events, click an event to open its real customer/booking dossier. src/pages/Dashboard.jsx:
  added the new stat cards, a "Last Month" filter preset (Today/Week/Month/Last Month/Year/Custom already existed), and
  the calendar widget.
- electron/services/advanceService.js + supplierAdvanceService.js: added listAll() (every standalone advance across
  every customer/supplier, searchable, with available/applied) for two new pages: src/pages/CustomerAdvances.jsx and
  src/pages/SupplierAdvances.jsx (Finance group) - a booking-tied advance still isn't listed here, same reasoning as
  Phase 5 (it's auto-absorbed when its invoice is generated).
- src/pages/ReportTemplates.jsx (new): lists every saved report template (created via the Custom Report Builder's
  "Save as Template"), with Use (reopens it in the builder) and Delete.
- electron/services/documentService.js: list() gained a documentType filter. src/pages/Documents.jsx: added a type
  filter dropdown and reads navState.presetType so sidebar entries can deep-link straight to a filtered view.
- Sidebar reorganised into the spec's 9 groups (Dashboard / CRM / Sales & Bookings / Travel Operations / Finance /
  Reports / Documents / Partners / Administration) in src/utils/navConfig.js - every pre-existing item is still present
  (several relabeled to match the spec's wording, e.g. "Leads" -> "Inquiries", "Ledger" -> "Customer Ledger", or moved
  into a different group - same path/module, so nothing breaks). Added Customer Advances, Supplier Advances and Report
  Templates as real new items; added Agents and Commissions as honest `implemented: false` placeholders (render
  ComingSoon, the same convention the codebase already used before earlier phases built out other pages) since an
  agent/commission-tracking module is materially new functionality outside the original request's scope.
- Reports group entries (Customer/Booking/Service/Financial/Travel Operations Reports) and Documents group entries
  (Tickets/Hotel Vouchers/Visa Documents/Receipts) deep-link into the existing Custom Report Builder / Documents page
  with a preset type, via a new `navState` property on nav items (Sidebar.jsx now passes NavLink `state`), rather than
  building 6+ near-duplicate pages. src/App.jsx's route generation deduplicates by path, since several sidebar entries
  now intentionally share one route.
- Known cosmetic-only quirk: because several Reports/Documents sidebar entries share one path, React Router's NavLink
  highlights all of them as "active" at once while on that page (path-based, blind to navState) - not a functional bug.
- Tests: 3 new dashboardService tests (always-current stats, calendar event grouping, cancelled-booking exclusion) and
  5 new advanceService/supplierAdvanceService listAll tests. Whole suite: 263 pass under the node:sqlite shim.

## Phase 9 changes
- schema.sql: new role_capabilities table - three GLOBAL, cross-module flags (master prompt section 48) distinct from
  the existing per-module view/create/edit/delete matrix: View Profit, View Supplier Costs, Export Reports. Seeded with
  sensible defaults (Admin & Manager: all granted; Staff: none granted) the same way the existing permission matrix
  backfills new modules, so a role never has a missing row.
- electron/services/authService.js: getCapabilitiesForRole/getCapabilitiesMatrix/updateCapability (the last logs an
  audit entry with the old -> new value, only when something actually changed); login() now returns the user's
  capabilities alongside their permissions. Fixed a real pre-existing gap: updatePermission() never wrote an audit log
  at all - it now logs "Permission Changed" with old -> new values for that role/module, again only on an actual change.
- src/context/AuthContext.jsx: new hasCapability(key) helper (fails closed - no user or unknown key = false), alongside
  the existing can(module, action).
- src/pages/StaffUsers.jsx: new "Financial visibility by role" matrix under the existing permissions grid, editable by
  anyone with staff/edit, Admin always shown as fully granted and locked.
- UI gating with hasCapability(): the Profitability section/cards in CustomerDossier, the Service-Cost/Estimated-vs-
  Actual sections in SupplierDossier, the Profit and Supplier Costs tabs (+ their Overview stat cards) in
  BookingDossier, the cost/profit figures and columns in PackageDossier, the 'profit'/'supplier_costs' section
  checkboxes and the 'Financial'/'Profitability' report types in the Custom Report Builder, and the PDF/Excel/Print
  export buttons on all four 360 dossiers, Ledger, Supplier Ledger, the Custom Report Builder, the legacy Reports page
  and Supplier Reports page. A restricted area shows a plain "restricted for your role" notice instead of silently
  vanishing. The Custom Report Builder also strips a restricted section from the actual request sent to the backend
  even if it arrived via a reopened Report History entry or a saved Template from a time the user did have access, and
  blocks a reopened/deep-linked 'financial'/'profitability' report type the same way - so regenerating old reports
  respects the CURRENT user's access, not whoever generated them originally.
- electron/services/reportHistoryService.js: record() now also writes a "Report Generated" audit log entry (master
  prompt section 49 lists this as its own audit event, distinct from the Report History row, which exists so the
  report can be reopened).
- Fixed a sandbox-only blocker as a side effect: harness/run.js (the test runner built for this project, not part of
  the delivered app) now stubs bcryptjs the same way it already stubbed better-sqlite3/electron, so authService.test.js
  - previously unable to even load here - now runs for real. Its 11 pre-existing tests plus a new capabilities describe
  block (6 tests: default grants, login payload, update + audit log, unknown-capability rejection, matrix shape) all
  pass. Also added 2 more tests (one in authService.test.js for updatePermission's new audit logging, one in
  customReportBuilder.test.js for reportHistoryService's new "Report Generated" entry).
- Honest, documented limit: enforcement here is UI-level only, same as every permission check elsewhere in this app
  (see "Known limits" below) - there is no session concept in the main process, so no IPC handler checks who's asking
  server-side. This was already true of the entire existing permission system before this phase; Phase 9 extends the
  same model to the three new capabilities rather than introducing a new gap. Building real server-side enforcement
  would mean threading a session/user identity through every IPC call (~300+ handlers) - a materially larger,
  separate effort flagged here for awareness, not attempted in this pass.
- Whole suite: 276 pass under the node:sqlite shim (backupService.test.js remains unrunnable here - it imports vitest
  directly rather than using the global test functions the rest of the suite relies on, unrelated to this phase).

## Phase 10 changes
Measured, not guessed: a benchmark (sandbox dev tooling, NOT shipped - it relies on the test shim for the SQLite driver) seeds 3,000-10,000 customers / 9,000-30,000
bookings / up to ~60,000 payments straight through SQL and times what this upgrade added. It found real problems, including
one of my own.

**Performance**
- Indexes: supplier_payments(booking_id); supplier_id on flights/hotels/visa_applications/transportation/other_services
  (Supplier 360 unions all five); hotels check_in/check_out; bookings departure/return; supplier_invoices(invoice_date);
  supplier_invoices(supplier_id, invoice_number). Verified with EXPLAIN QUERY PLAN (SCAN -> SEARCH USING INDEX).
- Bug caught by the benchmark and fixed: my first attempt at a plain index on payments(payment_type) made Customer 360 about
  25x SLOWER - 'Advance' is ~a third of all payments, so SQLite chose that low-selectivity index over idx_payments_booking for
  the per-booking advance subqueries. Replaced with a PARTIAL index (only standalone advances) that the advance list queries
  use and nothing else sees. Customer 360 dossier 19.5 ms -> 1.6 ms, advance list 5.1 -> 0.7 ms, a 200-customer report
  8.3 s -> 0.5 s. Single-record views stay flat (1-5 ms) when the data triples.
- The supplier_id indexes live in db.js ensurePostMigrationIndexes(), not schema.sql: that column is added by the additive
  migrations, which run AFTER schema.sql, so an index there fails on a fresh database (caught by the test run).
- dashboardService: month/day filters rewritten from strftime('%Y-%m', col) = ... (forces a full scan) to half-open date
  ranges on the raw column so the existing date indexes are used. Calendar payments are now one summary event per day
  (count + total, refunds excluded) instead of one event per payment.
- advanceService / supplierAdvanceService: removed a per-row SUM query (N+1) in favour of one joined aggregate; listAll now
  filters, counts, totals and pages in SQL instead of loading every advance and slicing in JavaScript.
- customReportService: no longer recomputes Customer/Supplier 360 summaries just for the grand total; the Booking report
  computes only the selected sections instead of all 16 per booking; previewLimit (preview builds the first N records, totals
  stay exact via one SQL aggregate or are omitted, exports are never limited).
- UI: report preview renders a page of records with Show more; leaf tables memoised; Payments/Documents tabs page with
  "Showing X of Y / Load more" instead of silently stopping at 200.
- Measured (10,000 customers / 30,000 bookings / ~60,000 payments): Customer 360 1.6 ms, Booking 360 ~1 ms, Supplier 360
  ~1-5 ms, advance list <1 ms, calendar month ~60 ms, report PREVIEW over ALL 30,000 bookings 73 ms. A full EXPORT over all
  30,000 bookings with 3 sections takes ~4 s - it is synchronous work on the main process, so for very large exports use
  filters/date range. Noted rather than hidden.

**Validation** (new electron/services/validation.js, used by the services)
- Real calendar dates (rejects 2026-02-30), from-date not after to-date, ISO 4217 currency codes (Intl.supportedValuesOf),
  non-negative amounts, and linked records that must exist - with readable messages instead of "FOREIGN KEY constraint failed".
- Supplier invoices: booking must exist, tax >= 0, valid dates, due date not before invoice date. Supplier payments: booking
  must exist. Packages: valid currency. Custom reports: valid date range.

**Duplicate-transaction prevention**
- Customer and supplier payments: the same party + non-blank reference + amount + method (+ type) is a resubmission and is
  rejected with the original payment's number. Blank references are never compared, so two cash instalments of the same
  amount are still allowed. Supplier invoices: one invoice number per supplier (case/space-insensitive); other suppliers may
  reuse a number. The helper index is deliberately NOT unique - an existing database might already hold duplicates and a
  UNIQUE index would stop the app from starting. (Advance double-application was already prevented in Phase 5.)

**Error / loading / retry states**
- New shared pieces: useIpcData, usePagedList, fetchAllPages, ErrorRetry. A failed load now shows the error with a Retry
  instead of turning into an empty list ("No records") on Customer/Supplier dossier tabs, the Booking vouchers tab and the
  Dashboard calendar. The shared hooks ignore a slower, older response arriving after a newer request.
- Exports are complete-or-cancel: Customer/Supplier dossier exports fetch every page (they used to stop at 500 rows
  silently) and cancel with a clear message if any section fails to load, rather than producing a file with a missing section.

**Tests**: validationPhase10.test.js (16: date/currency/range helpers, wiring into the services, duplicate guards), 2 advance
pagination tests, 1 calendar-payments test, previewLimit tests. Whole suite: 299 pass under the node:sqlite shim.
Not covered by automated tests (no React renderer here): the new hooks/components are syntax-checked only.

## Phase 11 - full regression and acceptance (final)
Each check below was also run against deliberately broken code to prove it can fail (mutation testing) - a check that
cannot fail proves nothing. The "caught" notes say what was broken and which check noticed.

**A. Nothing from the original was removed** (compared against the uploaded zip, extracted separately):
all 41 sidebar routes, 281 IPC channels, 281 preload invokes, 285 service functions across 47 service modules, 52 tables,
575 columns, 74 indexes, 46 pages, 18 components - all still present. The upgrade added 62 IPC channels and 5 tables
(role_capabilities, advance_applications, supplier_advance_applications, report_history, report_templates).
`package.json` is byte-identical (no new npm dependency; the xlsx writer is hand-built for that reason).
`backupService.js` is byte-identical to the original. All 172 original tests are still there (3 original test files only
gained lines; zero lines removed from any).

**B. A database from the ORIGINAL application upgrades cleanly** (`electron/services/__tests__/upgradeFromOriginal.test.js`).
fixtures/pre-upgrade/ holds a database exactly as the original code left it (52 tables, 219 rows: customers, a package
booking, invoices with a logo, an advance, a refund, supplier invoices/payments, an expense...) plus what the ORIGINAL services
reported for it. The test replays it, runs the real startup path (initDatabase) and checks: every stored row on every original
column is unchanged (SHA-256 fingerprint per table), no broken foreign keys, every existing invoice renders **byte-for-byte
identically** (logo included), ledger balances unchanged, the five list screens and all 14 legacy reports return the same
values (new fields may be added, none changed or dropped), starting the app again is harmless, and the new modules (Customer/
Booking/Package/Supplier 360, advances, reports, dashboard, calendar, capabilities) work on that old data. Caught: changing the
invoice logo size by 1px, dropping a field from a list screen, altering one report formula.

**C. The 20-point acceptance test of spec 60-A.20** (`acceptance.test.js`, 22 tests): Muhammad Ali, Premium Umrah 15 Days, 4
travellers, one booking with flight + two hotels + visa + transport + ziyarat, each with its supplier; advance + payment;
six supplier invoices and two supplier payments; an expense; then the package master is edited. Every point is asserted with
exact numbers and cross-checked between Customer 360, Booking 360, Package 360, Supplier 360, both ledgers, the legacy reports,
the Custom Report Builder, the dashboard and the calendar. Caught: profit ignoring the booking expense, supplier payable
ignoring payments, Package 360 using estimated instead of actual cost; (booking-tied advance offered for manual application
is caught by the dedicated Phase 5 test instead).

**D. Wiring** (`scripts/check-wiring.js`, shipped - run `node scripts/check-wiring.js` from the project root): all 343 preload
channels have a handler and vice versa; all 297 service calls made by handlers.js exist; all 332 `window.api.x.y()` calls in 78
source files are exposed by preload; all 274 relative imports resolve and their named imports exist; all 173 relative requires
resolve; registerIpcHandlers() registers exactly the 343 declared handlers. These are the bugs that only show up as a blank
screen or "No handler registered" at runtime. Caught: a misspelled service function, a misspelled preload channel, a page
calling a method preload doesn't expose.

**E. Things this phase found and how they were settled**
- The booking number is `BK-000001` (six digits, the application's original numbering); the spec's example reads BK-00001.
  Changing it would renumber every existing booking, so the tests use the real format.
- Editing a package master blanks the optional `package_component_id` pointer on bookings made from it. That is documented,
  long-standing design (components are rebuilt on every edit - see db.js), identical in the original code. Everything that
  matters is unaffected: the booking's frozen `package_snapshot`, its price, and every service's supplier/cost/selling price.
  The acceptance test asserts exactly that, and nothing more.
- Multi-currency: the application has only per-record currency labels and a default currency - no exchange rates - and nothing
  here converts. A customer with bookings in several currencies shows a per-currency breakdown with a warning, and reports
  carry a "not converted" notice, instead of a mixed total under one symbol. (See Known limits for what is not done.)

**How to verify on your machine** (needs `npm install` first; this environment had no network access):
1. `npm test` - expect everything to pass, including `backupService.test.js`, which could not run here.
2. `node scripts/check-wiring.js` - expect "all wiring checks passed".
3. `npm run dev:electron`, then click through, looking for a blank page or error banner:
   Dashboard (calendar + stat cards) -> Customers -> a customer's "Open Complete Travel Dossier" (7 tabs, PDF/Excel/Print) ->
   Suppliers -> folder icon (Supplier 360) -> Packages -> folder icon -> "Book This Package" -> Bookings -> drawer -> dossier
   (20 tabs, Vouchers) -> an invoice drawer (Customer Advance panel) -> Finance > Customer Advances / Supplier Advances ->
   Customer/Supplier Ledger (filters, export) -> Reports > Custom Report Builder (preview, Excel, template) -> Report History ->
   Settings > Branding (logo width/height) then open an invoice PDF -> Staff & Users > Permissions ("Financial visibility").
4. Log in as a Staff-role user: profit/supplier-cost areas and every export button should be replaced by a "restricted" notice.
5. Open an invoice PDF made BEFORE the upgrade and confirm it looks exactly as it did.

## Known limits (be aware)
Honest list of what is NOT done or NOT verified, so nothing is discovered later by surprise.

**Verification gaps**
- The running Electron UI was never launched here (no npm/network access in this environment). The backend is covered by 335
  tests; the UI is syntax-checked and wiring-checked (see Phase 11 D) but never rendered. Use the manual check-list above.
- Tests ran on Node's built-in SQLite through a small driver shim, with bcryptjs stubbed. `backupService.test.js` imports
  `vitest` directly and needs adm-zip, so it could not run here (the file itself is byte-identical to the original).
  The new React hooks/components (useIpcData, usePagedList, ErrorRetry, DashboardCalendar...) have no automated tests.

**Phase 21 - items that were previously listed here as "not built" are now built**
- Agents and Commissions: real modules (Partners group). `agents` / `commissions` tables, `bookings.agent_id`. Choosing an agent on a
  booking creates a Pending commission at the agent's rate (frozen on the row); Pending -> Approved -> Paid. Paying creates a real
  expense (category "Agent Commission") through expenseService, so cash/bank, Profit and the General Ledger all see it. Reversing a
  payment removes that expense. Changing a booking's agent is refused while the old agent has an Approved/Paid commission.
- Exchange rates: Finance > Exchange Rates (admin-entered, history kept, never hard-coded or fetched). Lookup: direct, inverse, or
  cross via the base currency (Settings > Default Currency). Customer 360 now adds a converted total in the base currency for a
  mixed-currency customer; report notices state the converted value; Commissions summary converts too. A currency with no rate is
  left OUT of a converted total and named - never guessed.
- General Ledger, Trial Balance, Balance Sheet (Finance group). The double-entry journal is DERIVED from invoices, payments, refunds,
  supplier bills/payments, expenses, supplier opening balances, bank/cash openings and manual deposits/withdrawals/transfers, so it
  always agrees with those screens and voids/cancels drop out. Tests prove debits = credits, A = L + E, GL = TB per account, and
  bank/cash GL balances = stored account balances. Payments/expenses with no bank/cash account post to "Funds - No Account Selected".
  Manual one-sided Accounting entries post against "Suspense - Manual Entries". Exports: PDF / Excel / Print.
- Server-side permissions: the main process now keeps the signed-in user (sessionService) and every one of the IPC channels goes
  through electron/ipc/accessControl.js before its handler runs (module + view/create/edit/delete from the channel name, plus the
  export_reports / view_profit capabilities). Permissions are re-read on every call, so edits and deactivation apply immediately.
  A test fails if any channel in handlers.js has no rule. New permission modules: exchange_rates, agents, commissions,
  financial_statements (Staff: none; Manager: read-only on exchange rates and statements).

**Behaviour changes caused by enforcing permissions** (these were previously ungated in the UI): a role without Edit can no longer
cancel an invoice, reverse an advance application, rename a document, or set a default invoice template; a role without Ledger
access no longer sees the Ledger tab / Full Ledger button on the customer dossier. Everyday work (adding records, marking tasks
done, converting leads, applying advances) still needs only Create. Settings can be read by every signed-in user (needed app-wide);
bank/cash and agent dropdown lists are readable by anyone who can create the records they feed.

**Phase 21b - the four limits above are now closed**
- Currency on invoices and payments: new `invoices.currency` / `payments.currency`. An invoice takes its booking's currency, a payment
  its invoice's / booking's / account's (electron/services/documentCurrency.js). Old rows are back-filled from their booking at
  startup (only rows still empty; an old payment whose account holds a different currency is left as it was). A payment for a USD
  invoice/booking into a PKR account (or a supplier payment typed in SAR from a USD account) is now REFUSED with an explanation,
  because the account balance would move by the same number in the wrong currency. Supplier payments no longer default to a
  hard-coded 'PKR': they adopt the account's currency, else the supplier's, else the base.
- FX revaluation: at the report date every foreign-currency cash/bank, receivable and payable balance is restated at that date's
  rate, and the difference is shown as "Foreign Exchange Gain / (Loss)" (account 4900, part of Profit). It is recomputed on every
  run, never stored. It includes both unrealised movement on open balances and the realised effect of settling at a different rate
  than booked. Tested: open USD bank (gain and loss), USD invoice settled at a new rate (no receivable left, gain booked),
  balanced and reconciled to the account balances. With no rate on file the balance stays as booked and a warning says so.
- Dossier profit/cost is now removed in the MAIN PROCESS (electron/ipc/redaction.js): without View Profit, cost/profit/margin fields
  in the Customer, Booking and Package dossiers and the customer booking list arrive as null; the Booking dossier's supplier-cost
  ledger needs View Supplier Costs. Revenue/paid/outstanding are untouched. Screens show a dash.
- Global search now drops every result group the user has no View permission for.

**Behaviour changes in 21b**: a payment whose currency conflicts with the chosen bank/cash account is rejected (see above); Staff-type
roles now see a dash instead of cost/profit in the Booking dossier service tabs and the customer booking list.

**Phase 21c - period lock, year-end close, cross-currency payments, previews**
- Period lock / year-end close (Finance > Period Close): a manual lock date, and year-end closes that also post a closing entry
  (revenue/expenses -> Retained Earnings, account 3300). Anything dated on or before the lock cannot be added, changed, voided or
  deleted (payments, invoices, supplier bills/payments, expenses, manual entries, deposits/withdrawals/transfers). A mistake in a
  locked period is fixed with a new entry dated today. Only the newest close can be undone. The lock date and close dates must be
  before today. FX revaluation is restated at every close date, so after a close only the movement since then counts. Admin only
  by default (Financial Statements > Edit); Manager can view.
- Payments in a different currency than the invoice: when a bank/cash account's currency differs from the invoice/booking it
  settles (USD invoice, PKR account) the form asks for the amount that REALLY moved through the account (`payments.received_amount`,
  `supplier_payments.account_amount`). The invoice is settled in its own currency, the account moves by the real amount, and the
  exchange difference is booked to Foreign Exchange Gain / (Loss). Same for refunds and for transfers between accounts of
  different currencies (`to_amount`); a transfer's two legs now post as one entry. Voids give back exactly what moved.
  A supplier payment against a supplier invoice must be in that invoice's currency.
- The customer Payments form now has an optional "Received Into" bank/cash selector. Before this, receipts recorded from the screen
  never reached a bank/cash account (only supplier payments, refunds and expenses could).
- Preview pane: Invoices (drawer > Preview) and the Trial Balance / Balance Sheet / General Ledger open the exact document in a
  full-size in-app pane with Save PDF and Print, before anything is saved.

**Behaviour changes in 21c**: records dated in a locked period are refused (by design); a payment whose invoice/booking currency
differs from the chosen account now asks for the received amount instead of being refused.

**Still not done / honest limits**
- Old payments/supplier payments that were already entered into an account of another currency stay as entered; the Balance Sheet's
  bank/cash reconciliation flags any that no longer add up.
- Revenue is recognised when invoiced; agent commission cost when paid (same as the Profit report).
- The customer ledger and invoice balances are in the invoice's own currency; no single combined customer balance is posted across currencies.
- The new UI pages were compiled (vite build) and wiring-checked but not clicked through in a running Electron window.

**Behaviour worth knowing**
- A full EXPORT over very large selections (e.g. all 30,000 bookings with sections) took ~4 s in the benchmark and runs
  synchronously on the main process; screen previews are bounded and fast. Use filters/date ranges for huge exports.
- Sidebar entries that deep-link into one page (several Reports/Documents entries) all highlight together on that page.
- payments/invoices have no per-row currency column; booking rows use booking -> package -> default currency.
- customers has no city/country columns (address is shown whole); timeline "staff" appears only where the source row records
  a user (quotation creator, follow-up assignee, lead agent).
- Booking numbers stay `BK-000001` (see Phase 11 E).

## Quotation page - full quotation form
Rebuilt the Quotations screen around the 5-section quotation form (basic info, travel details, multi-row services with
optional Umrah fields, pricing & payment terms, validity & status incl. revisions).
- DB (additive, auto-migrated): new `quotations` columns + new `quotation_items` table; old status `Approved` -> `Accepted`.
- All totals (line totals, subtotal, discount, final total, balance, cost, expected profit) are computed in
  `quotationService`, never trusted from the screen. Saving a quotation records no payment.
- Cost price / expected profit need the View Profit capability: hidden in responses (`redaction.js`) and a user without
  it cannot overwrite stored costs. New channels: `quotations:revise`, `quotations:referenceOptions`, `quotations:meta`.
- Tests: 13 new quotation tests in `salesModule.test.js`; full suite 442 passing. UI flow additionally exercised in jsdom
  against the real service. Not verified in a real Electron window.
