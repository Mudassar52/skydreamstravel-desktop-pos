const { getDb } = require('../../src/database/db');

// Package 360: one package, its components, and everything that has been sold
// from it. READ-ONLY, derived from real rows.
//
// "Sold" figures come from BOOKINGS linked by bookings.package_id. A cancelled
// booking is listed but excluded from revenue/collected/outstanding/profit so a
// cancelled sale can never inflate the numbers. Cost per booking is the ACTUAL
// supplier invoices when they exist, else the estimated service costs of that
// booking's own service rows (same rule as Customer 360 - never both).
//
// The master package is left untouched by bookings: each booking has its own
// frozen snapshot, so editing a package later never rewrites past sales.

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

const BOOKING_ROWS = `
  WITH rows AS (
    SELECT bk.id, bk.booking_code, bk.booking_date, bk.status, bk.total_price AS selling, bk.departure_date,
      c.full_name AS customer_name, bk.customer_id,
      (SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.payment_type <> 'Refund'
        AND (p.booking_id = bk.id OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id))) AS paid,
      (SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.payment_type = 'Refund'
        AND (p.booking_id = bk.id OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id))) AS refunded,
      (SELECT COALESCE(SUM(si.total),0) FROM supplier_invoices si WHERE si.booking_id = bk.id) AS cost_actual,
      ((SELECT COALESCE(SUM(cost),0) FROM flights WHERE booking_id = bk.id)
       + (SELECT COALESCE(SUM(cost),0) FROM hotels WHERE booking_id = bk.id)
       + (SELECT COALESCE(SUM(cost),0) FROM visa_applications WHERE booking_id = bk.id)
       + (SELECT COALESCE(SUM(cost),0) FROM transportation WHERE booking_id = bk.id)
       + (SELECT COALESCE(SUM(cost),0) FROM other_services WHERE booking_id = bk.id)) AS cost_estimated
    FROM bookings bk LEFT JOIN customers c ON c.id = bk.customer_id
    WHERE bk.package_id = ?
  )
  SELECT rows.*,
    (paid - refunded) AS net_paid,
    CASE WHEN cost_actual > 0 THEN cost_actual WHEN status = 'Cancelled' THEN 0 ELSE cost_estimated END AS cost
  FROM rows`;

function header(packageId) {
  const db = getDb();
  const p = db.prepare('SELECT * FROM packages WHERE id = ?').get(packageId);
  if (!p) throw new Error('Package not found.');
  const components = db.prepare(
    `SELECT pc.*, s.name AS supplier_name FROM package_components pc
     LEFT JOIN suppliers s ON s.id = pc.supplier_id WHERE pc.package_id = ? ORDER BY pc.id`
  ).all(packageId).map((c) => ({ ...c, cost: round2(c.cost), selling_price: round2(c.selling_price) }));
  const cost = components.reduce((a, c) => a + c.cost, 0);
  const price = Number(p.selling_price || 0);
  return {
    id: p.id, package_name: p.package_name, package_type: p.package_type, destination: p.destination || null,
    duration: p.duration || null, description: p.description || null, departure_date: p.departure_date || null,
    return_date: p.return_date || null, currency: p.currency || 'PKR', status: p.status,
    selling_price: round2(price), components,
    estimated_cost: round2(cost), estimated_profit: round2(price - cost),
    estimated_margin_percent: price > 0 ? round2(((price - cost) / price) * 100) : null
  };
}

function bookings(packageId) {
  const db = getDb();
  if (!db.prepare('SELECT 1 FROM packages WHERE id = ?').get(packageId)) throw new Error('Package not found.');
  return db.prepare(`${BOOKING_ROWS} ORDER BY id DESC`).all(packageId).map((r) => ({
    id: r.id, booking_code: r.booking_code, booking_date: r.booking_date, status: r.status,
    customer_id: r.customer_id, customer_name: r.customer_name, departure_date: r.departure_date,
    selling: round2(r.selling), paid: round2(r.net_paid), outstanding: round2(r.selling - r.net_paid),
    cost: round2(r.cost), profit: round2(r.selling - r.cost)
  }));
}

function summary(packageId) {
  const h = header(packageId);
  const rows = bookings(packageId);
  const live = rows.filter((r) => r.status !== 'Cancelled');
  const sum = (arr, k) => round2(arr.reduce((a, r) => a + r[k], 0));
  const revenue = sum(live, 'selling');
  const cost = sum(live, 'cost');
  return {
    bookings: {
      total: rows.length, active: rows.filter((r) => ['Inquiry', 'Pending', 'Confirmed'].includes(r.status)).length,
      completed: rows.filter((r) => r.status === 'Completed').length, cancelled: rows.filter((r) => r.status === 'Cancelled').length
    },
    sold: {
      revenue, collected: sum(live, 'paid'), outstanding: sum(live, 'outstanding'), cost,
      profit: round2(revenue - cost), margin_percent: revenue > 0 ? round2(((revenue - cost) / revenue) * 100) : null
    },
    list_price: h.selling_price,
    estimated_cost: h.estimated_cost,
    estimated_profit_per_booking: h.estimated_profit,
    // Suppliers named on the package's own components
    suppliers: [...new Set(h.components.map((c) => c.supplier_name).filter(Boolean))]
  };
}

function getDossier(packageId) {
  return { header: header(packageId), summary: summary(packageId), bookings: bookings(packageId) };
}

module.exports = { header, bookings, summary, getDossier };
