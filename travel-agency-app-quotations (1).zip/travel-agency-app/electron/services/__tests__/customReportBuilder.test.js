const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const expenseService = require('../expenseService');
const customReportService = require('../customReportService');
const reportHistoryService = require('../reportHistoryService');
const reportTemplateService = require('../reportTemplateService');

function seed() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  const cust1 = customerService.create({ full_name: 'Ali Raza' }).id;
  const cust2 = customerService.create({ full_name: 'Sana Malik' }).id;
  const sup = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;

  const b1 = bookingService.create({ customer_id: cust1, booking_type: 'Umrah', total_price: 200000, status: 'Confirmed', booking_date: '2026-05-01', departure_date: '2026-06-01' }).id;
  const b2 = bookingService.create({ customer_id: cust2, booking_type: 'Tour', total_price: 50000, status: 'Confirmed', booking_date: '2026-05-15' }).id;

  const db = getDb();
  db.prepare(`INSERT INTO flights (booking_id, airline, cost, selling_price, departure_date) VALUES (?, 'PIA', 60000, 80000, '2026-06-01')`).run(b1);
  db.prepare(`INSERT INTO hotels (booking_id, hotel_name, supplier_id, cost, selling_price, check_in) VALUES (?, 'Swissotel', ?, 40000, 55000, '2026-06-02')`).run(b1, sup);

  const inv1 = invoiceService.create({ customer_id: cust1, booking_id: b1, invoice_date: '2026-05-02', items: [{ description: 'Umrah', quantity: 1, unit_price: 200000 }] }).id;
  paymentService.create({ customer_id: cust1, invoice_id: inv1, amount: 100000, payment_date: '2026-05-03', payment_method: 'Cash', payment_type: 'Partial' });

  supplierInvoiceService.create({ supplier_id: sup, booking_id: b1, invoice_number: 'H-1', invoice_date: '2026-05-04', amount: 40000 });

  const cat = expenseService.listCategories()[0];
  expenseService.create({ category_id: cat.id, expense_date: '2026-05-05', amount: 5000, related_booking_id: b1 });

  return { cust1, cust2, sup, b1, b2, inv1 };
}

describe('customReportService metadata', () => {
  it('lists report types, date fields, sections, service types and ops types', () => {
    freshDb();
    expect(customReportService.listReportTypes().map((t) => t.key)).toEqual([
      'customer', 'supplier', 'booking', 'service', 'financial', 'profitability', 'travel_ops', 'payment', 'ledger'
    ]);
    expect(customReportService.listDateFields('customer').length).toBeGreaterThan(0);
    expect(customReportService.listSections('customer')).toContain('flights');
    expect(customReportService.listServiceTypes()).toContain('Ziyarat');
    expect(customReportService.listTravelOpsTypes()).toContain('Visa Expiry');
  });
});

describe('customReportService.run - customer report', () => {
  it('builds selected sections per selected customer from real data, and grand totals', () => {
    const { cust1 } = seed();
    const res = customReportService.run({
      reportType: 'customer', selection: { mode: 'specific', ids: [cust1] },
      sections: ['customer_info', 'bookings', 'flights', 'invoices', 'payments']
    });
    expect(res.records).toHaveLength(1);
    const rec = res.records[0];
    expect(rec.customer.full_name).toBe('Ali Raza');
    expect(rec.sections.bookings).toHaveLength(1);
    expect(rec.sections.flights).toHaveLength(1);
    expect(rec.sections.flights[0].cost).toBe(60000);
    expect(rec.sections.invoices).toHaveLength(1);
    expect(rec.sections.payments).toHaveLength(1);
    expect(res.grandTotals.total_billed).toBe(200000);
  });

  it('"all" selection includes every customer; date range (on departure date) narrows bookings included', () => {
    seed();
    const res = customReportService.run({
      reportType: 'customer', selection: { mode: 'all' }, sections: ['bookings'],
      dateField: 'departure_date', dateFrom: '2026-05-25', dateTo: '2026-06-15'
    });
    expect(res.records).toHaveLength(2);
    const ali = res.records.find((r) => r.customer.full_name === 'Ali Raza');
    const sana = res.records.find((r) => r.customer.full_name === 'Sana Malik');
    expect(ali.sections.bookings).toHaveLength(1); // b1 departs 2026-06-01, inside the range
    expect(sana.sections.bookings).toHaveLength(0); // b2 has no departure date set
  });
});

describe('customReportService.run - supplier report', () => {
  it('builds supplier sections from real supplier data', () => {
    const { sup } = seed();
    const res = customReportService.run({ reportType: 'supplier', selection: { mode: 'specific', ids: [sup] }, sections: ['supplier_info', 'services', 'invoices', 'payable'] });
    expect(res.records).toHaveLength(1);
    expect(res.records[0].sections.services).toHaveLength(1);
    expect(res.records[0].sections.invoices).toHaveLength(1);
    expect(res.records[0].sections.payable.payable).toBe(40000);
  });
});

describe('customReportService.run - booking report', () => {
  it('filters by customer, status and service type, and composes selected sections', () => {
    const { b1 } = seed();
    const res = customReportService.run({ reportType: 'booking', selection: { mode: 'all' }, serviceType: 'Flight', sections: ['booking_info', 'flights', 'profit'] });
    expect(res.records).toHaveLength(1);
    expect(res.records[0].booking.id).toBe(b1);
    expect(res.records[0].sections.flights).toHaveLength(1);
    expect(res.records[0].sections.profit.actual_supplier_cost).toBe(40000);
  });

  it('returns nothing for a service type with no matching bookings', () => {
    seed();
    const res = customReportService.run({ reportType: 'booking', selection: { mode: 'all' }, serviceType: 'Visa', sections: ['booking_info'] });
    expect(res.records).toHaveLength(0);
  });
});

describe('customReportService.run - service report', () => {
  it('aggregates count/purchase/sales/profit per service type within date range', () => {
    seed();
    const res = customReportService.run({ reportType: 'service', serviceTypes: ['Flight', 'Hotel'], dateFrom: '2026-01-01', dateTo: '2026-12-31' });
    const flight = res.rows.find((r) => r.service_type === 'Flight');
    const hotel = res.rows.find((r) => r.service_type === 'Hotel');
    expect(flight).toEqual({ service_type: 'Flight', count: 1, purchase: 60000, sales: 80000, profit: 20000 });
    expect(hotel.profit).toBe(15000);
    expect(res.grandTotals.profit).toBe(35000);
  });
});

describe('customReportService.run - financial report', () => {
  it('computes revenue, supplier cost, expenses and gross profit from real transactions', () => {
    seed();
    const res = customReportService.run({ reportType: 'financial' });
    const line = (name) => res.rows.find((r) => r.line === name).amount;
    expect(line('Revenue (Invoiced)')).toBe(200000);
    expect(line('Supplier Cost (Invoiced)')).toBe(40000);
    expect(line('Operating Expenses')).toBe(5000);
    expect(res.grandTotals.gross_profit).toBe(155000);
  });
});

describe('customReportService.run - profitability report', () => {
  it('lists per-booking selling/cost/profit/margin using actual supplier cost when available', () => {
    const { b1, b2 } = seed();
    const res = customReportService.run({ reportType: 'profitability' });
    const r1 = res.rows.find((r) => r.booking_code && r.customer_name === 'Ali Raza');
    expect(r1.selling).toBe(200000);
    expect(r1.cost).toBe(40000); // actual supplier invoice, not the 100,000 estimate
    expect(r1.profit).toBe(160000);
    const r2 = res.rows.find((r) => r.customer_name === 'Sana Malik');
    expect(r2.cost).toBe(0);
    void b1; void b2;
  });
});

describe('customReportService.run - travel ops report', () => {
  it('lists upcoming departures and visa expiry with date filters', () => {
    const { b1 } = seed();
    const dep = customReportService.run({ reportType: 'travel_ops', opsType: 'Upcoming Departures', dateFrom: '2026-06-01', dateTo: '2026-06-30' });
    expect(dep.rows).toHaveLength(1);
    expect(dep.rows[0].booking_code).toBeTruthy();
    void b1;
  });
});

describe('customReportService.run - payment report', () => {
  it('filters by customer and payment type', () => {
    const { cust1 } = seed();
    const res = customReportService.run({ reportType: 'payment', customerId: cust1 });
    expect(res.rows).toHaveLength(1);
    expect(res.grandTotals.total).toBe(100000);
  });
});

describe('customReportService.run - ledger report', () => {
  it('builds a ledger section per selected customer', () => {
    const { cust1 } = seed();
    const res = customReportService.run({ reportType: 'ledger', entityType: 'customer', selection: { mode: 'specific', ids: [cust1] } });
    expect(res.records).toHaveLength(1);
    expect(res.records[0].view.entries.length).toBeGreaterThan(0);
  });
});

describe('reportHistoryService', () => {
  it('records, lists, gets and regenerates a report spec', () => {
    const { cust1 } = seed();
    const spec = { reportType: 'customer', selection: { mode: 'specific', ids: [cust1] }, sections: ['customer_info'] };
    const rec = reportHistoryService.record({ reportName: 'Ali Complete Report', reportType: 'customer', spec, relatedCustomerId: cust1, generatedFormat: 'PDF' });
    const list = reportHistoryService.list({});
    expect(list.total).toBe(1);
    expect(list.rows[0].customer_name).toBe('Ali Raza');
    const got = reportHistoryService.get(rec.id);
    expect(got.spec.reportType).toBe('customer');
    const regen = reportHistoryService.regenerate(rec.id);
    expect(regen.result.records[0].customer.full_name).toBe('Ali Raza');
  });

  it('recording a report also writes a "Report Generated" audit log entry (master prompt section 49)', () => {
    freshDb();
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    reportHistoryService.record({ reportName: 'Monthly Sales', reportType: 'financial', spec: { reportType: 'financial' }, generatedFormat: 'PDF' });
    const logs = db.prepare(`SELECT * FROM audit_logs WHERE action = 'Report Generated'`).all();
    expect(logs).toHaveLength(1);
    expect(logs[0].description).toContain('Monthly Sales');
    expect(logs[0].description).toContain('PDF');
  });

  it('deleting a missing entry throws; filters by type and search', () => {
    seed();
    expect(() => reportHistoryService.remove(999)).toThrow(/not found/i);
    reportHistoryService.record({ reportName: 'Supplier X', reportType: 'supplier', spec: { reportType: 'supplier' } });
    reportHistoryService.record({ reportName: 'Customer Y', reportType: 'customer', spec: { reportType: 'customer' } });
    expect(reportHistoryService.list({ reportType: 'supplier' }).total).toBe(1);
    expect(reportHistoryService.list({ search: 'Customer' }).total).toBe(1);
  });
});

describe('reportTemplateService', () => {
  it('creates, lists, gets and deletes templates', () => {
    freshDb();
    const spec = { reportType: 'customer', sections: ['customer_info', 'bookings', 'flights'] };
    const t = reportTemplateService.create({ name: 'Customer Complete Travel Report', reportType: 'customer', spec });
    expect(reportTemplateService.list().find((x) => x.id === t.id).name).toBe('Customer Complete Travel Report');
    expect(reportTemplateService.get(t.id).spec.sections).toContain('flights');
    expect(reportTemplateService.list('customer')).toHaveLength(1);
    expect(reportTemplateService.list('supplier')).toHaveLength(0);
    reportTemplateService.remove(t.id);
    expect(() => reportTemplateService.get(t.id)).toThrow(/not found/i);
  });

  it('requires a name and a report type', () => {
    freshDb();
    expect(() => reportTemplateService.create({ name: '', reportType: 'customer', spec: {} })).toThrow(/name/i);
    expect(() => reportTemplateService.create({ name: 'X', reportType: '', spec: {} })).toThrow(/type/i);
  });
});

describe('previewLimit (Phase 10): bounded previews, never a truncated export', () => {
  function seedMany() {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    const sup = supplierService.create({ name: 'Hilton', service_type: 'Hotel' }).id;
    const custs = [];
    for (let i = 1; i <= 6; i++) {
      const c = customerService.create({ full_name: `Cust ${i}` }).id;
      custs.push(c);
      const b = bookingService.create({ customer_id: c, booking_type: 'Tour', total_price: i * 1000 }).id;
      invoiceService.create({ customer_id: c, booking_id: b, items: [{ description: 'T', quantity: 1, unit_price: i * 1000 }] });
      supplierInvoiceService.create({ supplier_id: sup, booking_id: b, invoice_number: `S-${i}`, amount: i * 100 });
    }
    return { custs, sup };
  }

  it('customer report: only the limited records are built, but total_billed still covers ALL of them', () => {
    seedMany();
    const full = customReportService.run({ reportType: 'customer', selection: { mode: 'all' }, sections: ['customer_info'] });
    const preview = customReportService.run({ reportType: 'customer', selection: { mode: 'all' }, sections: ['customer_info'], previewLimit: 2 });
    expect(full.records).toHaveLength(6);
    expect(full.truncated).toBeNull();
    expect(preview.records).toHaveLength(2);
    expect(preview.truncated).toEqual({ shown: 2, total: 6 });
    expect(preview.grandTotals.total_billed).toBe(21000);           // 1k+2k+...+6k, over all six
    expect(preview.grandTotals.total_billed).toBe(full.grandTotals.total_billed);
  });

  it('booking report: truncated preview keeps an exact total_selling and drops total_profit instead of showing a partial sum', () => {
    seedMany();
    const full = customReportService.run({ reportType: 'booking', selection: { mode: 'all' }, sections: ['booking_info', 'profit'] });
    const preview = customReportService.run({ reportType: 'booking', selection: { mode: 'all' }, sections: ['booking_info', 'profit'], previewLimit: 3 });
    expect(preview.records).toHaveLength(3);
    expect(preview.truncated.total).toBe(6);
    expect(preview.grandTotals.total_selling).toBe(full.grandTotals.total_selling);
    expect(preview.grandTotals).not.toHaveProperty('total_profit');
    expect(full.grandTotals).toHaveProperty('total_profit');
  });

  it('supplier report: truncated preview keeps total_payable over every selected supplier', () => {
    const { sup } = seedMany();
    const sup2 = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    supplierInvoiceService.create({ supplier_id: sup2, invoice_number: 'P-1', amount: 5000 });
    const full = customReportService.run({ reportType: 'supplier', selection: { mode: 'all' }, sections: ['supplier_info'] });
    const preview = customReportService.run({ reportType: 'supplier', selection: { mode: 'all' }, sections: ['supplier_info'], previewLimit: 1 });
    expect(preview.records).toHaveLength(1);
    expect(preview.truncated).toEqual({ shown: 1, total: 2 });
    expect(preview.grandTotals.total_payable).toBe(full.grandTotals.total_payable);
    void sup;
  });

  it('a limit larger than the selection, or no limit, is not truncated', () => {
    seedMany();
    expect(customReportService.run({ reportType: 'customer', selection: { mode: 'all' }, sections: ['customer_info'], previewLimit: 100 }).truncated).toBeNull();
    expect(customReportService.run({ reportType: 'customer', selection: { mode: 'all' }, sections: ['customer_info'] }).records).toHaveLength(6);
  });
});

describe('customReportService currency notice (Phase 11)', () => {
  it('adds a "not converted" notice only when live bookings span more than one currency', () => {
    freshDb();
    const packageService = require('../packageService');
    const cust = customerService.create({ full_name: 'Currency Notice' }).id;
    bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 1000 });
    expect(customReportService.run({ reportType: 'financial' }).currencyNotice).toBeNull();

    const sar = packageService.create({ package_name: 'SAR Pkg', package_type: 'Umrah', selling_price: 500, currency: 'SAR', components: [{ component_type: 'Flight', description: 'x', cost: 1, selling_price: 1 }] }).id;
    bookingService.create({ customer_id: cust, package_id: sar });
    const notice = customReportService.run({ reportType: 'financial' }).currencyNotice;
    expect(notice).toContain('PKR');
    expect(notice).toContain('SAR');
    expect(notice).toMatch(/NOT converted/);
  });
});
