const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const reportService = require('../reportService');
const exportService = require('../exportService');

describe('reportService', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Zainab Tariq' }).id;
  });

  it('lists all 14 report types', () => {
    expect(reportService.listReportTypes()).toHaveLength(14);
  });

  it('runs every report type without throwing on an empty database', () => {
    for (const { key } of reportService.listReportTypes()) {
      expect(() => reportService.run(key, {})).not.toThrow();
    }
  });

  it('the sales report filters correctly by customer', () => {
    invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    const other = customerService.create({ full_name: 'Other Customer' }).id;
    invoiceService.create({ customer_id: other, items: [{ description: 'Y', quantity: 1, unit_price: 20000 }] });

    expect(reportService.run('sales', {}).rows).toHaveLength(2);
    expect(reportService.run('sales', { customerId: cust }).rows).toHaveLength(1);
  });

  it('the outstanding report only includes invoices with a balance due', () => {
    invoiceService.create({ customer_id: cust, paid_amount: 10000, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] }); // fully paid
    invoiceService.create({ customer_id: cust, items: [{ description: 'Y', quantity: 1, unit_price: 20000 }] }); // unpaid

    const outstanding = reportService.run('outstanding', {});
    expect(outstanding.rows).toHaveLength(1);
    expect(outstanding.totals.remaining_amount).toBe(20000);
  });

  it('the customer ledger report switches between all-customers summary and per-customer detail', () => {
    invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    const summary = reportService.run('ledger', {});
    expect(summary.columns.map((c) => c.key)).toEqual(['customer', 'balance']);

    const detail = reportService.run('ledger', { customerId: cust });
    expect(detail.columns.map((c) => c.key)).toContain('running_balance');
    expect(detail.rows.length).toBeGreaterThan(0);
  });
});

describe('exportService', () => {
  it('escapes commas, quotes, and newlines correctly', () => {
    const report = {
      columns: [{ key: 'a', label: 'A' }, { key: 'b', label: 'B' }],
      rows: [{ a: 'He said "hi", bye', b: 5 }, { a: 'line1\nline2', b: 10 }]
    };
    const csv = exportService.toCsv(report);
    expect(csv).toContain('"He said ""hi"", bye"');
    expect(csv).toContain('"line1\nline2"');
  });

  it('builds valid HTML with the title and formatted money columns', () => {
    const report = {
      title: 'Test Report',
      columns: [{ key: 'amount', label: 'Amount', money: true }],
      rows: [{ amount: 50000 }],
      totals: { amount: 50000 }
    };
    const html = exportService.buildReportHtml(report);
    expect(html).toContain('Test Report');
    expect(html).toContain('Rs. 50,000');
  });

  it('builds a multi-section report with per-section totals, an empty-section notice, and grand totals', () => {
    const html = exportService.buildMultiSectionReportHtml({
      title: 'Customer Report',
      dateRangeLabel: '2026-01-01 to 2026-01-31',
      filtersSummary: '2 customers selected',
      sections: [
        { title: 'Bookings', columns: [{ key: 'selling', label: 'Selling', money: true }], rows: [{ selling: 100000 }], totals: { selling: 100000 } },
        { title: 'Documents', columns: [{ key: 'file_name', label: 'File' }], rows: [] }
      ],
      grandTotals: { total_billed: 100000 }
    });
    expect(html).toContain('Customer Report');
    expect(html).toContain('2026-01-01 to 2026-01-31');
    expect(html).toContain('2 customers selected');
    expect(html).toContain('Bookings');
    expect(html).toContain('Rs. 100,000');
    expect(html).toContain('No records.');
    expect(html).toContain('total_billed');
  });
});
