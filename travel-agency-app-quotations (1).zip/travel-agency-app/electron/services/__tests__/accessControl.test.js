const fs = require('fs');
const path = require('path');
const { freshDb } = require('./testUtils');
const authService = require('../authService');
const sessionService = require('../sessionService');
const ac = require('../../ipc/accessControl');
const { getDb } = require('../../../src/database/db');

function userFor(roleName) {
  const db = getDb();
  const role = db.prepare('SELECT id FROM roles WHERE name = ?').get(roleName);
  const username = `u_${roleName}`;
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  const id = existing ? existing.id : authService.createUser({ fullName: roleName, username, password: 'secret12', roleId: role.id }).id;
  sessionService.signIn(id);
  return sessionService.current();
}
const deny = (ch, user, args = []) => ac.authorize(ch, args, user);

describe('accessControl', () => {
  beforeEach(() => { freshDb(); authService.ensureDefaults(); sessionService.signOut(); });

  it('every IPC channel registered in handlers.js has a rule (nothing is silently open or unmapped)', () => {
    const src = fs.readFileSync(path.join(__dirname, '../../ipc/handlers.js'), 'utf8');
    const channels = [...src.matchAll(/ipcMain\.handle\('([^']+)'/g)].map((m) => m[1]);
    expect(channels.length).toBeGreaterThan(300);
    const sample = ['Bank', 1, { account_type: 'Bank', from_type: 'Bank', to_type: 'Cash' }];
    const unmapped = channels.filter((c) => ac.requirementFor(c, sample) === null);
    expect(unmapped).toEqual([]);
  });

  it('nobody signed in: everything except login is refused', () => {
    expect(deny('auth:login', null)).toBeNull();
    expect(deny('customers:list', null)).toMatch(/sign in again/i);
    expect(deny('settings:getAll', null)).toMatch(/sign in again/i);
  });

  it('an unknown channel is refused, never open', () => {
    const admin = userFor('Admin');
    expect(deny('madeUp:thing', admin)).toMatch(/not configured/);
  });

  it('Admin can do everything, including the new modules', () => {
    const admin = userFor('Admin');
    for (const ch of ['payments:void', 'commissions:pay', 'exchangeRates:create', 'financialStatements:trialBalance', 'users:create', 'backup:restore', 'customers:delete']) {
      expect(deny(ch, admin)).toBeNull();
    }
  });

  it('Staff: day-to-day work yes; money, admin and exports no', () => {
    const staff = userFor('Staff');
    expect(deny('customers:create', staff)).toBeNull();
    expect(deny('bookings:list', staff)).toBeNull();
    expect(deny('tasks:markStatus', staff)).toBeNull();
    expect(deny('umrah:groups:passengers:add', staff)).toBeNull();
    expect(deny('settings:getAll', staff)).toBeNull();
    expect(deny('bankAccounts:list', staff)).toBeNull();          // feeds the payment form
    expect(deny('agents:options', staff)).toBeNull();             // feeds the booking form
    expect(deny('customers:update', staff)).toMatch(/permission to change Customers/);
    expect(deny('customers:delete', staff)).toMatch(/delete from Customers/);
    expect(deny('payments:void', staff)).toMatch(/permission/);
    expect(deny('ledger:list', staff)).toMatch(/view Ledger/);
    expect(deny('users:list', staff)).toMatch(/permission/);
    expect(deny('settings:setMany', staff)).toMatch(/permission/);
    expect(deny('backup:create', staff)).toMatch(/permission/);
    expect(deny('commissions:list', staff)).toMatch(/permission/);
    expect(deny('exchangeRates:list', staff)).toMatch(/permission/);
    expect(deny('financialStatements:balanceSheet', staff)).toMatch(/permission/);
    expect(deny('accounts:deposit', staff, [{ account_type: 'Cash', account_id: 1, amount: 5 }])).toMatch(/permission/);
    expect(deny('profit:getSummary', staff)).toMatch(/profit/i);
    expect(deny('reportExport:exportExcel', staff)).toMatch(/not allowed to export/i);
    expect(deny('supplierReports:exportPdf', staff)).toMatch(/not allowed to export/i);
  });

  it('Manager: operations yes, delete / admin no, read-only on the new finance modules', () => {
    const m = userFor('Manager');
    expect(deny('customers:update', m)).toBeNull();
    expect(deny('customers:delete', m)).toMatch(/permission/);
    expect(deny('payments:void', m)).toMatch(/permission/);
    expect(deny('reportHistory:remove', m)).toBeNull();
    expect(deny('financialStatements:trialBalance', m)).toBeNull();
    expect(deny('exchangeRates:list', m)).toBeNull();
    expect(deny('exchangeRates:create', m)).toMatch(/permission/);
    expect(deny('financialStatements:exportPdf', m)).toBeNull(); // Manager has export_reports by default
    expect(deny('users:create', m)).toMatch(/permission/);
    expect(deny('backup:restore', m)).toMatch(/permission/);
  });

  it('period lock: viewing is a read, closing/locking/undoing needs Edit on Financial Statements (Admin only by default)', () => {
    const admin = userFor('Admin');
    const manager = userFor('Manager');
    const staff = userFor('Staff');
    for (const ch of ['periodLock:setManualLock', 'periodLock:closeYear', 'periodLock:reopenLastClose']) {
      expect(deny(ch, admin)).toBeNull();
      expect(deny(ch, manager)).toMatch(/permission to change Financial Statements/);
      expect(deny(ch, staff)).toMatch(/permission/);
    }
    expect(deny('periodLock:status', manager)).toBeNull();
    expect(deny('periodLock:status', staff)).toMatch(/permission/);
    expect(deny('invoices:preview', staff)).toBeNull();
    expect(deny('financialStatements:preview', staff)).toMatch(/permission/);
  });

  it('accounts:* depends on whether the account is Bank or Cash, and a transfer needs both', () => {
    const db = getDb();
    const staffRole = db.prepare("SELECT id FROM roles WHERE name = 'Staff'").get().id;
    authService.updatePermission({ roleId: staffRole, module: 'cash_accounts', can_view: 1, can_create: 1, can_edit: 1, can_delete: 0 });
    const staff = userFor('Staff');
    expect(deny('accounts:deposit', staff, [{ account_type: 'Cash', account_id: 1, amount: 5 }])).toBeNull();
    expect(deny('accounts:deposit', staff, [{ account_type: 'Bank', account_id: 1, amount: 5 }])).toMatch(/Bank Accounts/);
    expect(deny('accounts:transfer', staff, [{ from_type: 'Cash', to_type: 'Bank' }])).toMatch(/Bank Accounts/);
    expect(deny('accounts:create', staff, ['Cash', {}])).toBeNull();
    expect(deny('accounts:create', staff, ['Nonsense', {}])).toMatch(/not understood/);
  });

  it('permission edits and account deactivation take effect on the very next call', () => {
    const db = getDb();
    const staffRole = db.prepare("SELECT id FROM roles WHERE name = 'Staff'").get().id;
    let staff = userFor('Staff');
    expect(deny('customers:update', staff)).toMatch(/permission/);
    authService.updatePermission({ roleId: staffRole, module: 'customers', can_view: 1, can_create: 1, can_edit: 1, can_delete: 0 });
    staff = sessionService.current();
    expect(deny('customers:update', staff)).toBeNull();
    db.prepare("UPDATE users SET is_active = 0 WHERE username = 'u_Staff'").run();
    expect(sessionService.current()).toBeNull();
    expect(deny('customers:list', sessionService.current())).toMatch(/sign in again/i);
  });

  it('signOut ends the session', () => {
    userFor('Admin');
    expect(sessionService.current()).not.toBeNull();
    sessionService.signOut();
    expect(sessionService.current()).toBeNull();
  });
});
