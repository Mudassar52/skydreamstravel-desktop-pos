const { freshDb } = require('./testUtils');
const validation = require('../validation');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const packageService = require('../packageService');
const customReportService = require('../customReportService');

describe('validation helpers', () => {
  it('isValidDate accepts real dates (with optional time) and rejects impossible/garbled ones', () => {
    expect(validation.isValidDate('2026-02-28')).toBe(true);
    expect(validation.isValidDate('2026-02-28 10:30:00')).toBe(true);
    expect(validation.isValidDate('2024-02-29')).toBe(true);   // leap year
    expect(validation.isValidDate('2026-02-30')).toBe(false);  // no such day
    expect(validation.isValidDate('2026-13-01')).toBe(false);
    expect(validation.isValidDate('26-02-01')).toBe(false);
    expect(validation.isValidDate('not a date')).toBe(false);
    expect(validation.isValidDate(null)).toBe(false);
  });

  it('assertValidDate treats blank as fine but rejects junk with a useful message', () => {
    expect(() => validation.assertValidDate('', 'Due date')).not.toThrow();
    expect(() => validation.assertValidDate(null, 'Due date')).not.toThrow();
    expect(() => validation.assertValidDate('2026-02-30', 'Due date')).toThrow(/Due date is not a valid date/);
  });

  it('assertDateRange rejects from-after-to but allows equal, open-ended and blank ranges', () => {
    expect(() => validation.assertDateRange('2026-05-10', '2026-05-01')).toThrow(/cannot be after/i);
    expect(() => validation.assertDateRange('2026-05-01', '2026-05-01')).not.toThrow();
    expect(() => validation.assertDateRange('2026-05-01', '')).not.toThrow();
    expect(() => validation.assertDateRange('', '')).not.toThrow();
    expect(() => validation.assertDateRange('2026-05-01 00:00:00', '2026-05-01 23:59:59')).not.toThrow();
  });

  it('assertValidCurrency accepts real ISO codes (any case), blank, and rejects made-up ones', () => {
    expect(() => validation.assertValidCurrency('PKR')).not.toThrow();
    expect(() => validation.assertValidCurrency('usd')).not.toThrow();
    expect(() => validation.assertValidCurrency('')).not.toThrow();
    expect(() => validation.assertValidCurrency('ABC')).toThrow(/not a valid currency/i);
    expect(() => validation.assertValidCurrency('RUPEES')).toThrow(/not a valid currency/i);
  });

  it('assertNonNegative / assertRecordExists', () => {
    freshDb();
    expect(() => validation.assertNonNegative(0, 'Tax')).not.toThrow();
    expect(() => validation.assertNonNegative('', 'Tax')).not.toThrow();
    expect(() => validation.assertNonNegative(-1, 'Tax')).toThrow(/Tax must be zero or greater/);
    expect(() => validation.assertNonNegative('abc', 'Tax')).toThrow(/Tax must be zero or greater/);
    expect(() => validation.assertRecordExists('bookings', null, 'booking')).not.toThrow();
    expect(() => validation.assertRecordExists('bookings', 99999, 'booking')).toThrow(/Selected booking does not exist/);
  });
});

describe('Phase 10 validation wired into the services', () => {
  function seed() {
    freshDb();
    const supplier = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
    const customer = customerService.create({ full_name: 'Test Customer' }).id;
    const booking = bookingService.create({ customer_id: customer, booking_type: 'Tour', total_price: 1000 }).id;
    return { supplier, booking };
  }

  it('supplier invoice: rejects a non-existent booking with a useful message (not a raw FK error)', () => {
    const { supplier } = seed();
    expect(() => supplierInvoiceService.create({ supplier_id: supplier, booking_id: 99999, invoice_number: 'X-1', amount: 100 }))
      .toThrow(/Selected booking does not exist/);
  });

  it('supplier invoice: rejects negative tax and a due date before the invoice date', () => {
    const { supplier } = seed();
    expect(() => supplierInvoiceService.create({ supplier_id: supplier, invoice_number: 'X-2', amount: 100, tax: -5 })).toThrow(/Tax must be zero or greater/);
    expect(() => supplierInvoiceService.create({ supplier_id: supplier, invoice_number: 'X-3', amount: 100, invoice_date: '2026-05-10', due_date: '2026-05-01' }))
      .toThrow(/Due date cannot be before the invoice date/);
    expect(() => supplierInvoiceService.create({ supplier_id: supplier, invoice_number: 'X-4', amount: 100, invoice_date: '2026-02-30' })).toThrow(/not a valid date/);
  });

  it('supplier invoice: a valid one linked to a real booking still saves', () => {
    const { supplier, booking } = seed();
    const inv = supplierInvoiceService.create({ supplier_id: supplier, booking_id: booking, invoice_number: 'OK-1', amount: 250, tax: 0, invoice_date: '2026-05-01', due_date: '2026-05-30' });
    expect(inv.id).toBeTruthy();
  });

  it('supplier payment: rejects a non-existent booking with a useful message', () => {
    const { supplier } = seed();
    expect(() => supplierPaymentService.create({ supplier_id: supplier, booking_id: 99999, amount: 100, payment_method: 'Cash' }))
      .toThrow(/Selected booking does not exist/);
  });

  it('package: rejects an invalid currency code, accepts a real one', () => {
    freshDb();
    const base = { package_name: 'P', package_type: 'Umrah', selling_price: 100, components: [{ component_type: 'Flight', description: 'x', cost: 1, selling_price: 2 }] };
    expect(() => packageService.create({ ...base, currency: 'ZZZ' })).toThrow(/not a valid currency/i);
    expect(packageService.create({ ...base, currency: 'SAR' }).id).toBeTruthy();
  });

  it('custom report: rejects a from-date after the to-date for any report type', () => {
    freshDb();
    expect(() => customReportService.run({ reportType: 'financial', dateFrom: '2026-06-01', dateTo: '2026-05-01' })).toThrow(/cannot be after/i);
    expect(() => customReportService.run({ reportType: 'payment', dateFrom: '2026-13-01' })).toThrow(/not a valid date/i);
    expect(() => customReportService.run({ reportType: 'financial', dateFrom: '2026-05-01', dateTo: '2026-06-01' })).not.toThrow();
  });
});

describe('duplicate-transaction prevention (Phase 10)', () => {
  const paymentService = require('../paymentService');
  const invoiceTemplateService = require('../invoiceTemplateService');

  function seedCustomer() {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    return customerService.create({ full_name: 'Dup Test' }).id;
  }

  it('rejects the same customer payment resubmitted with the same reference, amount, method and type', () => {
    const cust = seedCustomer();
    const base = { customer_id: cust, amount: 5000, payment_method: 'Bank Transfer', payment_type: 'Advance', reference: 'TXN-8841' };
    paymentService.create(base);
    expect(() => paymentService.create(base)).toThrow(/already recorded/i);
    expect(() => paymentService.create({ ...base, reference: ' txn-8841 ' })).toThrow(/already recorded/i); // case/space-insensitive
  });

  it('allows legitimate repeats: different reference, different amount, or no reference at all', () => {
    const cust = seedCustomer();
    const base = { customer_id: cust, amount: 5000, payment_method: 'Cash', payment_type: 'Advance' };
    paymentService.create({ ...base, reference: 'R-1' });
    expect(paymentService.create({ ...base, reference: 'R-2' }).id).toBeTruthy();            // other reference
    expect(paymentService.create({ ...base, reference: 'R-1', amount: 6000 }).id).toBeTruthy(); // other amount
    expect(paymentService.create(base).id).toBeTruthy();                                      // two blank-reference cash instalments
    expect(paymentService.create(base).id).toBeTruthy();
  });

  it('the same reference is fine for a different customer', () => {
    const cust = seedCustomer();
    const other = customerService.create({ full_name: 'Someone Else' }).id;
    const base = { amount: 1000, payment_method: 'Online Transfer', payment_type: 'Advance', reference: 'CHQ-100' };
    paymentService.create({ ...base, customer_id: cust });
    expect(paymentService.create({ ...base, customer_id: other }).id).toBeTruthy();
  });

  it('supplier payment: same supplier + reference + amount + method is rejected; a different supplier is fine', () => {
    freshDb();
    const s1 = supplierService.create({ name: 'Hilton', service_type: 'Hotel' }).id;
    const s2 = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    const base = { amount: 9000, payment_method: 'Bank Transfer', reference: 'SUP-77' };
    supplierPaymentService.create({ ...base, supplier_id: s1 });
    expect(() => supplierPaymentService.create({ ...base, supplier_id: s1 })).toThrow(/already recorded/i);
    expect(supplierPaymentService.create({ ...base, supplier_id: s2 }).id).toBeTruthy();
  });

  it('supplier invoice: the same invoice number twice from one supplier is rejected (no doubled cost), but other suppliers may reuse it', () => {
    freshDb();
    const s1 = supplierService.create({ name: 'Hilton', service_type: 'Hotel' }).id;
    const s2 = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    supplierInvoiceService.create({ supplier_id: s1, invoice_number: 'INV-100', amount: 500 });
    expect(() => supplierInvoiceService.create({ supplier_id: s1, invoice_number: ' inv-100 ', amount: 500 })).toThrow(/already recorded/i);
    expect(supplierInvoiceService.create({ supplier_id: s2, invoice_number: 'INV-100', amount: 500 }).id).toBeTruthy();
  });
});
