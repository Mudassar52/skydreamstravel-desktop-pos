const { freshDb } = require('./testUtils');
const quotationService = require('../quotationService');
const packageService = require('../packageService');
const customerService = require('../customerService');
const travellerService = require('../travellerService');
const bookingService = require('../bookingService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const profitService = require('../profitService');

describe('quotationService', () => {
  let customerId;
  beforeEach(() => {
    freshDb();
    customerId = customerService.create({ full_name: 'Imran Qureshi' }).id;
  });

  it('requires a customer and generates a sequential quotation number', () => {
    expect(() => quotationService.create({})).toThrow(/customer must be selected/i);
    const a = quotationService.create({ customer_id: customerId, selling_price: 1000 });
    const b = quotationService.create({ customer_id: customerId, selling_price: 2000 });
    expect(quotationService.get(a.id).quotation_number).toBe('QT-000001');
    expect(quotationService.get(b.id).quotation_number).toBe('QT-000002');
  });

  it('converts to a booking, reusing customer, destination, dates, price and travellers, and is idempotent', () => {
    const { id: travellerId } = travellerService.create({ customer_id: customerId, full_name: 'Imran Qureshi' });
    const { id } = quotationService.create({
      customer_id: customerId, destination: 'Dubai', travel_date_from: '2027-05-01', travel_date_to: '2027-05-08',
      selling_price: 250000, notes: 'Family trip', traveller_ids: [travellerId]
    });

    const first = quotationService.convertToBooking(id);
    const booking = bookingService.get(first.bookingId);
    expect(booking.destination).toBe('Dubai');
    expect(booking.total_price).toBe(250000);
    expect(booking.customer_id).toBe(customerId);
    expect(travellerService.get(travellerId).bookings.length).toBe(1);
    expect(quotationService.get(id).status).toBe('Converted');

    const second = quotationService.convertToBooking(id);
    expect(second.alreadyConverted).toBe(true);
    expect(second.bookingId).toBe(first.bookingId);
  });

  it('blocks editing or deleting a converted quotation', () => {
    const { id } = quotationService.create({ customer_id: customerId, selling_price: 5000 });
    quotationService.convertToBooking(id);
    expect(() => quotationService.update(id, { customer_id: customerId, selling_price: 9999 })).toThrow(/cannot be edited/i);
    expect(() => quotationService.remove(id)).toThrow(/cannot be deleted/i);
  });

  it('rejects a travel end date before the start date', () => {
    expect(() =>
      quotationService.create({ customer_id: customerId, travel_date_from: '2027-05-10', travel_date_to: '2027-05-01' })
    ).toThrow(/end date cannot be before/i);
  });

  describe('full quotation form', () => {
    const items = () => [
      { category: 'Flight', name: 'LHE-JED return', quantity: 4, unit: 'Ticket', unit_price: 100000, discount: 10000, cost_price: 85000 },
      { category: 'Hotel', name: 'Makkah 5 nights', quantity: 2, unit: 'Room', unit_price: 50000, cost_price: 40000,
        details: { makkah_hotel: 'Hilton', room_type: 'Quad', junk: 'dropped' } }
    ];
    const full = (extra = {}) => ({
      customer_id: customerId, quotation_type: 'Umrah', departure_city: 'Lahore', destination: 'Jeddah',
      travel_date_from: '2027-03-01', travel_date_to: '2027-03-11', adults: 2, children: 1, infants: 1,
      travel_class: 'Economy', currency: 'SAR', items: items(), tax: 500, advance_required: 100000,
      discount_type: 'percent', discount_value: 10, ...extra
    });

    it('computes line totals, subtotal, discount, final total, balance, cost and profit on the server', () => {
      const { id } = quotationService.create(full({ selling_price: 1, subtotal: 1, balance_due: 1, expected_profit: 1 }), { userId: null });
      const q = quotationService.get(id);
      expect(q.items.map((i) => i.line_total)).toEqual([390000, 100000]);
      expect(q.subtotal).toBe(490000);
      expect(q.discount).toBe(49000);              // 10% of the subtotal
      expect(q.selling_price).toBe(441500);        // 490000 - 49000 + 500
      expect(q.advance_required).toBe(100000);
      expect(q.balance_due).toBe(341500);
      expect(q.cost).toBe(420000);                 // 4*85000 + 2*40000
      expect(q.expected_profit).toBe(21500);
      expect(q.total_nights).toBe(10);             // worked out from the dates
      expect(q.status).toBe('Draft');
      expect(q.revision_number).toBe(0);
      expect(q.quotation_date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(q.items[1].details).toEqual({ makkah_hotel: 'Hilton', room_type: 'Quad' });
    });

    it('supports a fixed overall discount and leaves profit empty when no cost was entered', () => {
      const { id } = quotationService.create(full({
        discount_type: 'amount', discount_value: 5000, tax: 0,
        items: [{ category: 'Package', name: 'Umrah package', quantity: 2, unit_price: 200000 }]
      }));
      const q = quotationService.get(id);
      expect(q.selling_price).toBe(395000);
      expect(q.expected_profit).toBeNull();
    });

    it('records who prepared it and stamps the sent time when status becomes Sent', () => {
      const { id } = quotationService.create(full({ status: 'Sent', sent_via: 'WhatsApp' }), { userId: null });
      expect(quotationService.get(id).sent_at).toBeTruthy();
      expect(quotationService.get(id).sent_via).toBe('WhatsApp');
    });

    it('rejects bad money and pricing input', () => {
      expect(() => quotationService.create(full({ items: [] }))).toThrow(/at least one service row/i);
      expect(() => quotationService.create(full({ items: [{ name: '', quantity: 1, unit_price: 5 }] }))).toThrow(/enter a service/i);
      expect(() => quotationService.create(full({ items: [{ name: 'x', quantity: 0, unit_price: 5 }] }))).toThrow(/quantity/i);
      expect(() => quotationService.create(full({ items: [{ name: 'x', quantity: 1, unit_price: 5, discount: 9 }] }))).toThrow(/discount cannot be more than the row/i);
      expect(() => quotationService.create(full({ discount_type: 'percent', discount_value: 150 }))).toThrow(/more than 100%/i);
      expect(() => quotationService.create(full({ discount_type: 'amount', discount_value: 9999999 }))).toThrow(/more than the subtotal/i);
      expect(() => quotationService.create(full({ advance_required: 99999999 }))).toThrow(/advance required cannot be more/i);
      expect(() => quotationService.create(full({ quotation_type: 'Cruise' }))).toThrow(/invalid quotation type/i);
      expect(() => quotationService.create(full({ currency: 'JPY' }))).toThrow(/invalid currency/i);
      expect(() => quotationService.create(full({ quotation_date: '2027-01-10', valid_until: '2027-01-01' }))).toThrow(/valid until/i);
      expect(() => quotationService.create(full({ adults: -1 }))).toThrow(/adults/i);
    });

    it('a user without View Profit can neither see nor overwrite cost data', () => {
      const { id } = quotationService.create(full(), { canSeeCost: true });
      const before = quotationService.get(id);
      // The screen sends the rows back with cost blanked (that is all it received).
      const rows = before.items.map((i) => ({ ...i, cost_price: null, unit_price: i.unit_price }));
      quotationService.update(id, { ...full(), items: rows }, { canSeeCost: false });
      const after = quotationService.get(id);
      expect(after.cost).toBe(before.cost);
      expect(after.expected_profit).toBe(before.expected_profit);

      // A row added by such a user starts with no cost; a hidden payload.cost is ignored.
      quotationService.update(id, { ...full(), cost: 1, items: [...rows, { name: 'Extra', quantity: 1, unit_price: 1000 }] }, { canSeeCost: false });
      expect(quotationService.get(id).cost).toBe(before.cost);
    });

    it('the response filter hides cost and profit from roles without View Profit', () => {
      const redaction = require('../../ipc/redaction');
      const { id } = quotationService.create(full());
      const staff = { permissions: { quotations: { view: 1 } }, capabilities: { view_profit: 0 } };
      const boss = { permissions: { quotations: { view: 1 } }, capabilities: { view_profit: 1 } };
      const one = { ok: true, data: quotationService.get(id) };
      const hidden = redaction.apply('quotations:get', one, staff).data;
      expect(hidden.cost).toBeNull();
      expect(hidden.expected_profit).toBeNull();
      expect(hidden.items.every((i) => i.cost_price === null)).toBe(true);
      expect(hidden.selling_price).toBe(one.data.selling_price);
      expect(redaction.apply('quotations:get', one, boss)).toBe(one);
      const many = { ok: true, data: quotationService.list({}) };
      expect(redaction.apply('quotations:list', many, staff).data.rows[0].expected_profit).toBeNull();
    });

    it('updates items and totals together, and keeps the number and preparer', () => {
      const { id } = quotationService.create(full(), { userId: null });
      const number = quotationService.get(id).quotation_number;
      quotationService.update(id, full({ items: [{ category: 'Visa', name: 'Visa', quantity: 4, unit_price: 20000 }], discount_value: 0, tax: 0, advance_required: 0 }));
      const q = quotationService.get(id);
      expect(q.quotation_number).toBe(number);
      expect(q.items.length).toBe(1);
      expect(q.selling_price).toBe(80000);
      expect(q.balance_due).toBe(80000);
    });

    it('turns a Sent quotation into Expired once its valid-until date has passed', () => {
      const { id } = quotationService.create(full({ status: 'Sent', quotation_date: '2020-01-01', valid_until: '2020-01-10' }));
      expect(quotationService.get(id).status).toBe('Expired');
      const draft = quotationService.create(full({ status: 'Draft', quotation_date: '2020-01-01', valid_until: '2020-01-10' }));
      expect(quotationService.get(draft.id).status).toBe('Draft');
    });

    it('revise bumps the revision number and puts the quotation back to Draft', () => {
      const { id } = quotationService.create(full({ status: 'Sent' }));
      expect(quotationService.revise(id).revision_number).toBe(1);
      const q = quotationService.get(id);
      expect(q.revision_number).toBe(1);
      expect(q.status).toBe('Draft');
      expect(q.sent_at).toBeNull();
      expect(quotationService.revise(id).revision_number).toBe(2);
    });

    it('lists the customer\'s own bookings and inquiries for the reference dropdowns', () => {
      const other = customerService.create({ full_name: 'Someone Else' }).id;
      const b = bookingService.create({ customer_id: customerId, booking_type: 'Umrah', destination: 'Makkah', total_price: 1000 }).id;
      bookingService.create({ customer_id: other, booking_type: 'Tour', total_price: 1000 });
      const opts = quotationService.referenceOptions({ customer_id: customerId });
      expect(opts.bookings.map((x) => x.id)).toEqual([b]);
      expect(quotationService.referenceOptions({}).bookings).toEqual([]);
      const { id } = quotationService.create(full({ booking_id: b }));
      expect(quotationService.get(id).booking_code).toMatch(/^BK-/);
    });

    it('converts using the quotation type, passenger count and final total, and records no payment', () => {
      const { id } = quotationService.create(full({ quotation_type: 'Transport' }));
      const { bookingId } = quotationService.convertToBooking(id);
      const booking = bookingService.get(bookingId);
      expect(booking.booking_type).toBe('Transportation');
      expect(booking.total_price).toBe(441500);
      expect(booking.number_of_passengers).toBe(3);   // adults + children, infants hold no seat
      expect(booking.paid_amount).toBe(0);
    });

    it('filters the list by type and searches the saved phone number', () => {
      quotationService.create(full({ customer_phone: '0300-1234567' }));
      quotationService.create(full({ quotation_type: 'Visa' }));
      expect(quotationService.list({ type: 'Visa' }).total).toBe(1);
      expect(quotationService.list({ search: '1234567' }).total).toBe(1);
    });

    it('renames the old Approved status to Accepted when the database is upgraded', () => {
      const { initDatabase } = require('../../../src/database/db');
      const { getDb } = require('../../../src/database/db');
      const { id } = quotationService.create({ customer_id: customerId, selling_price: 500 });
      getDb().prepare("UPDATE quotations SET status = 'Approved' WHERE id = ?").run(id);
      const dir = require('path').dirname(require('path').dirname(getDb().name));
      initDatabase(dir);
      expect(quotationService.get(id).status).toBe('Accepted');
    });
  });
});

describe('packageService', () => {
  beforeEach(() => freshDb());

  it('requires a package name and stores components', () => {
    expect(() => packageService.create({})).toThrow(/name is required/i);
    const { id } = packageService.create({
      package_name: 'Makkah Deluxe 7N', supplier_cost: 60000, selling_price: 95000,
      components: [{ component_type: 'Hotel', cost: 40000, selling_price: 60000 }, { component_type: 'Flight', cost: 20000, selling_price: 35000 }]
    });
    expect(packageService.get(id).components.length).toBe(2);
  });

  it('replaces components wholesale on update', () => {
    const { id } = packageService.create({
      package_name: 'Basic Pkg', selling_price: 1000,
      components: [{ component_type: 'Flight', cost: 100, selling_price: 200 }]
    });
    packageService.update(id, { package_name: 'Basic Pkg', selling_price: 1000, components: [] });
    expect(packageService.get(id).components.length).toBe(0);
  });

  it('options() only returns Active packages', () => {
    packageService.create({ package_name: 'Active One', status: 'Active' });
    packageService.create({ package_name: 'Inactive One', status: 'Inactive' });
    expect(packageService.options().map((p) => p.package_name)).toEqual(['Active One']);
  });
});

describe('booking destination persistence + per-booking profit', () => {
  it('bookingService now persists and updates the destination column', () => {
    freshDb();
    const customerId = customerService.create({ full_name: 'Fahad Nawaz' }).id;
    const { id } = bookingService.create({ customer_id: customerId, booking_type: 'Custom', destination: 'Istanbul', total_price: 10000 });
    expect(bookingService.get(id).destination).toBe('Istanbul');
    bookingService.update(id, { customer_id: customerId, booking_type: 'Custom', destination: 'Antalya', total_price: 10000 });
    expect(bookingService.get(id).destination).toBe('Antalya');
  });

  it('profitService.getByBooking blends invoiced revenue, supplier cost, and booking expenses', () => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    const customerId = customerService.create({ full_name: 'Hina Tariq' }).id;
    const { id: bookingId } = bookingService.create({ customer_id: customerId, booking_type: 'Custom', total_price: 100000 });
    const { id: supplierId } = supplierService.create({ name: 'Test Supplier' });
    supplierInvoiceService.create({ supplier_id: supplierId, booking_id: bookingId, invoice_number: 'SI-1', amount: 60000 });
    invoiceService.create({ customer_id: customerId, booking_id: bookingId, items: [{ description: 'Package', quantity: 1, unit_price: 100000 }] });

    const profit = profitService.getByBooking(bookingId);
    expect(profit.estimatedRevenue).toBe(100000);
    expect(profit.estimatedCost).toBe(60000);
    expect(profit.estimatedProfit).toBe(40000);
    expect(profit.actualRevenue).toBe(100000);
    expect(profit.actualCost).toBe(60000);
    expect(profit.actualProfit).toBe(40000);
  });
});
