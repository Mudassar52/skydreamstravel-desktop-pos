const { buildXlsx, colLetter, sanitizeSheetName } = require('../xlsxWriter');
const { readZip } = require('./helpers/zipReader');

function entry(entries, path) {
  const e = entries.find((x) => x.name === path);
  if (!e) throw new Error(`Missing zip entry: ${path}`);
  return e.data.toString('utf-8');
}

describe('xlsxWriter', () => {
  it('column letters follow spreadsheet convention (A..Z, AA, AB...)', () => {
    expect(colLetter(1)).toBe('A');
    expect(colLetter(26)).toBe('Z');
    expect(colLetter(27)).toBe('AA');
    expect(colLetter(28)).toBe('AB');
    expect(colLetter(52)).toBe('AZ');
  });

  it('sanitizes sheet names (length, forbidden characters, blank fallback)', () => {
    expect(sanitizeSheetName('Customers', 0)).toBe('Customers');
    expect(sanitizeSheetName('A/B:C*D?E[F]G', 0)).toBe('A B C D E F G');
    expect(sanitizeSheetName('x'.repeat(50), 0)).toHaveLength(31);
    expect(sanitizeSheetName('', 2)).toBe('Sheet3');
  });

  it('produces a structurally valid zip: signatures, CRCs, and every declared part present', () => {
    const buf = buildXlsx([
      { name: 'Summary', columns: [{ key: 'label', label: 'Label' }, { key: 'amount', label: 'Amount', money: true }], rows: [{ label: 'Total Billed', amount: 125000.5 }] }
    ]);
    expect(buf.subarray(0, 4).toString('hex')).toBe('504b0304'); // local file header magic "PK\x03\x04"
    const entries = readZip(buf); // throws on any signature/CRC mismatch
    const names = entries.map((e) => e.name).sort();
    expect(names).toEqual(['[Content_Types].xml', '_rels/.rels', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/workbook.xml', 'xl/worksheets/sheet1.xml'].sort());
  });

  it('workbook.xml lists every sheet by name with a matching worksheet part and relationship', () => {
    const buf = buildXlsx([
      { name: 'Summary', columns: [{ key: 'a', label: 'A' }], rows: [{ a: 1 }] },
      { name: 'Customers', columns: [{ key: 'a', label: 'A' }], rows: [{ a: 2 }] },
      { name: 'Bookings', columns: [{ key: 'a', label: 'A' }], rows: [{ a: 3 }] }
    ]);
    const entries = readZip(buf);
    const workbook = entry(entries, 'xl/workbook.xml');
    expect(workbook).toContain('name="Summary"');
    expect(workbook).toContain('name="Customers"');
    expect(workbook).toContain('name="Bookings"');
    expect(entries.some((e) => e.name === 'xl/worksheets/sheet2.xml')).toBe(true);
    expect(entries.some((e) => e.name === 'xl/worksheets/sheet3.xml')).toBe(true);
    const rels = entry(entries, 'xl/_rels/workbook.xml.rels');
    expect(rels).toContain('worksheets/sheet1.xml');
    expect(rels).toContain('worksheets/sheet2.xml');
    expect(rels).toContain('worksheets/sheet3.xml');
    expect(rels).toContain('styles.xml');
  });

  it('text cells use inline strings and numeric/money cells carry a numeric <v>, with XML-unsafe text escaped', () => {
    const buf = buildXlsx([{
      name: 'Data',
      columns: [{ key: 'name', label: 'Name' }, { key: 'total', label: 'Total', money: true }],
      rows: [{ name: 'Al<i> & "Sons"', total: 1999.99 }],
      totals: { total: 1999.99 }
    }]);
    const sheet = entry(readZip(buf), 'xl/worksheets/sheet1.xml');
    expect(sheet).toContain('<t>Al&lt;i&gt; &amp; &quot;Sons&quot;</t>');
    expect(sheet).toContain('<v>1999.99</v>');
    expect(sheet).toContain('t="inlineStr"');
    // header row, one data row, one totals row = 3 <row> elements
    expect((sheet.match(/<row /g) || []).length).toBe(3);
  });

  it('skips blank cells cleanly rather than writing "null" or "undefined"', () => {
    const buf = buildXlsx([{ name: 'Data', columns: [{ key: 'x', label: 'X' }], rows: [{ x: null }, { x: undefined }, {}] }]);
    const sheet = entry(readZip(buf), 'xl/worksheets/sheet1.xml');
    expect(sheet).not.toContain('null');
    expect(sheet).not.toContain('undefined');
  });

  it('throws on an empty sheet list rather than producing a corrupt file', () => {
    expect(() => buildXlsx([])).toThrow(/at least one sheet/i);
  });
});
