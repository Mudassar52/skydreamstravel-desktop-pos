const { freshDb } = require('./testUtils');
const authService = require('../authService');

describe('authService', () => {
  beforeEach(() => {
    freshDb();
    authService.ensureDefaults();
  });

  it('seeds a working default admin account', () => {
    const result = authService.login('admin', 'admin123');
    expect(result.role).toBe('Admin');
    expect(result.permissions.customers.delete).toBe(true);
  });

  it('rejects a wrong password without revealing why', () => {
    expect(() => authService.login('admin', 'wrong-password')).toThrow(/invalid username or password/i);
  });

  it('rejects a disabled account', () => {
    const roles = authService.getRoles();
    const managerRole = roles.find((r) => r.name === 'Manager');
    authService.createUser({ fullName: 'Test Manager', username: 'manager1', password: 'pass123', roleId: managerRole.id });
    authService.updateUser(
      authService.listUsers().find((u) => u.username === 'manager1').id,
      { fullName: 'Test Manager', roleId: managerRole.id, isActive: 0 }
    );
    expect(() => authService.login('manager1', 'pass123')).toThrow(/deactivated/i);
  });

  it('gives Manager and Staff sensible restricted defaults, not full access', () => {
    const roles = authService.getRoles();
    const managerRole = roles.find((r) => r.name === 'Manager');
    const staffRole = roles.find((r) => r.name === 'Staff');

    authService.createUser({ fullName: 'Mgr', username: 'mgr', password: 'pass123', roleId: managerRole.id });
    authService.createUser({ fullName: 'Stf', username: 'stf', password: 'pass123', roleId: staffRole.id });

    const mgr = authService.login('mgr', 'pass123');
    expect(mgr.permissions.customers.edit).toBe(true);
    expect(mgr.permissions.settings.edit).toBe(false);

    const stf = authService.login('stf', 'pass123');
    expect(stf.permissions.customers.create).toBe(true);
    expect(stf.permissions.ledger.view).toBe(false);
  });

  it('refuses to create a user with a duplicate username', () => {
    const roles = authService.getRoles();
    const adminRole = roles.find((r) => r.name === 'Admin');
    expect(() => authService.createUser({ fullName: 'Dup', username: 'admin', password: 'pass123', roleId: adminRole.id })).toThrow(
      /already taken/i
    );
  });

  it('live-edits a permission and it takes effect on next login', () => {
    const roles = authService.getRoles();
    const managerRole = roles.find((r) => r.name === 'Manager');
    authService.updatePermission({ roleId: managerRole.id, module: 'ledger', can_view: 1, can_create: 0, can_edit: 0, can_delete: 0 });

    authService.createUser({ fullName: 'Mgr2', username: 'mgr2', password: 'pass123', roleId: managerRole.id });
    const mgr = authService.login('mgr2', 'pass123');
    expect(mgr.permissions.ledger.view).toBe(true);
  });

  it('records old -> new values in the audit log when a permission actually changes, but not when it does not', () => {
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    const managerRole = authService.getRoles().find((r) => r.name === 'Manager');
    authService.updatePermission({ roleId: managerRole.id, module: 'expenses', can_view: 1, can_create: 1, can_edit: 1, can_delete: 1, actingUserId: 1 });
    let logs = db.prepare(`SELECT description FROM audit_logs WHERE action = 'Permission Changed'`).all();
    expect(logs).toHaveLength(1);
    expect(logs[0].description).toContain('Manager / expenses');

    // Calling it again with the exact same values should not add a second entry.
    authService.updatePermission({ roleId: managerRole.id, module: 'expenses', can_view: 1, can_create: 1, can_edit: 1, can_delete: 1, actingUserId: 1 });
    logs = db.prepare(`SELECT description FROM audit_logs WHERE action = 'Permission Changed'`).all();
    expect(logs).toHaveLength(1);
  });

  describe('capabilities (View Profit / View Supplier Costs / Export Reports)', () => {
    it('seeds sensible defaults: Admin and Manager see financials, Staff does not', () => {
      const roles = authService.getRoles();
      const admin = roles.find((r) => r.name === 'Admin');
      const manager = roles.find((r) => r.name === 'Manager');
      const staff = roles.find((r) => r.name === 'Staff');

      expect(authService.getCapabilitiesForRole(admin.id)).toEqual({ view_profit: true, view_supplier_costs: true, export_reports: true });
      expect(authService.getCapabilitiesForRole(manager.id)).toEqual({ view_profit: true, view_supplier_costs: true, export_reports: true });
      expect(authService.getCapabilitiesForRole(staff.id)).toEqual({ view_profit: false, view_supplier_costs: false, export_reports: false });
    });

    it('login includes the current user\'s capabilities', () => {
      const result = authService.login('admin', 'admin123');
      expect(result.capabilities.view_profit).toBe(true);
    });

    it('updateCapability flips one flag, logs the change, and it takes effect on next login', () => {
      const { getDb } = require('../../../src/database/db');
      const db = getDb();
      const staffRole = authService.getRoles().find((r) => r.name === 'Staff');
      authService.createUser({ fullName: 'Stf2', username: 'stf2', password: 'pass123', roleId: staffRole.id });

      let stf = authService.login('stf2', 'pass123');
      expect(stf.capabilities.view_profit).toBe(false);

      authService.updateCapability({ roleId: staffRole.id, capability: 'view_profit', granted: true, actingUserId: 1 });
      stf = authService.login('stf2', 'pass123');
      expect(stf.capabilities.view_profit).toBe(true);
      expect(stf.capabilities.view_supplier_costs).toBe(false); // untouched

      const logs = db.prepare(`SELECT description FROM audit_logs WHERE action = 'Permission Changed'`).all();
      expect(logs.some((l) => l.description.includes('view_profit') && l.description.includes('true'))).toBe(true);
    });

    it('rejects an unknown capability key', () => {
      const staffRole = authService.getRoles().find((r) => r.name === 'Staff');
      expect(() => authService.updateCapability({ roleId: staffRole.id, capability: 'delete_everything', granted: true })).toThrow(/unknown capability/i);
    });

    it('getCapabilitiesMatrix lists all capabilities, roles and grants for the Permissions screen', () => {
      const matrix = authService.getCapabilitiesMatrix();
      expect(matrix.capabilities.map((c) => c.key)).toEqual(['view_profit', 'view_supplier_costs', 'export_reports']);
      expect(matrix.roles).toHaveLength(3);
      expect(matrix.grants.length).toBe(9); // 3 roles x 3 capabilities
    });
  });
});
