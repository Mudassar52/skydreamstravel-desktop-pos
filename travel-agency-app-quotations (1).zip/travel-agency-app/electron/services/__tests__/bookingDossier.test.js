const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const travellerService = require('../travellerService');
const expenseService = require('../expenseService');
const voucherService = require('../voucherService');
const dossier = require('../bookingDossierService');

function seed() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  const cust = customerService.create({ full_name: 'Ayesha Khan', phone: '0300-9' }).id;
  const hilton = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
  const pia = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;

  const b = bookingService.create({
    customer_id: cust, booking_type: 'Umrah', total_price: 300000, status: 'Confirmed',
    departure_date: '2099-01-01', return_date: '2099-01-15', number_of_passengers: 2
  }).id;

  const db = getDb();
  db.prepare(`INSERT INTO flights (booking_id, airline, flight_number, supplier_id, cost, selling_price, departure_date) VALUES (?, 'PIA', 'PK-702', ?, 80000, 95000, '2099-01-01')`).run(b, pia);
  db.prepare(`INSERT INTO hotels (booking_id, hotel_name, supplier_id, cost, selling_price, check_in, check_out, confirmation_number) VALUES (?, 'Swissotel', ?, 60000, 75000, '2099-01-01', '2099-01-08', 'CONF-1')`).run(b, hilton);
  db.prepare(`INSERT INTO visa_applications (customer_id, booking_id, country, cost, selling_price) VALUES (?, ?, 'Saudi Arabia', 15000, 18000)`).run(cust, b);
  db.prepare(`INSERT INTO transportation (booking_id, pickup_location, drop_location, cost, selling_price, pickup_date) VALUES (?, 'Airport', 'Hotel', 5000, 7000, '2099-01-01')`).run(b);
  db.prepare(`INSERT INTO other_services (service_type, booking_id, customer_id, description, cost, selling_price) VALUES ('Ziyarat', ?, ?, 'Makkah Ziyarat', 3000, 5000)`).run(b, cust);

  const trav = travellerService.create({ full_name: 'Ayesha Khan', customer_id: cust }).id;
  travellerService.addToBooking(b, trav, 'Lead traveller');

  const inv = invoiceService.create({ customer_id: cust, booking_id: b, items: [{ description: 'Umrah Package', quantity: 1, unit_price: 300000 }] }).id;
  paymentService.create({ customer_id: cust, booking_id: b, amount: 100000, payment_method: 'Cash', payment_type: 'Advance' });
  paymentService.create({ customer_id: cust, invoice_id: inv, amount: 50000, payment_method: 'Bank Transfer', payment_type: 'Partial' });

  const supInv = supplierInvoiceService.create({ supplier_id: hilton, booking_id: b, invoice_number: 'H-1', amount: 62000 });
  supplierPaymentService.create({ supplier_id: hilton, supplier_invoice_id: supInv.id, booking_id: b, amount: 20000, payment_method: 'Cash' });

  const cat = expenseService.listCategories()[0];
  expenseService.create({ category_id: cat.id, expense_date: '2099-01-02', amount: 2000, related_booking_id: b });

  return { cust, b, hilton, pia, inv };
}

describe('bookingDossierService', () => {
  it('throws for an unknown booking', () => {
    seed();
    expect(() => dossier.header(999999)).toThrow(/not found/i);
  });

  it('header exposes the booking, customer and package snapshot (null when no package)', () => {
    const { b } = seed();
    const h = dossier.header(b);
    expect(h.booking_code).toMatch(/^BK-/);
    expect(h.customer.full_name).toBe('Ayesha Khan');
    expect(h.total_price).toBe(300000);
    expect(h.package_snapshot).toBeNull();
  });

  it('lists travellers linked to this booking only', () => {
    const { b, cust } = seed();
    const t = dossier.travellers(b);
    expect(t).toHaveLength(1);
    expect(t[0].full_name).toBe('Ayesha Khan');
    expect(t[0].booking_notes).toBe('Lead traveller');
    // another booking with no travellers stays empty
    const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 1000 }).id;
    expect(dossier.travellers(b2)).toHaveLength(0);
  });

  it('flights/hotels/visa/transport/ziyarat each report cost, selling and profit for this booking', () => {
    const { b } = seed();
    const f = dossier.flights(b)[0];
    expect(f.cost).toBe(80000); expect(f.selling_price).toBe(95000); expect(f.profit).toBe(15000); expect(f.supplier_name).toBe('PIA');
    const h = dossier.hotels(b)[0];
    expect(h.confirmation_number).toBe('CONF-1'); expect(h.profit).toBe(15000); expect(h.supplier_name).toBe('Hilton Makkah');
    const v = dossier.visa(b)[0];
    expect(v.profit).toBe(3000);
    const t = dossier.transport(b)[0];
    expect(t.profit).toBe(2000);
    const z = dossier.ziyarat(b)[0];
    expect(z.service_type).toBe('Ziyarat'); expect(z.profit).toBe(2000);
  });

  it('suppliers tab lists only the suppliers actually touching this booking', () => {
    const { b } = seed();
    const names = dossier.suppliers(b).map((s) => s.name).sort();
    expect(names).toEqual(['Hilton Makkah', 'PIA']);
  });

  it('invoices and payments are scoped to this booking', () => {
    const { b } = seed();
    expect(dossier.invoices(b)).toHaveLength(1);
    expect(dossier.invoices(b)[0].total).toBe(300000);
    const pays = dossier.payments(b);
    expect(pays).toHaveLength(2);
    expect(pays.reduce((a, p) => a + p.amount, 0)).toBe(150000);
  });

  it('advances: received vs used, never double counted with ordinary payments', () => {
    const { b } = seed();
    const a = dossier.advances(b);
    expect(a.received).toBe(100000);
    expect(a.used).toBe(100000); // tied to the booking directly
    expect(a.remaining).toBe(0);
  });

  it('outstanding = selling total minus net real payments', () => {
    const { b } = seed();
    const o = dossier.outstanding(b);
    expect(o.selling).toBe(300000);
    expect(o.paid).toBe(150000);
    expect(o.outstanding).toBe(150000);
  });

  it('supplier costs: invoiced, paid and payable for this booking only', () => {
    const { b } = seed();
    const sc = dossier.supplierCosts(b);
    expect(sc.invoiced).toBe(62000);
    expect(sc.paid).toBe(20000);
    expect(sc.payable).toBe(42000);
    expect(sc.invoices).toHaveLength(1);
    expect(sc.payments).toHaveLength(1);
  });

  it('profit: estimated (service cost) vs actual (supplier invoice + expenses), never mixed', () => {
    const { b } = seed();
    const p = dossier.profit(b);
    expect(p.estimated_cost).toBe(163000);        // 80k+60k+15k+5k+3k
    expect(p.estimated_profit).toBe(137000);       // 300k - 163k
    expect(p.actual_revenue).toBe(300000);
    expect(p.actual_supplier_cost).toBe(62000);    // real supplier invoice, not estimate
    expect(p.expenses).toBe(2000);
    expect(p.actual_profit).toBe(236000);          // 300000 - 62000 - 2000
  });

  it('timeline includes real events from every linked table, newest first', () => {
    const { b } = seed();
    const events = dossier.timeline(b).map((e) => e.event);
    expect(events).toContain('Booking created');
    expect(events).toContain('Invoice generated');
    expect(events).toContain('Advance received');
    expect(events).toContain('Payment received');
    expect(events).toContain('Supplier invoice recorded');
    expect(events).toContain('Supplier payment made');
    expect(events).toContain('Flight added');
    expect(events).toContain('Hotel added');
    const dates = dossier.timeline(b).map((e) => e.at);
    expect([...dates].sort().reverse()).toEqual(dates);
  });

  it('a booking with nothing recorded shows zeros, not errors', () => {
    const { cust } = seed();
    const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 5000 }).id;
    expect(dossier.flights(b2)).toHaveLength(0);
    expect(dossier.profit(b2).estimated_cost).toBe(0);
    expect(dossier.advances(b2).received).toBe(0);
    expect(dossier.supplierCosts(b2).invoiced).toBe(0);
  });

  it('getDossier bundles every section for one screen', () => {
    const { b } = seed();
    const d = dossier.getDossier(b);
    expect(d.header.id).toBe(b);
    expect(d.flights).toHaveLength(1);
    expect(d.profit.estimated_revenue).toBe(300000);
    expect(d.timeline.length).toBeGreaterThan(3);
  });
});

describe('voucherService', () => {
  it('lists which hotel/transport rows on a booking can get a voucher', () => {
    const { b } = seed();
    const av = voucherService.availableVouchers(b);
    expect(av.hotels).toHaveLength(1);
    expect(av.transport).toHaveLength(1);
  });

  it('builds a hotel voucher with real booking + hotel data, no invoice template involved', () => {
    const { b } = seed();
    const hotelId = voucherService.availableVouchers(b).hotels[0].id;
    const { html, suggestedName } = voucherService.buildHotelVoucherHtml(b, hotelId);
    expect(html).toContain('Hotel Voucher');
    expect(html).toContain('Swissotel');
    expect(html).toContain('CONF-1');
    expect(html).toContain('Ayesha Khan');
    expect(suggestedName).toMatch(/Hotel-Voucher-BK-/);
  });

  it('builds a transport voucher with real booking + transport data', () => {
    const { b } = seed();
    const transportId = voucherService.availableVouchers(b).transport[0].id;
    const { html } = voucherService.buildTransportVoucherHtml(b, transportId);
    expect(html).toContain('Transport Voucher');
    expect(html).toContain('Airport');
    expect(html).toContain('Hotel');
  });

  it('rejects a hotel/transport id that does not belong to the booking', () => {
    const { b, cust } = seed();
    const other = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 1 }).id;
    const hotelId = voucherService.availableVouchers(b).hotels[0].id;
    expect(() => voucherService.buildHotelVoucherHtml(other, hotelId)).toThrow(/not found/i);
  });
});
