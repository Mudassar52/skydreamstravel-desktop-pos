const { freshDb } = require('./testUtils');
const customerService = require('../customerService');

describe('customerService', () => {
  beforeEach(() => freshDb());

  it('creates a customer with valid data', () => {
    const result = customerService.create({ full_name: 'Ahmed Raza', phone: '+923001234567', email: 'ahmed@example.com' });
    expect(result.id).toBeGreaterThan(0);
    const fetched = customerService.get(result.id);
    expect(fetched.full_name).toBe('Ahmed Raza');
    expect(fetched.status).toBe('Active');
  });

  it('rejects an empty full name', () => {
    expect(() => customerService.create({ full_name: '' })).toThrow(/name is required/i);
  });

  it('rejects an invalid email', () => {
    expect(() => customerService.create({ full_name: 'Bad Email', email: 'not-an-email' })).toThrow(/valid email/i);
  });

  it('rejects passport expiry before issue date', () => {
    expect(() =>
      customerService.create({ full_name: 'Bad Dates', passport_issue_date: '2025-01-01', passport_expiry_date: '2020-01-01' })
    ).toThrow(/expiry date cannot be before/i);
  });

  it('searches by name, cnic, passport, and phone', () => {
    customerService.create({ full_name: 'Ahmed Raza', cnic: '35202-1234567-1', passport_number: 'AB123456', phone: '0300-1112223' });
    customerService.create({ full_name: 'Bilal Khan', phone: '0311-9998887' });

    expect(customerService.list({ search: 'Ahmed' }).total).toBe(1);
    expect(customerService.list({ search: '35202' }).total).toBe(1);
    expect(customerService.list({ search: 'AB123456' }).total).toBe(1);
    expect(customerService.list({ search: '9998887' }).total).toBe(1);
    expect(customerService.list({}).total).toBe(2);
  });

  it('paginates results', () => {
    for (let i = 0; i < 30; i++) customerService.create({ full_name: `Customer ${i}` });
    const page1 = customerService.list({ page: 1, pageSize: 10 });
    const page2 = customerService.list({ page: 2, pageSize: 10 });
    expect(page1.rows).toHaveLength(10);
    expect(page2.rows).toHaveLength(10);
    expect(page1.total).toBe(30);
    expect(page1.rows[0].id).not.toBe(page2.rows[0].id);
  });

  it('updates a customer', () => {
    const c = customerService.create({ full_name: 'Original Name' });
    customerService.update(c.id, { full_name: 'Updated Name', status: 'Inactive' });
    const fetched = customerService.get(c.id);
    expect(fetched.full_name).toBe('Updated Name');
    expect(fetched.status).toBe('Inactive');
  });

  it('deletes a customer with no bookings', () => {
    const c = customerService.create({ full_name: 'Deletable' });
    customerService.remove(c.id);
    expect(customerService.list({}).total).toBe(0);
  });

  it('refuses to delete a customer with an existing booking', () => {
    const { getDb } = require('../../../src/database/db');
    const c = customerService.create({ full_name: 'Has Booking' });
    getDb()
      .prepare("INSERT INTO bookings (booking_code, customer_id, booking_type, total_price) VALUES ('BK-0001', ?, 'Tour', 50000)")
      .run(c.id);
    expect(() => customerService.remove(c.id)).toThrow(/existing bookings/i);
  });
});
