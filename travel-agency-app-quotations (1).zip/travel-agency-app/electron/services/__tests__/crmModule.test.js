const { freshDb } = require('./testUtils');
const leadService = require('../leadService');
const travellerService = require('../travellerService');
const followUpService = require('../followUpService');
const customerService = require('../customerService');
const bookingService = require('../bookingService');

describe('leadService', () => {
  beforeEach(() => freshDb());

  it('requires a name and generates a sequential lead code', () => {
    expect(() => leadService.create({})).toThrow(/name is required/i);
    const a = leadService.create({ full_name: 'Bilal Khan' });
    const b = leadService.create({ full_name: 'Sana Malik' });
    expect(leadService.get(a.id).lead_code).toBe('LD-000001');
    expect(leadService.get(b.id).lead_code).toBe('LD-000002');
  });

  it('stores service-specific enquiry details (budget, travellers, Makkah/Madinah hotels) and reads them back as an object', () => {
    const details = {
      passports: [{ country: 'Pakistan', count: '2' }, { country: 'India', count: '1' }], adults: '2', children: '1', ages: { adults: ['40', '38'], children: ['7'] },
      makkah: { stars: '5', nights: '7', hotels: ['Clock Tower', 'Hilton'] },
      madinah: { stars: '4', nights: '4', hotels: ['Pullman Zamzam'] }
    };
    const { id } = leadService.create({ full_name: 'Bilal Khan', service_type: 'Umrah', estimated_value: 900000, details });
    const lead = leadService.get(id);
    expect(lead.details).toEqual(details);
    expect(lead.estimated_value).toBe(900000);
    expect(leadService.list().rows[0].details.makkah.hotels).toEqual(['Clock Tower', 'Hilton']);

    leadService.update(id, { service_type: 'Visa', details: { passports: [{ country: 'India', count: '1' }], visa_type: 'Tourist' } });
    expect(leadService.get(id).details).toEqual({ passports: [{ country: 'India', count: '1' }], visa_type: 'Tourist' });

    const { customerId } = leadService.convertToCustomer(id);
    expect(customerService.get(customerId).nationality).toBe('India');
  });

  it('logs a StatusChange activity when the stage changes, but not on unrelated edits', () => {
    const { id } = leadService.create({ full_name: 'Bilal Khan' });
    expect(leadService.get(id).activities.length).toBe(1); // creation note
    leadService.update(id, { notes: 'called once' });
    expect(leadService.get(id).activities.length).toBe(1); // no status change
    leadService.update(id, { status: 'Contacted' });
    expect(leadService.get(id).activities.length).toBe(2);
  });

  it('allows a partial (status-only) update without requiring full_name again', () => {
    const { id } = leadService.create({ full_name: 'Bilal Khan' });
    expect(() => leadService.update(id, { status: 'Qualified' })).not.toThrow();
    expect(leadService.get(id).status).toBe('Qualified');
  });

  it('converts a lead into a customer, reusing its contact details, and is idempotent', () => {
    const { id } = leadService.create({ full_name: 'Bilal Khan', phone: '0300-9999999', email: 'bilal@example.com' });
    const first = leadService.convertToCustomer(id);
    const customer = customerService.get(first.customerId);
    expect(customer.full_name).toBe('Bilal Khan');
    expect(customer.phone).toBe('0300-9999999');
    expect(leadService.get(id).status).toBe('Converted');

    const second = leadService.convertToCustomer(id);
    expect(second.alreadyConverted).toBe(true);
    expect(second.customerId).toBe(first.customerId);
  });

  it('the pipeline view returns every stage, including empty ones, with counts and values', () => {
    leadService.create({ full_name: 'A', status: 'New', estimated_value: 1000 });
    leadService.create({ full_name: 'B', status: 'New', estimated_value: 2000 });
    const pipe = leadService.pipeline();
    expect(pipe.map((p) => p.stage)).toEqual(leadService.STAGES);
    const newStage = pipe.find((p) => p.stage === 'New');
    expect(newStage.count).toBe(2);
    expect(newStage.totalValue).toBe(3000);
    expect(pipe.find((p) => p.stage === 'Lost').count).toBe(0);
  });
});

describe('travellerService', () => {
  let customerId;
  beforeEach(() => {
    freshDb();
    customerId = customerService.create({ full_name: 'Owais Sheikh' }).id;
  });

  it('requires a name and validates passport dates', () => {
    expect(() => travellerService.create({})).toThrow(/name is required/i);
    expect(() =>
      travellerService.create({ full_name: 'X', passport_issue_date: '2025-01-01', passport_expiry_date: '2024-01-01' })
    ).toThrow(/before the issue date/i);
  });

  it('links a traveller to a booking and blocks deletion while linked', () => {
    const { id: travellerId } = travellerService.create({ customer_id: customerId, full_name: 'Owais Sheikh', relationship: 'Self' });
    const booking = bookingService.create({ customer_id: customerId, booking_type: 'Custom', total_price: 50000 });
    travellerService.addToBooking(booking.id, travellerId, 'Primary pax');

    const detail = travellerService.get(travellerId);
    expect(detail.bookings.length).toBe(1);
    expect(() => travellerService.remove(travellerId)).toThrow(/linked to existing bookings/i);

    const membership = travellerService.listForBooking(booking.id)[0];
    travellerService.removeFromBooking(membership.membership_id);
    expect(travellerService.get(travellerId).bookings.length).toBe(0);
    expect(() => travellerService.remove(travellerId)).not.toThrow();
  });

  it('rejects adding the same traveller to a booking twice', () => {
    const { id: travellerId } = travellerService.create({ full_name: 'Dup Test' });
    const booking = bookingService.create({ customer_id: customerId, booking_type: 'Custom', total_price: 1000 });
    travellerService.addToBooking(booking.id, travellerId);
    expect(() => travellerService.addToBooking(booking.id, travellerId)).toThrow(/already on that booking/i);
  });
});

describe('followUpService', () => {
  let customerId;
  beforeEach(() => {
    freshDb();
    customerId = customerService.create({ full_name: 'Rida Fatima' }).id;
  });

  it('requires a date and a link to a customer, lead, or booking', () => {
    expect(() => followUpService.create({})).toThrow(/date is required/i);
    expect(() => followUpService.create({ follow_up_date: '2030-01-01' })).toThrow(/linked to a customer, lead, or booking/i);
  });

  it('derives Overdue for a past pending date and Pending for a future one, without a stored status change', () => {
    const past = followUpService.create({ follow_up_date: '2020-01-01', customer_id: customerId });
    const future = followUpService.create({ follow_up_date: '2099-06-15', customer_id: customerId });
    expect(followUpService.get(past.id).effective_status).toBe('Overdue');
    expect(followUpService.get(future.id).effective_status).toBe('Pending');
  });

  it('marking Completed or Cancelled overrides the date-derived status', () => {
    const { id } = followUpService.create({ follow_up_date: '2020-01-01', customer_id: customerId });
    followUpService.markStatus(id, 'Completed');
    expect(followUpService.get(id).effective_status).toBe('Completed');
  });

  it('dueSoon only returns Pending follow-ups within the window', () => {
    followUpService.create({ follow_up_date: '2020-01-01', customer_id: customerId }); // overdue-but-pending -> included (date <= window)
    const future = followUpService.create({ follow_up_date: '2099-01-01', customer_id: customerId });
    followUpService.markStatus(future.id, 'Completed');
    const due = followUpService.dueSoon(3650);
    expect(due.length).toBe(1);
  });

  it('logContact writes history, completes the old follow-up and schedules the next one', () => {
    const old = followUpService.create({ follow_up_date: '2020-01-01', customer_id: customerId });
    const r = followUpService.logContact({
      existing_follow_up_id: old.id, customer_id: customerId, contact_method: 'WhatsApp', activity: 'Message sent',
      purpose: 'Booking confirmation', outcome: 'Interested', next_follow_up_date: '2099-02-02'
    });
    expect(followUpService.get(old.id).effective_status).toBe('Completed');
    expect(followUpService.get(r.next_follow_up_id).effective_status).toBe('Pending');
    const h = followUpService.historyList({ search: 'Booking confirmation' });
    expect(h.total).toBe(1);
    expect(h.rows[0].outcome).toBe('Interested');
  });

  it('logContact works for a typed name with no customer/inquiry', () => {
    followUpService.logContact({ contact_name: 'Walk-in Ali', contact_phone: '0300', contact_method: 'In Person', activity: 'Customer replied' });
    expect(followUpService.historyList({ search: 'Walk-in Ali' }).total).toBe(1);
    expect(() => followUpService.logContact({ contact_method: 'Phone Call', activity: 'Message sent' })).toThrow(/select an inquiry/i);
  });
});
