const { freshDb } = require('./testUtils');
const agentService = require('../agentService');
const commissionService = require('../commissionService');
const bookingService = require('../bookingService');
const customerService = require('../customerService');
const accountService = require('../accountService');
const expenseService = require('../expenseService');
const { getDb } = require('../../../src/database/db');

function mkCustomer() {
  return customerService.create({ full_name: 'Ali Khan', phone: '0300' + Math.floor(Math.random() * 1e7) }).id;
}
function mkBooking(agentId, total = 200000, extra = {}) {
  return bookingService.create({ customer_id: mkCustomer(), booking_type: 'Custom', total_price: total, paid_amount: 0, agent_id: agentId || null, ...extra });
}

describe('agents', () => {
  beforeEach(() => freshDb());

  it('creates sequential codes and validates input', () => {
    expect(() => agentService.create({ name: '' })).toThrow(/name is required/i);
    expect(() => agentService.create({ name: 'A', commission_type: 'Percentage', commission_value: 120 })).toThrow(/more than 100/);
    expect(() => agentService.create({ name: 'A', commission_value: -1 })).toThrow(/negative/);
    expect(() => agentService.create({ name: 'A', email: 'nope' })).toThrow(/email/);
    expect(agentService.create({ name: 'A' }).agentCode).toBe('AG-0001');
    expect(agentService.create({ name: 'B' }).agentCode).toBe('AG-0002');
  });

  it('options() hides inactive agents; delete is blocked once an agent has bookings', () => {
    const a = agentService.create({ name: 'Zed', commission_type: 'Percentage', commission_value: 5 });
    const b = agentService.create({ name: 'Old', status: 'Inactive' });
    expect(agentService.options().map((x) => x.name)).toEqual(['Zed']);
    expect(agentService.options({ includeInactive: true }).length).toBe(2);
    mkBooking(a.id);
    expect(() => agentService.remove(a.id)).toThrow(/cannot be deleted/);
    expect(agentService.remove(b.id).success).toBe(true);
  });
});

describe('commissions', () => {
  beforeEach(() => freshDb());

  it('a booking saved with an agent gets a Pending commission at the agent rate', () => {
    const a = agentService.create({ name: 'Zed', commission_type: 'Percentage', commission_value: 5 });
    const { id } = mkBooking(a.id, 200000);
    const rows = commissionService.list({ bookingId: id }).rows;
    expect(rows.length).toBe(1);
    expect(rows[0]).toMatchObject({ status: 'Pending', commission_amount: 10000, base_amount: 200000, commission_value: 5 });
  });

  it('a booking with no agent has no commission; Fixed type is a flat amount', () => {
    const a = agentService.create({ name: 'Flat', commission_type: 'Fixed', commission_value: 7500 });
    const none = mkBooking(null);
    expect(commissionService.list({ bookingId: none.id }).total).toBe(0);
    const withAgent = mkBooking(a.id, 999);
    expect(commissionService.list({ bookingId: withAgent.id }).rows[0].commission_amount).toBe(7500);
  });

  it('changing the agent default rate later does not change an existing commission', () => {
    const a = agentService.create({ name: 'Zed', commission_type: 'Percentage', commission_value: 5 });
    const { id } = mkBooking(a.id, 100000);
    agentService.update(a.id, { name: 'Zed', commission_type: 'Percentage', commission_value: 20 });
    expect(commissionService.list({ bookingId: id }).rows[0].commission_amount).toBe(5000);
  });

  it('a Pending commission follows a price change; an Approved one does not', () => {
    const a = agentService.create({ name: 'Zed', commission_type: 'Percentage', commission_value: 10 });
    const { id } = mkBooking(a.id, 100000);
    const row = () => commissionService.list({ bookingId: id }).rows[0];
    const b = getDb().prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    const upd = (total) => bookingService.update(id, { customer_id: b.customer_id, booking_type: b.booking_type, total_price: total, paid_amount: 0, status: 'Inquiry' });
    upd(150000);
    expect(row().commission_amount).toBe(15000);
    commissionService.approve(row().id);
    upd(300000);
    expect(row().commission_amount).toBe(15000);
  });

  it('keeps the agent when an update does not mention agent_id, clears it only when asked, and blocks moving an approved commission', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    const c = agentService.create({ name: 'C', commission_value: 10 });
    const { id } = mkBooking(a.id, 100000);
    const b = getDb().prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    const base = { customer_id: b.customer_id, booking_type: b.booking_type, total_price: 100000, paid_amount: 0, status: 'Inquiry' };
    bookingService.update(id, base);
    expect(getDb().prepare('SELECT agent_id FROM bookings WHERE id = ?').get(id).agent_id).toBe(a.id);

    bookingService.update(id, { ...base, agent_id: c.id }); // Pending -> replaced
    const rows = commissionService.list({ bookingId: id }).rows;
    expect(rows.filter((r) => r.status === 'Pending').map((r) => r.agent_id)).toEqual([c.id]);
    expect(rows.filter((r) => r.status === 'Cancelled').map((r) => r.agent_id)).toEqual([a.id]);

    commissionService.approve(rows.find((r) => r.status === 'Pending').id);
    expect(() => bookingService.update(id, { ...base, agent_id: a.id })).toThrow(/already has an approved or paid commission/);
    expect(getDb().prepare('SELECT agent_id FROM bookings WHERE id = ?').get(id).agent_id).toBe(c.id); // rolled back
  });

  it('cancelling the booking cancels open commissions', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    const { id } = mkBooking(a.id, 100000);
    const b = getDb().prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    bookingService.update(id, { customer_id: b.customer_id, booking_type: b.booking_type, total_price: 100000, paid_amount: 0, status: 'Cancelled' });
    expect(commissionService.list({ bookingId: id }).rows[0].status).toBe('Cancelled');
  });

  it('enforces the Pending -> Approved -> Paid flow', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    const { id: bid } = mkBooking(a.id, 100000);
    const cid = commissionService.list({ bookingId: bid }).rows[0].id;
    expect(() => commissionService.pay(cid, {})).toThrow(/Only an Approved/);
    commissionService.approve(cid);
    expect(() => commissionService.approve(cid)).toThrow(/Only a Pending/);
    expect(() => commissionService.update(cid, { commission_value: 1 })).toThrow(/Only a Pending/);
  });

  it('paying creates a real expense and bank transaction; reversing undoes both', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    const bank = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 50000 });
    const { id: bid } = mkBooking(a.id, 100000);
    const cid = commissionService.list({ bookingId: bid }).rows[0].id;
    commissionService.approve(cid);
    expect(() => commissionService.pay(cid, { account_type: 'Bank', account_id: bank.id, payment_method: 'Wire' })).toThrow(/valid payment method/);
    commissionService.pay(cid, { account_type: 'Bank', account_id: bank.id, payment_method: 'Bank Transfer' });

    const c = commissionService.get(cid);
    expect(c.status).toBe('Paid');
    expect(accountService.get('Bank', bank.id).current_balance).toBe(40000);
    const exp = expenseService.get(c.expense_id);
    expect(exp).toMatchObject({ amount: 10000, category_name: 'Agent Commission', related_booking_id: bid });
    expect(() => expenseService.remove(c.expense_id)).toThrow(/Reverse the payment from Commissions/);
    expect(() => commissionService.cancel(cid)).toThrow(/Reverse the payment first/);

    commissionService.reversePayment(cid);
    expect(commissionService.get(cid)).toMatchObject({ status: 'Approved', expense_id: null });
    expect(accountService.get('Bank', bank.id).current_balance).toBe(50000);
    expect(getDb().prepare('SELECT COUNT(*) AS n FROM expenses').get().n).toBe(0);
  });

  it('refuses to pay from an account without enough balance, leaving nothing half-done', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    const cash = accountService.create('Cash', { account_name: 'Till', opening_balance: 100 });
    const { id: bid } = mkBooking(a.id, 100000);
    const cid = commissionService.list({ bookingId: bid }).rows[0].id;
    commissionService.approve(cid);
    expect(() => commissionService.pay(cid, { account_type: 'Cash', account_id: cash.id, payment_method: 'Cash' })).toThrow(/enough balance/);
    expect(commissionService.get(cid).status).toBe('Approved');
    expect(getDb().prepare('SELECT COUNT(*) AS n FROM expenses').get().n).toBe(0);
  });

  it('summary reports per currency and never silently adds different currencies', () => {
    const a = agentService.create({ name: 'A', commission_value: 10 });
    mkBooking(a.id, 100000);
    const { id: usd } = mkBooking(a.id, 1000);
    getDb().prepare("UPDATE commissions SET currency = 'USD' WHERE booking_id = ?").run(usd);
    const s = commissionService.summary();
    expect(s.mixed_currency).toBe(true);
    expect(s.converted.complete).toBe(false);
    expect(s.converted.missing).toEqual(['USD']);
    require('../exchangeRateService').create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2020-01-01' });
    const s2 = commissionService.summary();
    expect(s2.converted.complete).toBe(true);
    expect(s2.converted.pending).toBe(10000 + 100 * 280);
  });
});
