const { freshDb } = require('./testUtils');
const supplierService = require('../supplierService');
const supplierLedgerService = require('../supplierLedgerService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const supplierReportService = require('../supplierReportService');

describe('supplierService', () => {
  beforeEach(() => freshDb());

  it('requires a name and generates a sequential supplier code', () => {
    expect(() => supplierService.create({})).toThrow(/name is required/i);
    const a = supplierService.create({ name: 'Emirates GSA', service_type: 'Airline' });
    const b = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' });
    expect(supplierService.get(a.id).supplier_code).toBe('SUP-00001');
    expect(supplierService.get(b.id).supplier_code).toBe('SUP-00002');
  });

  it('posts an opening balance to the ledger on creation', () => {
    const { id } = supplierService.create({ name: 'Al Safar Transport', opening_balance: 15000 });
    expect(supplierLedgerService.getBalance(id)).toBe(15000);
  });

  it('blocks deleting a supplier that has invoices or payments', () => {
    const { id } = supplierService.create({ name: 'City Tours' });
    supplierInvoiceService.create({ supplier_id: id, invoice_number: 'INV-1', amount: 1000 });
    expect(() => supplierService.remove(id)).toThrow(/existing invoices or payments/i);
  });
});

describe('supplierInvoiceService + supplierPaymentService', () => {
  let supplierId;
  beforeEach(() => {
    freshDb();
    supplierId = supplierService.create({ name: 'Saudi Airlines GSA', service_type: 'Airline' }).id;
  });

  it('creating an invoice adds a debit ledger entry for its total (amount + tax)', () => {
    supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-1', amount: 100000, tax: 5000 });
    expect(supplierLedgerService.getBalance(supplierId)).toBe(105000);
  });

  it('derives status from paid vs total, and full payment marks it Paid', () => {
    const inv = supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-2', amount: 50000 });
    expect(supplierInvoiceService.get(inv.id).status).toBe('Unpaid');

    supplierPaymentService.create({ supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 20000 });
    expect(supplierInvoiceService.get(inv.id).status).toBe('Partially Paid');

    supplierPaymentService.create({ supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 30000 });
    const final = supplierInvoiceService.get(inv.id);
    expect(final.status).toBe('Paid');
    expect(final.remaining_amount).toBe(0);
  });

  it('rejects a payment that would exceed the invoice total', () => {
    const inv = supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-3', amount: 10000 });
    expect(() =>
      supplierPaymentService.create({ supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 20000 })
    ).toThrow(/exceed the invoice total/i);
  });

  it('voiding a payment reverses the invoice balance and the ledger', () => {
    const inv = supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-4', amount: 40000 });
    const payment = supplierPaymentService.create({ supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 40000 });
    expect(supplierInvoiceService.get(inv.id).status).toBe('Paid');

    supplierPaymentService.remove(payment.id);
    const reverted = supplierInvoiceService.get(inv.id);
    expect(reverted.status).toBe('Unpaid');
    expect(reverted.paid_amount).toBe(0);
    expect(supplierLedgerService.getBalance(supplierId)).toBe(40000);
  });

  it('refuses to delete a supplier invoice that has payments recorded', () => {
    const inv = supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-5', amount: 10000 });
    supplierPaymentService.create({ supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 5000 });
    expect(() => supplierInvoiceService.remove(inv.id)).toThrow(/payments recorded/i);
  });

  it('posts a bank/cash account transaction when a payment names an account', () => {
    const db = require('../../../src/database/db').getDb();
    const acc = db.prepare("INSERT INTO cash_accounts (account_name, currency, opening_balance, current_balance) VALUES ('Main Till', 'PKR', 100000, 100000)").run();
    const inv = supplierInvoiceService.create({ supplier_id: supplierId, invoice_number: 'SUP-6', amount: 20000 });
    supplierPaymentService.create({
      supplier_id: supplierId, supplier_invoice_id: inv.id, amount: 20000,
      account_type: 'Cash', account_id: acc.lastInsertRowid
    });
    const account = db.prepare('SELECT current_balance FROM cash_accounts WHERE id = ?').get(acc.lastInsertRowid);
    expect(account.current_balance).toBe(80000);
  });
});

describe('supplierReportService', () => {
  beforeEach(() => {
    freshDb();
    const s = supplierService.create({ name: 'Qatar Airways GSA', service_type: 'Airline' }).id;
    supplierInvoiceService.create({ supplier_id: s, invoice_number: 'Q-1', amount: 75000 });
  });

  it('runs every registered report type without error and returns columns+rows', () => {
    for (const { key } of supplierReportService.listReportTypes()) {
      const result = supplierReportService.run(key, {});
      expect(result.columns.length).toBeGreaterThan(0);
      expect(Array.isArray(result.rows)).toBe(true);
    }
  });

  it('the payables report only lists unpaid/partial invoices and totals them', () => {
    const result = supplierReportService.run('payables', {});
    expect(result.rows.length).toBe(1);
    expect(result.totals.remaining_amount).toBe(75000);
  });
});
