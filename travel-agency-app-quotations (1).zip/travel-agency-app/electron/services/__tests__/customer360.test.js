const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const c360 = require('../customer360Service');

// Scenario used across tests (all amounts are real transactions written
// through the same services the UI uses):
//   Customer "Muhammad Ali"
//   B1  Umrah   selling 425,000  confirmed   invoice 425,000  paid 100,000 (advance tied to booking) + 200,000 (partial on invoice)
//       services: flight cost 90,000, hotel cost 120,000, visa cost 30,000 (estimated)
//   B2  Tour    selling 100,000  confirmed   supplier invoice 70,000 (ACTUAL cost) + estimated hotel cost 999,999 that must be ignored
//   B3  Hajj    selling 500,000  cancelled   no money
//   unapplied advance 50,000 (no booking/invoice), refund 10,000 on B1
function seed() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  const db = getDb();
  const cust = customerService.create({ full_name: 'Muhammad Ali', phone: '0300-1', email: 'ali@example.com' }).id;

  const b1 = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 425000, status: 'Confirmed', departure_date: '2099-03-01', return_date: '2099-03-15' }).id;
  const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 100000, status: 'Confirmed', departure_date: '2000-01-10', return_date: '2000-01-20' }).id;
  const b3 = bookingService.create({ customer_id: cust, booking_type: 'Hajj', total_price: 500000, status: 'Cancelled' }).id;

  const inv1 = invoiceService.create({ customer_id: cust, booking_id: b1, items: [{ description: 'Umrah', quantity: 1, unit_price: 425000 }] }).id;

  // estimated service costs
  db.prepare(`INSERT INTO flights (booking_id, airline, cost, selling_price) VALUES (?, 'SV', 90000, 110000)`).run(b1);
  db.prepare(`INSERT INTO hotels (booking_id, hotel_name, cost, selling_price) VALUES (?, 'Hilton', 120000, 150000)`).run(b1);
  db.prepare(`INSERT INTO visa_applications (customer_id, booking_id, cost, selling_price) VALUES (?, ?, 30000, 40000)`).run(cust, b1);
  db.prepare(`INSERT INTO hotels (booking_id, hotel_name, cost) VALUES (?, 'Ignored Estimate', 999999)`).run(b2);

  const sup = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
  supplierInvoiceService.create({ supplier_id: sup, booking_id: b2, invoice_number: 'S-1', amount: 70000 });

  paymentService.create({ customer_id: cust, booking_id: b1, amount: 100000, payment_method: 'Cash', payment_type: 'Advance' });
  paymentService.create({ customer_id: cust, invoice_id: inv1, amount: 200000, payment_method: 'Bank Transfer', payment_type: 'Partial' });
  paymentService.create({ customer_id: cust, amount: 50000, payment_method: 'Cash', payment_type: 'Advance' });
  paymentService.create({ customer_id: cust, invoice_id: inv1, amount: 10000, payment_method: 'Cash', payment_type: 'Refund' });

  return { cust, b1, b2, b3, inv1 };
}

describe('customer360Service', () => {
  it('header shows a stable customer code and details', () => {
    const { cust } = seed();
    const h = c360.header(cust);
    expect(h.customer_code).toBe(`CUST-${String(cust).padStart(5, '0')}`);
    expect(h.full_name).toBe('Muhammad Ali');
    expect(h.status).toBe('Active');
    expect(h.registration_date).toBeTruthy();
  });

  it('throws for an unknown customer', () => {
    seed();
    expect(() => c360.summary(99999)).toThrow(/not found/i);
  });

  it('counts bookings by status', () => {
    const { cust } = seed();
    const s = c360.summary(cust);
    expect(s.bookings.total).toBe(3);
    expect(s.bookings.active).toBe(2);
    expect(s.bookings.completed).toBe(0);
    expect(s.bookings.cancelled).toBe(1);
  });

  it('derives paid / refund / advance figures from payments without double counting', () => {
    const { cust } = seed();
    const s = c360.summary(cust);
    expect(s.payments.total_paid).toBe(350000);      // 100k + 200k + 50k, refund excluded
    expect(s.payments.total_refunds).toBe(10000);
    expect(s.payments.net_received).toBe(340000);
    expect(s.advance.received).toBe(150000);         // two advance rows
    expect(s.advance.used).toBe(100000);             // the one tied to a booking
    expect(s.advance.remaining).toBe(50000);
    expect(s.payments.last_payment_date).toBeTruthy();
  });

  it('billed is the sum of non-cancelled invoices and outstanding equals the customer ledger balance', () => {
    const { cust } = seed();
    const s = c360.summary(cust);
    expect(s.invoices.count).toBe(1);
    expect(s.invoices.total_billed).toBe(425000);
    // ledger: +425,000 invoice - 100k - 200k - 50k + 10k refund = 85,000
    expect(s.outstanding_balance).toBe(85000);
  });

  it('uses ACTUAL supplier invoices instead of estimates for a booking that has them, estimates otherwise', () => {
    const { cust } = seed();
    const s = c360.summary(cust);
    const cb = s.profitability.cost_breakdown;
    expect(cb.supplier_invoices).toBe(70000);        // B2 actual
    expect(cb.hotel).toBe(120000);                   // B1 estimate only; B2's 999,999 estimate ignored
    expect(cb.flight).toBe(90000);
    expect(cb.visa).toBe(30000);
    expect(s.profitability.total_cost).toBe(310000);
  });

  it('computes gross profit and margin from billed revenue', () => {
    const { cust } = seed();
    const p = c360.summary(cust).profitability;
    expect(p.revenue).toBe(425000);
    expect(p.gross_profit).toBe(115000);
    expect(p.margin_percent).toBeCloseTo(27.06, 1);
  });

  it('finds last and next travel dates ignoring cancelled bookings', () => {
    const { cust } = seed();
    const s = c360.summary(cust, { today: '2026-09-28' });
    expect(s.travel.last_travel_date).toBe('2000-01-10');
    expect(s.travel.next_travel_date).toBe('2099-03-01');
  });

  it('a customer with no activity shows zeros, not fake numbers', () => {
    freshDb();
    const cust = customerService.create({ full_name: 'Empty Customer' }).id;
    const s = c360.summary(cust);
    expect(s.bookings.total).toBe(0);
    expect(s.invoices.total_billed).toBe(0);
    expect(s.outstanding_balance).toBe(0);
    expect(s.profitability.margin_percent).toBeNull();
    expect(s.travel.next_travel_date).toBeNull();
    expect(c360.bookingHistory(cust).items).toHaveLength(0);
  });

  describe('booking history', () => {
    it('returns per-booking selling, paid, advance, outstanding, cost, profit', () => {
      const { cust, b1, b2 } = seed();
      const h = c360.bookingHistory(cust, { sortBy: 'selling', sortDir: 'desc' });
      expect(h.total).toBe(3);
      const r1 = h.items.find((x) => x.id === b1);
      expect(r1.selling).toBe(425000);
      expect(r1.paid).toBe(290000);                  // 100k + 200k - 10k refund
      expect(r1.advance).toBe(100000);
      expect(r1.outstanding).toBe(135000);
      expect(r1.cost).toBe(240000);
      expect(r1.cost_source).toBe('estimated');
      expect(r1.profit).toBe(185000);
      expect(r1.payment_status).toBe('Partial');
      const r2 = h.items.find((x) => x.id === b2);
      expect(r2.cost).toBe(70000);
      expect(r2.cost_source).toBe('actual');
      expect(r2.payment_status).toBe('Unpaid');
    });

    it('cancelled booking with no supplier invoice carries zero cost', () => {
      const { cust, b3 } = seed();
      const r = c360.bookingHistory(cust).items.find((x) => x.id === b3);
      expect(r.cost).toBe(0);
    });

    it('filters by type, status, payment status, amount range and search, in SQL', () => {
      const { cust } = seed();
      expect(c360.bookingHistory(cust, { bookingType: 'Umrah' }).total).toBe(1);
      expect(c360.bookingHistory(cust, { status: 'Cancelled' }).total).toBe(1);
      expect(c360.bookingHistory(cust, { paymentStatus: 'Unpaid' }).total).toBe(2);
      expect(c360.bookingHistory(cust, { minAmount: 200000, maxAmount: 450000 }).total).toBe(1);
      expect(c360.bookingHistory(cust, { search: 'BK-' }).total).toBe(3);
      expect(c360.bookingHistory(cust, { search: 'no-such-thing' }).total).toBe(0);
      expect(c360.bookingHistory(cust, { currency: 'PKR' }).total).toBe(3);
      expect(c360.bookingHistory(cust, { currency: 'USD' }).total).toBe(0);
    });

    it('sorts and paginates', () => {
      const { cust } = seed();
      const p1 = c360.bookingHistory(cust, { sortBy: 'selling', sortDir: 'asc', page: 1, pageSize: 2 });
      expect(p1.items).toHaveLength(2);
      expect(p1.total).toBe(3);
      expect(p1.items[0].selling).toBe(100000);
      const p2 = c360.bookingHistory(cust, { sortBy: 'selling', sortDir: 'asc', page: 2, pageSize: 2 });
      expect(p2.items).toHaveLength(1);
      expect(p2.items[0].selling).toBe(500000);
    });

    it('pageSize 0 returns everything (for export) and an unknown sort column falls back safely', () => {
      const { cust } = seed();
      expect(c360.bookingHistory(cust, { pageSize: 0 }).items).toHaveLength(3);
      expect(() => c360.bookingHistory(cust, { sortBy: 'id; DROP TABLE bookings' })).not.toThrow();
      expect(getDb().prepare('SELECT COUNT(*) AS c FROM bookings').get().c).toBe(3);
    });

    it('only ever returns the requested customer\'s bookings', () => {
      const { cust } = seed();
      const other = customerService.create({ full_name: 'Someone Else' }).id;
      bookingService.create({ customer_id: other, booking_type: 'Tour', total_price: 1 });
      expect(c360.bookingHistory(cust).total).toBe(3);
      expect(c360.bookingHistory(other).total).toBe(1);
    });
  });

  describe('timeline', () => {
    it('lists real events newest-first with event, reference and date', () => {
      const { cust } = seed();
      const t = c360.timeline(cust);
      const events = t.items.map((e) => e.event);
      expect(events).toContain('Customer created');
      expect(events).toContain('Booking created');
      expect(events).toContain('Invoice generated');
      expect(events).toContain('Payment received');
      expect(events).toContain('Advance received');
      expect(events).toContain('Refund issued');
      expect(events).toContain('Flight booked');
      expect(events).toContain('Booking cancelled');
      const dates = t.items.map((e) => e.at);
      expect([...dates].sort().reverse()).toEqual(dates);
      expect(t.items.every((e) => e.at)).toBe(true);
    });

    it('does not leak another customer\'s events and paginates', () => {
      const { cust } = seed();
      const other = customerService.create({ full_name: 'Other' }).id;
      expect(c360.timeline(other).items.map((e) => e.event)).toEqual(['Customer created']);
      const p = c360.timeline(cust, { page: 1, pageSize: 3 });
      expect(p.items).toHaveLength(3);
      expect(p.total).toBeGreaterThan(3);
    });
  });

  it('getDossier bundles header, summary and currencies', () => {
    const { cust } = seed();
    const d = c360.getDossier(cust);
    expect(d.header.full_name).toBe('Muhammad Ali');
    expect(d.summary.bookings.total).toBe(3);
    expect(d.currencies).toEqual(['PKR']);
  });
});

describe('customer360Service multi-currency transparency (master prompt section 53)', () => {
  it('reports a per-currency breakdown and flags a customer whose bookings span currencies - never one silent total', () => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    const packageService = require('../packageService');
    const cust = customerService.create({ full_name: 'Two Currencies' }).id;
    const usd = packageService.create({ package_name: 'USD Tour', package_type: 'Tour', selling_price: 1000, currency: 'USD', components: [{ component_type: 'Hotel', description: 'x', cost: 1, selling_price: 1 }] }).id;
    bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 50000 });          // default currency (PKR)
    bookingService.create({ customer_id: cust, package_id: usd });                                    // the package's currency (USD)
    const s = c360.summary(cust);
    expect(s.mixed_currency).toBe(true);
    const by = Object.fromEntries(s.currencies.map((c) => [c.currency, c]));
    expect(by.PKR.selling).toBe(50000);
    expect(by.USD.selling).toBe(1000);
    expect(by.PKR.bookings).toBe(1);
  });

  it('a single-currency customer is not flagged, and a cancelled booking does not count towards a currency', () => {
    freshDb();
    const packageService = require('../packageService');
    const cust = customerService.create({ full_name: 'One Currency' }).id;
    const usd = packageService.create({ package_name: 'USD Tour', package_type: 'Tour', selling_price: 1000, currency: 'USD', components: [{ component_type: 'Hotel', description: 'x', cost: 1, selling_price: 1 }] }).id;
    bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 50000 });
    const cancelled = bookingService.create({ customer_id: cust, package_id: usd }).id;
    bookingService.update(cancelled, { customer_id: cust, booking_type: 'Tour', total_price: 1000, status: 'Cancelled' });
    const s = c360.summary(cust);
    expect(s.mixed_currency).toBe(false);
    expect(s.currencies.map((c) => c.currency)).toEqual(['PKR']);
  });
});
