const { freshDb } = require('./testUtils');
const fs = require('../financialStatementsService');
const fx = require('../exchangeRateService');
const lock = require('../periodLockService');
const accountService = require('../accountService');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const paymentService = require('../paymentService');
const expenseService = require('../expenseService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const accountingService = require('../accountingService');
const { getDb } = require('../../../src/database/db');

const row = (t, code) => t.rows.find((r) => r.code === code);

describe('period lock and year-end close', () => {
  let cust, cash, cat;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Lock Test' }).id;
    cash = accountService.create('Cash', { account_name: 'Till', opening_balance: 100000 }).id;
    cat = expenseService.createCategory('Rent').id;
  });

  it('nothing is locked by default and the status says so', () => {
    expect(lock.getLockDate()).toBeNull();
    expect(lock.status().closes).toEqual([]);
  });

  it('validates dates: valid, before today, later than the previous close', () => {
    expect(() => lock.setManualLock('nope')).toThrow(/valid/);
    expect(() => lock.setManualLock('2999-01-01')).toThrow(/before today/);
    expect(() => lock.closeYear({ closeDate: '2999-12-31' })).toThrow(/before today/);
    lock.closeYear({ closeDate: '2025-12-31' });
    expect(() => lock.closeYear({ closeDate: '2025-06-30' })).toThrow(/already closed through 2025-12-31/);
    expect(() => lock.closeYear({ closeDate: '2025-12-31' })).toThrow(/already closed/);
  });

  it('a lock blocks adding, changing and deleting records dated inside the period - and only those', () => {
    const e = expenseService.create({ expense_date: '2025-03-10', category_id: cat, amount: 500, payment_method: 'Cash' });
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'x', quantity: 1, unit_price: 100 }] });
    getDb().prepare("UPDATE invoices SET invoice_date = '2025-04-01' WHERE id = ?").run(inv.id);
    const si = supplierInvoiceService.create({ supplier_id: supplierService.create({ name: 'S' }).id, invoice_number: 'L-1', amount: 100, invoice_date: '2025-05-01' });

    lock.setManualLock('2025-12-31');
    expect(() => expenseService.create({ expense_date: '2025-12-31', category_id: cat, amount: 1, payment_method: 'Cash' })).toThrow(/locked through 2025-12-31/);
    expect(() => expenseService.update(e.id, { expense_date: '2026-01-05', category_id: cat, amount: 500, payment_method: 'Cash' })).toThrow(/locked/);
    expect(() => expenseService.remove(e.id)).toThrow(/locked/);
    expect(() => invoiceService.cancel(inv.id)).toThrow(/locked/);
    expect(() => supplierInvoiceService.remove(si.id)).toThrow(/locked/);
    expect(() => supplierInvoiceService.create({ supplier_id: 1, invoice_number: 'L-2', amount: 5, invoice_date: '2025-11-11' })).toThrow(/locked/);
    expect(() => accountingService.create({ account: 'Rev', credit: 1, entry_date: '2025-02-02' })).toThrow(/locked/);

    // dates after the lock, and "today" entries, are untouched
    expenseService.create({ expense_date: '2026-01-02', category_id: cat, amount: 5, payment_method: 'Cash' });
    paymentService.create({ customer_id: cust, amount: 10, payment_method: 'Cash', payment_type: 'Advance', account_type: 'Cash', account_id: cash });
    accountService.manualDeposit({ account_type: 'Cash', account_id: cash, amount: 1, description: 'ok' });

    lock.setManualLock(null);
    expenseService.remove(e.id); // unlocked again
  });

  it('voiding a payment dated inside a locked period is refused; the correction is a new entry', () => {
    const p = paymentService.create({ customer_id: cust, amount: 10, payment_method: 'Cash', payment_type: 'Advance', account_type: 'Cash', account_id: cash });
    getDb().prepare("UPDATE payments SET payment_date = '2025-02-01' WHERE id = ?").run(p.id);
    lock.setManualLock('2025-12-31');
    expect(() => paymentService.remove(p.id)).toThrow(/Payment #\d+ is dated 2025-02-01/);
  });

  it('year-end close moves the year profit into Retained Earnings and starts the new year at zero', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Umrah', quantity: 1, unit_price: 100000 }] });
    getDb().prepare("UPDATE invoices SET invoice_date = '2025-06-01' WHERE id = ?").run(inv.id);
    expenseService.create({ expense_date: '2025-07-01', category_id: cat, amount: 30000, payment_method: 'Cash', account_type: 'Cash', account_id: cash });

    const before = fs.balanceSheet({ asOf: '2025-12-31' });
    expect(before.profit_to_date).toBe(70000);

    lock.closeYear({ closeDate: '2025-12-31' });
    const after = fs.balanceSheet({ asOf: '2025-12-31' });
    expect(after.balanced).toBe(true);
    expect(after.profit_to_date).toBe(0);
    expect(after.equity.find((e) => e.label === 'Retained Earnings').amount).toBe(70000);
    expect(after.total_equity).toBe(before.total_equity);   // equity is unchanged, only re-labelled

    const tb = fs.trialBalance({ asOf: '2025-12-31' });
    expect(tb.balanced).toBe(true);
    expect(row(tb, '3300').credit).toBe(70000);
    const sales = row(tb, '4000');
    expect(sales.debit + sales.credit).toBe(0);              // revenue account closed to zero

    // before the close date the year is still open in the books
    expect(fs.trialBalance({ asOf: '2025-12-30' }).rows.find((r) => r.code === '4000').credit).toBe(100000);

    // a new year's activity starts from zero
    const inv2 = invoiceService.create({ customer_id: cust, items: [{ description: 'New', quantity: 1, unit_price: 5000 }] });
    const bs = fs.balanceSheet();
    expect(bs.profit_to_date).toBe(5000);
    expect(bs.equity.find((e) => e.label === 'Retained Earnings').amount).toBe(70000);
    expect(bs.balanced).toBe(true);
    expect(inv2.id).toBeGreaterThan(0);
  });

  it('only the newest close can be undone, and undoing restores the open year', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'x', quantity: 1, unit_price: 1000 }] });
    getDb().prepare("UPDATE invoices SET invoice_date = '2024-06-01' WHERE id = ?").run(inv.id);
    lock.closeYear({ closeDate: '2024-12-31' });
    lock.closeYear({ closeDate: '2025-12-31' });
    expect(lock.reopenLastClose().reopened).toBe('2025-12-31');
    expect(lock.getLockDate()).toBe('2024-12-31');
    lock.reopenLastClose();
    expect(lock.getLockDate()).toBeNull();
    expect(() => lock.reopenLastClose()).toThrow(/no year-end close/);
    expect(fs.balanceSheet({ asOf: '2025-12-31' }).profit_to_date).toBe(1000);
  });

  it('FX revaluation after a close counts only the movement since the close', () => {
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
    const usd = accountService.create('Bank', { account_name: 'USD', bank_name: 'B', currency: 'USD', opening_balance: 1000 }).id;
    getDb().prepare("UPDATE bank_accounts SET created_at = '2025-01-10' WHERE id = ?").run(usd);
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 290, effective_date: '2025-12-01' });
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 300, effective_date: '2026-02-01' });
    lock.closeYear({ closeDate: '2025-12-31' });
    const bs = fs.balanceSheet({ asOf: '2026-03-01' });
    expect(bs.balanced).toBe(true);
    expect(bs.equity.find((e) => e.label === 'Retained Earnings').amount).toBe(10000);  // 1000 x (290-280)
    expect(bs.profit_to_date).toBe(10000);                                              // 1000 x (300-290) since the close
    expect(bs.cash_total).toBe(300000);
  });
});

describe('payments in a different currency than the invoice', () => {
  let cust, usdInv, pkrBank, usdBank;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
    cust = customerService.create({ full_name: 'Cross Pay' }).id;
    const b = bookingService.create({ customer_id: cust, booking_type: 'Custom', total_price: 1000, paid_amount: 0 });
    getDb().prepare("UPDATE bookings SET currency = 'USD' WHERE id = ?").run(b.id);
    usdInv = invoiceService.createFromBooking(b.id).id;
    pkrBank = accountService.create('Bank', { account_name: 'PKR bank', bank_name: 'B', currency: 'PKR', opening_balance: 0 }).id;
    usdBank = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'B', currency: 'USD', opening_balance: 0 }).id;
  });
  const pay = (extra) => paymentService.create({ customer_id: cust, invoice_id: usdInv, amount: 1000, payment_method: 'Bank Transfer', payment_type: 'Full', account_type: 'Bank', account_id: pkrBank, ...extra });

  it('needs the amount actually received, then settles the invoice in its own currency', () => {
    expect(() => pay({})).toThrow(/Enter the amount actually received in PKR/);
    pay({ received_amount: 285000 });
    const inv = getDb().prepare('SELECT * FROM invoices WHERE id = ?').get(usdInv);
    expect(inv.paid_amount).toBe(1000);
    expect(inv.status).toBe('Paid');
    expect(accountService.get('Bank', pkrBank).current_balance).toBe(285000);   // the account moved by what was received
    expect(getDb().prepare('SELECT currency, amount, received_amount FROM payments').get()).toEqual({ currency: 'USD', amount: 1000, received_amount: 285000 });
  });

  it('voiding gives back exactly what was received', () => {
    const p = pay({ received_amount: 285000 });
    paymentService.remove(p.id);
    expect(accountService.get('Bank', pkrBank).current_balance).toBe(0);
    expect(getDb().prepare('SELECT paid_amount FROM invoices WHERE id = ?').get(usdInv).paid_amount).toBe(0);
  });

  it('the books show the exchange difference as FX gain, nothing owed, and bank reconciled', () => {
    pay({ received_amount: 285000 });
    const t = fs.trialBalance();
    expect(row(t, '4000').credit).toBe(280000);              // sold at 280
    expect(row(t, `1200-${pkrBank}`).debit).toBe(285000);    // PKR really received
    expect(row(t, '4900').credit).toBe(5000);                // difference
    const ar = row(t, '1300');
    expect(ar.debit + ar.credit).toBe(0);
    expect(t.balanced).toBe(true);
    expect(fs.balanceSheet().balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);
  });

  it('same-currency payments need no extra amount', () => {
    pay({ account_id: usdBank });
    expect(accountService.get('Bank', usdBank).current_balance).toBe(1000);
  });
});

describe('supplier payments and transfers across currencies', () => {
  beforeEach(() => {
    freshDb();
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
  });

  it('a USD supplier invoice paid from a PKR account needs the PKR amount that left', () => {
    const sup = supplierService.create({ name: 'Hotel' }).id;
    const si = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'U-1', amount: 1000, currency: 'USD' });
    const pkr = accountService.create('Bank', { account_name: 'P', bank_name: 'B', currency: 'PKR', opening_balance: 400000 }).id;
    const args = { supplier_id: sup, supplier_invoice_id: si.id, amount: 1000, payment_method: 'Bank Transfer', account_type: 'Bank', account_id: pkr };
    expect(() => supplierPaymentService.create(args)).toThrow(/amount that actually left the account in PKR/);
    expect(() => supplierPaymentService.create({ ...args, currency: 'PKR', account_amount: 1 })).toThrow(/must be in USD/);
    const p = supplierPaymentService.create({ ...args, account_amount: 290000 });
    expect(accountService.get('Bank', pkr).current_balance).toBe(110000);
    expect(getDb().prepare('SELECT paid_amount FROM supplier_invoices WHERE id = ?').get(si.id).paid_amount).toBe(1000);

    const t = fs.trialBalance();
    expect(row(t, '5000').debit).toBe(280000);
    expect(row(t, `1200-${pkr}`).debit).toBe(110000);
    expect(row(t, '4900').debit).toBe(10000);                // paid more PKR than booked -> loss
    expect(t.balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);

    supplierPaymentService.remove(p.id);
    expect(accountService.get('Bank', pkr).current_balance).toBe(400000);
  });

  it('a transfer between a USD and a PKR account needs the arriving amount and posts as one balanced entry', () => {
    const usd = accountService.create('Bank', { account_name: 'U', bank_name: 'B', currency: 'USD', opening_balance: 1000 }).id;
    const pkr = accountService.create('Bank', { account_name: 'P', bank_name: 'B', currency: 'PKR', opening_balance: 0 }).id;
    const args = { from_type: 'Bank', from_id: usd, to_type: 'Bank', to_id: pkr, amount: 500 };
    expect(() => accountService.transfer(args)).toThrow(/different currencies \(USD and PKR\)/);
    accountService.transfer({ ...args, to_amount: 142000 });
    expect(accountService.get('Bank', usd).current_balance).toBe(500);
    expect(accountService.get('Bank', pkr).current_balance).toBe(142000);
    const t = fs.trialBalance();
    expect(row(t, `1200-${pkr}`).debit).toBe(142000);
    expect(row(t, `1200-${usd}`).debit).toBe(140000);       // 500 USD left of 1000 at 280
    expect(row(t, '4900').credit).toBe(2000);               // 142000 arrived for 140000 (at 280) that left
    expect(t.balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);
  });
});
