const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const flightService = require('../flightService');
const hotelService = require('../hotelService');
const visaService = require('../visaService');
const transportationService = require('../transportationService');

describe('flightService', () => {
  let c1, c2;
  beforeEach(() => {
    freshDb();
    c1 = customerService.create({ full_name: 'Passenger A' }).id;
    c2 = customerService.create({ full_name: 'Passenger B' }).id;
  });

  it('rejects an empty flight number', () => {
    expect(() => flightService.create({})).toThrow(/flight number is required/i);
  });

  it('rejects arrival before departure', () => {
    expect(() => flightService.create({ flight_number: 'F1', departure_date: '2026-12-10', arrival_date: '2026-12-01' })).toThrow(
      /arrival date cannot be before/i
    );
  });

  it('manages a multi-passenger manifest without duplicates', () => {
    const flight = flightService.create({ flight_number: 'SV-718', airline: 'Saudia' });
    flightService.passengers.add(flight.id, c1);
    flightService.passengers.add(flight.id, c2);
    expect(flightService.passengers.list(flight.id)).toHaveLength(2);
    expect(() => flightService.passengers.add(flight.id, c1)).toThrow(/already on the flight/i);
  });

  it('paginates and searches', () => {
    for (let i = 0; i < 25; i++) flightService.create({ flight_number: `FL-${i}` });
    const page1 = flightService.list({ page: 1, pageSize: 10 });
    expect(page1.rows).toHaveLength(10);
    expect(page1.total).toBe(25);
    expect(flightService.list({ search: 'FL-5' }).total).toBeGreaterThanOrEqual(1);
  });
});

describe('hotelService', () => {
  beforeEach(() => freshDb());

  it('rejects check-out before check-in', () => {
    expect(() => hotelService.create({ hotel_name: 'X', check_in: '2026-11-05', check_out: '2026-11-01' })).toThrow(
      /check-out date cannot be before/i
    );
  });

  it('paginates', () => {
    for (let i = 0; i < 15; i++) hotelService.create({ hotel_name: `Hotel ${i}` });
    expect(hotelService.list({ page: 1, pageSize: 5 }).rows).toHaveLength(5);
    expect(hotelService.list({}).total).toBe(15);
  });
});

describe('visaService', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    cust = customerService.create({ full_name: 'Visa Applicant' }).id;
  });

  it('rejects a visa with no customer', () => {
    expect(() => visaService.create({ country: 'Saudi Arabia' })).toThrow(/customer must be selected/i);
  });

  it('flags a visa expiring within 30 days', () => {
    const soon = new Date();
    soon.setDate(soon.getDate() + 10);
    visaService.create({ customer_id: cust, country: 'Saudi Arabia', status: 'Approved', expiry_date: soon.toISOString().slice(0, 10) });
    const list = visaService.list({});
    expect(list.rows[0].expiringSoon).toBe(true);
  });

  it('does not flag a visa that is not Approved, even if the date is soon', () => {
    const soon = new Date();
    soon.setDate(soon.getDate() + 10);
    visaService.create({ customer_id: cust, country: 'UAE', status: 'Processing', expiry_date: soon.toISOString().slice(0, 10) });
    expect(visaService.list({}).rows[0].expiringSoon).toBe(false);
  });
});

describe('transportationService', () => {
  beforeEach(() => freshDb());

  it('rejects an empty pickup location', () => {
    expect(() => transportationService.create({})).toThrow(/pickup location is required/i);
  });

  it('rejects an invalid status', () => {
    expect(() => transportationService.create({ pickup_location: 'Airport', status: 'NotAStatus' })).toThrow(/valid status/i);
  });
});
