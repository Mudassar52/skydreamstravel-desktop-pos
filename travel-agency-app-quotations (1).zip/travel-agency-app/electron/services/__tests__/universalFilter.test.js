const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const paymentService = require('../paymentService');
const savedFilterService = require('../savedFilterService');

describe('date-range filtering (Universal Filter backend)', () => {
  let custId;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    custId = customerService.create({ full_name: 'Filter Customer' }).id;
  });

  it('bookingService.list filters by a chosen date field (departure_date), not just booking_date', () => {
    bookingService.create({ customer_id: custId, booking_type: 'Custom', total_price: 1000, departure_date: '2025-01-15' });
    bookingService.create({ customer_id: custId, booking_type: 'Custom', total_price: 2000, departure_date: '2027-06-15' });

    const in2027 = bookingService.list({ dateField: 'departure_date', dateFrom: '2027-01-01', dateTo: '2027-12-31' });
    expect(in2027.total).toBe(1);

    const both = bookingService.list({ dateField: 'departure_date', dateFrom: '2020-01-01', dateTo: '2030-01-01' });
    expect(both.total).toBe(2);
  });

  it('bookingService.list ignores an unrecognised dateField rather than erroring (falls back safely)', () => {
    bookingService.create({ customer_id: custId, booking_type: 'Custom', total_price: 1000 });
    expect(() => bookingService.list({ dateField: 'DROP TABLE bookings', dateFrom: '2020-01-01', dateTo: '2030-01-01' })).not.toThrow();
  });

  it('invoiceService.list filters by due_date', () => {
    invoiceService.create({ customer_id: custId, due_date: '2027-03-01', items: [{ description: 'X', quantity: 1, unit_price: 5000 }] });
    expect(invoiceService.list({ dateField: 'due_date', dateFrom: '2027-01-01', dateTo: '2027-12-31' }).total).toBe(1);
    expect(invoiceService.list({ dateField: 'due_date', dateFrom: '2030-01-01', dateTo: '2031-01-01' }).total).toBe(0);
  });

  it('paymentService.list filters by payment_date range', () => {
    const inv = invoiceService.create({ customer_id: custId, items: [{ description: 'X', quantity: 1, unit_price: 1000 }] });
    paymentService.create({ customer_id: custId, invoice_id: inv.id, amount: 500, payment_method: 'Cash', payment_type: 'Partial' });
    expect(paymentService.list({ dateFrom: '2020-01-01', dateTo: '2099-01-01' }).total).toBe(1);
    expect(paymentService.list({ dateFrom: '2099-01-01', dateTo: '2099-12-31' }).total).toBe(0);
  });
});

describe('savedFilterService integration with a real page filter shape', () => {
  it('round-trips a Bookings-page-shaped filter object exactly', () => {
    freshDb();
    const shape = { search: '', status: 'Pending', type: 'All', dateFilter: { preset: 'thisMonth', from: '2027-01-01', to: '2027-01-31', dateField: 'departure_date' } };
    savedFilterService.create({ name: 'Pending This Month', module: 'bookings', filter: shape });
    const [saved] = savedFilterService.list('bookings');
    expect(saved.filter).toEqual(shape);
  });
});
