-- Database as the ORIGINAL (pre-upgrade) code left it. Replayed by upgradeFromOriginal.test.js.
CREATE TABLE roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,              -- Admin, Manager, Staff
  description TEXT
);
CREATE TABLE permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  module TEXT NOT NULL,                   -- customers, bookings, invoices, ...
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  can_view INTEGER NOT NULL DEFAULT 0,
  can_create INTEGER NOT NULL DEFAULT 0,
  can_edit INTEGER NOT NULL DEFAULT 0,
  can_delete INTEGER NOT NULL DEFAULT 0,
  UNIQUE(module, role_id)
);
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role_id INTEGER REFERENCES roles(id),
  phone TEXT,
  email TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  father_husband_name TEXT,
  cnic TEXT,
  passport_number TEXT,
  passport_issue_date TEXT,
  passport_expiry_date TEXT,
  date_of_birth TEXT,
  gender TEXT,
  nationality TEXT,
  phone TEXT,
  whatsapp TEXT,
  email TEXT,
  address TEXT,
  emergency_contact TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  profile_picture_path TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
, postcode TEXT, customer_source TEXT, salesperson_id INTEGER REFERENCES users(id), customer_type TEXT DEFAULT 'Individual');
CREATE TABLE umrah_packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  package_type TEXT,
  departure_date TEXT,
  return_date TEXT,
  number_of_days INTEGER,
  visa_included INTEGER DEFAULT 0,
  flight_included INTEGER DEFAULT 0,
  hotel_included INTEGER DEFAULT 0,
  transport_included INTEGER DEFAULT 0,
  food_included INTEGER DEFAULT 0,
  ziyarat_included INTEGER DEFAULT 0,
  makkah_hotel TEXT,
  madinah_hotel TEXT,
  makkah_nights INTEGER,
  madinah_nights INTEGER,
  transport_details TEXT,
  package_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE umrah_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_name TEXT NOT NULL,
  package_id INTEGER REFERENCES umrah_packages(id),
  departure_date TEXT,
  return_date TEXT,
  total_passengers INTEGER DEFAULT 0,
  flight_id INTEGER,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE umrah_group_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES umrah_groups(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE hajj_packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  departure_date TEXT,
  return_date TEXT,
  makkah_hotel TEXT,
  madinah_hotel TEXT,
  package_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE hajj_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_name TEXT NOT NULL,
  package_id INTEGER REFERENCES hajj_packages(id),
  departure_date TEXT,
  return_date TEXT,
  total_pilgrims INTEGER DEFAULT 0,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE hajj_group_pilgrims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES hajj_groups(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE tours (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_name TEXT NOT NULL,
  destination TEXT,
  country TEXT,
  city TEXT,
  start_date TEXT,
  end_date TEXT,
  duration TEXT,
  total_seats INTEGER DEFAULT 0,
  available_seats INTEGER DEFAULT 0,
  package_price REAL DEFAULT 0,
  hotel TEXT,
  transport TEXT,
  meals TEXT,
  activities TEXT,
  guide TEXT,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE tour_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT
);
CREATE TABLE bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_code TEXT NOT NULL UNIQUE,
  booking_date TEXT NOT NULL DEFAULT (datetime('now')),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_type TEXT NOT NULL,          -- Umrah, Hajj, Tour, Flight, Hotel, Visa, Custom
  reference_id INTEGER,                -- id in the relevant package/group table
  departure_date TEXT,
  return_date TEXT,
  number_of_passengers INTEGER DEFAULT 1,
  total_price REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Inquiry', -- Inquiry, Pending, Confirmed, Cancelled, Completed
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
, destination TEXT, sales_agent_id INTEGER REFERENCES users(id), operations_agent_id INTEGER REFERENCES users(id), package_id INTEGER REFERENCES packages(id), package_snapshot TEXT);
CREATE TABLE booking_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT
);
CREATE TABLE flights (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  airline TEXT,
  flight_number TEXT,
  pnr TEXT,
  departure_airport TEXT,
  arrival_airport TEXT,
  departure_date TEXT,
  departure_time TEXT,
  arrival_date TEXT,
  arrival_time TEXT,
  class TEXT,
  ticket_number TEXT,
  status TEXT DEFAULT 'Confirmed',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, supplier_id INTEGER REFERENCES suppliers(id), package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL);
CREATE TABLE flight_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  flight_id INTEGER NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id)
);
CREATE TABLE hotels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  hotel_name TEXT NOT NULL,
  country TEXT,
  city TEXT,
  address TEXT,
  contact TEXT,
  check_in TEXT,
  check_out TEXT,
  room_type TEXT,
  number_of_rooms INTEGER DEFAULT 1,
  number_of_nights INTEGER DEFAULT 1,
  booking_reference TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, supplier_id INTEGER REFERENCES suppliers(id), package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL);
CREATE TABLE visa_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  country TEXT,
  visa_type TEXT,
  application_date TEXT,
  submission_date TEXT,
  approval_date TEXT,
  expiry_date TEXT,
  application_number TEXT,
  status TEXT DEFAULT 'Documents Pending',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, supplier_id INTEGER REFERENCES suppliers(id), package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL);
CREATE TABLE transportation (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  vehicle TEXT,
  vehicle_number TEXT,
  driver TEXT,
  driver_phone TEXT,
  pickup_location TEXT,
  drop_location TEXT,
  pickup_date TEXT,
  pickup_time TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  status TEXT DEFAULT 'Scheduled',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, supplier_id INTEGER REFERENCES suppliers(id), package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL);
CREATE TABLE invoice_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  template_name TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  config_json TEXT NOT NULL,   -- serialized layout/design config; visual design lives here only
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_date TEXT NOT NULL DEFAULT (datetime('now')),
  due_date TEXT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  template_id INTEGER REFERENCES invoice_templates(id),
  subtotal REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Unpaid',  -- Unpaid, Partially Paid, Paid, Cancelled
  notes TEXT,
  terms TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE invoice_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity REAL NOT NULL DEFAULT 1,
  unit_price REAL NOT NULL DEFAULT 0,
  line_total REAL NOT NULL DEFAULT 0
);
CREATE TABLE payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_id INTEGER REFERENCES invoices(id),
  payment_date TEXT NOT NULL DEFAULT (datetime('now')),
  amount REAL NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'Cash', -- Cash, Bank Transfer, Card, Online Transfer, Other
  payment_type TEXT NOT NULL DEFAULT 'Partial', -- Advance, Partial, Full, Refund
  reference TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, account_type TEXT, account_id INTEGER);
CREATE TABLE ledger_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  description TEXT,
  invoice_id INTEGER REFERENCES invoices(id),
  payment_id INTEGER REFERENCES payments(id),
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  running_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE expense_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_date TEXT NOT NULL DEFAULT (datetime('now')),
  category_id INTEGER REFERENCES expense_categories(id),
  description TEXT,
  amount REAL NOT NULL,
  payment_method TEXT DEFAULT 'Cash',
  related_booking_id INTEGER REFERENCES bookings(id),
  related_package_type TEXT,
  related_package_id INTEGER,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, account_type TEXT, account_id INTEGER);
CREATE TABLE documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  document_type TEXT,     -- CNIC, Passport, Visa, Ticket, Voucher, Receipt, Other
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
  notes TEXT
);
CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),
  action TEXT NOT NULL,
  record_type TEXT,
  record_id INTEGER,
  description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_code TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  source TEXT,
  destination TEXT,
  travel_date TEXT,
  service_type TEXT,
  assigned_agent_id INTEGER REFERENCES users(id),
  estimated_value REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'New',   -- New, Contacted, Qualified, Quotation Sent, Negotiation, Converted, Lost
  priority TEXT NOT NULL DEFAULT 'Medium', -- Low, Medium, High
  converted_customer_id INTEGER REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE lead_activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL,   -- Note, StatusChange, Call, Email, Conversion
  description TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER REFERENCES customers(id),  -- the "owning" customer/account
  full_name TEXT NOT NULL,
  relationship TEXT,             -- Self, Spouse, Child, Parent, Other
  date_of_birth TEXT,
  gender TEXT,
  nationality TEXT,
  passport_number TEXT,
  passport_issue_date TEXT,
  passport_expiry_date TEXT,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE booking_travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  traveller_id INTEGER NOT NULL REFERENCES travellers(id),
  notes TEXT
);
CREATE TABLE follow_ups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  follow_up_date TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id),
  lead_id INTEGER REFERENCES leads(id),
  booking_id INTEGER REFERENCES bookings(id),
  assigned_user_id INTEGER REFERENCES users(id),
  priority TEXT NOT NULL DEFAULT 'Medium',
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, Completed, Overdue, Cancelled
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE quotations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quotation_number TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  lead_id INTEGER REFERENCES leads(id),
  destination TEXT,
  travel_date_from TEXT,
  travel_date_to TEXT,
  supplier_id INTEGER REFERENCES suppliers(id),
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  markup REAL DEFAULT 0,
  discount REAL DEFAULT 0,
  tax REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Draft', -- Draft, Sent, Approved, Rejected, Expired, Converted
  notes TEXT,
  terms TEXT,
  converted_booking_id INTEGER REFERENCES bookings(id),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE quotation_travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quotation_id INTEGER NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
  traveller_id INTEGER NOT NULL REFERENCES travellers(id)
);
CREATE TABLE packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  destination TEXT,
  duration TEXT,
  description TEXT,
  supplier_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  markup REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
, package_type TEXT NOT NULL DEFAULT 'Custom', departure_date TEXT, return_date TEXT, number_of_days INTEGER, legacy_mirror_table TEXT, legacy_mirror_id INTEGER);
CREATE TABLE package_components (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_id INTEGER NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
  component_type TEXT NOT NULL, -- Flight, Hotel, Transport, Visa, Ziyarat, Meals, Insurance, Other
  description TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0
, supplier_id INTEGER REFERENCES suppliers(id));
CREATE TABLE suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  company TEXT,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  service_type TEXT,  -- Airline, Hotel, Transport, Visa Agent, Tour Operator, Other
  currency TEXT DEFAULT 'PKR',
  payment_terms TEXT,
  opening_balance REAL DEFAULT 0,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE supplier_invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_number TEXT NOT NULL,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_date TEXT NOT NULL DEFAULT (datetime('now')),
  due_date TEXT,
  currency TEXT DEFAULT 'PKR',
  amount REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Unpaid', -- Unpaid, Partially Paid, Paid, Overdue
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE supplier_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  booking_id INTEGER REFERENCES bookings(id),
  supplier_invoice_id INTEGER REFERENCES supplier_invoices(id),
  payment_date TEXT NOT NULL DEFAULT (datetime('now')),
  amount REAL NOT NULL,
  currency TEXT DEFAULT 'PKR',
  payment_method TEXT NOT NULL DEFAULT 'Bank Transfer',
  account_type TEXT,        -- Bank, Cash
  account_id INTEGER,       -- references bank_accounts.id or cash_accounts.id depending on account_type
  reference TEXT,
  notes TEXT,
  staff_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE supplier_ledger_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  description TEXT,
  supplier_invoice_id INTEGER REFERENCES supplier_invoices(id),
  supplier_payment_id INTEGER REFERENCES supplier_payments(id),
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  running_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE other_services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_type TEXT NOT NULL, -- Ziyarat, Meals, Insurance, Tours, Excursions, Guide, Tickets, Miscellaneous
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  traveller_id INTEGER REFERENCES travellers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  description TEXT,
  service_date TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Pending',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
, package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL);
CREATE TABLE tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  assigned_user_id INTEGER REFERENCES users(id),
  priority TEXT NOT NULL DEFAULT 'Medium',
  due_date TEXT,
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, In Progress, Completed, Overdue, Cancelled
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE deadlines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  deadline_type TEXT NOT NULL, -- Reservation, Ticketing, Payment, Cancellation, HotelCancellation, Visa, Confirmation
  title TEXT,
  due_date TEXT NOT NULL,
  booking_id INTEGER REFERENCES bookings(id),
  traveller_id INTEGER REFERENCES travellers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, Completed, Overdue, Cancelled
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE bank_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_name TEXT NOT NULL,
  bank_name TEXT,
  account_number TEXT,
  currency TEXT DEFAULT 'PKR',
  opening_balance REAL DEFAULT 0,
  current_balance REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE cash_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_name TEXT NOT NULL,
  currency TEXT DEFAULT 'PKR',
  opening_balance REAL DEFAULT 0,
  current_balance REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE account_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_type TEXT NOT NULL,  -- Bank, Cash
  account_id INTEGER NOT NULL, -- bank_accounts.id or cash_accounts.id
  transaction_date TEXT NOT NULL DEFAULT (datetime('now')),
  transaction_type TEXT NOT NULL, -- Deposit, Withdrawal, CustomerPayment, SupplierPayment, Expense, Transfer, Refund
  amount REAL NOT NULL,
  direction TEXT NOT NULL,     -- In, Out
  reference_type TEXT,         -- payments, supplier_payments, expenses, refunds, manual
  reference_id INTEGER,
  description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE refunds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_id INTEGER REFERENCES invoices(id),
  payment_id INTEGER REFERENCES payments(id),
  refund_amount REAL NOT NULL,
  refund_date TEXT NOT NULL DEFAULT (datetime('now')),
  reason TEXT,
  payment_method TEXT DEFAULT 'Bank Transfer',
  account_type TEXT,
  account_id INTEGER,
  notes TEXT,
  staff_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE accounting_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  account TEXT NOT NULL,      -- e.g. 'Cash', 'Bank - HBL', 'Customer Receivable', 'Supplier Payable', 'Revenue', 'Expense'
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  reference TEXT,
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  payment_id INTEGER REFERENCES payments(id),
  expense_id INTEGER REFERENCES expenses(id),
  is_reversal INTEGER NOT NULL DEFAULT 0,
  reversed_entry_id INTEGER REFERENCES accounting_entries(id),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  notif_type TEXT NOT NULL,   -- PaymentOverdue, SupplierPaymentPending, VisaDeadline, PassportExpiry, FlightDeadline, HotelDeadline, FollowUpDue, TaskOverdue, MissingDocument, BookingConfirmationPending
  title TEXT NOT NULL,
  message TEXT,
  record_type TEXT,           -- table name of the linked record
  record_id INTEGER,
  user_id INTEGER REFERENCES users(id), -- NULL = visible to all
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE saved_filters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  module TEXT NOT NULL,       -- which screen this filter applies to (bookings, invoices, ...)
  filter_json TEXT NOT NULL,  -- serialized filter configuration
  user_id INTEGER REFERENCES users(id), -- NULL = shared/global filter
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_customers_name ON customers(full_name);
CREATE INDEX idx_customers_cnic ON customers(cnic);
CREATE INDEX idx_customers_passport ON customers(passport_number);
CREATE INDEX idx_customers_phone ON customers(phone);
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_type ON bookings(booking_type);
CREATE INDEX idx_visa_status ON visa_applications(status);
CREATE INDEX idx_visa_expiry ON visa_applications(expiry_date);
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_payments_customer ON payments(customer_id);
CREATE INDEX idx_ledger_customer ON ledger_entries(customer_id);
CREATE INDEX idx_expenses_date ON expenses(expense_date);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_agent ON leads(assigned_agent_id);
CREATE INDEX idx_lead_activities_lead ON lead_activities(lead_id);
CREATE INDEX idx_travellers_customer ON travellers(customer_id);
CREATE INDEX idx_travellers_passport ON travellers(passport_number);
CREATE INDEX idx_booking_travellers_booking ON booking_travellers(booking_id);
CREATE INDEX idx_followups_date ON follow_ups(follow_up_date);
CREATE INDEX idx_followups_status ON follow_ups(status);
CREATE INDEX idx_quotations_customer ON quotations(customer_id);
CREATE INDEX idx_quotations_status ON quotations(status);
CREATE INDEX idx_package_components_package ON package_components(package_id);
CREATE INDEX idx_suppliers_name ON suppliers(name);
CREATE INDEX idx_suppliers_type ON suppliers(service_type);
CREATE INDEX idx_supplier_invoices_supplier ON supplier_invoices(supplier_id);
CREATE INDEX idx_supplier_invoices_status ON supplier_invoices(status);
CREATE INDEX idx_supplier_invoices_booking ON supplier_invoices(booking_id);
CREATE INDEX idx_supplier_payments_supplier ON supplier_payments(supplier_id);
CREATE INDEX idx_supplier_payments_invoice ON supplier_payments(supplier_invoice_id);
CREATE INDEX idx_supplier_ledger_supplier ON supplier_ledger_entries(supplier_id);
CREATE INDEX idx_other_services_booking ON other_services(booking_id);
CREATE INDEX idx_tasks_due ON tasks(due_date);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_assigned ON tasks(assigned_user_id);
CREATE INDEX idx_deadlines_due ON deadlines(due_date);
CREATE INDEX idx_deadlines_booking ON deadlines(booking_id);
CREATE INDEX idx_deadlines_status ON deadlines(status);
CREATE INDEX idx_account_txn_account ON account_transactions(account_type, account_id);
CREATE INDEX idx_account_txn_date ON account_transactions(transaction_date);
CREATE INDEX idx_refunds_customer ON refunds(customer_id);
CREATE INDEX idx_accounting_date ON accounting_entries(entry_date);
CREATE INDEX idx_accounting_booking ON accounting_entries(booking_id);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX idx_notifications_created ON notifications(created_at);
CREATE INDEX idx_saved_filters_module ON saved_filters(module);
CREATE INDEX idx_flights_booking ON flights(booking_id);
CREATE INDEX idx_flight_passengers_flight ON flight_passengers(flight_id);
CREATE INDEX idx_hotels_booking ON hotels(booking_id);
CREATE INDEX idx_visa_customer ON visa_applications(customer_id);
CREATE INDEX idx_visa_booking ON visa_applications(booking_id);
CREATE INDEX idx_transportation_booking ON transportation(booking_id);
CREATE INDEX idx_invoice_items_invoice ON invoice_items(invoice_id);
CREATE INDEX idx_invoices_booking ON invoices(booking_id);
CREATE INDEX idx_invoices_date ON invoices(invoice_date);
CREATE INDEX idx_payments_invoice ON payments(invoice_id);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_date ON payments(payment_date);
CREATE INDEX idx_ledger_invoice ON ledger_entries(invoice_id);
CREATE INDEX idx_expenses_category ON expenses(category_id);
CREATE INDEX idx_expenses_booking ON expenses(related_booking_id);
CREATE INDEX idx_documents_customer ON documents(customer_id);
CREATE INDEX idx_documents_booking ON documents(booking_id);
CREATE INDEX idx_umrah_groups_package ON umrah_groups(package_id);
CREATE INDEX idx_umrah_group_passengers_group ON umrah_group_passengers(group_id);
CREATE INDEX idx_hajj_groups_package ON hajj_groups(package_id);
CREATE INDEX idx_hajj_group_pilgrims_group ON hajj_group_pilgrims(group_id);
CREATE INDEX idx_tour_passengers_tour ON tour_passengers(tour_id);
CREATE INDEX idx_booking_passengers_booking ON booking_passengers(booking_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_record_type ON audit_logs(record_type);
INSERT INTO roles (id, name, description) VALUES (1, 'Admin', 'Full access to all modules');
INSERT INTO roles (id, name, description) VALUES (2, 'Manager', 'Operational access, limited settings');
INSERT INTO roles (id, name, description) VALUES (3, 'Staff', 'Day to day data entry access');
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (1, 'dashboard', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (2, 'customers', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (3, 'bookings', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (4, 'umrah', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (5, 'hajj', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (6, 'tours', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (7, 'flights', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (8, 'hotels', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (9, 'visa', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (10, 'transportation', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (11, 'invoices', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (12, 'payments', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (13, 'ledger', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (14, 'expenses', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (15, 'documents', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (16, 'reports', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (17, 'staff', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (18, 'invoice_templates', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (19, 'settings', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (20, 'backup', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (21, 'leads', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (22, 'travellers', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (23, 'followups', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (24, 'quotations', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (25, 'packages', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (26, 'other_services', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (27, 'tasks', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (28, 'deadlines', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (29, 'upcoming_travel', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (30, 'travel_calendar', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (31, 'suppliers', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (32, 'supplier_ledger', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (33, 'supplier_invoices', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (34, 'supplier_payments', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (35, 'supplier_reports', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (36, 'bank_accounts', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (37, 'cash_accounts', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (38, 'refunds', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (39, 'accounting', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (40, 'notifications', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (41, 'audit_logs', 1, 1, 1, 1, 1);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (42, 'dashboard', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (43, 'customers', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (44, 'bookings', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (45, 'umrah', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (46, 'hajj', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (47, 'tours', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (48, 'flights', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (49, 'hotels', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (50, 'visa', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (51, 'transportation', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (52, 'invoices', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (53, 'payments', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (54, 'ledger', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (55, 'expenses', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (56, 'documents', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (57, 'reports', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (58, 'staff', 2, 1, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (59, 'invoice_templates', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (60, 'settings', 2, 1, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (61, 'backup', 2, 1, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (62, 'leads', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (63, 'travellers', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (64, 'followups', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (65, 'quotations', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (66, 'packages', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (67, 'other_services', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (68, 'tasks', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (69, 'deadlines', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (70, 'upcoming_travel', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (71, 'travel_calendar', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (72, 'suppliers', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (73, 'supplier_ledger', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (74, 'supplier_invoices', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (75, 'supplier_payments', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (76, 'supplier_reports', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (77, 'bank_accounts', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (78, 'cash_accounts', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (79, 'refunds', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (80, 'accounting', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (81, 'notifications', 2, 1, 1, 1, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (82, 'audit_logs', 2, 1, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (83, 'dashboard', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (84, 'customers', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (85, 'bookings', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (86, 'umrah', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (87, 'hajj', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (88, 'tours', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (89, 'flights', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (90, 'hotels', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (91, 'visa', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (92, 'transportation', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (93, 'invoices', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (94, 'payments', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (95, 'ledger', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (96, 'expenses', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (97, 'documents', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (98, 'reports', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (99, 'staff', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (100, 'invoice_templates', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (101, 'settings', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (102, 'backup', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (103, 'leads', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (104, 'travellers', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (105, 'followups', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (106, 'quotations', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (107, 'packages', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (108, 'other_services', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (109, 'tasks', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (110, 'deadlines', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (111, 'upcoming_travel', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (112, 'travel_calendar', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (113, 'suppliers', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (114, 'supplier_ledger', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (115, 'supplier_invoices', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (116, 'supplier_payments', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (117, 'supplier_reports', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (118, 'bank_accounts', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (119, 'cash_accounts', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (120, 'refunds', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (121, 'accounting', 3, 0, 0, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (122, 'notifications', 3, 1, 1, 0, 0);
INSERT INTO permissions (id, module, role_id, can_view, can_create, can_edit, can_delete) VALUES (123, 'audit_logs', 3, 0, 0, 0, 0);
INSERT INTO users (id, full_name, username, password_hash, role_id, phone, email, is_active, created_at, updated_at) VALUES (1, 'Administrator', 'admin', 'h:admin123', 1, NULL, NULL, 1, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO customers (id, full_name, father_husband_name, cnic, passport_number, passport_issue_date, passport_expiry_date, date_of_birth, gender, nationality, phone, whatsapp, email, address, emergency_contact, notes, status, profile_picture_path, created_at, updated_at, postcode, customer_source, salesperson_id, customer_type) VALUES (1, 'Amina Siddiqui', NULL, NULL, 'AB1234567', NULL, NULL, NULL, NULL, NULL, '0300-1112223', NULL, 'amina@example.com', 'Lahore', NULL, NULL, 'Active', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', NULL, NULL, NULL, 'Individual');
INSERT INTO customers (id, full_name, father_husband_name, cnic, passport_number, passport_issue_date, passport_expiry_date, date_of_birth, gender, nationality, phone, whatsapp, email, address, emergency_contact, notes, status, profile_picture_path, created_at, updated_at, postcode, customer_source, salesperson_id, customer_type) VALUES (2, 'Bilal Hashmi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0321-9998887', NULL, NULL, NULL, NULL, NULL, 'Active', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', NULL, NULL, NULL, 'Individual');
INSERT INTO customers (id, full_name, father_husband_name, cnic, passport_number, passport_issue_date, passport_expiry_date, date_of_birth, gender, nationality, phone, whatsapp, email, address, emergency_contact, notes, status, profile_picture_path, created_at, updated_at, postcode, customer_source, salesperson_id, customer_type) VALUES (3, 'Cara Ellis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '07700 900123', NULL, 'cara@example.com', NULL, NULL, NULL, 'Active', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', NULL, NULL, NULL, 'Individual');
INSERT INTO umrah_packages (id, package_name, package_type, departure_date, return_date, number_of_days, visa_included, flight_included, hotel_included, transport_included, food_included, ziyarat_included, makkah_hotel, madinah_hotel, makkah_nights, madinah_nights, transport_details, package_cost, selling_price, description, notes, created_at) VALUES (1, 'Premium Umrah 14N', 'Custom', NULL, NULL, NULL, 1, 1, 1, 0, 0, 0, 'Swissotel', NULL, NULL, NULL, NULL, 115000, 250000, NULL, NULL, '2026-10-14 05:12:18');
INSERT INTO bookings (id, booking_code, booking_date, customer_id, booking_type, reference_id, departure_date, return_date, number_of_passengers, total_price, paid_amount, remaining_amount, status, notes, created_at, updated_at, destination, sales_agent_id, operations_agent_id, package_id, package_snapshot) VALUES (1, 'BK-000001', '2026-10-14 05:12:18', 1, 'Umrah', NULL, '2027-01-10', '2027-01-24', 1, 250000, 100000, 150000, 'Inquiry', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', 'Makkah', NULL, NULL, 1, '{"package_id":1,"package_name":"Premium Umrah 14N","package_type":"Umrah","destination":"Makkah","duration":null,"package_price":250000,"estimated_cost":115000,"estimated_profit":135000,"currency":"PKR","components":[{"component_type":"Flight","description":"PIA Direct","cost":60000,"selling_price":70000,"supplier_id":2,"supplier_name":"PIA Cargo"},{"component_type":"Visa","description":"Saudi","cost":15000,"selling_price":18000,"supplier_id":null,"supplier_name":null},{"component_type":"Makkah Hotel","description":"Swissotel","cost":40000,"selling_price":50000,"supplier_id":1,"supplier_name":"Hilton Makkah"}],"snapshotted_at":"2026-10-14T05:12:18.518Z"}');
INSERT INTO bookings (id, booking_code, booking_date, customer_id, booking_type, reference_id, departure_date, return_date, number_of_passengers, total_price, paid_amount, remaining_amount, status, notes, created_at, updated_at, destination, sales_agent_id, operations_agent_id, package_id, package_snapshot) VALUES (2, 'BK-000002', '2026-10-14 05:12:18', 2, 'Tour', NULL, '2027-02-01', '2027-02-08', 1, 120000, 0, 120000, 'Confirmed', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', 'Antalya', NULL, NULL, NULL, NULL);
INSERT INTO bookings (id, booking_code, booking_date, customer_id, booking_type, reference_id, departure_date, return_date, number_of_passengers, total_price, paid_amount, remaining_amount, status, notes, created_at, updated_at, destination, sales_agent_id, operations_agent_id, package_id, package_snapshot) VALUES (3, 'BK-000003', '2026-10-14 05:12:18', 3, 'Hotel', NULL, NULL, NULL, 1, 45000, 0, 45000, 'Pending', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18', NULL, NULL, NULL, NULL, NULL);
INSERT INTO flights (id, booking_id, airline, flight_number, pnr, departure_airport, arrival_airport, departure_date, departure_time, arrival_date, arrival_time, class, ticket_number, status, notes, created_at, supplier_id, package_component_id) VALUES (1, 1, NULL, 'PIA Direct', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', 'PIA Direct', '2026-10-14 05:12:18', 2, 1);
INSERT INTO flights (id, booking_id, airline, flight_number, pnr, departure_airport, arrival_airport, departure_date, departure_time, arrival_date, arrival_time, class, ticket_number, status, notes, created_at, supplier_id, package_component_id) VALUES (2, 2, 'TK', 'TK-714', NULL, 'LHE', 'AYT', '2027-02-01', NULL, NULL, NULL, NULL, NULL, 'Confirmed', NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO hotels (id, booking_id, hotel_name, country, city, address, contact, check_in, check_out, room_type, number_of_rooms, number_of_nights, booking_reference, cost, selling_price, notes, created_at, supplier_id, package_component_id) VALUES (1, 1, 'Swissotel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 40000, 50000, 'Swissotel', '2026-10-14 05:12:18', 1, 3);
INSERT INTO hotels (id, booking_id, hotel_name, country, city, address, contact, check_in, check_out, room_type, number_of_rooms, number_of_nights, booking_reference, cost, selling_price, notes, created_at, supplier_id, package_component_id) VALUES (2, 2, 'Sheraton', NULL, 'Antalya', NULL, NULL, '2027-02-01', '2027-02-08', NULL, 1, 1, NULL, 70000, 90000, NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO visa_applications (id, customer_id, booking_id, country, visa_type, application_date, submission_date, approval_date, expiry_date, application_number, status, notes, created_at, supplier_id, package_component_id) VALUES (1, 1, 1, 'Saudi', NULL, NULL, NULL, NULL, NULL, NULL, 'Documents Pending', 'Saudi', '2026-10-14 05:12:18', NULL, 2);
INSERT INTO transportation (id, booking_id, vehicle, vehicle_number, driver, driver_phone, pickup_location, drop_location, pickup_date, pickup_time, cost, selling_price, status, notes, created_at, supplier_id, package_component_id) VALUES (1, 2, NULL, NULL, NULL, NULL, 'Airport', 'Hotel', '2027-02-01', NULL, 4000, 6000, 'Scheduled', NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO invoice_templates (id, template_name, is_default, status, config_json, created_at) VALUES (1, 'Default Template', 1, 'Active', '{"html":"<!doctype html>\n<html>\n<head>\n<meta charset=\"utf-8\">\n<style>\n  @page { size: A4; margin: 16mm; }\n  * { box-sizing: border-box; }\n  body { font-family: Arial, Helvetica, sans-serif; color: #16233F; font-size: 12px; margin: 0; }\n  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1E4FA3; padding-bottom: 14px; margin-bottom: 20px; }\n  .agency-name { font-size: 19px; font-weight: 700; color: #1E4FA3; margin-bottom: 4px; }\n  .muted { color: #5B6B8C; }\n  .invoice-title { text-align: right; }\n  .invoice-title h1 { font-size: 22px; margin: 0 0 6px; color: #1E4FA3; letter-spacing: 0.04em; }\n  .section-title { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.05em; color: #8B97B3; margin: 18px 0 6px; font-weight: 700; }\n  table { width: 100%; border-collapse: collapse; margin-top: 6px; }\n  th, td { padding: 8px 10px; border-bottom: 1px solid #E4E9F2; text-align: left; }\n  th { background: #EAF1FC; color: #1E4FA3; text-transform: uppercase; font-size: 10px; letter-spacing: 0.03em; }\n  td.num, th.num { text-align: right; }\n  .totals { width: 260px; margin-left: auto; margin-top: 14px; }\n  .totals .row { display: flex; justify-content: space-between; padding: 4px 0; }\n  .totals .grand { font-weight: 700; font-size: 14px; border-top: 2px solid #1E4FA3; padding-top: 8px; margin-top: 4px; }\n  .footer { margin-top: 36px; font-size: 10.5px; color: #8B97B3; border-top: 1px solid #E4E9F2; padding-top: 10px; }\n</style>\n</head>\n<body>\n  <div class=\"header\">\n    <div>\n      <div class=\"agency-name\">{{agency_name}}</div>\n      <div class=\"muted\">{{agency_address}}</div>\n      <div class=\"muted\">{{agency_phone}} &middot; {{agency_email}}</div>\n    </div>\n    <div class=\"invoice-title\">\n      {{{logo_html}}}\n      <h1>INVOICE</h1>\n      <div>{{invoice_number}}</div>\n      <div class=\"muted\">Date: {{invoice_date}}</div>\n      <div class=\"muted\">Due: {{due_date}}</div>\n    </div>\n  </div>\n\n  <div class=\"section-title\">Bill To</div>\n  <div>{{customer_name}}</div>\n  <div class=\"muted\">{{customer_phone}}</div>\n  <div class=\"muted\">{{customer_email}}</div>\n  <div class=\"muted\">{{customer_address}}</div>\n\n  <div class=\"section-title\">Booking Reference</div>\n  <div class=\"muted\">{{booking_reference}}</div>\n\n  <table>\n    <thead>\n      <tr><th>Description</th><th class=\"num\">Qty</th><th class=\"num\">Unit Price</th><th class=\"num\">Line Total</th></tr>\n    </thead>\n    <tbody>\n      {{{line_items_html}}}\n    </tbody>\n  </table>\n\n  <div class=\"totals\">\n    <div class=\"row\"><span>Subtotal</span><span>{{subtotal}}</span></div>\n    <div class=\"row\"><span>Discount</span><span>{{discount}}</span></div>\n    <div class=\"row\"><span>Tax</span><span>{{tax}}</span></div>\n    <div class=\"row grand\"><span>Total</span><span>{{total}}</span></div>\n    <div class=\"row\"><span>Paid</span><span>{{paid_amount}}</span></div>\n    <div class=\"row\"><span>Balance Due</span><span>{{remaining_amount}}</span></div>\n  </div>\n\n  <div class=\"section-title\">Notes</div>\n  <div class=\"muted\">{{notes}}</div>\n\n  <div class=\"section-title\">Terms &amp; Conditions</div>\n  <div class=\"muted\">{{terms}}</div>\n\n  <div class=\"section-title\">Bank Details</div>\n  <div class=\"muted\">{{bank_details}}</div>\n\n  <div style=\"display:flex; justify-content:flex-end; gap:24px; margin-top:24px; align-items:flex-end;\">\n    {{{signature_html}}}\n    {{{stamp_html}}}\n  </div>\n\n  <div class=\"footer\">{{agency_name}} &middot; {{agency_website}}</div>\n</body>\n</html>"}', '2026-10-14 05:12:18');
INSERT INTO invoices (id, invoice_number, invoice_date, due_date, customer_id, booking_id, template_id, subtotal, discount, tax, total, paid_amount, remaining_amount, status, notes, terms, created_at, updated_at) VALUES (1, 'INV-1001', '2026-10-14 05:12:18', NULL, 1, 1, 1, 250000, 0, 0, 250000, 0, 250000, 'Unpaid', NULL, NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO invoices (id, invoice_number, invoice_date, due_date, customer_id, booking_id, template_id, subtotal, discount, tax, total, paid_amount, remaining_amount, status, notes, terms, created_at, updated_at) VALUES (2, 'INV-1002', '2026-10-14 05:12:18', NULL, 2, 2, 1, 120000, 0, 0, 120000, 45000, 75000, 'Partially Paid', NULL, NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO invoices (id, invoice_number, invoice_date, due_date, customer_id, booking_id, template_id, subtotal, discount, tax, total, paid_amount, remaining_amount, status, notes, terms, created_at, updated_at) VALUES (3, 'INV-1003', '2026-10-14 05:12:18', NULL, 3, NULL, 1, 45000, 0, 0, 45000, 0, 45000, 'Unpaid', NULL, NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO invoice_items (id, invoice_id, description, quantity, unit_price, line_total) VALUES (1, 1, 'Umrah Booking — BK-000001', 1, 250000, 250000);
INSERT INTO invoice_items (id, invoice_id, description, quantity, unit_price, line_total) VALUES (2, 2, 'Tour Booking — BK-000002', 1, 120000, 120000);
INSERT INTO invoice_items (id, invoice_id, description, quantity, unit_price, line_total) VALUES (3, 3, 'Hotel nights', 3, 15000, 45000);
INSERT INTO payments (id, customer_id, booking_id, invoice_id, payment_date, amount, payment_method, payment_type, reference, notes, created_at, account_type, account_id) VALUES (1, 1, 1, NULL, '2026-10-14 05:12:18', 100000, 'Bank Transfer', 'Advance', 'TXN-1', NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO payments (id, customer_id, booking_id, invoice_id, payment_date, amount, payment_method, payment_type, reference, notes, created_at, account_type, account_id) VALUES (2, 2, NULL, 2, '2026-10-14 05:12:18', 50000, 'Cash', 'Partial', NULL, NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO payments (id, customer_id, booking_id, invoice_id, payment_date, amount, payment_method, payment_type, reference, notes, created_at, account_type, account_id) VALUES (3, 3, NULL, NULL, '2026-10-14 05:12:18', 20000, 'Cash', 'Advance', NULL, NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO payments (id, customer_id, booking_id, invoice_id, payment_date, amount, payment_method, payment_type, reference, notes, created_at, account_type, account_id) VALUES (4, 2, NULL, 2, '2026-10-14 05:12:18', 5000, 'Cash', 'Refund', NULL, NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (1, 1, '2026-10-14 05:12:18', 'Invoice INV-1001', 1, NULL, 250000, 0, 250000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (2, 2, '2026-10-14 05:12:18', 'Invoice INV-1002', 2, NULL, 120000, 0, 120000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (3, 3, '2026-10-14 05:12:18', 'Invoice INV-1003', 3, NULL, 45000, 0, 45000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (4, 1, '2026-10-14 05:12:18', 'Advance payment — Booking BK-000001', NULL, 1, 0, 100000, 150000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (5, 2, '2026-10-14 05:12:18', 'Partial payment — Invoice INV-1002', 2, 2, 0, 50000, 70000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (6, 3, '2026-10-14 05:12:18', 'Advance payment', NULL, 3, 0, 20000, 25000, '2026-10-14 05:12:18');
INSERT INTO ledger_entries (id, customer_id, entry_date, description, invoice_id, payment_id, debit, credit, running_balance, created_at) VALUES (7, 2, '2026-10-14 05:12:18', 'Refund payment — Invoice INV-1002', 2, 4, 5000, 0, 75000, '2026-10-14 05:12:18');
INSERT INTO expense_categories (id, name) VALUES (1, 'Flight');
INSERT INTO expense_categories (id, name) VALUES (2, 'Hotel');
INSERT INTO expense_categories (id, name) VALUES (3, 'Visa');
INSERT INTO expense_categories (id, name) VALUES (4, 'Transport');
INSERT INTO expense_categories (id, name) VALUES (5, 'Food');
INSERT INTO expense_categories (id, name) VALUES (6, 'Staff');
INSERT INTO expense_categories (id, name) VALUES (7, 'Office');
INSERT INTO expense_categories (id, name) VALUES (8, 'Marketing');
INSERT INTO expense_categories (id, name) VALUES (9, 'Other');
INSERT INTO expenses (id, expense_date, category_id, description, amount, payment_method, related_booking_id, related_package_type, related_package_id, notes, created_at, account_type, account_id) VALUES (1, '2027-01-05', 1, NULL, 2500, 'Cash', 1, NULL, NULL, NULL, '2026-10-14 05:12:18', NULL, NULL);
INSERT INTO settings (key, value) VALUES ('agency_name', 'Royal Manchester Travels');
INSERT INTO settings (key, value) VALUES ('default_currency', 'GBP');
INSERT INTO settings (key, value) VALUES ('invoice_prefix', 'INV-');
INSERT INTO settings (key, value) VALUES ('invoice_next_number', '1004');
INSERT INTO settings (key, value) VALUES ('agency_address', '12 Peel St, Manchester');
INSERT INTO settings (key, value) VALUES ('agency_phone', '+44 161 000 0000');
INSERT INTO settings (key, value) VALUES ('agency_email', 'info@rmt.example');
INSERT INTO settings (key, value) VALUES ('tax_rate', '0');
INSERT INTO settings (key, value) VALUES ('terms_conditions', 'Payment due within 7 days.');
INSERT INTO settings (key, value) VALUES ('logo', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (1, NULL, 'Settings Updated', 'settings', NULL, 'Updated: agency_name, agency_address, agency_phone, agency_email, default_currency, tax_rate, terms_conditions', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (2, NULL, 'Customer Created', 'customer', 1, 'Customer "Amina Siddiqui" created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (3, NULL, 'Customer Created', 'customer', 2, 'Customer "Bilal Hashmi" created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (4, NULL, 'Customer Created', 'customer', 3, 'Customer "Cara Ellis" created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (5, NULL, 'Supplier Created', 'supplier', 1, 'Supplier "Hilton Makkah" (SUP-00001) created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (6, NULL, 'Supplier Created', 'supplier', 2, 'Supplier "PIA Cargo" (SUP-00002) created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (7, NULL, 'Package Created', 'package', 1, 'Umrah package "Premium Umrah 14N" created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (8, NULL, 'Booking Created', 'booking', 1, 'Booking BK-000001 created from package "Premium Umrah 14N"', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (9, NULL, 'flights:create', 'flights', 1, 'PIA Direct created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (10, NULL, 'visa_applications:create', 'visa_applications', 1, 'Saudi created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (11, NULL, 'hotels:create', 'hotels', 1, 'Swissotel created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (12, NULL, 'Booking Services Auto-Created', 'booking', 1, 'Flights:1 Hotels:1 Visa:1 Transport:0 Other:0', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (13, NULL, 'Booking Created', 'booking', 2, 'Booking BK-000002 created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (14, NULL, 'Booking Created', 'booking', 3, 'Booking BK-000003 created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (15, NULL, 'Traveller Created', 'traveller', 1, 'Traveller "Amina Siddiqui" created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (16, NULL, 'Invoice Created', 'invoice', 1, 'Invoice INV-1001 created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (17, NULL, 'Invoice Created', 'invoice', 2, 'Invoice INV-1002 created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (18, NULL, 'Invoice Created', 'invoice', 3, 'Invoice INV-1003 created', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (19, NULL, 'Payment Added', 'payment', 1, 'Advance payment — Booking BK-000001', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (20, NULL, 'Payment Added', 'payment', 2, 'Partial payment — Invoice INV-1002', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (21, NULL, 'Payment Added', 'payment', 3, 'Advance payment', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (22, NULL, 'Payment Refunded', 'payment', 4, 'Refund payment — Invoice INV-1002', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (23, NULL, 'Supplier Invoice Created', 'supplier_invoice', 1, 'Supplier invoice HM-77 created (52000)', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (24, NULL, 'Supplier Payment Added', 'supplier_payment', 1, 'Payment — Supplier Invoice HM-77', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (25, NULL, 'Supplier Payment Added', 'supplier_payment', 2, 'Payment to supplier', '2026-10-14 05:12:18');
INSERT INTO audit_logs (id, user_id, action, record_type, record_id, description, created_at) VALUES (26, NULL, 'Expense Added', 'expense', 1, 'Expense recorded', '2026-10-14 05:12:18');
INSERT INTO leads (id, lead_code, full_name, phone, email, source, destination, travel_date, service_type, assigned_agent_id, estimated_value, status, priority, converted_customer_id, notes, created_at, updated_at) VALUES (1, 'LD-1', 'Prospect One', '0333-1', NULL, NULL, NULL, NULL, NULL, NULL, 0, 'New', 'Medium', NULL, NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO travellers (id, customer_id, full_name, relationship, date_of_birth, gender, nationality, passport_number, passport_issue_date, passport_expiry_date, visa_status, notes, created_at, updated_at) VALUES (1, 1, 'Amina Siddiqui', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO booking_travellers (id, booking_id, traveller_id, notes) VALUES (1, 1, 1, 'Lead traveller');
INSERT INTO packages (id, package_name, destination, duration, description, supplier_cost, selling_price, markup, currency, status, created_at, updated_at, package_type, departure_date, return_date, number_of_days, legacy_mirror_table, legacy_mirror_id) VALUES (1, 'Premium Umrah 14N', 'Makkah', NULL, NULL, 0, 250000, 0, 'PKR', 'Active', '2026-10-14 05:12:18', '2026-10-14 05:12:18', 'Umrah', NULL, NULL, NULL, 'umrah_packages', 1);
INSERT INTO package_components (id, package_id, component_type, description, cost, selling_price, supplier_id) VALUES (1, 1, 'Flight', 'PIA Direct', 60000, 70000, 2);
INSERT INTO package_components (id, package_id, component_type, description, cost, selling_price, supplier_id) VALUES (2, 1, 'Visa', 'Saudi', 15000, 18000, NULL);
INSERT INTO package_components (id, package_id, component_type, description, cost, selling_price, supplier_id) VALUES (3, 1, 'Makkah Hotel', 'Swissotel', 40000, 50000, 1);
INSERT INTO suppliers (id, supplier_code, name, company, contact_person, phone, email, address, service_type, currency, payment_terms, opening_balance, notes, status, created_at, updated_at) VALUES (1, 'SUP-00001', 'Hilton Makkah', NULL, NULL, NULL, NULL, NULL, 'Hotel', 'SAR', NULL, 0, NULL, 'Active', '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO suppliers (id, supplier_code, name, company, contact_person, phone, email, address, service_type, currency, payment_terms, opening_balance, notes, status, created_at, updated_at) VALUES (2, 'SUP-00002', 'PIA Cargo', NULL, NULL, NULL, NULL, NULL, 'Airline', 'PKR', NULL, 0, NULL, 'Active', '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO supplier_invoices (id, invoice_number, supplier_id, booking_id, invoice_date, due_date, currency, amount, tax, total, paid_amount, remaining_amount, status, notes, created_at, updated_at) VALUES (1, 'HM-77', 1, 1, '2026-10-14T05:12:18.538Z', NULL, 'PKR', 52000, 0, 52000, 20000, 32000, 'Partially Paid', NULL, '2026-10-14 05:12:18', '2026-10-14 05:12:18');
INSERT INTO supplier_payments (id, supplier_id, booking_id, supplier_invoice_id, payment_date, amount, currency, payment_method, account_type, account_id, reference, notes, staff_id, created_at) VALUES (1, 1, 1, 1, '2026-10-14 05:12:18', 20000, 'PKR', 'Bank Transfer', NULL, NULL, NULL, NULL, NULL, '2026-10-14 05:12:18');
INSERT INTO supplier_payments (id, supplier_id, booking_id, supplier_invoice_id, payment_date, amount, currency, payment_method, account_type, account_id, reference, notes, staff_id, created_at) VALUES (2, 2, NULL, NULL, '2026-10-14 05:12:18', 9000, 'PKR', 'Cash', NULL, NULL, NULL, NULL, NULL, '2026-10-14 05:12:18');
INSERT INTO supplier_ledger_entries (id, supplier_id, entry_date, description, supplier_invoice_id, supplier_payment_id, debit, credit, running_balance, created_at) VALUES (1, 1, '2026-10-14 05:12:18', 'Supplier Invoice HM-77', 1, NULL, 52000, 0, 52000, '2026-10-14 05:12:18');
INSERT INTO supplier_ledger_entries (id, supplier_id, entry_date, description, supplier_invoice_id, supplier_payment_id, debit, credit, running_balance, created_at) VALUES (2, 1, '2026-10-14 05:12:18', 'Payment — Supplier Invoice HM-77', 1, 1, 0, 20000, 32000, '2026-10-14 05:12:18');
INSERT INTO supplier_ledger_entries (id, supplier_id, entry_date, description, supplier_invoice_id, supplier_payment_id, debit, credit, running_balance, created_at) VALUES (3, 2, '2026-10-14 05:12:18', 'Payment to supplier', NULL, 2, 0, 9000, -9000, '2026-10-14 05:12:18');
