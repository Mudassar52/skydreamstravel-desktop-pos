const fs = require('fs');
const os = require('os');
const path = require('path');
const { initDatabase } = require('../../../src/database/db');

/** Creates a fresh temp SQLite database (with schema applied) and returns its userData path. */
function freshDb() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tam-vitest-'));
  initDatabase(tmp);
  return tmp;
}

module.exports = { freshDb };
