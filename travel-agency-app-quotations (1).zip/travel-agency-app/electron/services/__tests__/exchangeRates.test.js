const { freshDb } = require('./testUtils');
const fx = require('../exchangeRateService');

describe('exchangeRateService', () => {
  beforeEach(() => freshDb());

  it('rejects bad input', () => {
    expect(() => fx.create({ from_currency: 'US', to_currency: 'PKR', rate: 280, effective_date: '2026-01-01' })).toThrow(/3-letter/);
    expect(() => fx.create({ from_currency: 'USD', to_currency: 'USD', rate: 1, effective_date: '2026-01-01' })).toThrow(/different/);
    expect(() => fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 0, effective_date: '2026-01-01' })).toThrow(/greater than zero/);
    expect(() => fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: 'soon' })).toThrow(/effective date/);
  });

  it('has no rates out of the box and never guesses', () => {
    expect(fx.getRate('USD', 'PKR')).toBeNull();
    expect(fx.convert(100, 'USD', 'PKR')).toEqual({ amount: null, rate: null, converted: false });
    expect(fx.getRate('PKR', 'PKR').rate).toBe(1);
  });

  it('uses the latest rate on or before the date, and blocks a duplicate date', () => {
    fx.create({ from_currency: 'usd', to_currency: 'pkr', rate: 280, effective_date: '2026-01-01' });
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 290, effective_date: '2026-03-01' });
    expect(fx.getRate('USD', 'PKR', '2026-02-15').rate).toBe(280);
    expect(fx.getRate('USD', 'PKR', '2026-03-01').rate).toBe(290);
    expect(fx.getRate('USD', 'PKR', '2025-12-31')).toBeNull();
    expect(() => fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 300, effective_date: '2026-03-01' })).toThrow(/already exists/);
  });

  it('derives the inverse and a cross rate through the base currency', () => {
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2026-01-01' });
    fx.create({ from_currency: 'SAR', to_currency: 'PKR', rate: 75, effective_date: '2026-01-01' });
    expect(fx.getRate('PKR', 'USD', '2026-02-01').rate).toBeCloseTo(1 / 280, 8);
    const cross = fx.getRate('USD', 'SAR', '2026-02-01');
    expect(cross.rate).toBeCloseTo(280 / 75, 8);
    expect(cross.source).toBe('via PKR');
  });

  it('convertTotals sums what it can and reports the currencies it could not convert', () => {
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2026-01-01' });
    const r = fx.convertTotals([{ currency: 'PKR', amount: 1000 }, { currency: 'USD', amount: 10 }, { currency: 'EUR', amount: 5 }], 'PKR', '2026-02-01');
    expect(r.total).toBe(3800);
    expect(r.complete).toBe(false);
    expect(r.missing).toEqual(['EUR']);
  });

  it('listCurrent returns one latest row per pair, and remove deletes + audits', () => {
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2026-01-01' });
    const b = fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 290, effective_date: '2026-03-01' });
    expect(fx.listCurrent('2026-06-01').map((r) => r.rate)).toEqual([290]);
    fx.remove(b.id);
    expect(fx.listCurrent('2026-06-01').map((r) => r.rate)).toEqual([280]);
    expect(() => fx.remove(9999)).toThrow(/not found/);
  });
});

describe('Customer 360 and report notice use the rates', () => {
  const customerService = require('../customerService');
  const bookingService = require('../bookingService');
  const c360 = require('../customer360Service');
  const reports = require('../customReportService');
  const { getDb } = require('../../../src/database/db');

  function setup() {
    freshDb();
    const cid = customerService.create({ full_name: 'Two Currency' }).id;
    const a = bookingService.create({ customer_id: cid, booking_type: 'Custom', total_price: 100000, paid_amount: 40000 });
    const b = bookingService.create({ customer_id: cid, booking_type: 'Custom', total_price: 1000, paid_amount: 0 });
    getDb().prepare("UPDATE bookings SET currency = 'USD' WHERE id = ?").run(b.id);
    return { cid, a, b };
  }

  it('without a rate: per-currency only, converted total is incomplete and names the missing currency', () => {
    const { cid } = setup();
    const s = c360.summary(cid);
    expect(s.mixed_currency).toBe(true);
    expect(s.converted.complete).toBe(false);
    expect(s.converted.missing).toEqual(['USD']);
  });

  it('with a rate: one converted total in the base currency', () => {
    const { cid } = setup();
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
    const s = c360.summary(cid);
    expect(s.converted.complete).toBe(true);
    expect(s.converted.currency).toBe('PKR');
    expect(s.converted.selling).toBe(100000 + 1000 * 280);
    expect(s.converted.outstanding).toBe(100000 + 1000 * 280); // paid comes from real payment rows, none recorded here
  });

  it('the report notice mentions the missing rate, then the converted value once a rate exists', () => {
    setup();
    const spec = { reportType: 'booking', dateFrom: null, dateTo: null };
    expect(reports.run(spec).currencyNotice).toMatch(/No exchange rate is on file for USD to PKR/);
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
    expect(reports.run(spec).currencyNotice).toMatch(/= PKR 380,000/);
  });
});
