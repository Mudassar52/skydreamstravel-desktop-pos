const { freshDb } = require('./testUtils');
const fs = require('../financialStatementsService');
const accountService = require('../accountService');
const accountingService = require('../accountingService');
const customerService = require('../customerService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const paymentService = require('../paymentService');
const refundService = require('../refundService');
const expenseService = require('../expenseService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const exchangeRates = require('../exchangeRateService');
const { getDb } = require('../../../src/database/db');

let bank, cash, cust, sup;
function seed() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  bank = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 100000 }).id;
  cash = accountService.create('Cash', { account_name: 'Till', opening_balance: 20000 }).id;
  cust = customerService.create({ full_name: 'Bilal Aziz' }).id;
  sup = supplierService.create({ name: 'Emirates GSA', service_type: 'Airline' }).id;
}
const tb = (o) => fs.trialBalance(o);
const row = (t, code) => t.rows.find((r) => r.code === code);

describe('financialStatements - empty database', () => {
  beforeEach(() => freshDb());
  it('is balanced and empty', () => {
    const t = fs.trialBalance();
    expect(t.rows).toEqual([]);
    expect(t.balanced).toBe(true);
    const b = fs.balanceSheet();
    expect(b.balanced).toBe(true);
    expect(b.total_assets).toBe(0);
  });
  it('rejects an unknown GL account', () => {
    expect(() => fs.generalLedger({ accountCode: '9999' })).toThrow(/not found/i);
  });
});

describe('financialStatements - a realistic month', () => {
  beforeEach(() => {
    seed();
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Umrah', quantity: 2, unit_price: 50000 }], tax: 5000 }); // total 105000
    paymentService.create({ customer_id: cust, invoice_id: inv.id, amount: 40000, payment_method: 'Bank Transfer', payment_type: 'Partial', account_type: 'Bank', account_id: bank });
    paymentService.create({ customer_id: cust, invoice_id: inv.id, amount: 5000, payment_method: 'Cash', payment_type: 'Partial', account_type: 'Cash', account_id: cash });
    const si = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'S-1', amount: 60000, tax: 3000 }); // 63000
    supplierPaymentService.create({ supplier_id: sup, supplier_invoice_id: si.id, amount: 30000, payment_method: 'Bank Transfer', account_type: 'Bank', account_id: bank });
    const cat = expenseService.createCategory('Stationery');
    expenseService.create({ expense_date: '2026-10-01', category_id: cat.id, amount: 2000, payment_method: 'Cash', account_type: 'Cash', account_id: cash });
    accountService.transfer({ from_type: 'Bank', from_id: bank, to_type: 'Cash', to_id: cash, amount: 10000 });
  });

  it('every account lands where the business events say', () => {
    const t = tb();
    expect(row(t, `1200-${bank}`).debit).toBe(100000 + 40000 - 30000 - 10000); // 100000
    expect(row(t, `1100-${cash}`).debit).toBe(20000 + 5000 - 2000 + 10000);   // 33000
    expect(row(t, '1300').debit).toBe(105000 - 45000);                          // receivable 60000
    expect(row(t, '2000').credit).toBe(63000 - 30000);                          // payable 33000
    expect(row(t, '4000').credit).toBe(100000);
    expect(row(t, '2100').credit).toBe(5000);
    expect(row(t, '5000').debit).toBe(60000);
    expect(row(t, '1500').debit).toBe(3000);
    expect(t.rows.find((r) => r.name === 'Expense - Stationery').debit).toBe(2000);
    // The two legs of the transfer post as one entry now, so nothing is left sitting in Transfer Clearing.
    expect(t.rows.find((r) => r.code === '1295')).toBeUndefined();
  });

  it('trial balance balances, and so does the balance sheet', () => {
    const t = tb();
    expect(t.balanced).toBe(true);
    expect(t.total_debit).toBe(t.total_credit);
    const b = fs.balanceSheet();
    expect(b.balanced).toBe(true);
    expect(b.total_assets).toBe(b.total_liabilities + b.total_equity);
    // profit = 100000 revenue - 60000 cost - 2000 expense
    expect(b.profit_to_date).toBe(38000);
  });

  it('the General Ledger agrees with the Trial Balance for every account', () => {
    const gl = fs.generalLedger({});
    const t = tb();
    for (const s of gl.sections) {
      const r = row(t, s.account.code);
      const net = s.account.type === 'Asset' || s.account.type === 'Expense' ? r.debit - r.credit : r.credit - r.debit;
      expect(s.closing).toBe(net);
    }
  });

  it('GL single account: opening, running balance and closing; date-from moves earlier postings into the opening balance', () => {
    const code = `1200-${bank}`;
    const all = fs.generalLedger({ accountCode: code });
    const s = all.sections[0];
    expect(s.rows.map((r) => r.balance)).toEqual([100000, 140000, 110000, 100000]);
    expect(s.closing).toBe(100000);
    const later = fs.generalLedger({ accountCode: code, dateFrom: '2999-01-01' });
    expect(later.sections.length).toBe(1);
    expect(later.sections[0].opening).toBe(100000);
    expect(later.sections[0].rows).toEqual([]);
  });

  it('as-of date excludes later activity and the statements still balance', () => {
    const early = tb({ asOf: '2000-01-01' });
    expect(early.rows).toEqual([]);
    expect(early.balanced).toBe(true);
  });

  it('bank and cash accounts reconcile to their stored balances', () => {
    const rec = fs.reconcileCashAndBank();
    expect(rec.length).toBe(2);
    for (const r of rec) expect(r.matches).toBe(true);
  });

  it('an overpayment shows as a customer advance (liability), not a negative receivable; refunds and voids keep it balanced', () => {
    const adv = customerService.create({ full_name: 'Advance Payer' }).id;
    paymentService.create({ customer_id: adv, amount: 25000, payment_method: 'Cash', payment_type: 'Advance', account_type: 'Cash', account_id: cash });
    let b = fs.balanceSheet();
    expect(b.liabilities.find((l) => l.label.startsWith('Customer Advances')).amount).toBe(25000);
    expect(b.balanced).toBe(true);

    const inv = invoiceService.create({ customer_id: adv, items: [{ description: 'x', quantity: 1, unit_price: 8000 }] });
    paymentService.create({ customer_id: adv, invoice_id: inv.id, amount: 8000, payment_method: 'Cash', payment_type: 'Full', account_type: 'Cash', account_id: cash });
    const refund = refundService.create({ customer_id: adv, invoice_id: inv.id, refund_amount: 500, account_type: 'Cash', account_id: cash });
    expect(fs.trialBalance().balanced).toBe(true);
    refundService.remove(refund.id);
    expect(fs.trialBalance().balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);
  });

  it('voiding a payment and cancelling an invoice drop out of the books and stay balanced', () => {
    const p = getDb().prepare('SELECT id FROM payments WHERE amount = 5000').get();
    paymentService.remove(p.id);
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'tmp', quantity: 1, unit_price: 7777 }] });
    invoiceService.cancel(inv.id);
    const t = tb();
    expect(row(t, '1300').debit).toBe(105000 - 40000);
    expect(row(t, '4000').credit).toBe(100000);
    expect(t.balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);
  });

  it('payments/expenses with no bank or cash account go to a visible clearing account instead of vanishing', () => {
    paymentService.create({ customer_id: cust, amount: 1000, payment_method: 'Cash', payment_type: 'Advance' });
    const t = tb();
    expect(row(t, '1290').debit).toBe(1000);
    expect(t.balanced).toBe(true);
  });

  it('manual one-sided accounting entries are balanced through Suspense and net out of the balance sheet', () => {
    accountingService.create({ account: 'Revenue', credit: 50000 });
    accountingService.create({ account: 'Sundry', debit: 1200 });
    const t = tb();
    expect(t.balanced).toBe(true);
    expect(row(t, 'M-Sundry').debit).toBe(1200);
    expect(row(t, '3900').debit - row(t, '3900').credit).toBe(50000 - 1200); // suspense carries the one-sided remainder
    expect(fs.balanceSheet().balanced).toBe(true);
  });

  it('the export block mirrors the on-screen figures', () => {
    const t = tb();
    expect(t.export.rows[t.export.rows.length - 1].name).toBe('TOTAL');
    expect(t.export.rows.length).toBe(t.rows.length + 1);
    expect(fs.balanceSheet().export.rows.some((r) => r.label === 'Total Assets')).toBe(true);
  });
});

describe('financialStatements - supplier opening balance and currencies', () => {
  beforeEach(seed);

  it('a supplier opening balance is a payable against Opening Balance Equity', () => {
    const s2 = supplierService.create({ name: 'Old Debt Hotel', opening_balance: 15000 }).id;
    const t = tb();
    expect(row(t, '2000').credit).toBe(15000);
    expect(t.balanced).toBe(true);
    supplierPaymentService.create({ supplier_id: s2, amount: 20000, payment_method: 'Cash', account_type: 'Cash', account_id: cash });
    const b = fs.balanceSheet();
    expect(b.assets.find((a) => a.label.startsWith('Supplier Advances')).amount).toBe(5000); // overpaid -> prepayment asset
    expect(b.balanced).toBe(true);
  });

  it('a foreign-currency supplier invoice is converted at the rate in force and both sides still balance', () => {
    exchangeRates.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
    supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'US-1', amount: 100, currency: 'USD' });
    const t = tb();
    expect(row(t, '5000').debit).toBe(28000);
    expect(row(t, '2000').credit).toBe(28000);
    expect(t.warnings).toEqual([]);
    expect(t.balanced).toBe(true);
  });

  it('with no rate on file the amount is kept at face value and a warning names the currency', () => {
    supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'US-2', amount: 100, currency: 'USD' });
    const t = tb();
    expect(row(t, '5000').debit).toBe(100);
    expect(t.warnings.join(' ')).toMatch(/USD to PKR/);
    expect(t.balanced).toBe(true);
  });
});
