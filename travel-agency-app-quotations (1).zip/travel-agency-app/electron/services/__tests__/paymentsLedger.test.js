const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const ledgerService = require('../ledgerService');

describe('paymentService + ledgerService', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Usman Farooq' }).id;
  });

  it('creating an invoice adds a debit ledger entry for its total', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Umrah', quantity: 1, unit_price: 300000 }] });
    expect(ledgerService.getBalance(cust)).toBe(300000);
  });

  it('rejects a zero-amount payment and an invalid method', () => {
    expect(() => paymentService.create({ customer_id: cust, amount: 0, payment_method: 'Cash', payment_type: 'Partial' })).toThrow(
      /greater than zero/i
    );
    expect(() => paymentService.create({ customer_id: cust, amount: 5000, payment_method: 'Bitcoin', payment_type: 'Partial' })).toThrow(
      /valid payment method/i
    );
  });

  it('a payment against an invoice reduces the ledger balance and updates invoice status', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 300000 }] });
    paymentService.create({ customer_id: cust, amount: 100000, payment_method: 'Bank Transfer', payment_type: 'Partial', invoice_id: inv.id });

    expect(invoiceService.get(inv.id).paid_amount).toBe(100000);
    expect(invoiceService.get(inv.id).status).toBe('Partially Paid');
    expect(ledgerService.getBalance(cust)).toBe(200000);
  });

  it('a full payment marks the invoice Paid and zeroes the balance', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 100000 }] });
    paymentService.create({ customer_id: cust, amount: 100000, payment_method: 'Cash', payment_type: 'Full', invoice_id: inv.id });
    expect(invoiceService.get(inv.id).status).toBe('Paid');
    expect(ledgerService.getBalance(cust)).toBe(0);
  });

  it('rejects a payment that would exceed the invoice total', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    expect(() =>
      paymentService.create({ customer_id: cust, amount: 999999, payment_method: 'Cash', payment_type: 'Partial', invoice_id: inv.id })
    ).toThrow(/exceed the invoice total/i);
  });

  it('a refund increases the balance owed again (models money going back out)', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 200000 }] });
    paymentService.create({ customer_id: cust, amount: 200000, payment_method: 'Cash', payment_type: 'Full', invoice_id: inv.id });
    expect(ledgerService.getBalance(cust)).toBe(0);

    const refund = paymentService.create({ customer_id: cust, amount: 50000, payment_method: 'Cash', payment_type: 'Refund', invoice_id: inv.id });
    expect(invoiceService.get(inv.id).paid_amount).toBe(150000);
    expect(ledgerService.getBalance(cust)).toBe(50000);

    paymentService.remove(refund.id); // void the refund
    expect(invoiceService.get(inv.id).paid_amount).toBe(200000);
    expect(ledgerService.getBalance(cust)).toBe(0);
  });

  it('voiding a normal payment reverses it without leaving a dangling reference', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    const payment = paymentService.create({ customer_id: cust, amount: 4000, payment_method: 'Cash', payment_type: 'Partial', invoice_id: inv.id });
    expect(invoiceService.get(inv.id).paid_amount).toBe(4000);
    expect(() => paymentService.remove(payment.id)).not.toThrow();
    expect(invoiceService.get(inv.id).paid_amount).toBe(0);
  });

  it('a booking-only payment (no invoice) updates the booking and the ledger', () => {
    const booking = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 40000, paid_amount: 0 });
    paymentService.create({ customer_id: cust, amount: 20000, payment_method: 'Cash', payment_type: 'Partial', booking_id: booking.id });
    expect(bookingService.get(booking.id).paid_amount).toBe(20000);
    expect(ledgerService.getBalance(cust)).toBe(-20000); // credit balance, no invoice debit exists yet
  });

  it('cancelling an invoice with an outstanding balance nets that portion out of the ledger', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Hotel', quantity: 1, unit_price: 50000 }] });
    const before = ledgerService.getBalance(cust);
    invoiceService.cancel(inv.id);
    expect(ledgerService.getBalance(cust)).toBe(before - 50000);
  });
});
