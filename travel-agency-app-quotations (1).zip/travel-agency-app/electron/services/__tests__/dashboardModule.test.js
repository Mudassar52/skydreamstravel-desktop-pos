const { freshDb } = require('./testUtils');
const searchService = require('../searchService');
const notificationService = require('../notificationService');
const savedFilterService = require('../savedFilterService');
const dashboardService = require('../dashboardService');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');

describe('searchService', () => {
  beforeEach(() => freshDb());

  it('returns no groups for a query shorter than 2 characters', () => {
    expect(searchService.search('a').groups).toEqual([]);
    expect(searchService.search('').groups).toEqual([]);
  });

  it('finds a customer by name and phone, and a booking by code', () => {
    const { id: custId } = customerService.create({ full_name: 'Zeeshan Tariq', phone: '0333-1234567' });
    const { id: bookingId } = bookingService.create({ customer_id: custId, booking_type: 'Custom', total_price: 1000 });
    const bookingCode = bookingService.get(bookingId).booking_code;

    const byName = searchService.search('Zeeshan');
    expect(byName.groups.find((g) => g.category === 'Customer')).toBeTruthy();

    const byPhone = searchService.search('0333-1234567');
    expect(byPhone.groups.find((g) => g.category === 'Customer')).toBeTruthy();

    const byBookingCode = searchService.search(bookingCode);
    expect(byBookingCode.groups.find((g) => g.category === 'Booking')).toBeTruthy();
  });

  it('every result item carries a route so the UI can open it', () => {
    customerService.create({ full_name: 'Findable Person' });
    const results = searchService.search('Findable');
    const group = results.groups.find((g) => g.category === 'Customer');
    expect(group.items[0].route).toBe('/customers');
  });
});

describe('notificationService', () => {
  let custId;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    custId = customerService.create({ full_name: 'Overdue Customer' }).id;
    invoiceService.create({ customer_id: custId, due_date: '2020-01-01', items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
  });

  it('generate() creates a notification for an overdue invoice and is idempotent', () => {
    const first = notificationService.generate();
    expect(first.created).toBeGreaterThanOrEqual(1);
    const second = notificationService.generate();
    expect(second.created).toBe(0);
  });

  it('markRead / markAllRead update unread counts correctly', () => {
    notificationService.generate();
    const before = notificationService.unreadCount();
    expect(before).toBeGreaterThan(0);
    const [first] = notificationService.list({});
    notificationService.markRead(first.id);
    expect(notificationService.unreadCount()).toBe(before - 1);
    notificationService.markAllRead();
    expect(notificationService.unreadCount()).toBe(0);
  });
});

describe('savedFilterService', () => {
  beforeEach(() => freshDb());

  it('requires a name and a module, and round-trips the filter JSON', () => {
    expect(() => savedFilterService.create({ module: 'bookings', filter: {} })).toThrow(/name is required/i);
    expect(() => savedFilterService.create({ name: 'X', filter: {} })).toThrow(/module is required/i);
    savedFilterService.create({ name: 'Unpaid Bookings This Month', module: 'bookings', filter: { status: 'Pending', dateField: 'booking_date' } });
    const filters = savedFilterService.list('bookings');
    expect(filters).toHaveLength(1);
    expect(filters[0].filter.status).toBe('Pending');
  });

  it('only returns filters for the requested module', () => {
    savedFilterService.create({ name: 'A', module: 'bookings', filter: {} });
    savedFilterService.create({ name: 'B', module: 'invoices', filter: {} });
    expect(savedFilterService.list('bookings')).toHaveLength(1);
    expect(savedFilterService.list('invoices')).toHaveLength(1);
  });
});

describe('dashboardService Phase 19 additions', () => {
  beforeEach(() => freshDb());

  it('getStats includes the new Phase 19 fields, all real numbers not undefined', () => {
    const stats = dashboardService.getStats();
    for (const key of ['customerPayments', 'supplierPayments', 'newLeadsThisMonth', 'newBookingsThisMonth', 'customerReceivables', 'supplierPayables', 'cashBalance', 'bankBalance', 'actualProfit']) {
      expect(stats[key]).not.toBeUndefined();
    }
  });

  it('getActionRequired surfaces an overdue invoice', () => {
    invoiceTemplateService.ensureDefaultTemplate();
    const custId = customerService.create({ full_name: 'Late Payer' }).id;
    invoiceService.create({ customer_id: custId, due_date: '2020-01-01', items: [{ description: 'X', quantity: 1, unit_price: 5000 }] });
    const items = dashboardService.getActionRequired();
    expect(items.some((i) => i.type === 'Overdue Customer Payment')).toBe(true);
  });

  it('getCharts returns all four expected chart datasets', () => {
    const charts = dashboardService.getCharts();
    expect(Object.keys(charts).sort()).toEqual(['bookingStatus', 'bookingsByServiceType', 'destinationPerformance', 'receivablesVsPayables'].sort());
  });

  it('getOperationsPanels returns the six real (empty) lists, never fabricated rows', () => {
    const ops = dashboardService.getOperationsPanels();
    expect(Object.keys(ops).sort()).toEqual(['departures', 'hajjGroups', 'hotelCheckIns', 'hotelCheckOuts', 'tours', 'transportToday']);
    Object.values(ops).forEach((v) => expect(v).toEqual([]));
  });

  it('getUpcomingPanels returns real (empty) arrays, never fabricated rows', () => {
    const panels = dashboardService.getUpcomingPanels();
    expect(panels.flights).toEqual([]);
    expect(panels.umrahGroups).toEqual([]);
    expect(panels.pendingPayments).toEqual([]);
  });
});

describe('dashboardService - Phase 8 additions', () => {
  beforeEach(() => freshDb());

  it('getStats reports always-current today/this-month figures independent of a past filter range', () => {
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    const cust = customerService.create({ full_name: 'Zara Sheikh' }).id;
    invoiceTemplateService.ensureDefaultTemplate();
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 50000 }] }).id;
    db.prepare(`UPDATE payments SET payment_date = date('now') WHERE invoice_id IS NULL`).run(); // no-op guard
    const paymentService = require('../paymentService');
    paymentService.create({ customer_id: cust, invoice_id: inv, amount: 20000, payment_method: 'Cash', payment_type: 'Partial' });

    const stats = dashboardService.getStats({ from: '2000-01-01', to: '2000-01-02' }); // a range with nothing in it
    expect(stats.todayPayments).toBe(20000);
    expect(stats.thisMonthSales).toBe(50000);
    expect(stats.thisMonthProfit).toBe(50000);
    expect(stats.pendingPaymentsCount).toBe(1);
  });

  it('getCalendarEvents groups departures, check-ins/outs, visa expiry, payments and follow-ups by day', () => {
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    const cust = customerService.create({ full_name: 'Imran Qureshi' }).id;
    const b = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 10000, departure_date: '2027-03-15', return_date: '2027-03-25' }).id;
    db.prepare(`INSERT INTO hotels (booking_id, hotel_name, check_in, check_out) VALUES (?, 'Hilton', '2027-03-15', '2027-03-20')`).run(b);
    db.prepare(`INSERT INTO visa_applications (customer_id, booking_id, country, expiry_date) VALUES (?, ?, 'Saudi Arabia', '2027-03-18')`).run(cust, b);
    db.prepare(`INSERT INTO follow_ups (follow_up_date, customer_id, status, notes) VALUES ('2027-03-15', ?, 'Pending', 'Confirm payment')`).run(cust);

    const events = dashboardService.getCalendarEvents(2027, 3);
    const types15 = events['2027-03-15'].map((e) => e.type).sort();
    expect(types15).toEqual(['Departure', 'Follow-up', 'Hotel Check-in']);
    expect(events['2027-03-25'][0].type).toBe('Arrival');
    expect(events['2027-03-20'][0].type).toBe('Hotel Check-out');
    expect(events['2027-03-18'][0].type).toBe('Visa Expiry');
    expect(events['2027-04-01']).toBeUndefined();
  });

  it('getCalendarEvents excludes cancelled bookings from departures/arrivals', () => {
    const cust = customerService.create({ full_name: 'Cancelled Case' }).id;
    bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 1000, departure_date: '2027-05-01', status: 'Cancelled' });
    const events = dashboardService.getCalendarEvents(2027, 5);
    expect(events['2027-05-01']).toBeUndefined();
  });
});

describe('dashboardService.getCalendarEvents payments (Phase 10)', () => {
  it('summarises payments per day (count + total) and leaves refunds out, instead of one event per payment', () => {
    freshDb();
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    const cust = customerService.create({ full_name: 'Cal Pay' }).id;
    const ins = db.prepare(`INSERT INTO payments (customer_id, payment_date, amount, payment_method, payment_type) VALUES (?, ?, ?, 'Cash', ?)`);
    ins.run(cust, '2027-06-10', 1000, 'Advance');
    ins.run(cust, '2027-06-10 15:30:00', 2500, 'Partial');
    ins.run(cust, '2027-06-10', 400, 'Refund');   // not "received"
    ins.run(cust, '2027-06-11', 700, 'Full');
    const events = dashboardService.getCalendarEvents(2027, 6);
    expect(events['2027-06-10']).toHaveLength(1);
    expect(events['2027-06-10'][0].type).toBe('Payment');
    expect(events['2027-06-10'][0].label).toContain('2 payments');
    expect(events['2027-06-10'][0].label).toContain('3,500');
    expect(events['2027-06-11'][0].label).toContain('1 payment received');
  });
});

describe('dashboardService.getOperationsPanels with real rows', () => {
  const hajjService = require('../hajjService');
  const { getDb } = require('../../../src/database/db');
  const iso = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  beforeEach(() => freshDb());

  it('reports tour seats filled / free from the tour itself', () => {
    const db = getDb();
    db.prepare(`INSERT INTO tours (tour_name, destination, start_date, total_seats, available_seats) VALUES ('Hunza', 'Hunza', ?, 30, 4)`).run(iso(5));
    db.prepare(`INSERT INTO tours (tour_name, start_date, total_seats, available_seats) VALUES ('Old tour', ?, 10, 0)`).run(iso(-5));
    const { tours } = dashboardService.getOperationsPanels();
    expect(tours).toHaveLength(1); // past tour is excluded
    expect(tours[0]).toMatchObject({ seats_filled: 26, seats_free: 4 });
  });

  it('Hajj seats: free = total_seats - pilgrims, and a full group refuses another pilgrim', () => {
    const a = customerService.create({ full_name: 'Pilgrim One' }).id;
    const b = customerService.create({ full_name: 'Pilgrim Two' }).id;
    const gid = hajjService.groups.create({ group_name: 'Hajj A', departure_date: iso(20), total_seats: '1' }).id;
    hajjService.pilgrims.add(gid, a);
    let g = dashboardService.getOperationsPanels().hajjGroups[0];
    expect(g).toMatchObject({ total_pilgrims: 1, total_seats: 1, seats_filled: 1, seats_free: 0 });
    expect(() => hajjService.pilgrims.add(gid, b)).toThrow(/No seats left/);

    const noLimit = hajjService.groups.create({ group_name: 'Hajj B', departure_date: iso(30), total_seats: '' }).id;
    hajjService.pilgrims.add(noLimit, a);
    hajjService.pilgrims.add(noLimit, b); // seats 0 = no limit, so this still works
    g = dashboardService.getOperationsPanels().hajjGroups.find((x) => x.id === noLimit);
    expect(g).toMatchObject({ total_seats: 0, total_pilgrims: 2, seats_free: 0 });
  });

  it('rejects a negative seat count', () => {
    expect(() => hajjService.groups.create({ group_name: 'Bad', total_seats: -3 })).toThrow(/Total seats/);
  });

  it('lists tomorrow\'s departure, hotel check-in/out and only today\'s non-cancelled pickups', () => {
    const db = getDb();
    db.prepare(`INSERT INTO umrah_groups (group_name, departure_date, total_passengers) VALUES ('Umrah Tomorrow', ?, 12)`).run(iso(1));
    db.prepare(`INSERT INTO umrah_groups (group_name, departure_date) VALUES ('Umrah Next Month', ?)`).run(iso(30));
    db.prepare(`INSERT INTO hotels (hotel_name, city, check_in, check_out, number_of_rooms) VALUES ('Hilton', 'Makkah', ?, ?, 3)`).run(iso(0), iso(2));
    db.prepare(`INSERT INTO transportation (pickup_location, pickup_date, pickup_time, status) VALUES ('Airport', ?, '10:00', 'Scheduled')`).run(iso(0));
    db.prepare(`INSERT INTO transportation (pickup_location, pickup_date, pickup_time, status) VALUES ('Cancelled one', ?, '11:00', 'Cancelled')`).run(iso(0));
    db.prepare(`INSERT INTO transportation (pickup_location, pickup_date, pickup_time, status) VALUES ('Tomorrow one', ?, '09:00', 'Scheduled')`).run(iso(1));

    const ops = dashboardService.getOperationsPanels();
    expect(ops.departures.map((d) => d.title)).toEqual(['Umrah Tomorrow']);
    expect(ops.hotelCheckIns.map((h) => h.hotel_name)).toEqual(['Hilton']);
    expect(ops.hotelCheckOuts.map((h) => h.hotel_name)).toEqual(['Hilton']);
    expect(ops.transportToday.map((t) => t.pickup_location)).toEqual(['Airport']);
  });
});
