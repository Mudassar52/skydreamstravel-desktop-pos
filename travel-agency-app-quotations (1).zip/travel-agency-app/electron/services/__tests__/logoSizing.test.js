const { freshDb } = require('./testUtils');
const settingsService = require('../settingsService');
const { buildLogoHtml, normalizeLogoDimension } = require('../templateEngine');

const LOGO = 'data:image/png;base64,AAAA';

describe('invoice logo width/height', () => {
  beforeEach(() => freshDb());

  it('keeps the original logo style when no size is configured (invoice design unchanged)', () => {
    expect(buildLogoHtml({ logo: LOGO })).toBe(`<img src="${LOGO}" style="max-height:56px;max-width:200px;object-fit:contain;" />`);
  });

  it('renders nothing when there is no logo', () => {
    expect(buildLogoHtml({})).toBe('');
    expect(buildLogoHtml({ logo: '', logo_width: '200' })).toBe('');
  });

  it('width and height can be set independently', () => {
    expect(buildLogoHtml({ logo: LOGO, logo_width: '300' })).toContain('width:300px;height:auto;');
    expect(buildLogoHtml({ logo: LOGO, logo_height: '90' })).toContain('width:auto;height:90px;');
    expect(buildLogoHtml({ logo: LOGO, logo_width: '240', logo_height: '80' })).toContain('width:240px;height:80px;');
  });

  it('validates the range and rejects junk', () => {
    expect(normalizeLogoDimension('')).toBeNull();
    expect(normalizeLogoDimension(undefined)).toBeNull();
    expect(normalizeLogoDimension('120.4')).toBe(120);
    expect(() => normalizeLogoDimension('abc', 'Logo width')).toThrow(/positive number/i);
    expect(() => normalizeLogoDimension('-4', 'Logo width')).toThrow(/positive number/i);
    expect(() => normalizeLogoDimension('5', 'Logo height')).toThrow(/between 10 and 600/i);
    expect(() => normalizeLogoDimension('601', 'Logo height')).toThrow(/between 10 and 600/i);
  });

  it('settings save persists valid sizes and a blank clears them', () => {
    settingsService.setMany({ logo_width: '250', logo_height: '70' });
    expect(settingsService.get('logo_width')).toBe('250');
    expect(settingsService.get('logo_height')).toBe('70');
    settingsService.setMany({ logo_width: '', logo_height: '' });
    expect(settingsService.get('logo_width')).toBe('');
    expect(settingsService.get('logo_height')).toBe('');
  });

  it('a bad size is rejected and nothing else in that save is written', () => {
    settingsService.setMany({ agency_name: 'Before' });
    expect(() => settingsService.setMany({ agency_name: 'After', logo_width: '9999' })).toThrow(/logo width/i);
    expect(settingsService.get('agency_name')).toBe('Before');
  });
});
