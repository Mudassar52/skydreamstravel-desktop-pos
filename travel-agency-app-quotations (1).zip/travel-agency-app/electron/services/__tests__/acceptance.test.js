// FINAL ACCEPTANCE TEST (master prompt 60-A.20) - run against real services and a real
// (temporary) database, no mocks. It builds the exact scenario from the spec:
//
//   Customer: Muhammad Ali      Package: Premium Umrah 15 Days     Travellers: 4
//   Booking: BK-000001 (the spec's example reads BK-00001; this app has always numbered bookings with six
//                       digits, and existing numbering is not changed)   Services: Flight, Makkah Hotel, Madinah Hotel, Visa, Transport, Ziyarat
//
// then verifies the spec's 20 numbered points one by one, plus that every screen
// agrees on the same money (customer ledger = Customer 360 = Booking 360 = invoice).
//
// Money (all amounts PKR):
//   package list price 990,000 (cost estimate 770,000)  -> booking total 990,000
//   advance 300,000 received against the booking, invoice raised, further payment 400,000
//     => paid 700,000, outstanding 290,000
//   supplier invoices (ACTUAL cost): PIA 325,000, Hilton 200,000, Oberoi 120,000, Visa agent 60,000,
//     Transport 30,000, Ziyarat 40,000 => 775,000 (estimate was 770,000 - actual must win)
//   supplier payments: PIA paid in full 325,000, Hilton part-paid 100,000 => payable 100,000
//   booking expense 5,000
//   => booking profit 990,000 - 775,000 - 5,000 = 210,000 (customer-level gross, expenses excluded: 215,000)

const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const travellerService = require('../travellerService');
const packageService = require('../packageService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const expenseService = require('../expenseService');
const ledgerService = require('../ledgerService');
const customer360 = require('../customer360Service');
const supplier360 = require('../supplier360Service');
const package360 = require('../package360Service');
const bookingDossier = require('../bookingDossierService');
const customReportService = require('../customReportService');
const dashboardService = require('../dashboardService');

let S; // the scenario's ids, built once for the whole file

function build() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  const db = getDb();

  const sup = {};
  for (const [key, name, type] of [['pia', 'PIA', 'Airline'], ['hilton', 'Hilton Makkah', 'Hotel'], ['oberoi', 'Oberoi Madinah', 'Hotel'],
    ['visa', 'Saudi Visa Agent', 'Visa'], ['transport', 'Haramain Transport', 'Transport'], ['ziyarat', 'Ziyarat Guides', 'Other']]) {
    sup[key] = supplierService.create({ name, service_type: type }).id;
  }

  const pkg = packageService.create({
    package_name: 'Premium Umrah 15 Days', package_type: 'Umrah', destination: 'Makkah & Madinah', duration: '15 Days',
    selling_price: 990000, currency: 'PKR',
    components: [
      { component_type: 'Flight', description: 'PIA Lahore-Jeddah', cost: 320000, selling_price: 380000, supplier_id: sup.pia },
      { component_type: 'Visa', description: 'Umrah visa x4', cost: 60000, selling_price: 80000, supplier_id: sup.visa },
      { component_type: 'Makkah Hotel', description: 'Hilton Makkah', cost: 200000, selling_price: 260000, supplier_id: sup.hilton },
      { component_type: 'Madinah Hotel', description: 'Oberoi Madinah', cost: 120000, selling_price: 160000, supplier_id: sup.oberoi },
      { component_type: 'Airport Pickup / Drop', description: 'Airport transfers', cost: 30000, selling_price: 50000, supplier_id: sup.transport },
      { component_type: 'Ziyarat', description: 'Makkah & Madinah ziyarat', cost: 40000, selling_price: 60000, supplier_id: sup.ziyarat }
    ]
  }).id;

  const customer = customerService.create({ full_name: 'Muhammad Ali', phone: '0300-1112233' }).id;
  const travellerNames = ['Muhammad Ali', 'Ayesha Ali', 'Hassan Ali', 'Fatima Ali'];
  const travellers = travellerNames.map((n) => travellerService.create({ full_name: n, customer_id: customer, passport_number: 'P' + n.length }).id);

  const created = bookingService.create({ customer_id: customer, package_id: pkg, departure_date: '2027-03-01', return_date: '2027-03-16', status: 'Confirmed' });
  const booking = created.id;
  travellers.forEach((t) => travellerService.addToBooking(booking, t, 'Umrah traveller'));

  // a document attached to the booking (inserted directly: the real service copies a file on disk)
  db.prepare(`INSERT INTO documents (customer_id, booking_id, document_type, file_name, file_path) VALUES (?, ?, 'Passport', 'ali-passport.pdf', '/tmp/ali-passport.pdf')`).run(customer, booking);

  // customer advance against the booking, then the invoice (which must absorb it), then a further payment
  paymentService.create({ customer_id: customer, booking_id: booking, amount: 300000, payment_method: 'Bank Transfer', payment_type: 'Advance', reference: 'ADV-1' });
  const invoice = invoiceService.createFromBooking(booking).id;
  paymentService.create({ customer_id: customer, invoice_id: invoice, amount: 400000, payment_method: 'Bank Transfer', payment_type: 'Partial', reference: 'PAY-2' });

  // supplier invoices (actual cost) + payments
  const sinv = {};
  for (const [key, number, amount] of [['pia', 'PIA-1', 325000], ['hilton', 'HIL-1', 200000], ['oberoi', 'OBE-1', 120000],
    ['visa', 'VIS-1', 60000], ['transport', 'TRN-1', 30000], ['ziyarat', 'ZIY-1', 40000]]) {
    sinv[key] = supplierInvoiceService.create({ supplier_id: sup[key], booking_id: booking, invoice_number: number, amount }).id;
  }
  supplierPaymentService.create({ supplier_id: sup.pia, supplier_invoice_id: sinv.pia, booking_id: booking, amount: 325000, payment_method: 'Bank Transfer', reference: 'SP-1' });
  supplierPaymentService.create({ supplier_id: sup.hilton, supplier_invoice_id: sinv.hilton, booking_id: booking, amount: 100000, payment_method: 'Bank Transfer', reference: 'SP-2' });

  expenseService.create({ category_id: expenseService.listCategories()[0].id, expense_date: '2027-02-20', amount: 5000, related_booking_id: booking });

  return { sup, pkg, customer, travellers, booking, bookingCode: created.booking_code || db.prepare('SELECT booking_code FROM bookings WHERE id = ?').get(booking).booking_code, invoice, sinv };
}

describe('FINAL ACCEPTANCE (60-A.20): Muhammad Ali / Premium Umrah 15 Days / 4 travellers / BK-000001', () => {
  beforeAll(() => { S = build(); });

  it('0. the booking gets the first booking number, BK-000001', () => {
    expect(S.bookingCode).toBe('BK-000001');
  });

  it('1. Customer sees BK-000001', () => {
    const rows = customer360.bookingHistory(S.customer).items;
    expect(rows.map((r) => r.booking_code)).toContain('BK-000001');
    expect(rows[0].package_name).toBe('Premium Umrah 15 Days');
  });

  it('2. Package sees BK-000001', () => {
    expect(package360.bookings(S.pkg).map((b) => b.booking_code)).toEqual(['BK-000001']);
  });

  it('3. Booking sees the exact package it was made from', () => {
    const h = bookingDossier.header(S.booking);
    expect(h.package_id).toBe(S.pkg);
    expect(h.package_snapshot.package_name).toBe('Premium Umrah 15 Days');
    expect(h.package_snapshot.components).toHaveLength(6);
    expect(h.total_price).toBe(990000);
  });

  it('4. Booking sees all 4 travellers', () => {
    expect(bookingDossier.travellers(S.booking).map((t) => t.full_name).sort())
      .toEqual(['Ayesha Ali', 'Fatima Ali', 'Hassan Ali', 'Muhammad Ali']);
  });

  it('5. Booking sees every generated service: Flight, Makkah + Madinah Hotel, Visa, Transport, Ziyarat', () => {
    expect(bookingDossier.flights(S.booking)).toHaveLength(1);
    expect(bookingDossier.hotels(S.booking).map((h) => h.hotel_name).sort()).toEqual(['Hilton Makkah', 'Oberoi Madinah']);
    expect(bookingDossier.visa(S.booking)).toHaveLength(1);
    expect(bookingDossier.transport(S.booking)).toHaveLength(1);
    const z = bookingDossier.ziyarat(S.booking);
    expect(z).toHaveLength(1);
    expect(z[0].service_type).toBe('Ziyarat');
  });

  it('6. Every service carries the correct supplier', () => {
    expect(bookingDossier.flights(S.booking)[0].supplier_name).toBe('PIA');
    const hotels = Object.fromEntries(bookingDossier.hotels(S.booking).map((h) => [h.hotel_name, h.supplier_name]));
    expect(hotels).toEqual({ 'Hilton Makkah': 'Hilton Makkah', 'Oberoi Madinah': 'Oberoi Madinah' });
    expect(bookingDossier.visa(S.booking)[0].supplier_name).toBe('Saudi Visa Agent');
    expect(bookingDossier.transport(S.booking)[0].supplier_name).toBe('Haramain Transport');
    expect(bookingDossier.ziyarat(S.booking)[0].supplier_name).toBe('Ziyarat Guides');
    expect(bookingDossier.suppliers(S.booking)).toHaveLength(6);
  });

  it('7. The customer invoice is linked to the booking (and carries the full price)', () => {
    const inv = bookingDossier.invoices(S.booking);
    expect(inv).toHaveLength(1);
    expect(inv[0].id).toBe(S.invoice);
    expect(inv[0].total).toBe(990000);
    expect(invoiceService.get(S.invoice).booking_id).toBe(S.booking);
  });

  it('8. The customer advance and the payment are linked (and the advance is counted once)', () => {
    const pays = bookingDossier.payments(S.booking);
    expect(pays.map((p) => p.amount).sort((a, b) => a - b)).toEqual([300000, 400000]);
    const adv = bookingDossier.advances(S.booking);
    expect(adv.received).toBe(300000);
    expect(adv.rows).toHaveLength(1);
    // the invoice absorbed the advance (paid 700k) - not 1,000k, which would mean it was counted twice
    expect(invoiceService.get(S.invoice).paid_amount).toBe(700000);
  });

  it('9. Supplier costs are linked to their services (estimate per service, actual per supplier invoice)', () => {
    expect(bookingDossier.flights(S.booking)[0].cost).toBe(320000);
    expect(bookingDossier.hotels(S.booking).reduce((a, h) => a + h.cost, 0)).toBe(320000);
    expect(bookingDossier.visa(S.booking)[0].cost).toBe(60000);
    expect(bookingDossier.transport(S.booking)[0].cost).toBe(30000);
    expect(bookingDossier.ziyarat(S.booking)[0].cost).toBe(40000);
    expect(bookingDossier.profit(S.booking).estimated_cost).toBe(770000);
  });

  it('10. Supplier invoices are linked to the booking and to the right suppliers', () => {
    const sc = bookingDossier.supplierCosts(S.booking);
    expect(sc.invoices).toHaveLength(6);
    expect(sc.invoiced).toBe(775000);
    expect(Object.fromEntries(sc.invoices.map((i) => [i.supplier_name, i.total]))).toEqual({
      PIA: 325000, 'Hilton Makkah': 200000, 'Oberoi Madinah': 120000, 'Saudi Visa Agent': 60000, 'Haramain Transport': 30000, 'Ziyarat Guides': 40000
    });
  });

  it('11. Supplier payments update the payable and the supplier ledger', () => {
    const hilton = supplier360.summary(S.sup.hilton);
    expect(hilton.invoices.payable).toBe(100000);          // 200,000 invoiced - 100,000 paid
    expect(hilton.ledger_balance).toBe(100000);
    const pia = supplier360.summary(S.sup.pia);
    expect(pia.invoices.payable).toBe(0);
    expect(pia.ledger_balance).toBe(0);
    const sc = bookingDossier.supplierCosts(S.booking);
    expect(sc.paid).toBe(425000);
    expect(sc.payable).toBe(350000);                        // 775,000 - 425,000 (unpaid Hilton 100k + Oberoi 120k + visa 60k + transport 30k + ziyarat 40k)
  });

  it('12. Outstanding is correct - and every screen agrees on it', () => {
    expect(bookingDossier.outstanding(S.booking).outstanding).toBe(290000);
    expect(invoiceService.get(S.invoice).remaining_amount).toBe(290000);
    expect(ledgerService.getBalance(S.customer)).toBe(290000);
    expect(customer360.summary(S.customer).outstanding_balance).toBe(290000);
    expect(customer360.bookingHistory(S.customer).items[0].outstanding).toBe(290000);
    expect(package360.bookings(S.pkg)[0].outstanding).toBe(290000);
  });

  it('13. Actual cost is correct: the real supplier invoices (775,000) win over the 770,000 estimate', () => {
    const p = bookingDossier.profit(S.booking);
    expect(p.actual_supplier_cost).toBe(775000);
    expect(p.estimated_cost).toBe(770000);
    expect(customer360.bookingHistory(S.customer).items[0].cost).toBe(775000);
    expect(customer360.bookingHistory(S.customer).items[0].cost_source).toBe('actual');
  });

  it('14. Profit is correct', () => {
    const p = bookingDossier.profit(S.booking);
    expect(p.estimated_profit).toBe(220000);                // 990,000 - 770,000
    expect(p.expenses).toBe(5000);
    expect(p.actual_profit).toBe(210000);                   // 990,000 - 775,000 - 5,000
    expect(p.margin_percent).toBeCloseTo(21.21, 1);
  });

  it('15. Customer 360 works and agrees', () => {
    const s = customer360.getDossier(S.customer).summary;
    expect(s.bookings.total).toBe(1);
    expect(s.bookings.active).toBe(1);
    expect(s.invoices.total_billed).toBe(990000);
    expect(s.payments.total_paid).toBe(700000);
    expect(s.advance).toEqual({ received: 300000, used: 300000, remaining: 0 });
    expect(s.profitability.total_cost).toBe(775000);
    expect(s.profitability.gross_profit).toBe(215000);      // customer-level: billed - cost (expenses are a company-level figure)
    expect(s.travel.next_travel_date).toBe('2027-03-01');
  });

  it('16. Package 360 works and agrees', () => {
    const d = package360.getDossier(S.pkg);
    expect(d.header.components).toHaveLength(6);
    expect(d.header.estimated_cost).toBe(770000);
    expect(d.summary.bookings.total).toBe(1);
    expect(d.summary.sold).toMatchObject
      ? expect(d.summary.sold.revenue).toBe(990000)
      : null;
    expect(d.summary.sold.collected).toBe(700000);
    expect(d.summary.sold.outstanding).toBe(290000);
    expect(d.summary.sold.cost).toBe(775000);
    expect(d.summary.sold.profit).toBe(215000);
    expect(d.summary.suppliers.sort()).toEqual(['Haramain Transport', 'Hilton Makkah', 'Oberoi Madinah', 'PIA', 'Saudi Visa Agent', 'Ziyarat Guides']);
  });

  it('17. Supplier 360 works and agrees', () => {
    const d = supplier360.getDossier(S.sup.hilton);
    expect(d.summary.services.count).toBe(1);
    expect(d.summary.services.bookings).toBe(1);
    expect(d.summary.invoices.total_billed).toBe(200000);
    expect(d.summary.payments.total_paid).toBe(100000);
    const b = supplier360.bookings(S.sup.hilton);
    expect(b).toHaveLength(1);
    expect(b[0]).toMatchObject
      ? expect(b[0].booking_code).toBe('BK-000001')
      : null;
    expect(b[0].customer_name).toBe('Muhammad Ali');
    expect(b[0].payable).toBe(100000);
    expect(supplier360.serviceUsage(S.sup.hilton).items[0].customer_name).toBe('Muhammad Ali');
  });

  it('18. Documents and the timeline stay linked, on the booking and on the customer', () => {
    expect(bookingDossier.documents(S.booking).map((d) => d.file_name)).toEqual(['ali-passport.pdf']);
    const events = bookingDossier.timeline(S.booking).map((e) => e.event);
    for (const wanted of ['Booking created', 'Invoice generated', 'Advance received', 'Payment received', 'Supplier invoice recorded', 'Supplier payment made', 'Flight added', 'Hotel added', 'Visa added', 'Transport added', 'Document uploaded']) {
      expect(events).toContain(wanted);
    }
    const custEvents = customer360.timeline(S.customer).items.map((e) => e.event);
    for (const wanted of ['Customer created', 'Booking created', 'Invoice generated', 'Document uploaded']) expect(custEvents).toContain(wanted);
    expect(customer360.timeline(S.customer).items.length).toBeGreaterThan(8);
  });

  it('19. Reports include the booking', () => {
    const booking = customReportService.run({ reportType: 'booking', selection: { mode: 'all' }, sections: ['booking_info', 'flights', 'hotels', 'visa', 'transport', 'ziyarat', 'invoices', 'payments', 'supplier_costs', 'profit'] });
    expect(booking.records).toHaveLength(1);
    expect(booking.records[0].booking.booking_code).toBe('BK-000001');
    expect(booking.records[0].sections.hotels).toHaveLength(2);
    expect(booking.records[0].sections.profit.actual_profit).toBe(210000);

    const customer = customReportService.run({ reportType: 'customer', selection: { mode: 'specific', ids: [S.customer] }, sections: ['bookings', 'invoices', 'payments', 'ledger'] });
    expect(customer.records[0].sections.bookings.map((b) => b.booking_code)).toEqual(['BK-000001']);
    expect(customer.grandTotals.total_billed).toBe(990000);
    expect(customer.records[0].sections.ledger.closingBalance).toBe(290000);

    const profitability = customReportService.run({ reportType: 'profitability' });
    const row = profitability.rows.find((r) => r.booking_code === 'BK-000001');
    expect(row).toMatchObject ? null : null;
    expect([row.selling, row.cost, row.profit]).toEqual([990000, 775000, 215000]);

    const payments = customReportService.run({ reportType: 'payment', customerId: S.customer });
    expect(payments.grandTotals.total).toBe(700000);

    const financial = customReportService.run({ reportType: 'financial' });
    const line = (n) => financial.rows.find((r) => r.line === n).amount;
    expect(line('Revenue (Invoiced)')).toBe(990000);
    expect(line('Supplier Cost (Invoiced)')).toBe(775000);
    expect(line('Operating Expenses')).toBe(5000);
    expect(financial.grandTotals.gross_profit).toBe(210000);

    const service = customReportService.run({ reportType: 'service', serviceTypes: ['Flight', 'Hotel', 'Visa', 'Transport', 'Ziyarat'] });
    expect(service.grandTotals.count).toBe(6);
    expect(service.grandTotals.purchase).toBe(770000);

    const supplier = customReportService.run({ reportType: 'supplier', selection: { mode: 'specific', ids: [S.sup.hilton] }, sections: ['invoices', 'payable'] });
    expect(supplier.records[0].sections.payable.payable).toBe(100000);
  });

  it('19b. The dashboard agrees with the same transactions', () => {
    const stats = dashboardService.getStats(null);
    expect(stats.totalSales).toBe(990000);
    expect(stats.totalCustomers).toBe(1);
    expect(stats.supplierPayables).toBe(350000);
    expect(stats.pendingPaymentsCount).toBe(1);
    expect(stats.pendingSupplierPaymentsCount).toBe(5);
  });

  it('20. Changing the package master later does NOT corrupt the historical booking', () => {
    const before = {
      header: bookingDossier.header(S.booking),
      profit: bookingDossier.profit(S.booking),
      customer: customer360.summary(S.customer),
      row: package360.bookings(S.pkg)[0]
    };

    // The agency re-prices and renames the master package, and drops a component.
    packageService.update(S.pkg, {
      package_name: 'Premium Umrah 15 Days (2028 rates)', package_type: 'Umrah', selling_price: 1500000, currency: 'PKR',
      components: [{ component_type: 'Flight', description: 'Changed', cost: 999999, selling_price: 1999999 }]
    });
    expect(package360.header(S.pkg).selling_price).toBe(1500000);

    const after = {
      header: bookingDossier.header(S.booking),
      profit: bookingDossier.profit(S.booking),
      customer: customer360.summary(S.customer),
      row: package360.bookings(S.pkg)[0]
    };
    expect(after.header.package_snapshot.package_name).toBe('Premium Umrah 15 Days');   // frozen at booking time
    expect(after.header.package_snapshot.components).toHaveLength(6);
    expect(after.header.total_price).toBe(990000);
    expect(after.profit).toEqual(before.profit);
    expect(after.customer.invoices.total_billed).toBe(before.customer.invoices.total_billed);
    expect(after.customer.profitability.gross_profit).toBe(before.customer.profitability.gross_profit);
    expect(after.row.selling).toBe(990000);
    expect(after.row.cost).toBe(775000);
    // and the booking's own services still carry what was sold, not the new master values
    expect(bookingDossier.flights(S.booking)[0].cost).toBe(320000);
    expect(bookingDossier.hotels(S.booking)).toHaveLength(2);
  });
});
