const { freshDb } = require('./testUtils');
const packageService = require('../packageService');
const umrahService = require('../umrahService');
const hajjService = require('../hajjService');
const { getDb } = require('../../../src/database/db');

describe('legacy Umrah/Hajj mirror + backfill (sanity)', () => {
  it('backfills a pre-existing legacy umrah_packages row into central packages on next init', () => {
    const tmp = freshDb();
    const legacy = umrahService.packages.create({
      package_name: 'Old Economy Umrah', package_type: 'Economy', departure_date: '2026-01-01',
      flight_included: 1, visa_included: 1, hotel_included: 1, makkah_hotel: 'Old Makkah Hotel',
      package_cost: 100000, selling_price: 130000
    });

    // Simulate the app restarting on the same database file (init runs the
    // idempotent migration again, without wiping anything).
    const { initDatabase } = require('../../../src/database/db');
    initDatabase(tmp);

    const central = packageService.list({ packageType: 'Umrah' });
    const migrated = central.rows.find((p) => p.package_name === 'Old Economy Umrah');
    expect(migrated).toBeTruthy();
    const full = packageService.get(migrated.id);
    expect(full.legacy_mirror_table).toBe('umrah_packages');
    expect(full.legacy_mirror_id).toBe(legacy.id);
    expect(full.components.some((c) => c.component_type === 'Makkah Hotel')).toBe(true);
  });

  it('creating a central Umrah package mirrors it into umrah_packages so Groups can use it', () => {
    freshDb();
    const pkg = packageService.create({
      package_name: 'New Central Umrah', package_type: 'Umrah', selling_price: 200000,
      components: [{ component_type: 'Flight', cost: 50000, selling_price: 60000 }]
    });
    const full = packageService.get(pkg.id);
    expect(full.legacy_mirror_table).toBe('umrah_packages');

    const legacyList = umrahService.packages.list();
    const mirrored = legacyList.find((p) => p.id === full.legacy_mirror_id);
    expect(mirrored.package_name).toBe('New Central Umrah');
    expect(mirrored.flight_included).toBe(1);

    // A Group can reference the mirror id without violating the FK.
    const group = umrahService.groups.create({ group_name: 'Dec Batch', package_id: mirrored.id });
    expect(group.id).toBeTruthy();

    // Editing the central package keeps the mirror in sync.
    packageService.update(pkg.id, {
      package_name: 'New Central Umrah (Updated)', package_type: 'Umrah', selling_price: 210000,
      components: [{ component_type: 'Flight', cost: 50000, selling_price: 60000 }]
    });
    const mirroredAfter = umrahService.packages.get(mirrored.id);
    expect(mirroredAfter.package_name).toBe('New Central Umrah (Updated)');

    // Deleting the central package leaves the mirror in place since a Group uses it.
    packageService.remove(pkg.id);
    expect(() => umrahService.packages.get(mirrored.id)).not.toThrow();
  });

  it('mirrors Hajj packages too', () => {
    freshDb();
    const pkg = packageService.create({
      package_name: 'Central Hajj Pkg', package_type: 'Hajj', selling_price: 500000,
      components: [{ component_type: 'Hotel', description: 'Makkah Towers', cost: 100000, selling_price: 120000 }]
    });
    const full = packageService.get(pkg.id);
    expect(full.legacy_mirror_table).toBe('hajj_packages');
    const mirrored = hajjService.packages.get(full.legacy_mirror_id);
    expect(mirrored.makkah_hotel).toBe('Makkah Towers');
  });
});
