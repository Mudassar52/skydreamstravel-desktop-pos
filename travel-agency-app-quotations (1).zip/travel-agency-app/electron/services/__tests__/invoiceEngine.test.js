const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const { renderTemplate } = require('../templateEngine');

describe('templateEngine', () => {
  it('HTML-escapes double-brace tokens but not triple-brace ones', () => {
    const html = renderTemplate('Hello {{name}}, table: {{{raw}}}', {
      name: '<script>alert(1)</script>',
      raw: '<tr><td>Line item</td></tr>'
    });
    expect(html).toContain('&lt;script&gt;');
    expect(html).not.toContain('<script>alert(1)</script>');
    expect(html).toContain('<tr><td>Line item</td></tr>');
  });

  it('renders missing tokens as empty string rather than throwing', () => {
    expect(() => renderTemplate('{{unknown_token}}', {})).not.toThrow();
    expect(renderTemplate('X{{unknown_token}}Y', {})).toBe('XY');
  });
});

describe('invoiceTemplateService', () => {
  beforeEach(() => freshDb());

  it('seeds exactly one default template', () => {
    invoiceTemplateService.ensureDefaultTemplate();
    const templates = invoiceTemplateService.list();
    expect(templates).toHaveLength(1);
    expect(templates[0].is_default).toBe(1);
  });

  it('refuses to delete the default template', () => {
    invoiceTemplateService.ensureDefaultTemplate();
    const def = invoiceTemplateService.getDefault();
    expect(() => invoiceTemplateService.remove(def.id)).toThrow(/cannot delete the default/i);
  });

  it('can promote a new template to default and delete the old one', () => {
    invoiceTemplateService.ensureDefaultTemplate();
    const oldDefault = invoiceTemplateService.getDefault();
    const created = invoiceTemplateService.create({ template_name: 'Minimal', html: '<html>{{invoice_number}}</html>' });
    invoiceTemplateService.setDefault(created.id);
    expect(invoiceTemplateService.getDefault().id).toBe(created.id);
    expect(() => invoiceTemplateService.remove(oldDefault.id)).not.toThrow();
  });
});

describe('invoiceService', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Hamza Sheikh' }).id;
  });

  it('rejects an invoice with no line items', () => {
    expect(() => invoiceService.create({ customer_id: cust, items: [] })).toThrow(/at least one line item/i);
  });

  it('rejects a blank line item description', () => {
    expect(() => invoiceService.create({ customer_id: cust, items: [{ description: '', quantity: 1, unit_price: 100 }] })).toThrow(
      /needs a description/i
    );
  });

  it('rejects a negative quantity', () => {
    expect(() => invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: -1, unit_price: 100 }] })).toThrow(
      /quantity must be greater than zero/i
    );
  });

  it('computes totals and status correctly, and issues sequential invoice numbers', () => {
    const inv1 = invoiceService.create({
      customer_id: cust,
      discount: 5000,
      paid_amount: 50000,
      items: [{ description: 'Umrah Package', quantity: 1, unit_price: 200000 }]
    });
    const detail = invoiceService.get(inv1.id);
    expect(detail.subtotal).toBe(200000);
    expect(detail.total).toBe(195000);
    expect(detail.remaining_amount).toBe(145000);
    expect(detail.status).toBe('Partially Paid');

    const inv2 = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 10000 }] });
    expect(Number(inv2.invoiceNumber.match(/\d+$/)[0])).toBeGreaterThan(Number(inv1.invoiceNumber.match(/\d+$/)[0]));
  });

  it('duplicates an invoice with paid reset to zero and status Unpaid', () => {
    const original = invoiceService.create({ customer_id: cust, paid_amount: 100000, items: [{ description: 'X', quantity: 1, unit_price: 100000 }] });
    const dup = invoiceService.duplicate(original.id);
    const detail = invoiceService.get(dup.id);
    expect(detail.paid_amount).toBe(0);
    expect(detail.status).toBe('Unpaid');
    expect(dup.invoiceNumber).not.toBe(original.invoiceNumber);
  });

  it('creates an invoice from a booking, carrying over price and paid amount', () => {
    const booking = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 40000, paid_amount: 10000 });
    const inv = invoiceService.createFromBooking(booking.id);
    const detail = invoiceService.get(inv.id);
    expect(detail.total).toBe(40000);
    expect(detail.paid_amount).toBe(10000);
    expect(detail.booking_code).toBe(booking.bookingCode);
  });

  it('blocks deleting an invoice with payments, allows cancelling it instead', () => {
    const inv = invoiceService.create({ customer_id: cust, paid_amount: 5000, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    expect(() => invoiceService.remove(inv.id)).toThrow(/cannot be deleted/i);
    expect(() => invoiceService.cancel(inv.id)).not.toThrow();
    expect(invoiceService.get(inv.id).status).toBe('Cancelled');
  });

  it('refuses to edit a cancelled invoice back to an active status', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }] });
    invoiceService.cancel(inv.id);
    expect(() =>
      invoiceService.update(inv.id, { customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 10000 }], status: 'Unpaid' })
    ).toThrow(/create a new invoice instead/i);
  });

  it('renders a full invoice to HTML with real customer/invoice data embedded', () => {
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Test Package', quantity: 1, unit_price: 50000 }] });
    const html = invoiceService.buildInvoiceHtml(inv.id);
    expect(html).toContain(inv.invoiceNumber);
    expect(html).toContain('Hamza Sheikh');
    expect(html).toContain('Test Package');
  });
});
