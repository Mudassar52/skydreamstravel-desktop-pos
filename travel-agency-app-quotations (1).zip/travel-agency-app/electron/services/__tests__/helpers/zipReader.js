// Minimal, independent ZIP reader (STORE method only) used purely to verify
// xlsxWriter.js's output in tests. Deliberately written from the ZIP spec
// independently of the writer, so it is a real cross-check rather than a
// mirror of the writer's own assumptions. Lives inside the repo (not in any
// sandbox tooling) so `npm test` works on any machine. Not a *.test.js file,
// so the test runner does not try to execute it as a suite.
const zlib = require('zlib');

function readZip(buf) {
  // Find the End Of Central Directory record (scan from the end for its signature).
  let eocdOffset = -1;
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocdOffset = i; break; }
  }
  if (eocdOffset === -1) throw new Error('Not a valid zip: EOCD not found');
  const totalEntries = buf.readUInt16LE(eocdOffset + 10);
  const centralDirOffset = buf.readUInt32LE(eocdOffset + 16);

  const entries = [];
  let p = centralDirOffset;
  for (let i = 0; i < totalEntries; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Bad central directory signature at entry ' + i);
    const method = buf.readUInt16LE(p + 10);
    const crc = buf.readUInt32LE(p + 16);
    const compSize = buf.readUInt32LE(p + 20);
    const uncompSize = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOffset = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf-8', p + 46, p + 46 + nameLen);
    entries.push({ name, method, crc, compSize, uncompSize, localOffset });
    p += 46 + nameLen + extraLen + commentLen;
  }

  for (const e of entries) {
    const lp = e.localOffset;
    if (buf.readUInt32LE(lp) !== 0x04034b50) throw new Error('Bad local header signature for ' + e.name);
    const nameLen = buf.readUInt16LE(lp + 26);
    const extraLen = buf.readUInt16LE(lp + 28);
    const dataStart = lp + 30 + nameLen + extraLen;
    e.data = buf.subarray(dataStart, dataStart + e.compSize);
    if (e.method !== 0) throw new Error('Expected STORE method for ' + e.name);
    const actualCrc = zlib.crc32(e.data) >>> 0;
    if (actualCrc !== e.crc) throw new Error(`CRC mismatch for ${e.name}: header=${e.crc} actual=${actualCrc}`);
  }
  return entries;
}

module.exports = { readZip };
