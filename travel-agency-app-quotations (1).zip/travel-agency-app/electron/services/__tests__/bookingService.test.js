const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const umrahService = require('../umrahService');

describe('bookingService', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    cust = customerService.create({ full_name: 'Zara Malik' }).id;
  });

  it('creates a booking with a sequential booking code', () => {
    const b1 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 50000 });
    const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 30000 });
    expect(b1.bookingCode).toBe('BK-000001');
    expect(b2.bookingCode).toBe('BK-000002');
  });

  it('rejects a missing customer', () => {
    expect(() => bookingService.create({ booking_type: 'Tour' })).toThrow(/customer must be selected/i);
  });

  it('rejects an invalid booking type', () => {
    expect(() => bookingService.create({ customer_id: cust, booking_type: 'NotAType' })).toThrow(/valid booking type/i);
  });

  it('rejects paid amount exceeding total', () => {
    expect(() => bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 100, paid_amount: 500 })).toThrow(
      /cannot exceed/i
    );
  });

  it('rejects a nonexistent customer', () => {
    expect(() => bookingService.create({ customer_id: 99999, booking_type: 'Tour' })).toThrow(/does not exist/i);
  });

  it('rejects return date before departure date', () => {
    expect(() =>
      bookingService.create({ customer_id: cust, booking_type: 'Tour', departure_date: '2026-12-10', return_date: '2026-12-01' })
    ).toThrow(/return date cannot be before/i);
  });

  it('computes remaining amount and derives correct status on update', () => {
    const b = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 200000, paid_amount: 50000 });
    expect(bookingService.get(b.id).remaining_amount).toBe(150000);

    bookingService.update(b.id, { customer_id: cust, booking_type: 'Umrah', total_price: 200000, paid_amount: 200000, status: 'Confirmed' });
    expect(bookingService.get(b.id).remaining_amount).toBe(0);
  });

  it('resolves the package/reference for Umrah bookings', () => {
    const pkg = umrahService.packages.create({ package_name: 'Deluxe Umrah' });
    const b = bookingService.create({ customer_id: cust, booking_type: 'Umrah', reference_id: pkg.id, total_price: 100000 });
    expect(bookingService.get(b.id).referenceLabel).toBe('Deluxe Umrah');
  });

  it('returns reference options only for types with a real package table', () => {
    umrahService.packages.create({ package_name: 'Deluxe Umrah' });
    expect(bookingService.getReferenceOptions('Umrah')).toHaveLength(1);
    expect(bookingService.getReferenceOptions('Flight')).toHaveLength(0);
  });

  it('syncs the passenger headcount automatically', () => {
    const b = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 10000 });
    const cust2 = customerService.create({ full_name: 'Second Passenger' }).id;
    bookingService.passengers.add(b.id, cust);
    bookingService.passengers.add(b.id, cust2);
    expect(bookingService.get(b.id).number_of_passengers).toBe(2);
  });

  it('blocks deleting a booking that has an invoice, allows it otherwise', () => {
    const { getDb } = require('../../../src/database/db');
    const b1 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 10000 });
    const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 10000 });
    getDb()
      .prepare("INSERT INTO invoices (invoice_number, customer_id, booking_id, total) VALUES ('INV-0001', ?, ?, 10000)")
      .run(cust, b1.id);

    expect(() => bookingService.remove(b1.id)).toThrow(/invoices linked/i);
    expect(() => bookingService.remove(b2.id)).not.toThrow();
  });
});
