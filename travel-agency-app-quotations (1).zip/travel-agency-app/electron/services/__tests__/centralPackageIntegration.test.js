const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const packageService = require('../packageService');
const bookingService = require('../bookingService');
const supplierService = require('../supplierService');
const flightService = require('../flightService');
const hotelService = require('../hotelService');
const visaService = require('../visaService');
const otherServiceService = require('../otherServiceService');

// Phase 20: one central Package Management module (Umrah/Hajj/Tour/Custom)
// feeding the same Booking system, instead of separate disconnected
// package/booking systems per product line.
describe('central package -> booking integration', () => {
  let cust;
  let supplier;

  beforeEach(() => {
    freshDb();
    cust = customerService.create({ full_name: 'Muhammad Ali' }).id;
    supplier = supplierService.create({ name: 'Al-Safar Travels', service_type: 'Hotel' }).id;
  });

  function makeUmrahPackage(overrides = {}) {
    return packageService.create({
      package_name: 'Premium Umrah 15 Days',
      package_type: 'Umrah',
      selling_price: 250000,
      departure_date: '2026-12-01',
      return_date: '2026-12-15',
      components: [
        { component_type: 'Flight', description: 'PIA Direct Flight', cost: 60000, selling_price: 70000 },
        { component_type: 'Visa', description: 'Saudi Arabia', cost: 15000, selling_price: 18000 },
        { component_type: 'Makkah Hotel', description: 'Swissotel Al Maqam', cost: 40000, selling_price: 50000, supplier_id: supplier },
        { component_type: 'Madinah Hotel', description: 'Anwar Al Madinah', cost: 30000, selling_price: 38000, supplier_id: supplier },
        { component_type: 'Ziyarat', description: 'Makkah + Madinah Ziyarat', cost: 5000, selling_price: 8000 }
      ],
      ...overrides
    });
  }

  it('computes estimated cost and profit from the component list', () => {
    const pkg = makeUmrahPackage();
    const full = packageService.get(pkg.id);
    expect(full.estimated_cost).toBe(150000);
    expect(full.estimated_profit).toBe(100000);
  });

  it('rejects a component type that does not belong to the chosen package type', () => {
    expect(() =>
      packageService.create({
        package_name: 'Bad Tour',
        package_type: 'Tour',
        components: [{ component_type: 'Ziyarat', cost: 100 }]
      })
    ).toThrow(/not a valid component/i);
  });

  it('creates a booking from a package and auto-links flights/hotels/visa/other services to the same booking', () => {
    const pkg = makeUmrahPackage();
    const booking = bookingService.create({ customer_id: cust, package_id: pkg.id, number_of_passengers: 4, paid_amount: 100000 });

    const b = bookingService.get(booking.id);
    expect(b.booking_type).toBe('Umrah');
    expect(b.package_id).toBe(pkg.id);
    expect(b.total_price).toBe(250000);
    expect(b.remaining_amount).toBe(150000);
    expect(b.departure_date).toBe('2026-12-01');

    expect(flightService.listByBooking(booking.id)).toHaveLength(1);
    expect(hotelService.listByBooking(booking.id)).toHaveLength(2);
    expect(visaService.listByBooking(booking.id)).toHaveLength(1);

    const others = otherServiceService.list({ bookingId: booking.id });
    expect(others.total).toBe(1);
    expect(others.rows[0].service_type).toBe('Ziyarat');

    const madinahHotel = hotelService.listByBooking(booking.id).find((h) => h.hotel_name.includes('Anwar'));
    expect(madinahHotel.supplier_id).toBe(supplier);
  });

  it('rejects using a non-matching package type for the booking', () => {
    const pkg = makeUmrahPackage();
    expect(() =>
      bookingService.create({ customer_id: cust, package_id: pkg.id, booking_type: 'Tour' })
    ).toThrow(/Umrah package and cannot be used for a Tour booking/i);
  });

  it('keeps a booking\'s frozen snapshot and price even after the master package is edited later', () => {
    const pkg = makeUmrahPackage();
    const booking = bookingService.create({ customer_id: cust, package_id: pkg.id });

    packageService.update(pkg.id, {
      package_name: 'Premium Umrah 15 Days',
      package_type: 'Umrah',
      selling_price: 999999,
      components: []
    });

    const bAfter = bookingService.get(booking.id);
    expect(bAfter.total_price).toBe(250000);
    const snapshot = JSON.parse(bAfter.package_snapshot);
    expect(snapshot.package_price).toBe(250000);
    expect(snapshot.components).toHaveLength(5);
  });

  it('blocks deleting a package that already has bookings against it', () => {
    const pkg = makeUmrahPackage();
    bookingService.create({ customer_id: cust, package_id: pkg.id });
    expect(() => packageService.remove(pkg.id)).toThrow(/bookings linked/i);
  });
});
