const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const travellerService = require('../travellerService');
const flightService = require('../flightService');
const hotelService = require('../hotelService');
const visaService = require('../visaService');
const voucherService = require('../voucherService');

function setup() {
  freshDb();
  const lead = customerService.create({ full_name: 'Ahmed Khan', passport_number: 'LEAD111' }).id;
  const booking = bookingService.create({ customer_id: lead, booking_type: 'Umrah', total_price: 600000, number_of_passengers: 3, status: 'Confirmed' }).id;
  const wife = travellerService.create({ customer_id: lead, full_name: 'Ayesha Khan', relationship: 'Spouse', passport_number: 'W222' }).id;
  const child = travellerService.create({ customer_id: lead, full_name: 'Bilal Khan', relationship: 'Child', passport_number: 'C333' }).id;
  travellerService.addToBooking(booking, wife, null);
  travellerService.addToBooking(booking, child, null);
  return { lead, booking, wife, child };
}

describe('family booking: travellers flow into flights, visas and hotel rooms', () => {
  it('flight: add all travellers of the booking in one click, no duplicates', () => {
    const { booking, wife } = setup();
    const flight = flightService.create({ booking_id: booking, airline: 'PIA', flight_number: 'PK741' }).id;
    expect(flightService.travellers.addAll(flight)).toEqual({ added: 2, total: 2 });
    expect(flightService.travellers.addAll(flight)).toEqual({ added: 0, total: 2 }); // safe to press twice
    expect(flightService.travellers.list(flight).map((t) => t.full_name)).toEqual(['Ayesha Khan', 'Bilal Khan']);
    expect(() => flightService.travellers.add(flight, wife)).toThrow(/already/);
  });

  it('flight: someone not on the booking cannot be put on its flight', () => {
    const { lead, booking } = setup();
    const stranger = travellerService.create({ customer_id: lead, full_name: 'Not Travelling' }).id;
    const flight = flightService.create({ booking_id: booking, airline: 'PIA', flight_number: 'PK1' }).id;
    expect(() => flightService.travellers.add(flight, stranger)).toThrow(/booking/i);
  });

  it('visa: one application per person, lead included, repeat press creates nothing new', () => {
    const { lead, booking, wife } = setup();
    expect(visaService.createForBooking(booking, { country: 'Saudi Arabia', visa_type: 'Umrah' })).toEqual({ created: 3, skipped: 0 });
    expect(visaService.createForBooking(booking, { country: 'Saudi Arabia', visa_type: 'Umrah' })).toEqual({ created: 0, skipped: 3 });
    const rows = visaService.listByBooking(booking);
    expect(rows.map((r) => r.customer_name).sort()).toEqual(['Ahmed Khan', 'Ayesha Khan', 'Bilal Khan']);
    const w = rows.find((r) => r.traveller_id === wife);
    expect(w.customer_id).toBe(lead);          // billed to the booking holder
    expect(w.passport_number).toBe('W222');
    // the Visa page list shows the member's own name and searches by it
    expect(visaService.list({ search: 'Ayesha' }).rows).toHaveLength(1);
  });

  it('visa: can leave the lead out; country is required', () => {
    const { booking } = setup();
    expect(visaService.createForBooking(booking, { country: 'UAE', include_lead: false }).created).toBe(2);
    expect(() => visaService.createForBooking(booking, { country: '' })).toThrow(/Country/);
  });

  it('hotel: guest list with rooms prints on the voucher, only ticked guests', () => {
    const { booking, wife, child } = setup();
    const hotel = hotelService.create({ booking_id: booking, hotel_name: 'Swissotel Makkah' }).id;
    const before = hotelService.guests.list(hotel);
    expect(before.guests.map((g) => g.selected)).toEqual([true, true, true]);   // default: everybody
    hotelService.guests.save(hotel, [
      { is_lead: 1, traveller_id: null, selected: true, room_number: '501' },
      { is_lead: 0, traveller_id: wife, selected: true, room_number: '501' },
      { is_lead: 0, traveller_id: child, selected: false, room_number: '' }
    ]);
    const html = voucherService.buildHotelVoucherHtml(booking, hotel).html;
    expect(html).toContain('Guests &amp; Room Allocation');
    expect(html).toContain('Ayesha Khan');
    expect(html).toContain('Room 501');
    expect(html).not.toContain('Bilal Khan');
    expect(hotelService.guests.list(hotel).guests.map((g) => g.selected)).toEqual([true, true, false]);
  });

  it('removing someone from the booking also removes them from its flights and hotel stays', () => {
    const { booking, wife } = setup();
    const flight = flightService.create({ booking_id: booking, airline: 'PIA', flight_number: 'PK2' }).id;
    const hotel = hotelService.create({ booking_id: booking, hotel_name: 'Hilton' }).id;
    flightService.travellers.addAll(flight);
    hotelService.guests.save(hotel, [{ is_lead: 0, traveller_id: wife, selected: true, room_number: '1' }]);
    const membership = travellerService.listForBooking(booking).find((t) => t.id === wife).membership_id;
    travellerService.removeFromBooking(membership);
    expect(flightService.travellers.list(flight).map((t) => t.traveller_id)).not.toContain(wife);
    expect(getDb().prepare('SELECT COUNT(*) c FROM hotel_guests WHERE traveller_id = ?').get(wife).c).toBe(0);
  });
});
