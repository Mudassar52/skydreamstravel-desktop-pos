const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const expenseService = require('../expenseService');
const profitService = require('../profitService');
const dashboardService = require('../dashboardService');

describe('expenseService', () => {
  beforeEach(() => freshDb());

  it('seeds default categories', () => {
    expect(expenseService.listCategories().length).toBeGreaterThan(0);
  });

  it('rejects a duplicate category name', () => {
    expect(() => expenseService.createCategory('Flight')).toThrow(/already exists/i);
  });

  it('rejects an expense with no category/date/amount', () => {
    expect(() => expenseService.create({})).toThrow();
  });

  it('rejects a negative amount', () => {
    const cat = expenseService.listCategories()[0];
    expect(() => expenseService.create({ category_id: cat.id, expense_date: '2026-09-01', amount: -100 })).toThrow(
      /greater than zero/i
    );
  });

  it('blocks deleting a category that has expenses, allows it when unused', () => {
    const cat = expenseService.listCategories()[0];
    expenseService.create({ category_id: cat.id, expense_date: '2026-09-01', amount: 5000 });
    expect(() => expenseService.removeCategory(cat.id)).toThrow(/cannot be deleted/i);

    const unused = expenseService.createCategory('Unused Category');
    expect(() => expenseService.removeCategory(unused.id)).not.toThrow();
  });
});

describe('profitService', () => {
  let cust, booking;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Fahad Malik' }).id;
    booking = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 100000, paid_amount: 0 }).id;
  });

  it('computes profit as Revenue (sales) minus Expenses - never Payments minus Expenses', () => {
    invoiceService.createFromBooking(booking);
    const cat = expenseService.listCategories()[0];
    expenseService.create({ category_id: cat.id, expense_date: '2026-09-01', amount: 35000, related_booking_id: booking });

    const summary = profitService.getSummary();
    expect(summary.revenue).toBe(100000); // the sale, even though nothing has been paid
    expect(summary.expenses).toBe(35000);
    expect(summary.profit).toBe(65000);
  });

  it("the Dashboard's estimated profit uses the same Sales-based formula", () => {
    invoiceService.createFromBooking(booking);
    const cat = expenseService.listCategories()[0];
    expenseService.create({ category_id: cat.id, expense_date: '2026-09-01', amount: 35000 });

    const stats = dashboardService.getStats();
    expect(stats.totalReceived).toBe(0); // no payments recorded
    expect(stats.estimatedProfit).toBe(stats.totalSales - stats.totalExpenses);
    expect(stats.estimatedProfit).toBe(65000);
  });

  it('breaks profit down by booking type', () => {
    invoiceService.createFromBooking(booking);
    const byType = profitService.getByBookingType();
    const umrahRow = byType.find((r) => r.type === 'Umrah');
    expect(umrahRow.revenue).toBe(100000);
  });

  it('Total Sales and Estimated Profit stay consistent even with a cancelled invoice present', () => {
    invoiceService.createFromBooking(booking);
    const cancelledInv = invoiceService.create({ customer_id: cust, items: [{ description: 'Cancelled Item', quantity: 1, unit_price: 999999 }] });
    invoiceService.cancel(cancelledInv.id);

    const stats = dashboardService.getStats();
    // The cancelled invoice's huge amount must not leak into either figure.
    expect(stats.totalSales).toBe(100000);
    expect(stats.estimatedProfit).toBe(stats.totalSales - stats.totalExpenses);
  });
});
