import { describe, it, expect, beforeEach, vi } from 'vitest';
import fs from 'fs';
import os from 'os';
import path from 'path';
import Module from 'module';
import { createRequire } from 'module';

// backupService reads app.getPath()/dialog.* from 'electron', which doesn't
// exist outside a real Electron process. vi.mock only intercepts Vite's own
// module graph, not plain Node require() calls between CJS files (which is
// what's needed here so db.js's singleton is actually shared across
// db.js/customerService.js/documentService.js/backupService.js) - so
// 'electron' is faked by patching Node's own module loader directly instead,
// the same technique used to verify this service manually back in Phase 14.
const state = { userData: '' };
const fakeElectron = {
  app: {
    getPath: (name) => (name === 'temp' ? os.tmpdir() : state.userData),
    getVersion: () => '0.1.0-test',
    relaunch: vi.fn(),
    exit: vi.fn()
  },
  dialog: {
    showSaveDialog: vi.fn(),
    showOpenDialog: vi.fn()
  }
};
const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return fakeElectron;
  return originalLoad.apply(this, arguments);
};

const require = createRequire(import.meta.url);
const { initDatabase } = require('../../../src/database/db.js');
const customerService = require('../customerService.js');
const documentService = require('../documentService.js');
const backupService = require('../backupService.js');
const { dialog } = fakeElectron;

describe('backupService', () => {
  let storageDir;

  beforeEach(() => {
    state.userData = fs.mkdtempSync(path.join(os.tmpdir(), 'tam-vitest-backup-'));
    initDatabase(state.userData);
    documentService.initStorage(state.userData);
    storageDir = path.join(state.userData, 'storage', 'documents');
    dialog.showSaveDialog.mockReset();
    dialog.showOpenDialog.mockReset();
  });

  it('creates a backup zip containing the database and documents', async () => {
    customerService.create({ full_name: 'Backup Test Customer' });
    fs.writeFileSync(path.join(storageDir, 'test-doc.txt'), 'hello backup world');

    const zipPath = path.join(os.tmpdir(), `test-backup-${Date.now()}.zip`);
    dialog.showSaveDialog.mockResolvedValueOnce({ canceled: false, filePath: zipPath });

    const result = await backupService.createBackup();
    expect(result.saved).toBe(true);
    expect(fs.existsSync(zipPath)).toBe(true);
  });

  it('handles a cancelled save dialog gracefully', async () => {
    dialog.showSaveDialog.mockResolvedValueOnce({ canceled: true });
    const result = await backupService.createBackup();
    expect(result.saved).toBe(false);
  });

  it('restore replaces current data with the backup, exactly (proven by mutating data after backup)', async () => {
    customerService.create({ full_name: 'Should Survive' });
    fs.writeFileSync(path.join(storageDir, 'keep-me.txt'), 'keep me');

    const zipPath = path.join(os.tmpdir(), `test-backup-restore-${Date.now()}.zip`);
    dialog.showSaveDialog.mockResolvedValueOnce({ canceled: false, filePath: zipPath });
    await backupService.createBackup();

    customerService.create({ full_name: 'Should Disappear' });
    fs.writeFileSync(path.join(storageDir, 'should-disappear.txt'), 'temp');
    expect(customerService.list({}).total).toBe(2);

    dialog.showOpenDialog.mockResolvedValueOnce({ canceled: false, filePaths: [zipPath] });
    const restoreResult = await backupService.restoreBackup();
    expect(restoreResult.restored).toBe(true);

    const afterRestore = customerService.list({});
    expect(afterRestore.total).toBe(1);
    expect(afterRestore.rows[0].full_name).toBe('Should Survive');

    const filesNow = fs.readdirSync(storageDir);
    expect(filesNow).toContain('keep-me.txt');
    expect(filesNow).not.toContain('should-disappear.txt');
    expect(fs.readFileSync(path.join(storageDir, 'keep-me.txt'), 'utf-8')).toBe('keep me');
  });

  it('rejects a zip that does not contain agency.db', async () => {
    const AdmZip = require('adm-zip');
    const badZip = new AdmZip();
    badZip.addFile('not-a-db.txt', Buffer.from('nope'));
    const badZipPath = path.join(os.tmpdir(), `bad-${Date.now()}.zip`);
    badZip.writeZip(badZipPath);

    dialog.showOpenDialog.mockResolvedValueOnce({ canceled: false, filePaths: [badZipPath] });
    await expect(backupService.restoreBackup()).rejects.toThrow(/valid backup file/i);
  });

  it('auto-backup runs once when due, then skips an immediate second check', async () => {
    dialog.showOpenDialog.mockResolvedValueOnce({ canceled: false, filePaths: [state.userData] });
    await backupService.chooseBackupFolder();
    backupService.setAutoBackupEnabled(true);

    const first = await backupService.runAutomaticBackupIfDue();
    expect(first.ran).toBe(true);

    const second = await backupService.runAutomaticBackupIfDue();
    expect(second.ran).toBe(false);
  });
});
