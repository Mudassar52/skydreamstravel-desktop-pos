const { freshDb } = require('./testUtils');
const otherServiceService = require('../otherServiceService');
const taskService = require('../taskService');
const deadlineService = require('../deadlineService');
const calendarService = require('../calendarService');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const flightService = require('../flightService');
const hotelService = require('../hotelService');

describe('otherServiceService', () => {
  beforeEach(() => freshDb());

  it('requires a valid service type', () => {
    expect(() => otherServiceService.create({})).toThrow(/valid service type/i);
    expect(() => otherServiceService.create({ service_type: 'NotAType' })).toThrow(/valid service type/i);
    const { id } = otherServiceService.create({ service_type: 'Ziyarat', cost: 1000, selling_price: 1500 });
    expect(otherServiceService.get(id).service_type).toBe('Ziyarat');
  });
});

describe('taskService', () => {
  beforeEach(() => freshDb());

  it('requires a title and derives Overdue from a past due_date on a Pending task', () => {
    expect(() => taskService.create({})).toThrow(/title is required/i);
    const { id } = taskService.create({ title: 'Call customer', due_date: '2020-01-01' });
    expect(taskService.get(id).effective_status).toBe('Overdue');
  });

  it('marking Completed overrides the date-derived Overdue status', () => {
    const { id } = taskService.create({ title: 'Send itinerary', due_date: '2020-01-01' });
    taskService.markStatus(id, 'Completed');
    expect(taskService.get(id).effective_status).toBe('Completed');
  });

  it('rejects an invalid status transition', () => {
    const { id } = taskService.create({ title: 'X' });
    expect(() => taskService.update(id, { status: 'NotAStatus' })).toThrow(/invalid task status/i);
  });
});

describe('deadlineService', () => {
  beforeEach(() => freshDb());

  it('requires a valid deadline type and a due date', () => {
    expect(() => deadlineService.create({})).toThrow(/valid deadline type/i);
    expect(() => deadlineService.create({ deadline_type: 'Visa' })).toThrow(/due date is required/i);
  });

  it('computes daysUntil and reminderLevel correctly for near, far, and overdue dates', () => {
    const near = deadlineService.create({ deadline_type: 'Visa', due_date: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10) });
    const far = deadlineService.create({ deadline_type: 'Payment', due_date: new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10) });
    const past = deadlineService.create({ deadline_type: 'Confirmation', due_date: '2020-01-01' });

    expect(deadlineService.get(near.id).reminderLevel).toBe('3 days');
    expect(deadlineService.get(far.id).reminderLevel).toBeNull();
    expect(deadlineService.get(past.id).effective_status).toBe('Overdue');
    expect(deadlineService.get(past.id).reminderLevel).toBe('Overdue');
  });

  it('dueSoon only returns Pending deadlines within the window', () => {
    const a = deadlineService.create({ deadline_type: 'Visa', due_date: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10) });
    const b = deadlineService.create({ deadline_type: 'Payment', due_date: new Date(Date.now() + 100 * 86400000).toISOString().slice(0, 10) });
    deadlineService.markStatus(b.id, 'Completed');
    expect(deadlineService.dueSoon(30).map((d) => d.id)).toEqual([a.id]);
  });
});

describe('calendarService + bookingService.upcomingTravel', () => {
  let bookingId;
  beforeEach(() => {
    freshDb();
    const customerId = customerService.create({ full_name: 'Test Traveller' }).id;
    bookingId = bookingService.create({
      customer_id: customerId, booking_type: 'Custom', destination: 'Jeddah', total_price: 100000,
      departure_date: '2027-02-10', return_date: '2027-02-20'
    }).id;
    flightService.create({ booking_id: bookingId, flight_number: 'PK-1', airline: 'PIA', departure_airport: 'LHE', arrival_airport: 'JED', departure_date: '2027-02-10' });
    hotelService.create({ booking_id: bookingId, hotel_name: 'Test Hotel', check_in: '2027-02-10', check_out: '2027-02-18' });
  });

  it('aggregates flight, hotel, and travel-date events within a date range', () => {
    const events = calendarService.list({ from: '2027-02-01', to: '2027-02-28' });
    const types = events.map((e) => e.type);
    expect(types).toContain('FlightDeparture');
    expect(types).toContain('HotelCheckIn');
    expect(types).toContain('HotelCheckOut');
    expect(types).toContain('TravelDate');
  });

  it('filters events by type', () => {
    const events = calendarService.list({ from: '2027-02-01', to: '2027-02-28', eventType: 'HotelCheckIn' });
    expect(events.every((e) => e.type === 'HotelCheckIn')).toBe(true);
    expect(events.length).toBeGreaterThan(0);
  });

  it('upcomingTravel rolls up real flight/hotel/visa/transport status per booking', () => {
    const rows = bookingService.upcomingTravel({ from: '2027-02-01', to: '2027-02-28' });
    expect(rows.length).toBe(1);
    expect(rows[0].flightStatus).toBe('Confirmed');
    expect(rows[0].hotelStatus).toBe('Booked');
    expect(rows[0].visaStatus).toBe('Not started');
    expect(rows[0].transportStatus).toBe('Not booked');
  });
});
