const { freshDb } = require('./testUtils');
const fs = require('../financialStatementsService');
const fx = require('../exchangeRateService');
const accountService = require('../accountService');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierPaymentService = require('../supplierPaymentService');
const { getDb, backfillDocumentCurrencies } = require('../../../src/database/db');

const row = (t, code) => t.rows.find((r) => r.code === code);

describe('currencies on invoices and payments', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    cust = customerService.create({ full_name: 'Dollar Customer' }).id;
  });
  function usdBooking(total = 1000) {
    const b = bookingService.create({ customer_id: cust, booking_type: 'Custom', total_price: total, paid_amount: 0 });
    getDb().prepare("UPDATE bookings SET currency = 'USD' WHERE id = ?").run(b.id);
    return b.id;
  }

  it('an invoice takes its booking currency, a plain one the base currency', () => {
    const inv = invoiceService.createFromBooking(usdBooking());
    expect(getDb().prepare('SELECT currency FROM invoices WHERE id = ?').get(inv.id).currency).toBe('USD');
    const plain = invoiceService.create({ customer_id: cust, items: [{ description: 'x', quantity: 1, unit_price: 10 }] });
    expect(getDb().prepare('SELECT currency FROM invoices WHERE id = ?').get(plain.id).currency).toBe('PKR');
  });

  it('a payment takes the invoice currency and is refused into an account of another currency', () => {
    const inv = invoiceService.createFromBooking(usdBooking());
    const pkrBank = accountService.create('Bank', { account_name: 'PKR bank', bank_name: 'HBL', currency: 'PKR', opening_balance: 0 }).id;
    const usdBank = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'HBL', currency: 'USD', opening_balance: 0 }).id;
    const base = { customer_id: cust, invoice_id: inv.id, amount: 100, payment_method: 'Bank Transfer', payment_type: 'Partial' };
    expect(() => paymentService.create({ ...base, account_type: 'Bank', account_id: pkrBank })).toThrow(/USD invoice but the selected account holds PKR/);
    expect(getDb().prepare('SELECT COUNT(*) AS n FROM payments').get().n).toBe(0);
    paymentService.create({ ...base, account_type: 'Bank', account_id: usdBank });
    expect(getDb().prepare('SELECT currency FROM payments').get().currency).toBe('USD');
  });

  it('a payment with no invoice or booking adopts its account currency', () => {
    const usdCash = accountService.create('Cash', { account_name: 'USD till', currency: 'USD', opening_balance: 0 }).id;
    paymentService.create({ customer_id: cust, amount: 50, payment_method: 'Cash', payment_type: 'Advance', account_type: 'Cash', account_id: usdCash });
    expect(getDb().prepare('SELECT currency FROM payments').get().currency).toBe('USD');
  });

  it('supplier payments: account currency is adopted, an explicit conflicting currency is refused', () => {
    const sup = supplierService.create({ name: 'Gulf Hotel' }).id;
    const usd = accountService.create('Bank', { account_name: 'U', bank_name: 'B', currency: 'USD', opening_balance: 5000 }).id;
    supplierPaymentService.create({ supplier_id: sup, amount: 100, payment_method: 'Bank Transfer', account_type: 'Bank', account_id: usd });
    expect(getDb().prepare('SELECT currency FROM supplier_payments').get().currency).toBe('USD');
    expect(() => supplierPaymentService.create({ supplier_id: sup, amount: 100, currency: 'SAR', payment_method: 'Bank Transfer', account_type: 'Bank', account_id: usd })).toThrow(/in SAR but the selected account holds USD/);
  });

  it('old rows without a currency are given their booking currency, except an old mixed-currency payment', () => {
    const b = usdBooking();
    const inv = invoiceService.createFromBooking(b);
    const pkr = accountService.create('Bank', { account_name: 'P', bank_name: 'B', currency: 'PKR', opening_balance: 0 }).id;
    const db = getDb();
    db.prepare('INSERT INTO payments (customer_id, invoice_id, payment_date, amount, payment_method, payment_type) VALUES (?, ?, datetime(\'now\'), 10, \'Cash\', \'Partial\')').run(cust, inv.id);
    db.prepare("INSERT INTO payments (customer_id, invoice_id, payment_date, amount, payment_method, payment_type, account_type, account_id) VALUES (?, ?, datetime('now'), 10, 'Cash', 'Partial', 'Bank', ?)").run(cust, inv.id, pkr);
    db.prepare('UPDATE invoices SET currency = NULL').run();
    backfillDocumentCurrencies();
    expect(db.prepare('SELECT currency FROM invoices').get().currency).toBe('USD');
    const pays = db.prepare('SELECT currency FROM payments ORDER BY id').all().map((p) => p.currency);
    expect(pays).toEqual(['USD', null]);
  });
});

describe('FX revaluation in the statements', () => {
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 280, effective_date: '2000-01-01' });
  });

  it('an open foreign balance is restated at the report-date rate, with the gain in one account, and it stays balanced', () => {
    const usd = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'B', currency: 'USD', opening_balance: 1000 }).id;
    getDb().prepare("UPDATE bank_accounts SET created_at = '2026-01-10' WHERE id = ?").run(usd);
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 290, effective_date: '2026-02-01' });

    const jan = fs.trialBalance({ asOf: '2026-01-31' });
    expect(row(jan, `1200-${usd}`).debit).toBe(280000);
    expect(row(jan, '4900')).toBeUndefined();
    expect(jan.balanced).toBe(true);

    const feb = fs.trialBalance({ asOf: '2026-02-28' });
    expect(row(feb, `1200-${usd}`).debit).toBe(290000);
    expect(row(feb, '4900').credit).toBe(10000);
    expect(feb.balanced).toBe(true);
    const bs = fs.balanceSheet({ asOf: '2026-02-28' });
    expect(bs.balanced).toBe(true);
    expect(bs.profit_to_date).toBe(10000);
    expect(bs.cash_total).toBe(290000);
  });

  it('a rate fall shows as a loss', () => {
    const usd = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'B', currency: 'USD', opening_balance: 1000 }).id;
    getDb().prepare("UPDATE bank_accounts SET created_at = '2026-01-10' WHERE id = ?").run(usd);
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 270, effective_date: '2026-02-01' });
    const t = fs.trialBalance({ asOf: '2026-02-28' });
    expect(row(t, '4900').debit).toBe(10000);
    expect(fs.balanceSheet({ asOf: '2026-02-28' }).profit_to_date).toBe(-10000);
  });

  it('a USD invoice settled at a different rate leaves no receivable and books the difference as FX gain', () => {
    const cust = customerService.create({ full_name: 'Rate Mover' }).id;
    const b = bookingService.create({ customer_id: cust, booking_type: 'Custom', total_price: 1000, paid_amount: 0 });
    getDb().prepare("UPDATE bookings SET currency = 'USD' WHERE id = ?").run(b.id);
    const inv = invoiceService.createFromBooking(b.id);
    const usd = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'B', currency: 'USD', opening_balance: 0 }).id;
    paymentService.create({ customer_id: cust, invoice_id: inv.id, amount: 1000, payment_method: 'Bank Transfer', payment_type: 'Full', account_type: 'Bank', account_id: usd });
    fx.create({ from_currency: 'USD', to_currency: 'PKR', rate: 290, effective_date: '2026-02-01' });
    const db = getDb();
    db.prepare("UPDATE invoices SET invoice_date = '2026-01-15' WHERE id = ?").run(inv.id);
    db.prepare("UPDATE payments SET payment_date = '2026-02-15'").run();

    const t = fs.trialBalance({ asOf: '2026-03-01' });
    expect(row(t, '4000').credit).toBe(280000);                 // sold at the January rate
    expect(row(t, `1200-${usd}`).debit).toBe(290000);           // cash received at the February rate
    expect(row(t, '1300').debit + row(t, '1300').credit).toBe(0); // nothing left owing, even after revaluation
    expect(row(t, '4900').credit).toBe(10000);                   // the difference is the exchange gain
    expect(t.balanced).toBe(true);
    expect(fs.balanceSheet({ asOf: '2026-03-01' }).balanced).toBe(true);
    expect(fs.reconcileCashAndBank().every((r) => r.matches)).toBe(true);
  });

  it('with no usable rate a foreign balance is left as booked and a warning says so', () => {
    freshDb();
    const usd = accountService.create('Bank', { account_name: 'USD bank', bank_name: 'B', currency: 'USD', opening_balance: 1000 }).id;
    const t = fs.trialBalance();
    expect(row(t, `1200-${usd}`).debit).toBe(1000);
    expect(t.warnings.join(' ')).toMatch(/USD to PKR/);
    expect(t.balanced).toBe(true);
  });
});
