const fs = require('fs');
const path = require('path');
const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const documentService = require('../documentService');

describe('documentService', () => {
  let cust, storageDir, tmp;

  beforeEach(() => {
    tmp = freshDb();
    documentService.initStorage(tmp);
    cust = customerService.create({ full_name: 'Rida Naveed' }).id;
    storageDir = path.join(tmp, 'storage', 'documents');
  });

  function plantFile(name, contents = 'fake content') {
    const dest = path.join(storageDir, name);
    fs.writeFileSync(dest, contents);
    const { getDb } = require('../../../src/database/db');
    const result = getDb()
      .prepare('INSERT INTO documents (customer_id, document_type, file_name, file_path) VALUES (?, ?, ?, ?)')
      .run(cust, 'Passport', name, dest);
    return result.lastInsertRowid;
  }

  it('lists documents for a customer, paginated', () => {
    plantFile('a.pdf');
    plantFile('b.pdf');
    const result = documentService.list({ customerId: cust });
    expect(result.total).toBe(2);
    expect(result.rows).toHaveLength(2);
  });

  it('renames a document, preserving the extension when none is given', () => {
    const id = plantFile('passport-scan.pdf');
    documentService.rename(id, 'Renamed Document');
    const doc = documentService.get(id);
    expect(doc.file_name).toBe('Renamed Document.pdf');
    expect(fs.existsSync(doc.file_path)).toBe(true);
  });

  it('refuses to rename onto an existing file name', () => {
    const id1 = plantFile('first.pdf');
    plantFile('second.pdf');
    expect(() => documentService.rename(id1, 'second.pdf')).toThrow(/already exists/i);
  });

  it('deletes both the database row and the file on disk', () => {
    const id = plantFile('to-delete.pdf');
    const doc = documentService.get(id);
    expect(fs.existsSync(doc.file_path)).toBe(true);

    documentService.remove(id);
    expect(fs.existsSync(doc.file_path)).toBe(false);
    expect(documentService.list({ customerId: cust }).total).toBe(0);
  });
});
