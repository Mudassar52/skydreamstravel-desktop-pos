const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const advanceService = require('../advanceService');
const ledgerService = require('../ledgerService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const supplierAdvanceService = require('../supplierAdvanceService');
const supplierLedgerService = require('../supplierLedgerService');
const customer360Service = require('../customer360Service');

function setup() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  return customerService.create({ full_name: 'Fatima Noor' }).id;
}

describe('advanceService (customer)', () => {
  it('a standalone advance is available and can be applied partially to an invoice', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 100000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 60000 }] }).id;

    let avail = advanceService.availableAdvances(cust);
    expect(avail.total_available).toBe(100000);

    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 40000 });
    avail = advanceService.availableAdvances(cust);
    expect(avail.total_available).toBe(60000);

    const invoiceAfter = invoiceService.get(inv);
    expect(invoiceAfter.paid_amount).toBe(40000);
    expect(invoiceAfter.remaining_amount).toBe(20000);
    expect(invoiceAfter.status).toBe('Partially Paid');
  });

  it('applying the rest fully pays the invoice, and the advance becomes fully used', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 60000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 60000 }] }).id;
    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 60000 });
    expect(invoiceService.get(inv).status).toBe('Paid');
    expect(advanceService.availableAdvances(cust).total_available).toBe(0);
  });

  it('refuses to apply more than is available, or more than the invoice needs', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 10000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 60000 }] }).id;
    expect(() => advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 20000 })).toThrow(/available/i);

    const adv2 = paymentService.create({ customer_id: cust, amount: 90000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv2 = invoiceService.create({ customer_id: cust, items: [{ description: 'Small', quantity: 1, unit_price: 5000 }] }).id;
    expect(() => advanceService.applyToInvoice({ paymentId: adv2, invoiceId: inv2, amount: 8000 })).toThrow(/exceeds/i);
  });

  it('never double counts: applying does not touch the ledger balance a second time', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 50000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const balanceBeforeInvoice = ledgerService.getBalance(cust); // -50,000 (credit)
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Umrah', quantity: 1, unit_price: 50000 }] }).id;
    const balanceAfterInvoice = ledgerService.getBalance(cust); // 0 (debit 50k, credit 50k already there)
    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 50000 });
    const balanceAfterApply = ledgerService.getBalance(cust);
    expect(balanceBeforeInvoice).toBe(-50000);
    expect(balanceAfterInvoice).toBe(0);
    expect(balanceAfterApply).toBe(0); // unchanged - applying is allocation, not a new movement
  });

  it('a booking-tied advance is not offered for manual application (already auto-absorbed by createFromBooking)', () => {
    const cust = setup();
    const b = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 40000 }).id;
    const adv = paymentService.create({ customer_id: cust, booking_id: b, amount: 40000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    expect(advanceService.availableAdvances(cust).rows).toHaveLength(0);
    const inv = invoiceService.createFromBooking(b).id;
    expect(invoiceService.get(inv).paid_amount).toBe(40000); // absorbed automatically, not via advanceService
    expect(() => advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 1 })).toThrow(/already tied to a booking/i);
  });

  it('reversing an application frees the advance again and rolls back the invoice', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 30000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Tour', quantity: 1, unit_price: 30000 }] }).id;
    const app = advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 30000 });
    expect(invoiceService.get(inv).status).toBe('Paid');
    advanceService.reverseApplication(app.id);
    expect(invoiceService.get(inv).status).toBe('Unpaid');
    expect(advanceService.availableAdvances(cust).total_available).toBe(30000);
  });

  it('summary: received / used / remaining are consistent whether applied or tied at receipt', () => {
    const cust = setup();
    const adv = paymentService.create({ customer_id: cust, amount: 100000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 40000 }] }).id;
    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 40000 });
    const s = advanceService.summary(cust);
    expect(s.received).toBe(100000);
    expect(s.used).toBe(40000);
    expect(s.remaining).toBe(60000);
  });

  it('an applied advance is reflected in Customer 360 (booking paid/outstanding and advance-used totals)', () => {
    const cust = setup();
    const b = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 80000 }).id;
    const adv = paymentService.create({ customer_id: cust, amount: 80000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, booking_id: b, items: [{ description: 'Tour', quantity: 1, unit_price: 80000 }] }).id;
    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 80000 });

    const row = customer360Service.bookingHistory(cust).items.find((r) => r.id === b);
    expect(row.paid).toBe(80000);
    expect(row.advance).toBe(80000);
    expect(row.outstanding).toBe(0);

    const s = customer360Service.summary(cust);
    expect(s.advance.used).toBe(80000);
    expect(s.advance.remaining).toBe(0);
  });
});

describe('ledgerService.filteredView (customer)', () => {
  it('classifies rows and computes opening/closing/totals for the full range', () => {
    const cust = setup();
    paymentService.create({ customer_id: cust, amount: 50000, payment_method: 'Cash', payment_type: 'Advance' });
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'Umrah', quantity: 1, unit_price: 120000 }] }).id;
    paymentService.create({ customer_id: cust, invoice_id: inv, amount: 30000, payment_method: 'Cash', payment_type: 'Partial' });
    paymentService.create({ customer_id: cust, invoice_id: inv, amount: 5000, payment_method: 'Cash', payment_type: 'Refund' });

    const v = ledgerService.filteredView(cust);
    expect(v.openingBalance).toBe(0);
    expect(v.entries.map((e) => e.txn_type)).toEqual(['Advance', 'Invoice', 'Partial', 'Refund']);
    expect(v.totalDebit).toBe(125000);   // 120,000 invoice + 5,000 refund
    expect(v.totalCredit).toBe(80000);   // 50,000 advance + 30,000 partial
    expect(v.closingBalance).toBe(45000);
  });

  it('filters by date range with a correct opening balance carried forward', () => {
    const cust = setup();
    paymentService.create({ customer_id: cust, amount: 20000, payment_method: 'Cash', payment_type: 'Advance' });
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 50000 }] }).id;
    const future = '2099-01-01';
    const v = ledgerService.filteredView(cust, { dateFrom: future });
    expect(v.entries).toHaveLength(0);
    expect(v.openingBalance).toBe(30000); // -20,000 + 50,000 carried from before the range
    expect(v.closingBalance).toBe(30000);
    void inv;
  });

  it('filters by transaction type and by invoice id', () => {
    const cust = setup();
    const inv1 = invoiceService.create({ customer_id: cust, items: [{ description: 'A', quantity: 1, unit_price: 1000 }] }).id;
    const inv2 = invoiceService.create({ customer_id: cust, items: [{ description: 'B', quantity: 1, unit_price: 2000 }] }).id;
    expect(ledgerService.filteredView(cust, { transactionType: 'Invoice' }).entries).toHaveLength(2);
    expect(ledgerService.filteredView(cust, { invoiceId: inv1 }).entries).toHaveLength(1);
    expect(ledgerService.transactionTypes(cust)).toEqual(['Invoice']);
    void inv2;
  });

  it('filters by booking id (via the invoice raised for that booking)', () => {
    const cust = setup();
    const b = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 15000 }).id;
    invoiceService.createFromBooking(b);
    const other = invoiceService.create({ customer_id: cust, items: [{ description: 'Other', quantity: 1, unit_price: 500 }] }).id;
    expect(ledgerService.filteredView(cust, { bookingId: b }).entries).toHaveLength(1);
    void other;
  });
});

describe('supplierAdvanceService', () => {
  function setupSupplier() {
    freshDb();
    return supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
  }

  it('a standalone supplier advance can be applied to a supplier invoice, partially then fully', () => {
    const sup = setupSupplier();
    const adv = supplierPaymentService.create({ supplier_id: sup, amount: 50000, payment_method: 'Cash' }).id;
    const inv = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'H-1', amount: 45000 }).id;

    supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 20000 });
    let av = supplierAdvanceService.availableAdvances(sup);
    expect(av.total_available).toBe(30000);
    expect(supplierInvoiceService.get(inv).paid_amount).toBe(20000);

    supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 25000 });
    expect(supplierInvoiceService.get(inv).status).toBe('Paid');
    av = supplierAdvanceService.availableAdvances(sup);
    expect(av.total_available).toBe(5000);
  });

  it('refuses over-application and booking-tied advances', () => {
    const sup = setupSupplier();
    const adv = supplierPaymentService.create({ supplier_id: sup, amount: 10000, payment_method: 'Cash' }).id;
    const inv = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'H-2', amount: 50000 }).id;
    expect(() => supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 20000 })).toThrow(/available/i);
  });

  it('reversal restores the supplier invoice and frees the advance', () => {
    const sup = setupSupplier();
    const adv = supplierPaymentService.create({ supplier_id: sup, amount: 15000, payment_method: 'Cash' }).id;
    const inv = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'H-3', amount: 15000 }).id;
    const app = supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 15000 });
    expect(supplierInvoiceService.get(inv).status).toBe('Paid');
    supplierAdvanceService.reverseApplication(app.id);
    expect(supplierInvoiceService.get(inv).paid_amount).toBe(0);
    expect(supplierAdvanceService.availableAdvances(sup).total_available).toBe(15000);
  });

  it('summary reports paid-as-advance / used / remaining', () => {
    const sup = setupSupplier();
    const adv = supplierPaymentService.create({ supplier_id: sup, amount: 30000, payment_method: 'Cash' }).id;
    const inv = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'H-4', amount: 30000 }).id;
    supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 10000 });
    const s = supplierAdvanceService.summary(sup);
    expect(s.paid_as_advance).toBe(30000);
    expect(s.used).toBe(10000);
    expect(s.remaining).toBe(20000);
  });

  it('an applied standalone advance is reflected in the booking-level paid/payable figures (supplier360Service.bookings)', () => {
    freshDb();
    const cust = customerService.create({ full_name: 'Booking Test Customer' }).id;
    const sup = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
    const b = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 50000 }).id;
    const adv = supplierPaymentService.create({ supplier_id: sup, amount: 60000, payment_method: 'Cash' }).id; // standalone, no booking_id
    const inv = supplierInvoiceService.create({ supplier_id: sup, booking_id: b, invoice_number: 'H-5', amount: 60000 }).id;
    supplierAdvanceService.applyToInvoice({ supplierPaymentId: adv, supplierInvoiceId: inv, amount: 60000 });

    const supplier360Service = require('../supplier360Service');
    const row = supplier360Service.bookings(sup).find((r) => r.id === b);
    expect(row.invoiced).toBe(60000);
    expect(row.paid).toBe(60000);
    expect(row.payable).toBe(0);
  });
});

describe('supplierLedgerService.filteredView', () => {
  it('classifies invoice/advance/payment rows and computes totals', () => {
    freshDb();
    const sup = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    supplierPaymentService.create({ supplier_id: sup, amount: 20000, payment_method: 'Cash' }); // advance
    const inv = supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'P-1', amount: 60000 }).id;
    supplierPaymentService.create({ supplier_id: sup, supplier_invoice_id: inv, amount: 15000, payment_method: 'Cash' }); // payment

    const v = supplierLedgerService.filteredView(sup);
    expect(v.entries.map((e) => e.txn_type)).toEqual(['Advance', 'Invoice', 'Payment']);
    expect(v.totalDebit).toBe(60000);
    expect(v.totalCredit).toBe(35000);
    expect(v.closingBalance).toBe(25000);
  });

  it('filters by transaction type', () => {
    freshDb();
    const sup = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    supplierPaymentService.create({ supplier_id: sup, amount: 5000, payment_method: 'Cash' });
    supplierInvoiceService.create({ supplier_id: sup, invoice_number: 'P-2', amount: 9000 });
    expect(supplierLedgerService.filteredView(sup, { transactionType: 'Advance' }).entries).toHaveLength(1);
    expect(supplierLedgerService.transactionTypes(sup).sort()).toEqual(['Advance', 'Invoice']);
  });
});

describe('advanceService.listAll / supplierAdvanceService.listAll (Phase 8)', () => {
  it('lists standalone advances across all customers, searchable, excluding booking-tied ones', () => {
    freshDb();
    const cust1 = customerService.create({ full_name: 'Nadia Hussain' }).id;
    const cust2 = customerService.create({ full_name: 'Omar Farooq' }).id;
    paymentService.create({ customer_id: cust1, amount: 30000, payment_method: 'Cash', payment_type: 'Advance' });
    paymentService.create({ customer_id: cust2, amount: 15000, payment_method: 'Cash', payment_type: 'Advance' });
    const b = bookingService.create({ customer_id: cust1, booking_type: 'Tour', total_price: 5000 }).id;
    paymentService.create({ customer_id: cust1, booking_id: b, amount: 5000, payment_method: 'Cash', payment_type: 'Advance' });

    const all = advanceService.listAll({});
    expect(all.total).toBe(2); // the booking-tied one is excluded
    expect(all.totalAvailable).toBe(45000);
    const nadia = advanceService.listAll({ search: 'Nadia' });
    expect(nadia.total).toBe(1);
    expect(nadia.rows[0].customer_name).toBe('Nadia Hussain');
  });

  it('onlyAvailable excludes fully-applied advances', () => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    const cust = customerService.create({ full_name: 'Fully Applied' }).id;
    const adv = paymentService.create({ customer_id: cust, amount: 20000, payment_method: 'Cash', payment_type: 'Advance' }).id;
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 20000 }] }).id;
    advanceService.applyToInvoice({ paymentId: adv, invoiceId: inv, amount: 20000 });
    expect(advanceService.listAll({}).total).toBe(1);
    expect(advanceService.listAll({ onlyAvailable: true }).total).toBe(0);
  });

  it('supplierAdvanceService.listAll mirrors the above for suppliers', () => {
    freshDb();
    const sup1 = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
    const sup2 = supplierService.create({ name: 'PIA', service_type: 'Airline' }).id;
    supplierPaymentService.create({ supplier_id: sup1, amount: 40000, payment_method: 'Cash' });
    supplierPaymentService.create({ supplier_id: sup2, amount: 10000, payment_method: 'Cash' });
    const all = supplierAdvanceService.listAll({});
    expect(all.total).toBe(2);
    expect(all.totalAvailable).toBe(50000);
    expect(supplierAdvanceService.listAll({ search: 'PIA' }).total).toBe(1);
  });
});

describe('advance list queries are paginated in SQL with correct totals (Phase 10)', () => {
  it('customer listAll: pages, count and totalAvailable stay correct across pages and filters', () => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    const cust = customerService.create({ full_name: 'Many Advances' }).id;
    const ids = [];
    for (let i = 1; i <= 5; i++) {
      ids.push(paymentService.create({ customer_id: cust, amount: i * 1000, payment_method: 'Cash', payment_type: 'Advance' }).id);
    }
    // Fully consume the 1,000 advance so it drops out of "available".
    const inv = invoiceService.create({ customer_id: cust, items: [{ description: 'X', quantity: 1, unit_price: 1000 }] }).id;
    advanceService.applyToInvoice({ paymentId: ids[0], invoiceId: inv, amount: 1000 });

    const p1 = advanceService.listAll({ page: 1, pageSize: 2 });
    const p2 = advanceService.listAll({ page: 2, pageSize: 2 });
    const p3 = advanceService.listAll({ page: 3, pageSize: 2 });
    expect(p1.total).toBe(5);
    expect([p1.rows.length, p2.rows.length, p3.rows.length]).toEqual([2, 2, 1]);
    const seen = [...p1.rows, ...p2.rows, ...p3.rows].map((r) => r.id);
    expect(new Set(seen).size).toBe(5); // no row repeated or skipped across pages
    expect(p1.totalAvailable).toBe(14000); // 15,000 received - 1,000 applied

    const avail = advanceService.listAll({ onlyAvailable: true, page: 1, pageSize: 10 });
    expect(avail.total).toBe(4);
    expect(avail.totalAvailable).toBe(14000);
    expect(advanceService.availableAdvances(cust).rows).toHaveLength(4);
  });

  it('supplier listAll paginates the same way', () => {
    freshDb();
    const sup = supplierService.create({ name: 'Many Advances Supplier', service_type: 'Hotel' }).id;
    for (let i = 1; i <= 3; i++) supplierPaymentService.create({ supplier_id: sup, amount: i * 500, payment_method: 'Cash' });
    const p1 = supplierAdvanceService.listAll({ page: 1, pageSize: 2 });
    const p2 = supplierAdvanceService.listAll({ page: 2, pageSize: 2 });
    expect(p1.total).toBe(3);
    expect([p1.rows.length, p2.rows.length]).toEqual([2, 1]);
    expect(p1.totalAvailable).toBe(3000);
  });
});
