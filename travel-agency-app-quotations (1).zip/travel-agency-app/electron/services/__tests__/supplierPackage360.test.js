const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const paymentService = require('../paymentService');
const supplierService = require('../supplierService');
const supplierInvoiceService = require('../supplierInvoiceService');
const supplierPaymentService = require('../supplierPaymentService');
const packageService = require('../packageService');
const s360 = require('../supplier360Service');
const p360 = require('../package360Service');

function base() {
  freshDb();
  invoiceTemplateService.ensureDefaultTemplate();
  const cust = customerService.create({ full_name: 'Bilal Ahmed' }).id;
  const hilton = supplierService.create({ name: 'Hilton Makkah', service_type: 'Hotel' }).id;
  const pia = supplierService.create({ name: 'PIA Cargo', service_type: 'Airline' }).id;
  const pkg = packageService.create({
    package_name: 'Premium Umrah', package_type: 'Umrah', selling_price: 250000,
    components: [
      { component_type: 'Flight', description: 'PIA Direct', cost: 60000, selling_price: 70000, supplier_id: pia },
      { component_type: 'Visa', description: 'Saudi Arabia', cost: 15000, selling_price: 18000 },
      { component_type: 'Makkah Hotel', description: 'Swissotel', cost: 40000, selling_price: 50000, supplier_id: hilton }
    ]
  });
  return { cust, hilton, pia, pkg: pkg.id };
}

describe('package -> booking now carries costs to flights and visa', () => {
  it('flight + visa rows created from a package keep cost and selling price', () => {
    const { cust, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    const db = getDb();
    const f = db.prepare('SELECT cost, selling_price FROM flights WHERE booking_id = ?').get(b.id);
    const v = db.prepare('SELECT cost, selling_price FROM visa_applications WHERE booking_id = ?').get(b.id);
    expect(f.cost).toBe(60000); expect(f.selling_price).toBe(70000);
    expect(v.cost).toBe(15000); expect(v.selling_price).toBe(18000);
  });
});

describe('supplier360Service', () => {
  it('header and unknown supplier', () => {
    const { hilton } = base();
    expect(s360.header(hilton).name).toBe('Hilton Makkah');
    expect(() => s360.summary(99999)).toThrow(/not found/i);
  });

  it('lists only this supplier\'s service rows, across service types', () => {
    const { cust, hilton, pia, pkg } = base();
    bookingService.create({ customer_id: cust, package_id: pkg });
    const h = s360.serviceUsage(hilton);
    expect(h.total).toBe(1);
    expect(h.items[0].service_type).toBe('Hotel');
    expect(h.items[0].cost).toBe(40000);
    expect(h.items[0].profit).toBe(10000);
    expect(h.items[0].customer_name).toBe('Bilal Ahmed');
    const p = s360.serviceUsage(pia);
    expect(p.total).toBe(1);
    expect(p.items[0].service_type).toBe('Flight');
  });

  it('summary: service cost/selling, invoices, payments, payable and ledger balance are consistent', () => {
    const { cust, hilton, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    const inv = supplierInvoiceService.create({ supplier_id: hilton, booking_id: b.id, invoice_number: 'H-1', amount: 45000 });
    supplierPaymentService.create({ supplier_id: hilton, supplier_invoice_id: inv.id, booking_id: b.id, amount: 20000, payment_method: 'Cash' });
    supplierPaymentService.create({ supplier_id: hilton, amount: 5000, payment_method: 'Cash' }); // not against an invoice

    const s = s360.summary(hilton);
    expect(s.invoices.count).toBe(1);
    expect(s.invoices.total_billed).toBe(45000);
    expect(s.invoices.payable).toBe(25000);
    expect(s.payments.total_paid).toBe(25000);
    expect(s.payments.not_against_invoice).toBe(5000);
    expect(s.ledger_balance).toBe(20000);            // 45,000 billed - 25,000 paid
    expect(s.services.service_cost).toBe(40000);
    expect(s.services.service_selling).toBe(50000);
    expect(s.services.margin_percent).toBe(20);
    // estimate and actual are shown side by side, never merged
    expect(s.cost_check.estimated_service_cost).toBe(40000);
    expect(s.cost_check.actually_invoiced).toBe(45000);
    expect(s.cost_check.difference).toBe(5000);
  });

  it('service usage filters, sorts and paginates in SQL; bad sort column is safe', () => {
    const { cust, hilton, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    const db = getDb();
    db.prepare(`INSERT INTO hotels (booking_id, hotel_name, supplier_id, cost, selling_price, check_in) VALUES (?, 'Extra Hotel', ?, 100, 300, '2030-01-01')`).run(b.id, hilton);
    expect(s360.serviceUsage(hilton).total).toBe(2);
    expect(s360.serviceUsage(hilton, { search: 'Extra' }).total).toBe(1);
    expect(s360.serviceUsage(hilton, { serviceType: 'Flight' }).total).toBe(0);
    expect(s360.serviceUsage(hilton, { dateFrom: '2029-01-01' }).total).toBe(1);
    const p1 = s360.serviceUsage(hilton, { sortBy: 'cost', sortDir: 'asc', page: 1, pageSize: 1 });
    expect(p1.items).toHaveLength(1);
    expect(p1.items[0].cost).toBe(100);
    expect(s360.serviceUsage(hilton, { pageSize: 0 }).items).toHaveLength(2);
    expect(() => s360.serviceUsage(hilton, { sortBy: 'x; DROP TABLE hotels' })).not.toThrow();
    expect(db.prepare('SELECT COUNT(*) AS c FROM hotels').get().c).toBe(2);
  });

  it('bookings tab: per-booking services, invoiced, paid and payable for that supplier only', () => {
    const { cust, hilton, pia, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    supplierInvoiceService.create({ supplier_id: hilton, booking_id: b.id, invoice_number: 'H-1', amount: 45000 });
    supplierPaymentService.create({ supplier_id: hilton, booking_id: b.id, amount: 10000, payment_method: 'Cash' });
    supplierInvoiceService.create({ supplier_id: pia, booking_id: b.id, invoice_number: 'P-1', amount: 61000 });
    const rows = s360.bookings(hilton);
    expect(rows).toHaveLength(1);
    expect(rows[0].services).toBe(1);
    expect(rows[0].invoiced).toBe(45000);
    expect(rows[0].paid).toBe(10000);
    expect(rows[0].payable).toBe(35000);
  });

  it('timeline, invoices and payments are per supplier and newest first', () => {
    const { cust, hilton, pia, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    supplierInvoiceService.create({ supplier_id: hilton, booking_id: b.id, invoice_number: 'H-1', amount: 100 });
    supplierInvoiceService.create({ supplier_id: pia, invoice_number: 'P-1', amount: 100 });
    expect(s360.invoices(hilton)).toHaveLength(1);
    const ev = s360.timeline(hilton).items.map((e) => e.event);
    expect(ev).toContain('Supplier created');
    expect(ev).toContain('Hotel assigned');
    expect(ev).toContain('Supplier invoice recorded');
    expect(ev).not.toContain('Flight assigned');
    const dates = s360.timeline(hilton).items.map((e) => e.at);
    expect([...dates].sort().reverse()).toEqual(dates);
  });

  it('a supplier with no activity shows zeros', () => {
    freshDb();
    const s = supplierService.create({ name: 'Idle Co', service_type: 'Other' }).id;
    const sum = s360.summary(s);
    expect(sum.invoices.total_billed).toBe(0);
    expect(sum.services.margin_percent).toBeNull();
    expect(s360.serviceUsage(s).total).toBe(0);
    expect(s360.bookings(s)).toEqual([]);
  });
});

describe('package360Service', () => {
  it('header: components, estimated cost, profit and margin', () => {
    const { pkg } = base();
    const h = p360.header(pkg);
    expect(h.components).toHaveLength(3);
    expect(h.estimated_cost).toBe(115000);
    expect(h.estimated_profit).toBe(135000);
    expect(h.estimated_margin_percent).toBe(54);
    expect(() => p360.header(99999)).toThrow(/not found/i);
  });

  it('sold figures come from linked bookings and exclude cancelled ones', () => {
    const { cust, pkg } = base();
    const b1 = bookingService.create({ customer_id: cust, package_id: pkg });
    const b2 = bookingService.create({ customer_id: cust, package_id: pkg });
    const b3 = bookingService.create({ customer_id: cust, package_id: pkg });
    bookingService.update(b3.id, { customer_id: cust, booking_type: 'Umrah', total_price: 250000, status: 'Cancelled' });
    const inv = invoiceService.create({ customer_id: cust, booking_id: b1.id, items: [{ description: 'Umrah', quantity: 1, unit_price: 250000 }] }).id;
    paymentService.create({ customer_id: cust, invoice_id: inv, amount: 100000, payment_method: 'Cash', payment_type: 'Partial' });

    const s = p360.summary(pkg);
    expect(s.bookings.total).toBe(3);
    expect(s.bookings.cancelled).toBe(1);
    expect(s.sold.revenue).toBe(500000);          // 2 live x 250,000
    expect(s.sold.collected).toBe(100000);
    expect(s.sold.outstanding).toBe(400000);
    expect(s.sold.cost).toBe(230000);             // 2 x 115,000 estimated
    expect(s.sold.profit).toBe(270000);
    expect(s.suppliers.length).toBe(2);
    expect(p360.bookings(pkg)).toHaveLength(3);
  });

  it('editing the master package does not change what past bookings sold for', () => {
    const { cust, pkg } = base();
    const b = bookingService.create({ customer_id: cust, package_id: pkg });
    packageService.update(pkg, { package_name: 'Premium Umrah', package_type: 'Umrah', selling_price: 999999 });
    expect(p360.bookings(pkg).find((r) => r.id === b.id).selling).toBe(250000);
  });

  it('a package with no bookings shows zeros', () => {
    const { pkg } = base();
    const s = p360.summary(pkg);
    expect(s.sold.revenue).toBe(0);
    expect(s.sold.margin_percent).toBeNull();
  });
});
