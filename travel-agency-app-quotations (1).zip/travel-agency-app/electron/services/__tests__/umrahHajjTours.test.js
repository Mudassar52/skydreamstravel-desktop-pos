const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const umrahService = require('../umrahService');
const hajjService = require('../hajjService');
const tourService = require('../tourService');

describe('umrahService', () => {
  let c1, c2;
  beforeEach(() => {
    freshDb();
    c1 = customerService.create({ full_name: 'Ali Hassan' }).id;
    c2 = customerService.create({ full_name: 'Sara Ahmed' }).id;
  });

  it('rejects an empty package name', () => {
    expect(() => umrahService.packages.create({ package_name: '' })).toThrow(/name is required/i);
  });

  it('rejects group return date before departure date', () => {
    expect(() => umrahService.groups.create({ group_name: 'G', departure_date: '2026-12-10', return_date: '2026-12-01' })).toThrow(
      /return date cannot be before/i
    );
  });

  it('auto-syncs the passenger headcount and blocks duplicates', () => {
    const pkg = umrahService.packages.create({ package_name: 'Ramzan Umrah' });
    const grp = umrahService.groups.create({ group_name: 'Group A', package_id: pkg.id });

    umrahService.passengers.add(grp.id, c1);
    umrahService.passengers.add(grp.id, c2);
    expect(umrahService.groups.get(grp.id).total_passengers).toBe(2);

    expect(() => umrahService.passengers.add(grp.id, c1)).toThrow(/already in the group/i);

    const list = umrahService.passengers.list(grp.id);
    umrahService.passengers.remove(list[0].membership_id, grp.id);
    expect(umrahService.groups.get(grp.id).total_passengers).toBe(1);
  });
});

describe('hajjService', () => {
  let c1;
  beforeEach(() => {
    freshDb();
    c1 = customerService.create({ full_name: 'Pilgrim One' }).id;
  });

  it('syncs the pilgrim headcount', () => {
    const pkg = hajjService.packages.create({ package_name: 'Hajj Premium' });
    const grp = hajjService.groups.create({ group_name: 'Batch 1', package_id: pkg.id });
    hajjService.pilgrims.add(grp.id, c1);
    expect(hajjService.groups.get(grp.id).total_pilgrims).toBe(1);
  });
});

describe('tourService', () => {
  let c1, c2, c3;
  beforeEach(() => {
    freshDb();
    c1 = customerService.create({ full_name: 'Passenger 1' }).id;
    c2 = customerService.create({ full_name: 'Passenger 2' }).id;
    c3 = customerService.create({ full_name: 'Passenger 3' }).id;
  });

  it('rejects end date before start date', () => {
    expect(() => tourService.create({ tour_name: 'Bad Tour', start_date: '2026-12-10', end_date: '2026-12-01' })).toThrow(
      /end date cannot be before/i
    );
  });

  it('defaults available_seats to total_seats and decrements on booking', () => {
    const tour = tourService.create({ tour_name: 'Hunza Adventure', total_seats: 2 });
    expect(tourService.get(tour.id).available_seats).toBe(2);

    tourService.passengers.add(tour.id, c1);
    expect(tourService.get(tour.id).available_seats).toBe(1);

    tourService.passengers.add(tour.id, c2);
    expect(tourService.get(tour.id).available_seats).toBe(0);
  });

  it('refuses to overbook a full tour', () => {
    const tour = tourService.create({ tour_name: 'Small Tour', total_seats: 1 });
    tourService.passengers.add(tour.id, c1);
    expect(() => tourService.passengers.add(tour.id, c2)).toThrow(/no available seats/i);
  });

  it('restores a seat when a passenger is removed', () => {
    const tour = tourService.create({ tour_name: 'Restore Test', total_seats: 1 });
    tourService.passengers.add(tour.id, c1);
    const list = tourService.passengers.list(tour.id);
    tourService.passengers.remove(list[0].membership_id, tour.id);
    expect(tourService.get(tour.id).available_seats).toBe(1);
    // seat freed up, so a new passenger can now be added
    expect(() => tourService.passengers.add(tour.id, c3)).not.toThrow();
  });
});
