const { freshDb } = require('./testUtils');
const accountService = require('../accountService');
const refundService = require('../refundService');
const accountingService = require('../accountingService');
const customerService = require('../customerService');
const invoiceService = require('../invoiceService');
const invoiceTemplateService = require('../invoiceTemplateService');
const paymentService = require('../paymentService');
const expenseService = require('../expenseService');

describe('accountService', () => {
  beforeEach(() => freshDb());

  it('creates a bank account with an opening balance and requires a bank name', () => {
    expect(() => accountService.create('Bank', { account_name: 'Main' })).toThrow(/bank name is required/i);
    const { id } = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 50000 });
    expect(accountService.get('Bank', id).current_balance).toBe(50000);
  });

  it('deposit/withdrawal update the balance and log a transaction; overdraft is rejected', () => {
    const { id } = accountService.create('Cash', { account_name: 'Till', opening_balance: 10000 });
    accountService.manualDeposit({ account_type: 'Cash', account_id: id, amount: 5000 });
    expect(accountService.get('Cash', id).current_balance).toBe(15000);
    accountService.manualWithdrawal({ account_type: 'Cash', account_id: id, amount: 3000 });
    expect(accountService.get('Cash', id).current_balance).toBe(12000);
    expect(() => accountService.manualWithdrawal({ account_type: 'Cash', account_id: id, amount: 999999 })).toThrow(/exceeds the current account balance/i);
    expect(accountService.get('Cash', id).transactions.length).toBe(2);
  });

  it('transfer moves money between two accounts atomically', () => {
    const bank = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 20000 });
    const cash = accountService.create('Cash', { account_name: 'Till', opening_balance: 0 });
    accountService.transfer({ from_type: 'Bank', from_id: bank.id, to_type: 'Cash', to_id: cash.id, amount: 8000 });
    expect(accountService.get('Bank', bank.id).current_balance).toBe(12000);
    expect(accountService.get('Cash', cash.id).current_balance).toBe(8000);
  });

  it('blocks deleting an account that has transaction history', () => {
    const { id } = accountService.create('Cash', { account_name: 'Till', opening_balance: 1000 });
    accountService.manualDeposit({ account_type: 'Cash', account_id: id, amount: 500 });
    expect(() => accountService.remove('Cash', id)).toThrow(/transaction history/i);
  });
});

describe('paymentService + expenseService account posting', () => {
  let bankId, custId, invId;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    bankId = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 0 }).id;
    custId = customerService.create({ full_name: 'Bilal Aziz' }).id;
    invId = invoiceService.create({ customer_id: custId, items: [{ description: 'Trip', quantity: 1, unit_price: 40000 }] }).id;
  });

  it('a customer payment posted against a bank account increases its balance; voiding reverses it', () => {
    const { id: paymentId } = paymentService.create({ customer_id: custId, invoice_id: invId, amount: 15000, payment_method: 'Bank Transfer', payment_type: 'Partial', account_type: 'Bank', account_id: bankId });
    expect(accountService.get('Bank', bankId).current_balance).toBe(15000);
    paymentService.remove(paymentId);
    expect(accountService.get('Bank', bankId).current_balance).toBe(0);
  });

  it('an expense posted against a bank account decreases its balance', () => {
    const cat = expenseService.createCategory('Fuel');
    accountService.manualDeposit({ account_type: 'Bank', account_id: bankId, amount: 100000 });
    const { id: expenseId } = expenseService.create({ expense_date: '2027-01-01', category_id: cat.id, amount: 4000, account_type: 'Bank', account_id: bankId });
    expect(accountService.get('Bank', bankId).current_balance).toBe(96000);
    expenseService.remove(expenseId);
    expect(accountService.get('Bank', bankId).current_balance).toBe(100000);
  });
});

describe('refundService', () => {
  let custId, invId;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    custId = customerService.create({ full_name: 'Nadia Yousuf' }).id;
    invId = invoiceService.create({ customer_id: custId, items: [{ description: 'Trip', quantity: 1, unit_price: 60000 }] }).id;
    paymentService.create({ customer_id: custId, invoice_id: invId, amount: 60000, payment_method: 'Bank Transfer', payment_type: 'Full' });
  });

  it('issuing a refund reduces the invoice paid amount and is reflected in the customer ledger', () => {
    refundService.create({ customer_id: custId, invoice_id: invId, refund_amount: 10000, reason: 'Service issue' });
    const invoice = invoiceService.get(invId);
    expect(invoice.paid_amount).toBe(50000);
    expect(invoice.status).not.toBe('Paid');
  });

  it('voiding a refund restores the original paid amount', () => {
    const refund = refundService.create({ customer_id: custId, invoice_id: invId, refund_amount: 10000, reason: 'Service issue' });
    refundService.remove(refund.id);
    expect(invoiceService.get(invId).paid_amount).toBe(60000);
  });

  it('a refund posted against a bank account moves money out, and voiding reverses it', () => {
    const bankId = accountService.create('Bank', { account_name: 'Main', bank_name: 'HBL', opening_balance: 100000 }).id;
    const refund = refundService.create({ customer_id: custId, invoice_id: invId, refund_amount: 7000, account_type: 'Bank', account_id: bankId });
    expect(accountService.get('Bank', bankId).current_balance).toBe(93000);
    refundService.remove(refund.id);
    expect(accountService.get('Bank', bankId).current_balance).toBe(100000);
  });
});

describe('accountingService', () => {
  beforeEach(() => freshDb());

  it('requires an account and exactly one of debit/credit', () => {
    expect(() => accountingService.create({ account: 'Cash' })).toThrow(/enter either a debit or a credit/i);
    expect(() => accountingService.create({ account: 'Cash', debit: 100, credit: 100 })).toThrow(/not both/i);
    expect(() => accountingService.create({ debit: 100 })).toThrow(/account name is required/i);
  });

  it('reverse() posts an equal-and-opposite entry and cannot be applied twice', () => {
    const { id } = accountingService.create({ account: 'Revenue', credit: 50000 });
    const reversal = accountingService.reverse(id);
    const summary = accountingService.summary({});
    const revenueRow = summary.rows.find((r) => r.account === 'Revenue');
    expect(revenueRow.net).toBe(0); // 50000 credit + 50000 debit (reversal) nets to zero
    expect(() => accountingService.reverse(id)).toThrow(/already been reversed/i);
    expect(() => accountingService.reverse(reversal.id)).toThrow(/reversal entry cannot itself be reversed/i);
  });

  it('summary groups by account with correct debit/credit/net totals', () => {
    accountingService.create({ account: 'Cash', debit: 20000 });
    accountingService.create({ account: 'Cash', debit: 5000 });
    accountingService.create({ account: 'Revenue', credit: 25000 });
    const summary = accountingService.summary({});
    const cash = summary.rows.find((r) => r.account === 'Cash');
    expect(cash.total_debit).toBe(25000);
    expect(cash.net).toBe(25000);
  });
});
