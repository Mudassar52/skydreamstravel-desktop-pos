const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const travellerService = require('../travellerService');
const voucherService = require('../voucherService');

describe('family members on a booking show up on vouchers', () => {
  it('lists every added traveller (not only the lead customer) on hotel and transport vouchers', () => {
    freshDb();
    const lead = customerService.create({ full_name: 'Ahmed Khan' }).id;
    const booking = bookingService.create({ customer_id: lead, booking_type: 'Umrah', total_price: 600000, number_of_passengers: 3, status: 'Confirmed' }).id;
    const db = getDb();
    const hotel = db.prepare(`INSERT INTO hotels (booking_id, hotel_name, check_in) VALUES (?, 'Swissotel Makkah', '2026-12-01')`).run(booking).lastInsertRowid;
    const transport = db.prepare(`INSERT INTO transportation (booking_id, vehicle, pickup_location) VALUES (?, 'Hiace', 'Jeddah Airport')`).run(booking).lastInsertRowid;

    const wife = travellerService.create({ customer_id: lead, full_name: 'Ayesha Khan', relationship: 'Spouse', passport_number: 'AB1234567' }).id;
    const child = travellerService.create({ customer_id: lead, full_name: 'Bilal Khan', relationship: 'Child' }).id;

    // Before adding anyone: no "other travellers" section.
    const before = voucherService.buildHotelVoucherHtml(booking, hotel).html;
    expect(before).not.toContain('Other Travellers');

    travellerService.addToBooking(booking, wife, null);
    travellerService.addToBooking(booking, child, null);

    for (const html of [voucherService.buildHotelVoucherHtml(booking, hotel).html, voucherService.buildTransportVoucherHtml(booking, transport).html]) {
      expect(html).toContain('Ahmed Khan');
      expect(html).toContain('Other Travellers');
      expect(html).toContain('Ayesha Khan');
      expect(html).toContain('AB1234567');
      expect(html).toContain('Bilal Khan');
    }
  });
});
