const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const { initDatabase, getDb } = require('../../../src/database/db');

// Master prompt sections 58/60-A.20: the upgrade must not break what already existed.
//
// fixtures/pre-upgrade/pre-upgrade.sql is a database exactly as the ORIGINAL (pre-upgrade)
// application left it - 52 tables of customers, bookings, a package booking, invoices (with a
// logo), payments incl. an advance and a refund, supplier invoices/payments, expenses, etc.
// fixtures/pre-upgrade/expected.json is what the ORIGINAL services returned for that database
// (every invoice's rendered HTML, ledger balances, list screens, the 14 legacy reports, and a
// fingerprint of every stored row). Each test here replays the old database, runs the REAL
// upgrade path (initDatabase: schema + additive migrations + seeds) and holds the upgraded
// code to the original answers.

const FIX = path.join(__dirname, 'fixtures', 'pre-upgrade');
const expected = JSON.parse(fs.readFileSync(path.join(FIX, 'expected.json'), 'utf8'));
const OLD_SQL = fs.readFileSync(path.join(FIX, 'pre-upgrade.sql'), 'utf8');
const ids = expected.ids;

function upgraded() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'upgrade-'));
  fs.mkdirSync(path.join(dir, 'database'));
  const old = new Database(path.join(dir, 'database', 'agency.db'));
  // Replaying a dump inserts tables in file order, not dependency order - so foreign keys are
  // off for the replay only. The upgraded database is checked with foreign_key_check below.
  old.pragma('foreign_keys = OFF');
  old.exec(OLD_SQL);
  old.close();
  initDatabase(dir); // the real startup path on an existing database
  return dir;
}

// Every key/value the original reported must still be reported, unchanged. The upgraded code
// may ADD fields (new columns), never change or drop one.
function expectSubset(want, got, where = 'root') {
  if (want !== null && typeof want === 'object') {
    expect(got !== null && typeof got === 'object', `${where} should be an object`).toBe(true);
    if (Array.isArray(want)) {
      expect(Array.isArray(got), `${where} should be an array`).toBe(true);
      expect(got.length, `${where} length`).toBe(want.length);
      want.forEach((w, i) => expectSubset(w, got[i], `${where}[${i}]`));
    } else {
      for (const k of Object.keys(want)) {
        expect(k in got, `${where}.${k} must still exist`).toBe(true);
        expectSubset(want[k], got[k], `${where}.${k}`);
      }
    }
  } else {
    expect(got, where).toBe(want);
  }
}

describe('upgrading a database created by the ORIGINAL application', () => {
  beforeEach(() => upgraded());

  it('keeps every stored row exactly as it was (row counts and a fingerprint of every original column)', () => {
    const db = getDb();
    expect(db.prepare('PRAGMA foreign_key_check').all(), 'no broken references after the upgrade').toEqual([]);
    for (const table of Object.keys(expected.counts)) {
      const count = db.prepare(`SELECT COUNT(*) AS c FROM ${table}`).get().c;
      expect(count, `${table} row count`).toBe(expected.counts[table]);
      const rows = db.prepare(`SELECT ${expected.columns[table].join(', ')} FROM ${table} ORDER BY rowid`).all();
      const fingerprint = crypto.createHash('sha256').update(JSON.stringify(rows)).digest('hex');
      expect(fingerprint, `${table} data fingerprint`).toBe(expected.checksums[table]);
    }
  });

  it('renders every existing invoice byte-for-byte as before - the invoice design is untouched, logo included', () => {
    const invoiceService = require('../invoiceService');
    for (const id of Object.keys(expected.invoiceHtml)) {
      const html = invoiceService.buildInvoiceHtml(Number(id));
      expect(html.includes('data:image/png;base64'), 'the agency logo is still rendered').toBe(true);
      expect(html === expected.invoiceHtml[id], `invoice ${id} HTML must be identical to the original`).toBe(true);
    }
  });

  it('customer ledger balances are unchanged', () => {
    const ledgerService = require('../ledgerService');
    for (const [customerId, balance] of Object.entries(expected.ledgerBalances)) {
      expect(ledgerService.getBalance(Number(customerId))).toBe(balance);
    }
  });

  it('the existing list screens return what they returned before (new fields may be added, nothing changes or disappears)', () => {
    const services = {
      customers: () => require('../customerService').list({ pageSize: 50 }),
      bookings: () => require('../bookingService').list({ pageSize: 50 }),
      invoices: () => require('../invoiceService').list({ pageSize: 50 }),
      payments: () => require('../paymentService').list({ pageSize: 50 }),
      suppliers: () => require('../supplierService').list({ pageSize: 50 })
    };
    for (const [name, run] of Object.entries(services)) expectSubset(JSON.parse(JSON.stringify(expected.lists[name])), JSON.parse(JSON.stringify(run())), name);
  });

  it('all 14 existing reports still produce the same results', () => {
    const reportService = require('../reportService');
    for (const key of Object.keys(expected.lists.reports)) {
      const filters = key === 'ledger' ? { customerId: ids.c1 } : {};
      expectSubset(expected.lists.reports[key], JSON.parse(JSON.stringify(reportService.run(key, filters))), `report ${key}`);
    }
  });

  it('upgrading again on the next start is harmless (idempotent)', () => {
    const dir = upgraded();
    const before = getDb().prepare('SELECT COUNT(*) AS c FROM sqlite_master').get().c;
    initDatabase(dir);
    initDatabase(dir);
    expect(getDb().prepare('SELECT COUNT(*) AS c FROM sqlite_master').get().c).toBe(before);
    for (const table of ['customers', 'bookings', 'invoices', 'payments']) {
      expect(getDb().prepare(`SELECT COUNT(*) AS c FROM ${table}`).get().c).toBe(expected.counts[table]);
    }
  });
});

describe('the new modules work on the old data', () => {
  beforeEach(() => upgraded());

  it('permission roles seeded by the old version gain the three new capabilities, without disturbing the old matrix', () => {
    const authService = require('../authService');
    const before = getDb().prepare('SELECT COUNT(*) AS c FROM permissions').get().c;
    authService.ensureDefaults();
    expect(getDb().prepare('SELECT COUNT(*) AS c FROM permissions').get().c).toBeGreaterThanOrEqual(before);
    const roles = authService.getRoles();
    const admin = roles.find((r) => r.name === 'Admin');
    const staff = roles.find((r) => r.name === 'Staff');
    expect(authService.getCapabilitiesForRole(admin.id)).toEqual({ view_profit: true, view_supplier_costs: true, export_reports: true });
    expect(authService.getCapabilitiesForRole(staff.id)).toEqual({ view_profit: false, view_supplier_costs: false, export_reports: false });
  });

  it('Customer 360 reads the old customer correctly and agrees with the old ledger', () => {
    const c360 = require('../customer360Service');
    const dossier = c360.getDossier(ids.c1);
    expect(dossier.header.full_name).toBe('Amina Siddiqui');
    expect(dossier.summary.outstanding_balance).toBe(expected.ledgerBalances[ids.c1]);
    expect(dossier.summary.bookings.total).toBe(1);
    expect(dossier.summary.advance.received).toBe(100000);
    const history = c360.bookingHistory(ids.c1, { pageSize: 0 }).items;
    expect(history).toHaveLength(1);
    expect(history[0].selling).toBe(250000);
    expect(history[0].package_name).toBe('Premium Umrah 14N');
  });

  it('Booking 360, Package 360 and Supplier 360 work on the old booking, package and supplier', () => {
    const booking = require('../bookingDossierService').getDossier(ids.b1);
    expect(booking.header.package_snapshot.package_name).toBe('Premium Umrah 14N'); // the old frozen snapshot is read as-is
    expect(booking.travellers).toHaveLength(1);
    expect(booking.supplierCosts.invoiced).toBe(52000);
    expect(booking.supplierCosts.paid).toBe(20000);

    const pkg = require('../package360Service').getDossier(ids.pkg);
    expect(pkg.summary.bookings.total).toBe(1);

    const sup = require('../supplier360Service').summary(ids.s1);
    expect(sup.invoices.total_billed).toBe(52000);
    expect(sup.invoices.payable).toBe(32000);
  });

  it('a standalone advance paid under the old version can be applied to an invoice with the new feature', () => {
    const advanceService = require('../advanceService');
    const invoiceService = require('../invoiceService');
    const available = advanceService.availableAdvances(ids.c3);
    expect(available.total_available).toBe(20000);
    advanceService.applyToInvoice({ paymentId: available.rows[0].id, invoiceId: ids.i3, amount: 20000 });
    const invoice = invoiceService.get(ids.i3);
    expect(invoice.paid_amount).toBe(20000);
    expect(invoice.status).toBe('Partially Paid');
  });

  it('reports, dashboard and calendar run against the old data', () => {
    const report = require('../customReportService').run({ reportType: 'financial' });
    expect(report.rows.find((r) => r.line === 'Revenue (Invoiced)').amount).toBeGreaterThan(0);
    const dash = require('../dashboardService');
    expect(dash.getStats(null).totalCustomers).toBe(3);
    expect(() => dash.getCalendarEvents(2027, 1)).not.toThrow();
    expect(Object.keys(dash.getCalendarEvents(2027, 1)).length).toBeGreaterThan(0); // the old booking departs 2027-01-10
  });
});
