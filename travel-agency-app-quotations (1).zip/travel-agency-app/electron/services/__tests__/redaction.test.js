const { freshDb } = require('./testUtils');
const redaction = require('../../ipc/redaction');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const customer360 = require('../customer360Service');
const bookingDossier = require('../bookingDossierService');
const searchService = require('../searchService');

const staff = { permissions: { customers: { view: 1 }, bookings: { view: 1 } }, capabilities: { view_profit: 0, view_supplier_costs: 0 } };
const boss = { permissions: { customers: { view: 1 }, bookings: { view: 1 }, suppliers: { view: 1 } }, capabilities: { view_profit: 1, view_supplier_costs: 1 } };

describe('redaction', () => {
  let cid, bid;
  beforeEach(() => {
    freshDb();
    cid = customerService.create({ full_name: 'Zara Search' }).id;
    bid = bookingService.create({ customer_id: cid, booking_type: 'Custom', total_price: 50000, paid_amount: 0 }).id;
  });

  it('blanks cost and profit in the customer dossier but keeps revenue/outstanding, unless the role has View Profit', () => {
    const res = { ok: true, data: customer360.getDossier(cid) };
    const hidden = redaction.apply('customer360:dossier', res, staff).data;
    expect(hidden.summary.profitability.gross_profit).toBeNull();
    expect(hidden.summary.profitability.total_cost).toBeNull();
    expect(hidden.summary.profitability.cost_breakdown).toBeNull();
    expect(hidden.summary.profitability.revenue).toBe(res.data.summary.profitability.revenue);
    expect(hidden.summary.outstanding_balance).toBe(res.data.summary.outstanding_balance);
    expect(redaction.apply('customer360:dossier', res, boss)).toBe(res);
  });

  it('blanks cost/profit on each booking row of the customer booking history', () => {
    const res = { ok: true, data: customer360.bookingHistory(cid, {}) };
    const hidden = redaction.apply('customer360:bookings', res, staff).data;
    expect(hidden.items.length).toBe(1);
    expect(hidden.items[0].cost).toBeNull();
    expect(hidden.items[0].profit).toBeNull();
    expect(hidden.items[0].selling).toBe(50000);
  });

  it('booking dossier: profit section needs View Profit, supplier-cost ledger needs View Supplier Costs', () => {
    const res = { ok: true, data: bookingDossier.getDossier(bid) };
    const partial = redaction.apply('bookingDossier:get', res, { ...boss, capabilities: { view_profit: 1, view_supplier_costs: 0 } }).data;
    expect(partial.supplierCosts).toBeNull();
    expect(partial.profit).not.toBeNull();
    const none = redaction.apply('bookingDossier:get', res, staff).data;
    expect(none.profit).toBeNull();
    expect(none.supplierCosts).toBeNull();
    expect(none.header.booking_code).toBe(res.data.header.booking_code);
  });

  it('never touches an error envelope or an unrelated channel', () => {
    const err = { ok: false, error: 'x' };
    expect(redaction.apply('customer360:dossier', err, staff)).toBe(err);
    const other = { ok: true, data: { cost: 5 } };
    expect(redaction.apply('payments:list', other, staff)).toBe(other);
  });

  it('search drops result groups the user cannot view', () => {
    const raw = { ok: true, data: searchService.search('Zara') };
    expect(raw.data.groups.map((g) => g.category)).toContain('Customer');
    const onlyBookings = { permissions: { bookings: { view: 1 } }, capabilities: {} };
    const filtered = redaction.apply('search:query', raw, onlyBookings).data;
    expect(filtered.groups.map((g) => g.category)).not.toContain('Customer');
    const all = redaction.apply('search:query', raw, boss).data;
    expect(all.groups.map((g) => g.category)).toContain('Customer');
  });
});
