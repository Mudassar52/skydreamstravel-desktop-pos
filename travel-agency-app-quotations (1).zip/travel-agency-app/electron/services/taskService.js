const { getDb } = require('../../src/database/db');

const PRIORITIES = ['Low', 'Medium', 'High'];
const STATUSES = ['Pending', 'In Progress', 'Completed', 'Overdue', 'Cancelled'];

const FIELDS = ['title', 'description', 'assigned_user_id', 'priority', 'due_date', 'booking_id', 'customer_id'];

function validate(payload) {
  if (!payload.title || !payload.title.trim()) throw new Error('Task title is required.');
}

/** Stored status stays as set; "Overdue" is derived at query time for Pending/In Progress tasks past their due date. */
const EFFECTIVE_STATUS_SQL = `
  CASE
    WHEN t.status IN ('Completed', 'Cancelled') THEN t.status
    WHEN t.due_date IS NOT NULL AND t.due_date < date('now') THEN 'Overdue'
    ELSE t.status
  END
`;

function list({ search = '', status = 'All', assignedUserId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(t.title LIKE @q OR c.full_name LIKE @q OR b.booking_code LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (assignedUserId) { conditions.push('t.assigned_user_id = @assignedUserId'); params.assignedUserId = assignedUserId; }

  let having = '';
  if (status && status !== 'All') { having = 'HAVING effective_status = @status'; params.status = status; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const baseQuery = `
    SELECT t.*, u.full_name AS agent_name, c.full_name AS customer_name, b.booking_code,
      ${EFFECTIVE_STATUS_SQL} AS effective_status
    FROM tasks t
    LEFT JOIN users u ON u.id = t.assigned_user_id
    LEFT JOIN customers c ON c.id = t.customer_id
    LEFT JOIN bookings b ON b.id = t.booking_id
    ${where}
  `;

  const total = db.prepare(`SELECT COUNT(*) AS c FROM (${baseQuery} ${having})`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`${baseQuery} ${having} ORDER BY t.due_date IS NULL, t.due_date ASC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT t.*, u.full_name AS agent_name, c.full_name AS customer_name, b.booking_code,
        ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM tasks t
       LEFT JOIN users u ON u.id = t.assigned_user_id
       LEFT JOIN customers c ON c.id = t.customer_id
       LEFT JOIN bookings b ON b.id = t.booking_id
       WHERE t.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Task not found.');
  return row;
}

/** Pending/In Progress/Overdue tasks due within N days - for Dashboard/Action Required. */
function dueSoon(days = 7) {
  const db = getDb();
  return db
    .prepare(
      `SELECT t.*, u.full_name AS agent_name, ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM tasks t LEFT JOIN users u ON u.id = t.assigned_user_id
       WHERE t.status NOT IN ('Completed', 'Cancelled') AND t.due_date IS NOT NULL AND t.due_date <= date('now', '+' || ? || ' days')
       ORDER BY t.due_date ASC`
    )
    .all(days);
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of FIELDS) params[f] = payload[f] ?? null;
  if (!params.priority) params.priority = 'Medium';

  const result = db
    .prepare(`INSERT INTO tasks (${FIELDS.join(', ')}) VALUES (${FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Task Created', 'task', ?, ?)`
  ).run(result.lastInsertRowid, `Task "${payload.title}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM tasks WHERE id = ?').get(id);
  if (!existing) throw new Error('Task not found.');

  const params = { id };
  const sets = [];
  for (const f of [...FIELDS, 'status']) {
    if (payload[f] !== undefined) {
      if (f === 'status' && !STATUSES.includes(payload.status)) throw new Error('Invalid task status.');
      sets.push(`${f} = @${f}`);
      params[f] = payload[f];
    }
  }
  sets.push("updated_at = datetime('now')");
  db.prepare(`UPDATE tasks SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Task Updated', 'task', ?, ?)`
  ).run(id, `Task #${id} updated`);

  return { success: true };
}

function markStatus(id, status) {
  return update(id, { status });
}

function remove(id) {
  const db = getDb();
  db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'task', ?, ?)`
  ).run(id, `Task #${id} deleted`);
  return { success: true };
}

module.exports = { PRIORITIES, STATUSES, list, get, dueSoon, create, update, markStatus, remove };
