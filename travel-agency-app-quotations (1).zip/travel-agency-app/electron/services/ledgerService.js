const { getDb } = require('../../src/database/db');

/**
 * Appends one ledger row and returns the new running balance. Takes `db`
 * so callers can run this inside their own transaction (invoice creation,
 * payment recording, etc.) rather than opening a nested one.
 *
 * running_balance is what the customer currently owes the agency:
 * a debit (an invoice being raised) increases it, a credit (a payment
 * received) decreases it. A refund is modeled as a debit - it increases
 * the balance owed again, since money already counted as received is
 * being given back.
 */
function addEntry(db, { customer_id, description, invoice_id, payment_id, debit = 0, credit = 0 }) {
  const last = db
    .prepare('SELECT running_balance FROM ledger_entries WHERE customer_id = ? ORDER BY id DESC LIMIT 1')
    .get(customer_id);
  const prevBalance = last ? last.running_balance : 0;
  const runningBalance = prevBalance + Number(debit || 0) - Number(credit || 0);

  db.prepare(
    `INSERT INTO ledger_entries (customer_id, description, invoice_id, payment_id, debit, credit, running_balance)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(customer_id, description, invoice_id || null, payment_id || null, debit || 0, credit || 0, runningBalance);

  return runningBalance;
}

function list(customerId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT l.*, i.invoice_number FROM ledger_entries l
       LEFT JOIN invoices i ON i.id = l.invoice_id
       WHERE l.customer_id = ? ORDER BY l.id ASC`
    )
    .all(customerId);
}

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

const TXN_TYPE_SQL = `
  CASE
    WHEN l.invoice_id IS NOT NULL AND l.payment_id IS NULL THEN 'Invoice'
    WHEN p.payment_type IS NOT NULL THEN p.payment_type
    WHEN l.description LIKE '%voided%' THEN 'Adjustment'
    ELSE 'Other'
  END`;

/**
 * The professional ledger view (master prompt section 17): filterable by date
 * range, booking, invoice, payment and transaction type, with an opening
 * balance computed as the running balance just before the filtered range
 * starts (0 if the range starts at the very first entry), plus total debit,
 * total credit and closing balance for the filtered rows.
 */
function filteredView(customerId, opts = {}) {
  const db = getDb();
  const { dateFrom = '', dateTo = '', bookingId = null, invoiceId = null, paymentId = null, transactionType = 'All' } = opts;

  const base = `
    WITH classified AS (
      SELECT l.*, i.invoice_number, COALESCE(i.booking_id, p.booking_id) AS booking_id,
             p.reference AS payment_reference, p.payment_method, ${TXN_TYPE_SQL} AS txn_type
      FROM ledger_entries l
      LEFT JOIN invoices i ON i.id = l.invoice_id
      LEFT JOIN payments p ON p.id = l.payment_id
      WHERE l.customer_id = @customerId
    )`;

  const where = [];
  const params = { customerId };
  if (dateFrom) { where.push('date(entry_date) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { where.push('date(entry_date) <= date(@dateTo)'); params.dateTo = dateTo; }
  if (bookingId) { where.push('booking_id = @bookingId'); params.bookingId = Number(bookingId); }
  if (invoiceId) { where.push('invoice_id = @invoiceId'); params.invoiceId = Number(invoiceId); }
  if (paymentId) { where.push('payment_id = @paymentId'); params.paymentId = Number(paymentId); }
  if (transactionType && transactionType !== 'All') { where.push('txn_type = @txnType'); params.txnType = transactionType; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const entries = db.prepare(`${base} SELECT * FROM classified ${whereSql} ORDER BY id ASC`).all(params)
    .map((r) => ({ ...r, debit: round2(r.debit), credit: round2(r.credit), running_balance: round2(r.running_balance) }));

  // Opening balance = running balance of the last entry strictly before the
  // filtered range (by id, since entry_date can repeat); 0 if there is none.
  let openingBalance = 0;
  if (entries.length > 0) {
    const firstId = entries[0].id;
    const prior = db.prepare('SELECT running_balance FROM ledger_entries WHERE customer_id = ? AND id < ? ORDER BY id DESC LIMIT 1').get(customerId, firstId);
    openingBalance = prior ? round2(prior.running_balance) : 0;
  } else {
    // No rows matched the filter - the "opening" balance for an empty window
    // is simply the customer's current balance (the last entry overall, if any).
    openingBalance = round2(getBalance(customerId));
  }
  const totalDebit = round2(entries.reduce((a, e) => a + e.debit, 0));
  const totalCredit = round2(entries.reduce((a, e) => a + e.credit, 0));
  const closingBalance = entries.length > 0 ? entries[entries.length - 1].running_balance : openingBalance;

  return { entries, openingBalance, totalDebit, totalCredit, closingBalance };
}

/** Distinct transaction types actually present for this customer (for the filter dropdown). */
function transactionTypes(customerId) {
  const db = getDb();
  return db.prepare(
    `WITH classified AS (
       SELECT ${TXN_TYPE_SQL} AS txn_type FROM ledger_entries l
       LEFT JOIN invoices i ON i.id = l.invoice_id
       LEFT JOIN payments p ON p.id = l.payment_id
       WHERE l.customer_id = ?
     ) SELECT DISTINCT txn_type FROM classified ORDER BY txn_type`
  ).all(customerId).map((r) => r.txn_type);
}

function getBalance(customerId) {
  const db = getDb();
  const last = db
    .prepare('SELECT running_balance FROM ledger_entries WHERE customer_id = ? ORDER BY id DESC LIMIT 1')
    .get(customerId);
  return last ? last.running_balance : 0;
}

module.exports = { addEntry, list, filteredView, transactionTypes, getBalance };
