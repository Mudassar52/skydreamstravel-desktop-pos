const { dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const { getDb } = require('../../src/database/db');
const { normalizeLogoDimension } = require('./templateEngine');

// Every settings key the UI is allowed to write - anything else is silently
// ignored so a stray/unexpected key from the renderer can't create garbage
// rows. Image fields are stored as data URIs directly in the settings
// table (no separate file management needed) so they drop straight into
// an <img src="..."> in the invoice template.
const TEXT_FIELDS = [
  'agency_name', 'agency_address', 'agency_phone', 'agency_whatsapp', 'agency_email', 'agency_website',
  'business_info', 'bank_details', 'default_currency', 'invoice_prefix', 'invoice_next_number',
  'tax_rate', 'terms_conditions', 'logo_width', 'logo_height'
];
const IMAGE_FIELDS = ['logo', 'signature', 'stamp'];

const MIME_BY_EXT = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp' };

function get(key, fallback = '') {
  const db = getDb();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
}

function getAll() {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}

function set(key, value) {
  const db = getDb();
  db.prepare(
    `INSERT INTO settings (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(key, String(value));
  return { success: true };
}

/** Saves several text settings at once, ignoring any key not in TEXT_FIELDS. */
function setMany(payload) {
  const db = getDb();
  const tx = db.transaction((entries) => {
    for (const [key, value] of entries) set(key, value ?? '');
  });
  const entries = Object.entries(payload).filter(([key]) => TEXT_FIELDS.includes(key));
  // Validate logo dimensions BEFORE writing anything, so a bad value never
  // leaves the settings half-saved.
  const normalized = entries.map(([key, value]) => {
    if (key === 'logo_width') return [key, normalizeLogoDimension(value, 'Logo width') ?? ''];
    if (key === 'logo_height') return [key, normalizeLogoDimension(value, 'Logo height') ?? ''];
    return [key, value];
  });
  tx(normalized);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, description) VALUES ('Settings Updated', 'settings', ?)`
  ).run(`Updated: ${entries.map(([k]) => k).join(', ')}`);
  return { success: true };
}

/** Opens the native file picker, reads the chosen image, stores it as a data URI. */
async function uploadImage(fieldKey) {
  if (!IMAGE_FIELDS.includes(fieldKey)) throw new Error('Unknown image field.');

  const result = await dialog.showOpenDialog({
    title: 'Select image',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }]
  });
  if (result.canceled || result.filePaths.length === 0) return { updated: false };

  const filePath = result.filePaths[0];
  const ext = path.extname(filePath).toLowerCase();
  const mime = MIME_BY_EXT[ext];
  if (!mime) throw new Error('Unsupported image type. Use PNG, JPG, GIF, or WEBP.');

  const buffer = fs.readFileSync(filePath);
  if (buffer.length > 2 * 1024 * 1024) {
    throw new Error('Image is too large (max 2 MB). Please use a smaller file.');
  }
  const dataUri = `data:${mime};base64,${buffer.toString('base64')}`;
  set(fieldKey, dataUri);
  return { updated: true, dataUri };
}

function removeImage(fieldKey) {
  if (!IMAGE_FIELDS.includes(fieldKey)) throw new Error('Unknown image field.');
  set(fieldKey, '');
  return { success: true };
}

module.exports = { TEXT_FIELDS, IMAGE_FIELDS, get, getAll, set, setMany, uploadImage, removeImage };
