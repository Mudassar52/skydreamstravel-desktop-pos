const { getDb } = require('../../src/database/db');

const COMMISSION_TYPES = ['Percentage', 'Fixed'];
const STATUSES = ['Active', 'Inactive'];

function validate(payload) {
  if (!payload.name || !String(payload.name).trim()) throw new Error('Agent name is required.');
  const type = payload.commission_type || 'Percentage';
  if (!COMMISSION_TYPES.includes(type)) throw new Error('Commission type must be Percentage or Fixed.');
  const value = Number(payload.commission_value || 0);
  if (!Number.isFinite(value) || value < 0) throw new Error('Commission value cannot be negative.');
  if (type === 'Percentage' && value > 100) throw new Error('A percentage commission cannot be more than 100.');
  if (payload.status && !STATUSES.includes(payload.status)) throw new Error('Status must be Active or Inactive.');
  if (payload.email && !/^\S+@\S+\.\S+$/.test(String(payload.email).trim())) throw new Error('Please enter a valid email address.');
}

function nextAgentCode(db) {
  const last = db.prepare('SELECT agent_code FROM agents ORDER BY id DESC LIMIT 1').get();
  let n = 1;
  if (last && last.agent_code) {
    const m = last.agent_code.match(/(\d+)$/);
    if (m) n = Number(m[1]) + 1;
  }
  return `AG-${String(n).padStart(4, '0')}`;
}

const SUMMARY_SQL = `
  SELECT a.*,
    (SELECT COUNT(*) FROM bookings b WHERE b.agent_id = a.id AND b.status <> 'Cancelled') AS booking_count,
    (SELECT COALESCE(SUM(c.commission_amount), 0) FROM commissions c WHERE c.agent_id = a.id AND c.status IN ('Pending','Approved')) AS commission_due,
    (SELECT COALESCE(SUM(c.commission_amount), 0) FROM commissions c WHERE c.agent_id = a.id AND c.status = 'Paid') AS commission_paid
  FROM agents a`;

function list({ search = '', status = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const cond = [];
  const params = {};
  if (search && search.trim()) {
    cond.push('(a.name LIKE @q OR a.agent_code LIKE @q OR a.company LIKE @q OR a.phone LIKE @q OR a.email LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') { cond.push('a.status = @status'); params.status = status; }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM agents a ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db.prepare(`${SUMMARY_SQL} ${where} ORDER BY a.name LIMIT @limit OFFSET @offset`).all({ ...params, limit: pageSize, offset });
  return { rows, total, page, pageSize };
}

/** Small list for dropdowns (booking form, commission form). Active agents only unless told otherwise. */
function options({ includeInactive = false } = {}) {
  const db = getDb();
  return db.prepare(
    `SELECT id, agent_code, name, company, commission_type, commission_value, status FROM agents
     ${includeInactive ? '' : "WHERE status = 'Active'"} ORDER BY name`
  ).all();
}

function get(id) {
  const db = getDb();
  const row = db.prepare(`${SUMMARY_SQL} WHERE a.id = ?`).get(id);
  if (!row) throw new Error('Agent not found.');
  const bookings = db.prepare(
    `SELECT b.id, b.booking_code, b.booking_date, b.status, b.total_price, c.full_name AS customer_name
     FROM bookings b JOIN customers c ON c.id = b.customer_id WHERE b.agent_id = ? ORDER BY b.id DESC LIMIT 200`
  ).all(id);
  return { ...row, bookings };
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const code = nextAgentCode(db);
  const result = db.prepare(
    `INSERT INTO agents (agent_code, name, company, phone, email, city, address, commission_type, commission_value, status, notes)
     VALUES (@agent_code, @name, @company, @phone, @email, @city, @address, @commission_type, @commission_value, @status, @notes)`
  ).run({
    agent_code: code,
    name: String(payload.name).trim(),
    company: payload.company || null,
    phone: payload.phone || null,
    email: payload.email ? String(payload.email).trim() : null,
    city: payload.city || null,
    address: payload.address || null,
    commission_type: payload.commission_type || 'Percentage',
    commission_value: Number(payload.commission_value || 0),
    status: payload.status || 'Active',
    notes: payload.notes || null
  });
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Agent Created', 'agent', ?, ?)`)
    .run(result.lastInsertRowid, `Agent ${code} "${String(payload.name).trim()}" created`);
  return { id: result.lastInsertRowid, agentCode: code };
}

/**
 * Editing an agent's default rate only affects commissions created AFTER the edit - existing commissions
 * froze their own rate when they were created.
 */
function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM agents WHERE id = ?').get(id);
  if (!existing) throw new Error('Agent not found.');
  db.prepare(
    `UPDATE agents SET name=@name, company=@company, phone=@phone, email=@email, city=@city, address=@address,
       commission_type=@commission_type, commission_value=@commission_value, status=@status, notes=@notes, updated_at=datetime('now')
     WHERE id=@id`
  ).run({
    id,
    name: String(payload.name).trim(),
    company: payload.company || null,
    phone: payload.phone || null,
    email: payload.email ? String(payload.email).trim() : null,
    city: payload.city || null,
    address: payload.address || null,
    commission_type: payload.commission_type || 'Percentage',
    commission_value: Number(payload.commission_value || 0),
    status: payload.status || 'Active',
    notes: payload.notes || null
  });
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Agent Updated', 'agent', ?, ?)`)
    .run(id, `Agent #${id} updated`);
  return { success: true };
}

function remove(id) {
  const db = getDb();
  const agent = db.prepare('SELECT agent_code, name FROM agents WHERE id = ?').get(id);
  if (!agent) throw new Error('Agent not found.');
  const bookings = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE agent_id = ?').get(id).c;
  const commissions = db.prepare('SELECT COUNT(*) AS c FROM commissions WHERE agent_id = ?').get(id).c;
  if (bookings > 0 || commissions > 0) {
    throw new Error('This agent has bookings or commissions on record and cannot be deleted. Mark the agent Inactive instead.');
  }
  db.prepare('DELETE FROM agents WHERE id = ?').run(id);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'agent', ?, ?)`)
    .run(id, `Agent ${agent.agent_code} "${agent.name}" deleted`);
  return { success: true };
}

module.exports = { COMMISSION_TYPES, STATUSES, list, options, get, create, update, remove };
