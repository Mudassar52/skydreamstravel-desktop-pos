const { getDb } = require('../../src/database/db');
const { AVAILABLE_TOKENS } = require('./templateEngine');

// A plain, professional starting design. This is deliberately just the
// seeded default, not "the" invoice theme - anyone can add more templates
// from the Invoice Templates screen and set a different one as default
// without touching any other part of the app.
const DEFAULT_HTML = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4; margin: 16mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #16233F; font-size: 12px; margin: 0; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1E4FA3; padding-bottom: 14px; margin-bottom: 20px; }
  .agency-name { font-size: 19px; font-weight: 700; color: #1E4FA3; margin-bottom: 4px; }
  .muted { color: #5B6B8C; }
  .invoice-title { text-align: right; }
  .invoice-title h1 { font-size: 22px; margin: 0 0 6px; color: #1E4FA3; letter-spacing: 0.04em; }
  .section-title { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.05em; color: #8B97B3; margin: 18px 0 6px; font-weight: 700; }
  table { width: 100%; border-collapse: collapse; margin-top: 6px; }
  th, td { padding: 8px 10px; border-bottom: 1px solid #E4E9F2; text-align: left; }
  th { background: #EAF1FC; color: #1E4FA3; text-transform: uppercase; font-size: 10px; letter-spacing: 0.03em; }
  td.num, th.num { text-align: right; }
  .totals { width: 260px; margin-left: auto; margin-top: 14px; }
  .totals .row { display: flex; justify-content: space-between; padding: 4px 0; }
  .totals .grand { font-weight: 700; font-size: 14px; border-top: 2px solid #1E4FA3; padding-top: 8px; margin-top: 4px; }
  .footer { margin-top: 36px; font-size: 10.5px; color: #8B97B3; border-top: 1px solid #E4E9F2; padding-top: 10px; }
</style>
</head>
<body>
  <div class="header">
    <div>
      <div class="agency-name">{{agency_name}}</div>
      <div class="muted">{{agency_address}}</div>
      <div class="muted">{{agency_phone}} &middot; {{agency_email}}</div>
    </div>
    <div class="invoice-title">
      {{{logo_html}}}
      <h1>INVOICE</h1>
      <div>{{invoice_number}}</div>
      <div class="muted">Date: {{invoice_date}}</div>
      <div class="muted">Due: {{due_date}}</div>
    </div>
  </div>

  <div class="section-title">Bill To</div>
  <div>{{customer_name}}</div>
  <div class="muted">{{customer_phone}}</div>
  <div class="muted">{{customer_email}}</div>
  <div class="muted">{{customer_address}}</div>

  <div class="section-title">Booking Reference</div>
  <div class="muted">{{booking_reference}}</div>

  <table>
    <thead>
      <tr><th>Description</th><th class="num">Qty</th><th class="num">Unit Price</th><th class="num">Line Total</th></tr>
    </thead>
    <tbody>
      {{{line_items_html}}}
    </tbody>
  </table>

  <div class="totals">
    <div class="row"><span>Subtotal</span><span>{{subtotal}}</span></div>
    <div class="row"><span>Discount</span><span>{{discount}}</span></div>
    <div class="row"><span>Tax</span><span>{{tax}}</span></div>
    <div class="row grand"><span>Total</span><span>{{total}}</span></div>
    <div class="row"><span>Paid</span><span>{{paid_amount}}</span></div>
    <div class="row"><span>Balance Due</span><span>{{remaining_amount}}</span></div>
  </div>

  <div class="section-title">Notes</div>
  <div class="muted">{{notes}}</div>

  <div class="section-title">Terms &amp; Conditions</div>
  <div class="muted">{{terms}}</div>

  <div class="section-title">Bank Details</div>
  <div class="muted">{{bank_details}}</div>

  <div style="display:flex; justify-content:flex-end; gap:24px; margin-top:24px; align-items:flex-end;">
    {{{signature_html}}}
    {{{stamp_html}}}
  </div>

  <div class="footer">{{agency_name}} &middot; {{agency_website}}</div>
</body>
</html>`;

function ensureDefaultTemplate() {
  const db = getDb();
  const count = db.prepare('SELECT COUNT(*) AS c FROM invoice_templates').get().c;
  if (count === 0) {
    db.prepare(
      `INSERT INTO invoice_templates (template_name, is_default, status, config_json) VALUES (?, 1, 'Active', ?)`
    ).run('Default Template', JSON.stringify({ html: DEFAULT_HTML }));
  }
}

function list() {
  const db = getDb();
  return db.prepare('SELECT id, template_name, is_default, status, created_at FROM invoice_templates ORDER BY is_default DESC, created_at DESC').all();
}

function get(id) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM invoice_templates WHERE id = ?').get(id);
  if (!row) throw new Error('Template not found.');
  const config = JSON.parse(row.config_json);
  return { ...row, html: config.html };
}

function getDefault() {
  const db = getDb();
  const row = db.prepare('SELECT * FROM invoice_templates WHERE is_default = 1 LIMIT 1').get();
  if (!row) throw new Error('No default invoice template is set.');
  const config = JSON.parse(row.config_json);
  return { ...row, html: config.html };
}

function validate(payload) {
  if (!payload.template_name || !payload.template_name.trim()) throw new Error('Template name is required.');
  if (!payload.html || !payload.html.trim()) throw new Error('Template HTML cannot be empty.');
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const result = db
    .prepare(`INSERT INTO invoice_templates (template_name, is_default, status, config_json) VALUES (?, 0, ?, ?)`)
    .run(payload.template_name, payload.status || 'Active', JSON.stringify({ html: payload.html }));

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Template Created', 'invoice_template', ?, ?)`
  ).run(result.lastInsertRowid, `Template "${payload.template_name}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM invoice_templates WHERE id = ?').get(id);
  if (!existing) throw new Error('Template not found.');
  db.prepare(`UPDATE invoice_templates SET template_name = ?, status = ?, config_json = ? WHERE id = ?`)
    .run(payload.template_name, payload.status || 'Active', JSON.stringify({ html: payload.html }), id);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Template Updated', 'invoice_template', ?, ?)`
  ).run(id, `Template "${payload.template_name}" updated`);

  return { success: true };
}

function setDefault(id) {
  const db = getDb();
  const tx = db.transaction((templateId) => {
    db.prepare('UPDATE invoice_templates SET is_default = 0').run();
    db.prepare('UPDATE invoice_templates SET is_default = 1 WHERE id = ?').run(templateId);
  });
  tx(id);
  return { success: true };
}

function remove(id) {
  const db = getDb();
  const row = db.prepare('SELECT is_default FROM invoice_templates WHERE id = ?').get(id);
  if (!row) throw new Error('Template not found.');
  if (row.is_default) throw new Error('Cannot delete the default template. Set another template as default first.');
  const inUse = db.prepare('SELECT COUNT(*) AS c FROM invoices WHERE template_id = ?').get(id).c;
  if (inUse > 0) throw new Error('This template is used by existing invoices and cannot be deleted.');
  db.prepare('DELETE FROM invoice_templates WHERE id = ?').run(id);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'invoice_template', ?, ?)`
  ).run(id, `Invoice template #${id} deleted`);
  return { success: true };
}

module.exports = { ensureDefaultTemplate, list, get, getDefault, create, update, setDefault, remove, AVAILABLE_TOKENS };
