const { getDb } = require('../../src/database/db');
const { makeCrudService } = require('./genericCrud');

const STATUSES = ['Documents Pending', 'Ready to Apply', 'Applied', 'Processing', 'Approved', 'Rejected', 'Expired'];

const FIELDS = [
  'customer_id', 'traveller_id', 'booking_id', 'country', 'visa_type', 'application_date',
  'submission_date', 'approval_date', 'expiry_date', 'application_number', 'status', 'notes',
  'supplier_id', 'package_component_id',
  'visa_number', 'passport_number', 'issue_date', 'cost', 'selling_price'
];

function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!payload.country || !payload.country.trim()) throw new Error('Country is required.');
  if (payload.status && !STATUSES.includes(payload.status)) throw new Error('Please select a valid visa status.');
}

const crud = makeCrudService('visa_applications', FIELDS, { validate, recordLabelField: 'country' });

function list({ search = '', status = '', page = 1, pageSize = 20 } = {}) {
  // Overridden (rather than the generic list()) to also surface the
  // customer's name, since a bare country/status row isn't very useful on
  // its own - and to flag visas expiring soon (Section 13: expiry reminders).
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push('(c.full_name LIKE @q OR t.full_name LIKE @q OR v.country LIKE @q OR v.application_number LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (status) { conditions.push('v.status = @status'); params.status = status; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM visa_applications v JOIN customers c ON c.id = v.customer_id LEFT JOIN travellers t ON t.id = v.traveller_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT v.*, COALESCE(t.full_name, c.full_name) AS customer_name, c.full_name AS holder_name
       FROM visa_applications v JOIN customers c ON c.id = v.customer_id LEFT JOIN travellers t ON t.id = v.traveller_id
       ${where}
       ORDER BY v.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  const now = new Date();
  const in30Days = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const withFlags = rows.map((r) => ({
    ...r,
    expiringSoon: !!r.expiry_date && r.status === 'Approved' && new Date(r.expiry_date) <= in30Days && new Date(r.expiry_date) >= now
  }));

  return { rows: withFlags, total, page, pageSize };
}

function getExpiringSoon(days = 30) {
  const db = getDb();
  return db
    .prepare(
      `SELECT v.*, COALESCE(t.full_name, c.full_name) AS customer_name FROM visa_applications v
       JOIN customers c ON c.id = v.customer_id LEFT JOIN travellers t ON t.id = v.traveller_id
       WHERE v.status = 'Approved' AND v.expiry_date IS NOT NULL
       AND date(v.expiry_date) BETWEEN date('now') AND date('now', '+' || ? || ' days')
       ORDER BY v.expiry_date ASC`
    )
    .all(days);
}

function listByBooking(bookingId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT v.*, COALESCE(t.full_name, c.full_name) AS customer_name FROM visa_applications v
       JOIN customers c ON c.id = v.customer_id LEFT JOIN travellers t ON t.id = v.traveller_id
       WHERE v.booking_id = ? ORDER BY v.created_at DESC`
    )
    .all(bookingId);
}

/**
 * One visa application per person on the booking (the lead customer + every traveller), all linked to the booking and
 * starting at "Documents Pending". People who already have an application for that country on this booking are skipped,
 * so it is safe to press twice.
 */
function createForBooking(bookingId, { country, visa_type, include_lead = true } = {}) {
  const db = getDb();
  if (!country || !String(country).trim()) throw new Error('Country is required.');
  const booking = db.prepare('SELECT id, customer_id FROM bookings WHERE id = ?').get(bookingId);
  if (!booking) throw new Error('Booking not found.');
  const travellers = db.prepare(
    `SELECT t.id, t.passport_number FROM booking_travellers bt JOIN travellers t ON t.id = bt.traveller_id WHERE bt.booking_id = ? ORDER BY bt.id`
  ).all(bookingId);
  const lead = db.prepare('SELECT passport_number FROM customers WHERE id = ?').get(booking.customer_id);
  let created = 0; let skipped = 0;
  db.transaction(() => {
    const base = { booking_id: bookingId, country: country.trim(), visa_type: visa_type || null, status: 'Documents Pending' };
    if (include_lead) {
      const has = db.prepare('SELECT id FROM visa_applications WHERE booking_id = ? AND customer_id = ? AND traveller_id IS NULL AND country = ?').get(bookingId, booking.customer_id, base.country);
      if (has) skipped += 1;
      else { crud.create({ ...base, customer_id: booking.customer_id, traveller_id: null, passport_number: (lead && lead.passport_number) || null }); created += 1; }
    }
    for (const t of travellers) {
      const has = db.prepare('SELECT id FROM visa_applications WHERE booking_id = ? AND traveller_id = ? AND country = ?').get(bookingId, t.id, base.country);
      if (has) skipped += 1;
      else { crud.create({ ...base, customer_id: booking.customer_id, traveller_id: t.id, passport_number: t.passport_number || null }); created += 1; }
    }
  })();
  return { created, skipped };
}

module.exports = { ...crud, list, getExpiringSoon, listByBooking, createForBooking, STATUSES };
