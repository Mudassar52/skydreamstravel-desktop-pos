const { getDb } = require('../../src/database/db');
const { makeCrudService } = require('./genericCrud');

const STATUSES = ['Scheduled', 'In Progress', 'Completed', 'Cancelled'];

const FIELDS = [
  'booking_id', 'vehicle', 'vehicle_number', 'driver', 'driver_phone',
  'pickup_location', 'drop_location', 'pickup_date', 'pickup_time',
  'cost', 'selling_price', 'status', 'notes', 'supplier_id', 'package_component_id', 'transport_type'
];

function validate(payload) {
  if (!payload.pickup_location || !payload.pickup_location.trim()) {
    throw new Error('Pickup location is required.');
  }
  if (payload.status && !STATUSES.includes(payload.status)) {
    throw new Error('Please select a valid status.');
  }
}

const crud = makeCrudService('transportation', FIELDS, { validate, recordLabelField: 'pickup_location' });

/** Paginated/searchable - see the matching note in flightService.js. */
function list({ search = '', page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push('(pickup_location LIKE @q OR drop_location LIKE @q OR driver LIKE @q OR vehicle LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM transportation ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`SELECT * FROM transportation ${where} ORDER BY created_at DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function listByBooking(bookingId) {
  const db = getDb();
  return db.prepare('SELECT * FROM transportation WHERE booking_id = ? ORDER BY pickup_date').all(bookingId);
}

module.exports = { ...crud, list, listByBooking, STATUSES };
