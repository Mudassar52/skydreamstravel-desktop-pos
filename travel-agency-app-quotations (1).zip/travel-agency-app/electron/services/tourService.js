const { getDb } = require('../../src/database/db');
const { makeCrudService } = require('./genericCrud');

const TOUR_FIELDS = [
  'tour_name', 'destination', 'country', 'city', 'start_date', 'end_date', 'duration',
  'total_seats', 'available_seats', 'package_price', 'hotel', 'transport', 'meals',
  'activities', 'guide', 'description', 'notes'
];

function validateTour(payload) {
  if (!payload.tour_name || !payload.tour_name.trim()) {
    throw new Error('Tour name is required.');
  }
  if (payload.start_date && payload.end_date && new Date(payload.end_date) < new Date(payload.start_date)) {
    throw new Error('End date cannot be before the start date.');
  }
}

const crud = makeCrudService('tours', TOUR_FIELDS, {
  validate: validateTour,
  recordLabelField: 'tour_name'
});

// Wrap create so available_seats defaults sensibly when not provided.
function create(payload) {
  const p = { ...payload };
  if (p.available_seats === undefined || p.available_seats === null || p.available_seats === '') {
    p.available_seats = p.total_seats;
  }
  return crud.create(p);
}

function listPassengers(tourId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT tp.id AS membership_id, tp.notes, c.id AS customer_id, c.full_name, c.phone, c.passport_number
       FROM tour_passengers tp
       JOIN customers c ON c.id = tp.customer_id
       WHERE tp.tour_id = ?
       ORDER BY tp.id ASC`
    )
    .all(tourId);
}

function addPassenger(tourId, customerId, notes) {
  const db = getDb();
  const tour = db.prepare('SELECT total_seats, available_seats FROM tours WHERE id = ?').get(tourId);
  if (!tour) throw new Error('Tour not found.');
  if (tour.available_seats !== null && tour.available_seats <= 0) {
    throw new Error('No available seats left on this tour.');
  }
  const existing = db.prepare('SELECT id FROM tour_passengers WHERE tour_id = ? AND customer_id = ?').get(tourId, customerId);
  if (existing) throw new Error('This customer is already on the tour.');

  db.prepare('INSERT INTO tour_passengers (tour_id, customer_id, notes) VALUES (?, ?, ?)').run(tourId, customerId, notes || null);
  db.prepare('UPDATE tours SET available_seats = MAX(available_seats - 1, 0) WHERE id = ?').run(tourId);
  return { success: true };
}

function removePassenger(membershipId, tourId) {
  const db = getDb();
  db.prepare('DELETE FROM tour_passengers WHERE id = ?').run(membershipId);
  const tour = db.prepare('SELECT total_seats FROM tours WHERE id = ?').get(tourId);
  const remaining = db.prepare('SELECT COUNT(*) AS c FROM tour_passengers WHERE tour_id = ?').get(tourId).c;
  db.prepare('UPDATE tours SET available_seats = ? WHERE id = ?').run(Math.max((tour?.total_seats || 0) - remaining, 0), tourId);
  return { success: true };
}

module.exports = {
  ...crud,
  create,
  passengers: { list: listPassengers, add: addPassenger, remove: removePassenger }
};
