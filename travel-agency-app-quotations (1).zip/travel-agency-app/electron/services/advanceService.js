const { getDb } = require('../../src/database/db');
const { deriveStatus } = require('./invoiceService');

// Customer Advance System (master prompt sections 16, 17, 60-A.12).
//
// An "Advance" is a payments row with payment_type = 'Advance'. The payment
// row itself is immutable (never edited, matching paymentService's own
// "corrections are a new reversal, not a silent edit" philosophy). What
// changes over time is how much of it has been ALLOCATED to invoices - that
// is tracked here, one row per allocation, in advance_applications. This
// makes every allocation traceable and makes double counting impossible:
// available balance is always `amount - SUM(applied)`, computed fresh.
//
// Applying an advance to an invoice does NOT create a new ledger entry and
// does NOT move money through accountService again - the cash was already
// received (and the ledger credit already booked) at the moment the advance
// payment was created. Applying it only tells a specific INVOICE how much of
// that already-received money is covering it, so the invoice's own
// paid/remaining/status reflect reality.

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

/** Every advance payment for a customer that still has an unallocated balance.
 * Only STANDALONE advances (no booking_id, no invoice_id at the time they were
 * received) are offered here. A booking-tied advance is already absorbed
 * automatically the moment an invoice is generated from that booking
 * (invoiceService.createFromBooking seeds paid_amount from booking.paid_amount);
 * offering it here too would double count it, which the master spec
 * explicitly forbids ("Prevent duplicate accounting").
 */
// Applied-so-far per advance, computed ONCE as a grouped subquery and joined
// in, instead of one SUM query per advance row (an N+1 that made the list
// pages slower the more advances existed).
const APPLIED_JOIN = `LEFT JOIN (SELECT payment_id, SUM(amount) AS applied FROM advance_applications GROUP BY payment_id) a ON a.payment_id = p.id`;

function shape(row) {
  const applied = Number(row.applied) || 0;
  return { ...row, amount: round2(row.amount), applied: round2(applied), available: round2(row.amount - applied) };
}

function availableAdvances(customerId) {
  const db = getDb();
  const rows = db.prepare(
    `SELECT p.*, COALESCE(a.applied, 0) AS applied FROM payments p ${APPLIED_JOIN}
     WHERE p.customer_id = ? AND p.payment_type = 'Advance' AND p.booking_id IS NULL
       AND p.amount - COALESCE(a.applied, 0) > 0.005
     ORDER BY p.payment_date ASC`
  ).all(customerId).map(shape);
  return { rows, total_available: round2(rows.reduce((a, r) => a + r.available, 0)) };
}

/** Applications already made against one invoice (for its own Advances/Payments view). */
function applicationsForInvoice(invoiceId) {
  const db = getDb();
  return db.prepare(
    `SELECT aa.*, p.payment_date, p.reference, p.payment_method FROM advance_applications aa
     JOIN payments p ON p.id = aa.payment_id WHERE aa.invoice_id = ? ORDER BY aa.applied_at DESC`
  ).all(invoiceId).map((r) => ({ ...r, amount: round2(r.amount) }));
}

/** Applies part or all of one advance payment to one invoice. Atomic; fully traceable. */
function applyToInvoice({ paymentId, invoiceId, amount, notes = null }) {
  const db = getDb();
  const amt = Number(amount);
  if (!(amt > 0)) throw new Error('Amount to apply must be greater than zero.');

  const tx = db.transaction(() => {
    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId);
    if (!payment) throw new Error('Advance payment not found.');
    if (payment.payment_type !== 'Advance') throw new Error('Only an Advance payment can be applied to an invoice.');
    if (payment.booking_id) throw new Error('This advance is already tied to a booking and is applied automatically when that booking is invoiced.');

    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
    if (!invoice) throw new Error('Invoice not found.');
    if (invoice.customer_id !== payment.customer_id) throw new Error('That advance does not belong to this invoice\'s customer.');
    if (invoice.status === 'Cancelled') throw new Error('Cannot apply an advance to a cancelled invoice.');

    const alreadyApplied = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM advance_applications WHERE payment_id = ?').get(paymentId).s;
    const available = payment.amount - alreadyApplied;
    if (amt > available + 0.005) throw new Error(`Only ${round2(available)} is available on this advance.`);
    if (amt > invoice.remaining_amount + 0.005) throw new Error('Amount exceeds what remains on this invoice.');

    db.prepare(
      `INSERT INTO advance_applications (payment_id, invoice_id, amount, notes) VALUES (?, ?, ?, ?)`
    ).run(paymentId, invoiceId, amt, notes);

    const newPaid = invoice.paid_amount + amt;
    const newStatus = deriveStatus(invoice.total, newPaid);
    db.prepare(
      `UPDATE invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(newPaid, invoice.total - newPaid, newStatus, invoice.id);

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Advance Applied', 'invoice', ?, ?)`
    ).run(invoiceId, `${round2(amt)} of advance payment #${paymentId} applied to invoice ${invoice.invoice_number}`);

    return db.prepare('SELECT * FROM advance_applications WHERE payment_id = ? AND invoice_id = ? ORDER BY id DESC LIMIT 1').get(paymentId, invoiceId);
  });

  const row = tx();
  return { id: row.id, amount: round2(row.amount) };
}

/** Reverses one application (frees the advance again, reduces the invoice's paid amount back). */
function reverseApplication(applicationId) {
  const db = getDb();
  const tx = db.transaction(() => {
    const app = db.prepare('SELECT * FROM advance_applications WHERE id = ?').get(applicationId);
    if (!app) throw new Error('Advance application not found.');

    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(app.invoice_id);
    if (invoice) {
      const restoredPaid = invoice.paid_amount - app.amount;
      if (restoredPaid < -0.005) throw new Error('Cannot reverse: the invoice has since been paid down below this amount.');
      const newStatus = invoice.status === 'Cancelled' ? 'Cancelled' : deriveStatus(invoice.total, Math.max(restoredPaid, 0));
      db.prepare(
        `UPDATE invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(Math.max(restoredPaid, 0), invoice.total - Math.max(restoredPaid, 0), newStatus, invoice.id);
    }

    db.prepare('DELETE FROM advance_applications WHERE id = ?').run(applicationId);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Advance Application Reversed', 'invoice', ?, ?)`
    ).run(app.invoice_id, `Advance application #${applicationId} (${round2(app.amount)}) reversed`);
  });
  tx();
  return { success: true };
}

/** Summary for Customer 360 / Ledger: received, used (applied + tied directly), remaining. */
function summary(customerId) {
  const db = getDb();
  const rows = db.prepare(`SELECT * FROM payments WHERE customer_id = ? AND payment_type = 'Advance'`).all(customerId);
  const received = round2(rows.reduce((a, r) => a + r.amount, 0));
  const appliedTotal = rows.reduce((a, r) => {
    const applied = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM advance_applications WHERE payment_id = ?').get(r.id).s;
    return a + applied;
  }, 0);
  // "Used" also counts an advance that was recorded directly against a booking/invoice at receipt time (never had a free balance to apply).
  const tiedAtReceipt = rows.filter((r) => r.invoice_id || r.booking_id).reduce((a, r) => a + r.amount, 0);
  const used = round2(appliedTotal + tiedAtReceipt);
  return { received, used, remaining: round2(received - used) };
}

/**
 * Every standalone advance across every customer (for the Customer Advances
 * sidebar page, master prompt section 44's Finance group) - searchable by
 * customer name, with each advance's available/applied breakdown.
 */
function listAll({ search = '', onlyAvailable = false, page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const where = [`p.payment_type = 'Advance'`, 'p.booking_id IS NULL'];
  const params = {};
  if (search && search.trim()) { where.push('c.full_name LIKE @q'); params.q = `%${search.trim()}%`; }
  const baseWhere = where.join(' AND ');
  const listWhere = onlyAvailable ? `${baseWhere} AND p.amount - COALESCE(a.applied, 0) > 0.005` : baseWhere;
  const from = `FROM payments p JOIN customers c ON c.id = p.customer_id ${APPLIED_JOIN}`;

  // Filtering, counting, totalling and paging all happen in SQL - nothing is
  // loaded just to be sliced in JavaScript afterwards.
  const total = db.prepare(`SELECT COUNT(*) AS c ${from} WHERE ${listWhere}`).get(params).c;
  const totalAvailable = db.prepare(`SELECT COALESCE(SUM(p.amount - COALESCE(a.applied, 0)), 0) AS s ${from} WHERE ${baseWhere}`).get(params).s;
  const size = Number(pageSize) || 20;
  const rows = db.prepare(
    `SELECT p.*, c.full_name AS customer_name, COALESCE(a.applied, 0) AS applied ${from}
     WHERE ${listWhere} ORDER BY p.payment_date DESC, p.id DESC LIMIT @limit OFFSET @offset`
  ).all({ ...params, limit: size, offset: (Math.max(1, Number(page) || 1) - 1) * size }).map(shape);

  return { rows, total, page: Number(page) || 1, pageSize: size, totalAvailable: round2(totalAvailable) };
}

module.exports = { availableAdvances, applicationsForInvoice, applyToInvoice, reverseApplication, summary, listAll };
