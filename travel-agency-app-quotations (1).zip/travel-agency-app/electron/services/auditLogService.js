const { getDb } = require('../../src/database/db');

function list({ search = '', action = '', recordType = '', dateFrom = '', dateTo = '', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push('(a.description LIKE @q OR a.action LIKE @q OR u.full_name LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (action) { conditions.push('a.action = @action'); params.action = action; }
  if (recordType) { conditions.push('a.record_type = @recordType'); params.recordType = recordType; }
  if (dateFrom) { conditions.push('date(a.created_at) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('date(a.created_at) <= date(@dateTo)'); params.dateTo = dateTo; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT a.*, u.full_name AS user_name
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
       ${where}
       ORDER BY a.created_at DESC, a.id DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function listDistinctActions() {
  const db = getDb();
  return db.prepare('SELECT DISTINCT action FROM audit_logs ORDER BY action').all().map((r) => r.action);
}

function listDistinctRecordTypes() {
  const db = getDb();
  return db
    .prepare("SELECT DISTINCT record_type FROM audit_logs WHERE record_type IS NOT NULL ORDER BY record_type")
    .all()
    .map((r) => r.record_type);
}

module.exports = { list, listDistinctActions, listDistinctRecordTypes };
