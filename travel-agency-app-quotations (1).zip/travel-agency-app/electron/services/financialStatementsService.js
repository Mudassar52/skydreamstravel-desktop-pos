const { getDb } = require('../../src/database/db');
const exchangeRates = require('./exchangeRateService');

/**
 * General Ledger, Trial Balance and Balance Sheet (Phase 21).
 *
 * This app never had a posting engine: invoices, payments, supplier bills, expenses and bank/cash movements each
 * live in their own table. Rather than add a second set of "journal" tables that could drift away from those
 * records, the double-entry journal is DERIVED on demand from them. Every business event becomes a balanced
 * journal entry (debits = credits), so the statements always agree with the screens they came from, and a void,
 * a delete or a cancel automatically drops out of the books exactly as it drops out of the screens.
 *
 *   Invoice (not cancelled)        Dr Accounts Receivable            Cr Sales Revenue (+ Tax Payable)
 *   Customer payment               Dr Cash / Bank                    Cr Accounts Receivable
 *   Customer refund                Dr Accounts Receivable            Cr Cash / Bank
 *   Supplier invoice               Dr Cost of Services (+ Input Tax) Cr Accounts Payable
 *   Supplier payment               Dr Accounts Payable               Cr Cash / Bank
 *   Expense                        Dr Expense - <category>           Cr Cash / Bank
 *   Opening balance of an account  Dr Cash / Bank                    Cr Opening Balance Equity
 *   Supplier opening balance       Dr Opening Balance Equity         Cr Accounts Payable
 *   Manual deposit / withdrawal    Dr Cash / Bank | Owner Withdrawals Cr Owner Deposits | Cash / Bank
 *   Transfer between accounts      Dr / Cr each account against a Transfer Clearing account (nets to zero)
 *   Manual Accounting entry        the one-sided line as typed, against Suspense - Manual Entries
 *
 * A payment, supplier payment or expense that has no bank/cash account chosen is posted to "Funds - No Account
 * Selected" so the books still balance and the gap is visible rather than hidden.
 *
 * Currency: every invoice, payment, supplier bill/payment and bank/cash account has a currency (rows from before
 * Phase 21b fall back to their account's currency, else the base). Each event is converted to the base currency ONCE,
 * at the exchange rate in force on the event date, and both sides use that same figure so the entry still balances.
 * A currency with no rate on file is left unconverted and is listed in `warnings` - it is never guessed.
 *
 * Revaluation: at the report date every foreign-currency cash/bank, receivable and payable balance is restated at that
 * date's rate. The difference from what the entries added up to is posted as "Foreign Exchange Gain / (Loss)" (an
 * adjusting entry dated the report date, recomputed on every run, never stored). It therefore includes both the
 * unrealised gain/loss on balances still open AND the realised effect of settling an invoice/bill at a different rate
 * than it was booked at - once a foreign balance is fully settled its native amount is zero, so whatever base-currency
 * residue the two rates left behind lands in this account and nowhere else.
 *
 * Year-end closes (Period Close screen) add, on each close date, a closing entry that moves every revenue and expense
 * balance into Retained Earnings; the FX revaluation is restated at each close date first, so after a close only the
 * movement since then is counted. A payment/refund/supplier payment/transfer whose two sides are in different
 * currencies (the customer paid PKR against a USD invoice) posts each side in its own currency and the exchange
 * difference to Foreign Exchange Gain / (Loss).
 *
 * Revenue/cost are recognised when invoiced (accrual); expenses when recorded. Agent commissions are expenses
 * recorded when paid, so they follow the same rule as the Profit report.
 */

const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

const ACC = {
  NO_ACCOUNT: { code: '1290', name: 'Funds - No Account Selected', type: 'Asset' },
  TRANSFER: { code: '1295', name: 'Transfer Clearing', type: 'Asset' },
  AR: { code: '1300', name: 'Accounts Receivable (Customers)', type: 'Asset' },
  INPUT_TAX: { code: '1500', name: 'Input Tax Recoverable', type: 'Asset' },
  AP: { code: '2000', name: 'Accounts Payable (Suppliers)', type: 'Liability' },
  TAX: { code: '2100', name: 'Tax Payable', type: 'Liability' },
  OPENING: { code: '3000', name: 'Opening Balance Equity', type: 'Equity' },
  DEPOSITS: { code: '3100', name: 'Owner Deposits & Other Receipts', type: 'Equity' },
  WITHDRAWALS: { code: '3200', name: 'Owner Withdrawals', type: 'Equity' },
  SUSPENSE: { code: '3900', name: 'Suspense - Manual Entries', type: 'Equity' },
  RETAINED: { code: '3300', name: 'Retained Earnings', type: 'Equity' },
  SALES: { code: '4000', name: 'Sales Revenue', type: 'Revenue' },
  FX: { code: '4900', name: 'Foreign Exchange Gain / (Loss)', type: 'Revenue' },
  COST: { code: '5000', name: 'Cost of Services (Supplier Bills)', type: 'Expense' }
};

const TYPE_ORDER = { Asset: 1, Liability: 2, Equity: 3, Revenue: 4, Expense: 5, Manual: 6 };
const DEBIT_NORMAL = new Set(['Asset', 'Expense']);

function dateOnly(v) { return String(v || '').slice(0, 10); }

function cashAccount(type, a) {
  return { code: `${type === 'Bank' ? '1200' : '1100'}-${a.id}`, name: `${type === 'Bank' ? 'Bank' : 'Cash'} - ${a.account_name}`, type: 'Asset', native: true, currency: a.currency };
}

/**
 * Builds the whole journal up to `dateTo` (inclusive, optional). Returns { lines, accounts, warnings, base }.
 * Each line: { seq, date, source, ref, description, code, name, type, debit, credit, party, nativeDebit, nativeCredit }.
 */
function buildJournal({ dateTo = null, revalue = false } = {}) {
  const db = getDb();
  const base = exchangeRates.getBaseCurrency();
  const lines = [];
  const accounts = new Map();
  const missing = new Map(); // "USD>PKR" -> count
  let seq = 0;

  const bankById = new Map(db.prepare('SELECT * FROM bank_accounts').all().map((a) => [a.id, a]));
  const cashById = new Map(db.prepare('SELECT * FROM cash_accounts').all().map((a) => [a.id, a]));
  const catById = new Map(db.prepare('SELECT id, name FROM expense_categories').all().map((c) => [c.id, c.name]));
  const customerName = new Map(db.prepare('SELECT id, full_name FROM customers').all().map((c) => [c.id, c.full_name]));
  const supplierName = new Map(db.prepare('SELECT id, name FROM suppliers').all().map((s) => [s.id, s.name]));

  const rateCache = new Map();
  function factor(cur, date) {
    const c = String(cur || base).toUpperCase();
    if (c === base) return 1;
    const key = `${c}|${date}`;
    if (rateCache.has(key)) return rateCache.get(key);
    const r = exchangeRates.getRate(c, base, date);
    if (!r) {
      const k = `${c}>${base}`;
      missing.set(k, (missing.get(k) || 0) + 1);
      rateCache.set(key, 1);
      return 1;
    }
    rateCache.set(key, r.rate);
    return r.rate;
  }

  function acctOf(type, id) {
    if (!type || !id) return null;
    const a = type === 'Bank' ? bankById.get(id) : cashById.get(id);
    return a ? { type, row: a, acc: cashAccount(type, a) } : null;
  }

  function reg(acc) {
    if (!accounts.has(acc.code)) accounts.set(acc.code, { code: acc.code, name: acc.name, type: acc.type });
  }

  /**
   * entry(): legs = [{ acc, dr, cr, party, cur? }] in the leg's own currency (default: the event's); each leg is converted
   * to the base currency at the event date's rate, once. An event whose legs are in different currencies (a payment in
   * PKR that settles a USD invoice) will not add up after conversion by exactly the exchange difference, so with
   * `fxPlug` that difference is posted to Foreign Exchange Gain / (Loss) and the entry still balances.
   */
  function entry({ date, source, ref, description, currency, legs, fxPlug = false }) {
    const d = dateOnly(date);
    if (dateTo && d > dateTo) return;
    seq += 1;
    const made = [];
    for (const leg of legs) {
      if (!(leg.dr || leg.cr)) continue;
      const cur = String(leg.cur || currency || base).toUpperCase();
      const f = factor(cur, d);
      reg(leg.acc);
      made.push({
        seq, date: d, source, ref, description,
        code: leg.acc.code, name: leg.acc.name, type: leg.acc.type,
        debit: r2((leg.dr || 0) * f), credit: r2((leg.cr || 0) * f),
        party: leg.party || null,
        cur,
        rawDebit: leg.dr || 0,
        rawCredit: leg.cr || 0,
        nativeDebit: leg.acc.native ? (leg.dr || 0) : 0,
        nativeCredit: leg.acc.native ? (leg.cr || 0) : 0
      });
    }
    if (fxPlug) {
      const imb = r2(made.reduce((a, l) => a + l.debit - l.credit, 0));
      if (Math.abs(imb) >= 0.005) {
        reg(ACC.FX);
        made.push({ seq, date: d, source, ref, description, code: ACC.FX.code, name: ACC.FX.name, type: ACC.FX.type, debit: imb < 0 ? -imb : 0, credit: imb > 0 ? imb : 0, party: null, cur: base, rawDebit: 0, rawCredit: 0, nativeDebit: 0, nativeCredit: 0 });
      }
    }
    lines.push(...made);
  }

  const cashLeg = (a, dr, cr) => (a ? { acc: a.acc, dr, cr } : { acc: ACC.NO_ACCOUNT, dr, cr });
  const curOf = (a, fallback) => (a ? a.row.currency || base : fallback || base);

  // 1. Opening balances of bank/cash accounts.
  for (const [type, map] of [['Bank', bankById], ['Cash', cashById]]) {
    for (const row of map.values()) {
      const amt = Number(row.opening_balance || 0);
      if (!amt) continue;
      const acc = cashAccount(type, row);
      entry({
        date: row.created_at, source: 'Opening Balance', ref: acc.name, description: 'Opening balance',
        currency: row.currency || base,
        legs: [{ acc, dr: amt > 0 ? amt : 0, cr: amt < 0 ? -amt : 0 }, { acc: ACC.OPENING, dr: amt < 0 ? -amt : 0, cr: amt > 0 ? amt : 0 }]
      });
    }
  }

  // 2. Customer invoices (cancelled ones net to zero in the customer ledger, so they are left out).
  for (const inv of db.prepare("SELECT * FROM invoices WHERE status <> 'Cancelled'").all()) {
    const total = Number(inv.total || 0);
    const tax = Math.min(Number(inv.tax || 0), total);
    const party = { type: 'customer', id: inv.customer_id, name: customerName.get(inv.customer_id) || `Customer #${inv.customer_id}` };
    entry({
      date: inv.invoice_date, source: 'Invoice', ref: inv.invoice_number, description: `Invoice ${inv.invoice_number} - ${party.name}`,
      currency: inv.currency || base,
      legs: [{ acc: ACC.AR, dr: total, cr: 0, party }, { acc: ACC.SALES, dr: 0, cr: total - tax }, { acc: ACC.TAX, dr: 0, cr: tax }]
    });
  }

  // 3. Customer payments and refunds.
  for (const p of db.prepare('SELECT * FROM payments').all()) {
    const a = acctOf(p.account_type, p.account_id);
    const amt = Number(p.amount || 0);
    const refund = p.payment_type === 'Refund';
    const party = { type: 'customer', id: p.customer_id, name: customerName.get(p.customer_id) || `Customer #${p.customer_id}` };
    // received_amount: what really moved through the account when its currency differs from the invoice/booking's.
    const cash = Number(p.received_amount || 0) > 0 ? Number(p.received_amount) : amt;
    const cashCur = p.received_amount ? (a ? a.row.currency || base : base) : null;
    const cashLegFor = (dr, cr) => ({ ...cashLeg(a, dr, cr), cur: cashCur || undefined });
    entry({
      date: p.payment_date, source: refund ? 'Customer Refund' : 'Customer Payment', ref: `PAY-${String(p.id).padStart(5, '0')}`,
      description: `${refund ? 'Refund to' : 'Payment from'} ${party.name}${p.reference ? ` (${p.reference})` : ''}`,
      currency: p.currency || curOf(a), fxPlug: !!p.received_amount,
      legs: refund
        ? [{ acc: ACC.AR, dr: amt, cr: 0, party }, cashLegFor(0, cash)]
        : [cashLegFor(cash, 0), { acc: ACC.AR, dr: 0, cr: amt, party }]
    });
  }

  // 3b. Supplier opening balances (what the agency already owed a supplier, or had prepaid, when the supplier was added).
  for (const sup of db.prepare('SELECT id, name, currency, opening_balance, created_at FROM suppliers WHERE opening_balance <> 0').all()) {
    const amt = Number(sup.opening_balance || 0);
    const party = { type: 'supplier', id: sup.id, name: sup.name };
    entry({
      date: sup.created_at, source: 'Opening Balance', ref: sup.name, description: `Opening balance - ${sup.name}`, currency: sup.currency || base,
      legs: [{ acc: ACC.OPENING, dr: amt > 0 ? amt : 0, cr: amt < 0 ? -amt : 0 }, { acc: ACC.AP, dr: amt < 0 ? -amt : 0, cr: amt > 0 ? amt : 0, party }]
    });
  }

  // 4. Supplier invoices.
  for (const si of db.prepare('SELECT * FROM supplier_invoices').all()) {
    const total = Number(si.total || 0);
    const tax = Math.min(Number(si.tax || 0), total);
    const party = { type: 'supplier', id: si.supplier_id, name: supplierName.get(si.supplier_id) || `Supplier #${si.supplier_id}` };
    entry({
      date: si.invoice_date, source: 'Supplier Invoice', ref: si.invoice_number, description: `Supplier invoice ${si.invoice_number} - ${party.name}`,
      currency: si.currency || base,
      legs: [{ acc: ACC.COST, dr: total - tax, cr: 0 }, { acc: ACC.INPUT_TAX, dr: tax, cr: 0 }, { acc: ACC.AP, dr: 0, cr: total, party }]
    });
  }

  // 5. Supplier payments.
  for (const sp of db.prepare('SELECT * FROM supplier_payments').all()) {
    const a = acctOf(sp.account_type, sp.account_id);
    const amt = Number(sp.amount || 0);
    const party = { type: 'supplier', id: sp.supplier_id, name: supplierName.get(sp.supplier_id) || `Supplier #${sp.supplier_id}` };
    entry({
      date: sp.payment_date, source: 'Supplier Payment', ref: `SPAY-${String(sp.id).padStart(5, '0')}`,
      description: `Payment to ${party.name}${sp.reference ? ` (${sp.reference})` : ''}`,
      currency: sp.currency || curOf(a), fxPlug: !!sp.account_amount,
      legs: sp.account_amount
        ? [{ acc: ACC.AP, dr: amt, cr: 0, party }, { ...cashLeg(a, 0, Number(sp.account_amount)), cur: a ? a.row.currency || base : base }]
        : [{ acc: ACC.AP, dr: amt, cr: 0, party }, cashLeg(a, 0, amt)]
    });
  }

  // 6. Expenses.
  for (const e of db.prepare('SELECT * FROM expenses').all()) {
    const a = acctOf(e.account_type, e.account_id);
    const amt = Number(e.amount || 0);
    const catName = e.category_id ? (catById.get(e.category_id) || `Category #${e.category_id}`) : 'Uncategorised';
    const acc = { code: e.category_id ? `6${String(e.category_id).padStart(3, '0')}` : '6999', name: `Expense - ${catName}`, type: 'Expense' };
    entry({
      date: e.expense_date, source: 'Expense', ref: `EXP-${String(e.id).padStart(5, '0')}`, description: e.description || `Expense - ${catName}`,
      currency: curOf(a),
      legs: [{ acc, dr: amt, cr: 0 }, cashLeg(a, 0, amt)]
    });
  }

  // 7. Manual deposits / withdrawals / transfers on bank & cash accounts. Customer/supplier payments, expenses and
  // refunds also write account_transactions rows, but they are already posted above from their own records.
  // A transfer's two legs share a reference, so they post as ONE entry (Dr destination, Cr source) - in two currencies
  // when the accounts differ, with the exchange difference going to Foreign Exchange Gain / (Loss). A leg whose partner
  // is missing (older data) falls back to a Transfer Clearing balance.
  const txns = db.prepare("SELECT * FROM account_transactions WHERE transaction_type IN ('Deposit','Withdrawal','Transfer') ORDER BY id").all();
  const pairs = new Map();
  for (const t of txns) {
    if (t.transaction_type === 'Transfer' && t.reference_type === 'transfer' && t.reference_id) {
      const e = pairs.get(t.reference_id) || {};
      e[t.direction === 'In' ? 'in' : 'out'] = t;
      pairs.set(t.reference_id, e);
    }
  }
  const paired = new Set();
  for (const e of pairs.values()) {
    if (!e.in || !e.out) continue;
    const ai = acctOf(e.in.account_type, e.in.account_id);
    const ao = acctOf(e.out.account_type, e.out.account_id);
    if (!ai || !ao) continue;
    paired.add(e.in.id); paired.add(e.out.id);
    entry({
      date: e.out.transaction_date, source: 'Transfer', ref: `${ao.acc.name} → ${ai.acc.name}`, description: e.out.description || 'Transfer',
      currency: base, fxPlug: true,
      legs: [{ acc: ai.acc, dr: Number(e.in.amount), cr: 0, cur: ai.row.currency || base }, { acc: ao.acc, dr: 0, cr: Number(e.out.amount), cur: ao.row.currency || base }]
    });
  }
  for (const t of txns) {
    if (paired.has(t.id)) continue;
    const a = acctOf(t.account_type, t.account_id);
    if (!a) continue;
    const amt = Number(t.amount || 0);
    const inflow = t.direction === 'In';
    const contra = t.transaction_type === 'Transfer' ? ACC.TRANSFER : (inflow ? ACC.DEPOSITS : ACC.WITHDRAWALS);
    entry({
      date: t.transaction_date, source: t.transaction_type, ref: a.acc.name, description: t.description || t.transaction_type,
      currency: a.row.currency || base,
      legs: inflow
        ? [{ acc: a.acc, dr: amt, cr: 0 }, { acc: contra, dr: 0, cr: amt }]
        : [{ acc: contra, dr: amt, cr: 0 }, { acc: a.acc, dr: 0, cr: amt }]
    });
  }

  // 8. Manual Accounting entries (one-sided by design) against Suspense, so the books still balance.
  for (const m of db.prepare('SELECT * FROM accounting_entries').all()) {
    const acc = { code: `M-${m.account}`, name: m.account, type: 'Manual' };
    entry({
      date: m.entry_date, source: m.is_reversal ? 'Manual Entry (reversal)' : 'Manual Entry', ref: `ACC-${m.id}`, description: m.reference || m.account,
      currency: base,
      legs: [{ acc, dr: Number(m.debit || 0), cr: Number(m.credit || 0) }, { acc: ACC.SUSPENSE, dr: Number(m.credit || 0), cr: Number(m.debit || 0) }]
    });
  }

  const reportDate = dateTo || db.prepare("SELECT date('now') AS d").get().d;
  const revalWarnings = [];
  const isMonetary = (code) => code.startsWith('1100-') || code.startsWith('1200-') || code === '1290' || code === '1300' || code === '2000';

  /** Restates foreign-currency monetary balances as at `at` (only lines dated on or before it count). Earlier adjusting
   *  lines are already in `lines`, so each run posts only the INCREMENT since the previous one. */
  function revalAt(at) {
    const groups = new Map();
    for (const l of lines) {
      if (l.date > at || !isMonetary(l.code) || l.cur === base) continue;
      const key = `${l.code}|${l.party ? l.party.id : ''}|${l.cur}`;
      const g = groups.get(key) || { code: l.code, name: l.name, type: l.type, party: l.party, cur: l.cur, native: 0, book: 0 };
      g.native += l.rawDebit - l.rawCredit;
      g.book += l.debit - l.credit;
      groups.set(key, g);
    }
    for (const g of groups.values()) {
      const r = exchangeRates.getRate(g.cur, base, at);
      if (!r) {
        const msg = `No exchange rate on file for ${g.cur} to ${base} on ${at}: ${g.cur} balances could not be revalued.`;
        if (!revalWarnings.includes(msg)) revalWarnings.push(msg);
        continue;
      }
      const adj = r2(r2(g.native * r.rate) - r2(g.book));
      if (Math.abs(adj) < 0.005) continue;
      reg(ACC.FX);
      seq += 1;
      const common = { seq, date: at, source: 'FX Revaluation', ref: 'FX-REVAL', description: `Revalue ${g.cur} ${g.native.toFixed(2)} at ${Number(r.rate.toPrecision(8))}`, cur: g.cur, rawDebit: 0, rawCredit: 0, nativeDebit: 0, nativeCredit: 0 };
      lines.push({ ...common, code: g.code, name: g.name, type: g.type, debit: adj > 0 ? adj : 0, credit: adj < 0 ? -adj : 0, party: g.party || null });
      lines.push({ ...common, code: ACC.FX.code, name: ACC.FX.name, type: ACC.FX.type, debit: adj < 0 ? -adj : 0, credit: adj > 0 ? adj : 0, party: null });
    }
  }

  /** Year-end closing entry at `at`: every revenue/expense balance is zeroed into Retained Earnings. */
  function closeAt(at) {
    const net = new Map();
    for (const l of lines) {
      if (l.date > at || (l.type !== 'Revenue' && l.type !== 'Expense')) continue;
      const n = net.get(l.code) || { code: l.code, name: l.name, type: l.type, v: 0 };
      n.v += l.debit - l.credit;
      net.set(l.code, n);
    }
    let any = false;
    for (const n of net.values()) {
      const v = r2(n.v);
      if (Math.abs(v) < 0.005) continue;
      if (!any) { seq += 1; reg(ACC.RETAINED); any = true; }
      const common = { seq, date: at, source: 'Year-End Close', ref: `CLOSE-${at}`, description: `Closing entry - books closed through ${at}`, cur: base, rawDebit: 0, rawCredit: 0, nativeDebit: 0, nativeCredit: 0, party: null };
      lines.push({ ...common, code: n.code, name: n.name, type: n.type, debit: v < 0 ? -v : 0, credit: v > 0 ? v : 0 });
      lines.push({ ...common, code: ACC.RETAINED.code, name: ACC.RETAINED.name, type: ACC.RETAINED.type, debit: v > 0 ? v : 0, credit: v < 0 ? -v : 0 });
    }
  }

  // Closes up to the report date first, in order (revalue then close each), then the report-date revaluation.
  const closes = revalue ? require('./periodLockService').closeDates(db).filter((c) => c <= reportDate) : [];
  for (const c of closes) { revalAt(c); closeAt(c); }
  if (revalue) revalAt(reportDate);

  lines.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.seq - b.seq));

  const warnings = [];
  for (const [k, n] of missing) {
    const [from, to] = k.split('>');
    warnings.push(`No exchange rate on file for ${from} to ${to}: ${n} transaction${n === 1 ? '' : 's'} in ${from} are included at face value, unconverted. Add a rate under Finance > Exchange Rates.`);
  }
  warnings.push(...revalWarnings);
  return { lines, accounts, warnings, base };
}

function sortAccounts(list) {
  return list.sort((a, b) => (TYPE_ORDER[a.type] - TYPE_ORDER[b.type]) || (a.code < b.code ? -1 : a.code > b.code ? 1 : 0));
}

const money = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ------------------------------------------------------------------ General Ledger
function listAccounts() {
  const { accounts } = buildJournal({ revalue: true });
  return sortAccounts([...accounts.values()]);
}

/**
 * One account (or every account) with an opening balance, each posting with a running balance, and a closing
 * balance. Balance sign follows the account's normal side (assets/expenses: debit-positive; others: credit-positive).
 */
function generalLedger({ accountCode = null, dateFrom = null, dateTo = null, maxLines = 5000 } = {}) {
  const j = buildJournal({ dateTo, revalue: true });
  const wanted = sortAccounts([...j.accounts.values()]).filter((a) => !accountCode || a.code === accountCode);
  if (accountCode && !wanted.length) {
    const known = listAccounts().some((a) => a.code === accountCode);
    if (!known) throw new Error('Account not found.');
  }
  let emitted = 0;
  let truncated = false;
  const sections = [];
  for (const acc of wanted) {
    const sign = DEBIT_NORMAL.has(acc.type) ? 1 : -1;
    let opening = 0;
    let running = 0;
    let dr = 0;
    let cr = 0;
    const rows = [];
    for (const l of j.lines) {
      if (l.code !== acc.code) continue;
      const net = (l.debit - l.credit) * sign;
      if (dateFrom && l.date < dateFrom) { opening += net; running += net; continue; }
      running += net;
      dr += l.debit; cr += l.credit;
      if (emitted < maxLines) {
        rows.push({ date: l.date, source: l.source, ref: l.ref, description: l.description, party: l.party ? l.party.name : '', debit: l.debit, credit: l.credit, balance: r2(running) });
        emitted += 1;
      } else truncated = true;
    }
    if (!rows.length && !opening && !(dr || cr)) continue;
    sections.push({ account: acc, opening: r2(opening), total_debit: r2(dr), total_credit: r2(cr), closing: r2(running), normal_side: sign === 1 ? 'Debit' : 'Credit', rows });
  }
  const flat = [];
  for (const s of sections) {
    flat.push({ date: '', account: `${s.account.code}  ${s.account.name}`, source: 'Opening balance', ref: '', description: '', debit: '', credit: '', balance: money(s.opening) });
    for (const r of s.rows) flat.push({ date: r.date, account: `${s.account.code}  ${s.account.name}`, source: r.source, ref: r.ref, description: r.description, debit: r.debit ? money(r.debit) : '', credit: r.credit ? money(r.credit) : '', balance: money(r.balance) });
    flat.push({ date: '', account: `${s.account.code}  ${s.account.name}`, source: 'Closing balance', ref: '', description: '', debit: money(s.total_debit), credit: money(s.total_credit), balance: money(s.closing) });
  }
  return {
    base_currency: j.base, dateFrom, dateTo, accountCode, sections, truncated, warnings: j.warnings,
    export: {
      title: `General Ledger${accountCode ? ` - ${accountCode}` : ''} (${j.base})${dateFrom || dateTo ? ` ${dateFrom || '...'} to ${dateTo || '...'}` : ''}`,
      columns: [
        { key: 'date', label: 'Date' }, { key: 'account', label: 'Account' }, { key: 'source', label: 'Source' }, { key: 'ref', label: 'Reference' },
        { key: 'description', label: 'Description' }, { key: 'debit', label: 'Debit' }, { key: 'credit', label: 'Credit' }, { key: 'balance', label: 'Balance' }
      ],
      rows: flat
    }
  };
}

// ------------------------------------------------------------------ Trial Balance
function totalsByAccount(lines) {
  const m = new Map();
  for (const l of lines) {
    const t = m.get(l.code) || { code: l.code, name: l.name, type: l.type, debit: 0, credit: 0 };
    t.debit += l.debit; t.credit += l.credit;
    m.set(l.code, t);
  }
  return m;
}

function trialBalance({ asOf = null, includeZero = false } = {}) {
  const j = buildJournal({ dateTo: asOf, revalue: true });
  const rows = sortAccounts([...totalsByAccount(j.lines).values()]).map((t) => {
    const net = r2(t.debit - t.credit);
    return { code: t.code, name: t.name, type: t.type, total_debit: r2(t.debit), total_credit: r2(t.credit), debit: net > 0 ? net : 0, credit: net < 0 ? -net : 0 };
  }).filter((r) => includeZero || r.debit || r.credit || r.total_debit || r.total_credit);
  const totalDebit = r2(rows.reduce((a, r) => a + r.debit, 0));
  const totalCredit = r2(rows.reduce((a, r) => a + r.credit, 0));
  const difference = r2(totalDebit - totalCredit);
  return {
    base_currency: j.base, asOf, rows, total_debit: totalDebit, total_credit: totalCredit, difference, balanced: Math.abs(difference) < 0.005,
    warnings: j.warnings,
    export: {
      title: `Trial Balance (${j.base}) as at ${asOf || 'today'}`,
      columns: [{ key: 'code', label: 'Code' }, { key: 'name', label: 'Account' }, { key: 'type', label: 'Type' }, { key: 'debit', label: 'Debit' }, { key: 'credit', label: 'Credit' }],
      rows: [
        ...rows.map((r) => ({ code: r.code, name: r.name, type: r.type, debit: r.debit ? money(r.debit) : '', credit: r.credit ? money(r.credit) : '' })),
        { code: '', name: 'TOTAL', type: '', debit: money(totalDebit), credit: money(totalCredit) }
      ]
    }
  };
}

// ------------------------------------------------------------------ Balance Sheet
function balanceSheet({ asOf = null } = {}) {
  const j = buildJournal({ dateTo: asOf, revalue: true });
  const closesBefore = j.lines.some((l) => l.source === 'Year-End Close');
  const tot = totalsByAccount(j.lines);
  const net = (code) => { const t = tot.get(code); return t ? t.debit - t.credit : 0; };

  // Per-party balances, so a customer who has paid more than they were invoiced (an advance) is shown as a
  // liability and a supplier who has been paid more than billed (a prepayment) is shown as an asset - rather than
  // letting credit balances quietly shrink receivables and debit balances shrink payables.
  const cust = new Map();
  const supp = new Map();
  for (const l of j.lines) {
    if (!l.party) continue;
    const m = l.party.type === 'customer' ? cust : supp;
    const e = m.get(l.party.id) || { name: l.party.name, net: 0 };
    e.net += l.debit - l.credit; // customers: debit-positive. suppliers: negate below.
    m.set(l.party.id, e);
  }
  let receivables = 0; let customerAdvances = 0; let payables = 0; let supplierPrepay = 0;
  for (const e of cust.values()) { if (e.net > 0.004) receivables += e.net; else if (e.net < -0.004) customerAdvances += -e.net; }
  for (const e of supp.values()) { const owed = -e.net; if (owed > 0.004) payables += owed; else if (owed < -0.004) supplierPrepay += -owed; }

  const assets = []; const liabilities = []; const equity = [];
  const add = (arr, label, amount, extra = {}) => { const a = r2(amount); if (Math.abs(a) >= 0.005 || extra.always) arr.push({ label, amount: a, ...extra }); };

  const cashRows = [];
  for (const t of sortAccounts([...tot.values()])) {
    if (t.code.startsWith('1100-') || t.code.startsWith('1200-')) cashRows.push({ label: t.name, amount: r2(t.debit - t.credit) });
  }
  const cashTotal = r2(cashRows.reduce((a, r) => a + r.amount, 0));
  for (const r of cashRows) { if (r.amount >= 0) add(assets, r.label, r.amount, { group: 'Cash & Bank' }); else add(liabilities, `${r.label} (overdrawn)`, -r.amount, { group: 'Overdrawn Accounts' }); }
  const noAcct = net('1290');
  if (noAcct >= 0) add(assets, ACC.NO_ACCOUNT.name, noAcct, { group: 'Cash & Bank' }); else add(liabilities, ACC.NO_ACCOUNT.name, -noAcct, { group: 'Other Liabilities' });
  const clearing = net('1295');
  if (clearing >= 0) add(assets, ACC.TRANSFER.name, clearing, { group: 'Cash & Bank' }); else add(liabilities, ACC.TRANSFER.name, -clearing, { group: 'Other Liabilities' });
  add(assets, 'Accounts Receivable (Customers)', receivables, { group: 'Receivables' });
  add(assets, 'Supplier Advances & Prepayments', supplierPrepay, { group: 'Receivables' });
  const inTax = net('1500');
  if (inTax >= 0) add(assets, ACC.INPUT_TAX.name, inTax, { group: 'Receivables' }); else add(liabilities, ACC.INPUT_TAX.name, -inTax, { group: 'Taxes' });

  add(liabilities, 'Accounts Payable (Suppliers)', payables, { group: 'Payables' });
  add(liabilities, 'Customer Advances & Credit Balances', customerAdvances, { group: 'Payables' });
  const taxPay = -net('2100');
  if (taxPay >= 0) add(liabilities, ACC.TAX.name, taxPay, { group: 'Taxes' }); else add(assets, ACC.TAX.name, -taxPay, { group: 'Receivables' });

  add(equity, ACC.OPENING.name, -net('3000'), { group: 'Capital' });
  add(equity, ACC.DEPOSITS.name, -net('3100'), { group: 'Capital' });
  add(equity, ACC.WITHDRAWALS.name, -net('3200'), { group: 'Capital' });
  let manual = -net('3900');
  for (const t of tot.values()) if (t.type === 'Manual') manual += -(t.debit - t.credit);
  add(equity, 'Manual Accounting Entries (net)', manual, { group: 'Capital' });
  add(equity, ACC.RETAINED.name, -net('3300'), { group: 'Earnings' });

  let revenue = 0; let expenses = 0;
  for (const t of tot.values()) { if (t.type === 'Revenue') revenue += t.credit - t.debit; if (t.type === 'Expense') expenses += t.debit - t.credit; }
  const profit = r2(revenue - expenses);
  add(equity, closesBefore ? 'Profit / (Loss) since last year-end close' : 'Profit / (Loss) to date', profit, { group: 'Earnings', always: true });

  const sum = (arr) => r2(arr.reduce((a, r) => a + r.amount, 0));
  const totalAssets = sum(assets); const totalLiabilities = sum(liabilities); const totalEquity = sum(equity);
  const difference = r2(totalAssets - totalLiabilities - totalEquity);

  const flat = [];
  const section = (title, arr, total) => {
    flat.push({ section: title, label: '', amount: '' });
    let g = null;
    for (const r of arr) { if (r.group !== g) { g = r.group; } flat.push({ section: '', label: `${r.group ? `${r.group}: ` : ''}${r.label}`, amount: money(r.amount) }); }
    flat.push({ section: '', label: `Total ${title}`, amount: money(total) });
  };
  section('Assets', assets, totalAssets);
  section('Liabilities', liabilities, totalLiabilities);
  section('Equity', equity, totalEquity);
  flat.push({ section: '', label: 'Total Liabilities + Equity', amount: money(r2(totalLiabilities + totalEquity)) });

  return {
    base_currency: j.base, asOf, assets, liabilities, equity,
    total_assets: totalAssets, total_liabilities: totalLiabilities, total_equity: totalEquity,
    total_liabilities_and_equity: r2(totalLiabilities + totalEquity), difference, balanced: Math.abs(difference) < 0.005,
    cash_total: cashTotal, profit_to_date: profit, warnings: j.warnings,
    export: { title: `Balance Sheet (${j.base}) as at ${asOf || 'today'}`, columns: [{ key: 'section', label: 'Section' }, { key: 'label', label: 'Item' }, { key: 'amount', label: `Amount (${j.base})` }], rows: flat }
  };
}

/**
 * Cross-check: for every bank/cash account, the balance the General Ledger arrives at (in the account's own
 * currency) versus the balance stored on the account. A difference means something moved the account without
 * going through a normal record - for example an expense whose amount was edited after it was paid.
 */
function reconcileCashAndBank() {
  const db = getDb();
  const j = buildJournal();
  const native = new Map();
  for (const l of j.lines) {
    if (!(l.code.startsWith('1100-') || l.code.startsWith('1200-'))) continue;
    native.set(l.code, (native.get(l.code) || 0) + l.nativeDebit - l.nativeCredit);
  }
  const out = [];
  for (const [type, table] of [['Bank', 'bank_accounts'], ['Cash', 'cash_accounts']]) {
    for (const a of db.prepare(`SELECT * FROM ${table}`).all()) {
      const code = `${type === 'Bank' ? '1200' : '1100'}-${a.id}`;
      const gl = r2(native.get(code) || 0);
      const stored = r2(a.current_balance);
      out.push({ account: `${type} - ${a.account_name}`, currency: a.currency, gl_balance: gl, account_balance: stored, difference: r2(gl - stored), matches: Math.abs(gl - stored) < 0.005 });
    }
  }
  return out;
}

module.exports = { ACC, buildJournal, listAccounts, generalLedger, trialBalance, balanceSheet, reconcileCashAndBank };
