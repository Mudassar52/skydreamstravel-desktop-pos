const { dialog, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const { getDb } = require('../../src/database/db');

const DOCUMENT_TYPES = ['CNIC', 'Passport', 'Visa', 'Flight Ticket', 'Hotel Voucher', 'Payment Receipt', 'Other'];

let storageDir = null;

/**
 * Files are copied into the app's own per-user storage directory (not
 * referenced in place) so the agency's documents survive the source file
 * being moved, renamed, or deleted elsewhere, and so Backup & Restore
 * (Phase 14) can back up one folder and get everything.
 */
function initStorage(userDataPath) {
  storageDir = path.join(userDataPath, 'storage', 'documents');
  fs.mkdirSync(storageDir, { recursive: true });
}

function assertStorageReady() {
  if (!storageDir) throw new Error('Document storage has not been initialized.');
}

function uniqueDestPath(originalName) {
  const ext = path.extname(originalName);
  const base = path.basename(originalName, ext);
  let candidate = path.join(storageDir, `${base}${ext}`);
  let counter = 1;
  while (fs.existsSync(candidate)) {
    candidate = path.join(storageDir, `${base} (${counter})${ext}`);
    counter += 1;
  }
  return candidate;
}

/**
 * Opens the native "choose file(s)" dialog, copies each selected file into
 * storage, and creates one document row per file.
 */
async function upload({ customerId, bookingId, documentType, notes }) {
  assertStorageReady();
  if (!customerId && !bookingId) {
    throw new Error('A document must be attached to a customer or a booking.');
  }

  const result = await dialog.showOpenDialog({
    title: 'Select document(s) to upload',
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled || result.filePaths.length === 0) return { uploaded: [] };

  const db = getDb();
  const insert = db.prepare(
    `INSERT INTO documents (customer_id, booking_id, document_type, file_name, file_path, notes)
     VALUES (?, ?, ?, ?, ?, ?)`
  );

  const uploaded = [];
  for (const sourcePath of result.filePaths) {
    const originalName = path.basename(sourcePath);
    const destPath = uniqueDestPath(originalName);
    fs.copyFileSync(sourcePath, destPath);
    const insertResult = insert.run(
      customerId || null,
      bookingId || null,
      documentType || 'Other',
      originalName,
      destPath,
      notes || null
    );
    uploaded.push({ id: insertResult.lastInsertRowid, file_name: originalName });
  }

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, description) VALUES ('Document Uploaded', 'document', ?)`
  ).run(`${uploaded.length} file(s) uploaded`);

  return { uploaded };
}

function list({ customerId = null, bookingId = null, documentType = null, search = '', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (customerId) { conditions.push('d.customer_id = @customerId'); params.customerId = customerId; }
  if (bookingId) { conditions.push('d.booking_id = @bookingId'); params.bookingId = bookingId; }
  if (documentType && documentType !== 'All') { conditions.push('d.document_type = @documentType'); params.documentType = documentType; }
  if (search && search.trim()) {
    conditions.push('(d.file_name LIKE @q OR d.document_type LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM documents d ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT d.*, c.full_name AS customer_name, b.booking_code
       FROM documents d
       LEFT JOIN customers c ON c.id = d.customer_id
       LEFT JOIN bookings b ON b.id = d.booking_id
       ${where}
       ORDER BY d.uploaded_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM documents WHERE id = ?').get(id);
  if (!row) throw new Error('Document not found.');
  return row;
}

/** Opens the file with the OS default application - doubles as preview and view. */
function openFile(id) {
  const doc = get(id);
  if (!fs.existsSync(doc.file_path)) throw new Error('The file for this document could not be found on disk.');
  shell.openPath(doc.file_path);
  return { success: true };
}

async function downloadAs(id) {
  const doc = get(id);
  if (!fs.existsSync(doc.file_path)) throw new Error('The file for this document could not be found on disk.');
  const result = await dialog.showSaveDialog({ title: 'Save Document As', defaultPath: doc.file_name });
  if (result.canceled || !result.filePath) return { saved: false };
  fs.copyFileSync(doc.file_path, result.filePath);
  return { saved: true, filePath: result.filePath };
}

function rename(id, newName) {
  if (!newName || !newName.trim()) throw new Error('File name cannot be empty.');
  const db = getDb();
  const doc = get(id);

  const oldExt = path.extname(doc.file_path);
  const newExt = path.extname(newName);
  const finalName = newExt ? newName : `${newName}${oldExt}`;
  const newPath = path.join(path.dirname(doc.file_path), finalName);

  if (newPath !== doc.file_path && fs.existsSync(newPath)) {
    throw new Error('A file with that name already exists in storage.');
  }
  fs.renameSync(doc.file_path, newPath);
  db.prepare('UPDATE documents SET file_name = ?, file_path = ? WHERE id = ?').run(finalName, newPath, id);
  return { success: true };
}

function remove(id) {
  const db = getDb();
  const doc = get(id);
  if (fs.existsSync(doc.file_path)) fs.unlinkSync(doc.file_path);
  db.prepare('DELETE FROM documents WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'document', ?, ?)`
  ).run(id, `Document "${doc.file_name}" deleted`);
  return { success: true };
}

module.exports = { DOCUMENT_TYPES, initStorage, upload, list, get, openFile, downloadAs, rename, remove };
