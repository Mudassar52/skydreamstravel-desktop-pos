const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const documentCurrency = require('./documentCurrency');
const settingsService = require('./settingsService');
const invoiceTemplateService = require('./invoiceTemplateService');
const ledgerService = require('./ledgerService');
const { renderTemplate, escapeHtml, buildLogoHtml } = require('./templateEngine');

const STATUSES = ['Unpaid', 'Partially Paid', 'Paid', 'Cancelled'];

function money(n) {
  return `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
}

function nextInvoiceNumber() {
  const prefix = settingsService.get('invoice_prefix', 'INV-');
  const nextNum = parseInt(settingsService.get('invoice_next_number', '1001'), 10) || 1001;
  settingsService.set('invoice_next_number', String(nextNum + 1));
  return `${prefix}${nextNum}`;
}

function computeTotals(items, discount = 0, tax = 0) {
  const subtotal = items.reduce((sum, it) => sum + Number(it.quantity || 1) * Number(it.unit_price || 0), 0);
  const total = Math.max(subtotal - Number(discount || 0) + Number(tax || 0), 0);
  return { subtotal, total };
}

function deriveStatus(total, paid, requestedStatus) {
  if (requestedStatus === 'Cancelled') return 'Cancelled';
  if (paid <= 0) return 'Unpaid';
  if (paid >= total) return 'Paid';
  return 'Partially Paid';
}

function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!Array.isArray(payload.items) || payload.items.length === 0) {
    throw new Error('Add at least one line item.');
  }
  for (const item of payload.items) {
    if (!item.description || !item.description.trim()) throw new Error('Each line item needs a description.');
    if (Number(item.quantity) <= 0) throw new Error('Quantity must be greater than zero.');
    if (Number(item.unit_price) < 0) throw new Error('Unit price cannot be negative.');
  }
  if (Number(payload.discount || 0) < 0) throw new Error('Discount cannot be negative.');
  if (Number(payload.tax || 0) < 0) throw new Error('Tax cannot be negative.');
  if (Number(payload.paid_amount || 0) < 0) throw new Error('Paid amount cannot be negative.');
}

function list({ search = '', status = 'All', dateField = 'invoice_date', dateFrom = null, dateTo = null, page = 1, pageSize = 15 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push('(i.invoice_number LIKE @q OR c.full_name LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') {
    conditions.push('i.status = @status');
    params.status = status;
  }
  const validDateFields = ['invoice_date', 'due_date', 'created_at'];
  const col = validDateFields.includes(dateField) ? dateField : 'invoice_date';
  if (dateFrom) { conditions.push(`date(i.${col}) >= date(@dateFrom)`); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push(`date(i.${col}) <= date(@dateTo)`); params.dateTo = dateTo; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM invoices i JOIN customers c ON c.id = i.customer_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT i.*, c.full_name AS customer_name
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       ${where}
       ORDER BY i.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const invoice = db
    .prepare(
      `SELECT i.*, c.full_name AS customer_name, c.phone AS customer_phone, c.email AS customer_email, c.address AS customer_address,
              b.booking_code
       FROM invoices i
       JOIN customers c ON c.id = i.customer_id
       LEFT JOIN bookings b ON b.id = i.booking_id
       WHERE i.id = ?`
    )
    .get(id);
  if (!invoice) throw new Error('Invoice not found.');

  const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY id').all(id);
  return { ...invoice, items };
}

function saveItems(db, invoiceId, items) {
  db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(invoiceId);
  const insert = db.prepare(
    'INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?)'
  );
  for (const item of items) {
    const lineTotal = Number(item.quantity || 1) * Number(item.unit_price || 0);
    insert.run(invoiceId, item.description, Number(item.quantity || 1), Number(item.unit_price || 0), lineTotal);
  }
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(payload.customer_id);
  if (!customer) throw new Error('Selected customer does not exist.');
  periodLock.assertOpen(null, 'This invoice');

  const { subtotal, total } = computeTotals(payload.items, payload.discount, payload.tax);
  const paid = Number(payload.paid_amount || 0);
  if (paid > total) throw new Error('Paid amount cannot exceed the total.');

  const invoiceNumber = nextInvoiceNumber();
  const template = invoiceTemplateService.getDefault();

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO invoices (
          invoice_number, invoice_date, due_date, customer_id, booking_id, template_id,
          subtotal, discount, tax, total, paid_amount, remaining_amount, status, notes, terms, currency
        ) VALUES (@invoice_number, datetime('now'), @due_date, @customer_id, @booking_id, @template_id,
          @subtotal, @discount, @tax, @total, @paid_amount, @remaining_amount, @status, @notes, @terms, @currency)`
      )
      .run({
        invoice_number: invoiceNumber,
        due_date: payload.due_date || null,
        customer_id: payload.customer_id,
        booking_id: payload.booking_id || null,
        template_id: template.id,
        subtotal,
        discount: Number(payload.discount || 0),
        tax: Number(payload.tax || 0),
        total,
        paid_amount: paid,
        remaining_amount: total - paid,
        status: deriveStatus(total, paid, payload.status),
        notes: payload.notes || null,
        terms: payload.terms || null,
        currency: documentCurrency.forInvoice(db, { bookingId: payload.booking_id, explicit: payload.currency })
      });

    saveItems(db, result.lastInsertRowid, payload.items);

    if (total > 0) {
      ledgerService.addEntry(db, {
        customer_id: payload.customer_id,
        description: `Invoice ${invoiceNumber}`,
        invoice_id: result.lastInsertRowid,
        debit: total
      });
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Created', 'invoice', ?, ?)`
    ).run(result.lastInsertRowid, `Invoice ${invoiceNumber} created`);

    return result.lastInsertRowid;
  });

  const id = tx();
  return { id, invoiceNumber };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!existing) throw new Error('Invoice not found.');
  periodLock.assertOpen(existing.invoice_date, `Invoice ${existing.invoice_number}`);
  if (existing.status === 'Cancelled' && payload.status !== 'Cancelled') {
    throw new Error('This invoice is cancelled. Create a new invoice instead of reactivating it.');
  }

  const { subtotal, total } = computeTotals(payload.items, payload.discount, payload.tax);
  const paid = Number(payload.paid_amount || 0);
  if (paid > total) throw new Error('Paid amount cannot exceed the total.');

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE invoices SET
        due_date = @due_date, customer_id = @customer_id, booking_id = @booking_id,
        subtotal = @subtotal, discount = @discount, tax = @tax, total = @total,
        paid_amount = @paid_amount, remaining_amount = @remaining_amount, status = @status,
        notes = @notes, terms = @terms, updated_at = datetime('now')
       WHERE id = @id`
    ).run({
      id,
      due_date: payload.due_date || null,
      customer_id: payload.customer_id,
      booking_id: payload.booking_id || null,
      subtotal,
      discount: Number(payload.discount || 0),
      tax: Number(payload.tax || 0),
      total,
      paid_amount: paid,
      remaining_amount: total - paid,
      status: deriveStatus(total, paid, payload.status),
      notes: payload.notes || null,
      terms: payload.terms || null
    });
    saveItems(db, id, payload.items);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Updated', 'invoice', ?, ?)`
    ).run(id, `Invoice #${id} updated`);
  });
  tx();

  return { success: true };
}

function cancel(id) {
  const db = getDb();
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!invoice) throw new Error('Invoice not found.');
  periodLock.assertOpen(invoice.invoice_date, `Invoice ${invoice.invoice_number}`);

  const tx = db.transaction(() => {
    db.prepare(`UPDATE invoices SET status = 'Cancelled', updated_at = datetime('now') WHERE id = ?`).run(id);
    if (invoice.remaining_amount > 0) {
      // Nets out the still-outstanding portion of this invoice's debit so
      // the customer's balance reflects that it's no longer owed.
      ledgerService.addEntry(db, {
        customer_id: invoice.customer_id,
        description: `Invoice ${invoice.invoice_number} cancelled`,
        invoice_id: id,
        credit: invoice.remaining_amount
      });
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Cancelled', 'invoice', ?, ?)`
    ).run(id, `Invoice #${id} cancelled`);
  });
  tx();

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!invoice) throw new Error('Invoice not found.');
  periodLock.assertOpen(invoice.invoice_date, `Invoice ${invoice.invoice_number}`);
  if (invoice.paid_amount > 0) {
    throw new Error('This invoice has recorded payments and cannot be deleted. Cancel it instead.');
  }
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(id);
    db.prepare('DELETE FROM invoices WHERE id = ?').run(id);
    if (invoice.status !== 'Cancelled' && invoice.total > 0) {
      // Reverses the original debit entry - the invoice never existed.
      ledgerService.addEntry(db, {
        customer_id: invoice.customer_id,
        description: `Invoice ${invoice.invoice_number} deleted`,
        credit: invoice.total
      });
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'invoice', ?, ?)`
    ).run(id, `Invoice ${invoice.invoice_number} deleted`);
  });
  tx();
  return { success: true };
}

function duplicate(id) {
  const original = get(id);
  return create({
    customer_id: original.customer_id,
    booking_id: original.booking_id,
    discount: original.discount,
    tax: original.tax,
    paid_amount: 0,
    status: 'Unpaid',
    notes: original.notes,
    terms: original.terms,
    items: original.items.map((it) => ({ description: it.description, quantity: it.quantity, unit_price: it.unit_price }))
  });
}

function createFromBooking(bookingId) {
  const db = getDb();
  const booking = db
    .prepare(
      `SELECT b.*, c.full_name AS customer_name FROM bookings b JOIN customers c ON c.id = b.customer_id WHERE b.id = ?`
    )
    .get(bookingId);
  if (!booking) throw new Error('Booking not found.');

  return create({
    customer_id: booking.customer_id,
    booking_id: booking.id,
    paid_amount: booking.paid_amount,
    status: undefined,
    items: [
      {
        description: `${booking.booking_type} Booking — ${booking.booking_code}`,
        quantity: 1,
        unit_price: booking.total_price
      }
    ]
  });
}

// ------------------------------------------------------------- PDF/print
function buildInvoiceHtml(id) {
  const invoice = get(id);
  const template = invoice.template_id ? invoiceTemplateService.get(invoice.template_id) : invoiceTemplateService.getDefault();
  const settings = settingsService.getAll();

  const lineItemsHtml = invoice.items
    .map(
      (it) => `<tr>
        <td>${escapeHtml(it.description)}</td>
        <td class="num">${escapeHtml(it.quantity)}</td>
        <td class="num">${escapeHtml(money(it.unit_price))}</td>
        <td class="num">${escapeHtml(money(it.line_total))}</td>
      </tr>`
    )
    .join('');

  const data = {
    agency_name: settings.agency_name || 'Your Travel Agency',
    agency_address: settings.agency_address || '',
    agency_phone: settings.agency_phone || '',
    agency_whatsapp: settings.agency_whatsapp || '',
    agency_email: settings.agency_email || '',
    agency_website: settings.agency_website || '',
    invoice_number: invoice.invoice_number,
    invoice_date: invoice.invoice_date,
    due_date: invoice.due_date || '',
    customer_name: invoice.customer_name,
    customer_phone: invoice.customer_phone || '',
    customer_email: invoice.customer_email || '',
    customer_address: invoice.customer_address || '',
    booking_reference: invoice.booking_code || '',
    line_items_html: lineItemsHtml,
    subtotal: money(invoice.subtotal),
    discount: money(invoice.discount),
    tax: money(invoice.tax),
    total: money(invoice.total),
    paid_amount: money(invoice.paid_amount),
    remaining_amount: money(invoice.remaining_amount),
    status: invoice.status,
    notes: invoice.notes || '',
    terms: invoice.terms || settings.terms_conditions || '',
    bank_details: settings.bank_details || '',
    logo_html: buildLogoHtml(settings),
    signature_html: settings.signature ? `<img src="${settings.signature}" style="max-height:48px;" />` : '',
    stamp_html: settings.stamp ? `<img src="${settings.stamp}" style="max-height:70px;" />` : ''
  };

  return renderTemplate(template.html, data);
}

function listByCustomer(customerId) {
  const db = getDb();
  return db
    .prepare('SELECT id, invoice_number, total, paid_amount, remaining_amount, status, currency FROM invoices WHERE customer_id = ? ORDER BY created_at DESC')
    .all(customerId);
}

function listByBooking(bookingId) {
  const db = getDb();
  return db
    .prepare('SELECT id, invoice_number, total, paid_amount, remaining_amount, status FROM invoices WHERE booking_id = ? ORDER BY created_at DESC')
    .all(bookingId);
}

module.exports = {
  STATUSES,
  list,
  get,
  listByCustomer,
  listByBooking,
  create,
  update,
  cancel,
  remove,
  duplicate,
  createFromBooking,
  buildInvoiceHtml,
  deriveStatus
};
