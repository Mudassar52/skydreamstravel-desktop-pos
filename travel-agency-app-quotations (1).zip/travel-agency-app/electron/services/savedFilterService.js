const { getDb } = require('../../src/database/db');

function list(module) {
  const db = getDb();
  const conditions = ['module = @module'];
  const params = { module };
  const where = `WHERE ${conditions.join(' AND ')}`;
  return db.prepare(`SELECT * FROM saved_filters ${where} ORDER BY name`).all(params).map((r) => ({ ...r, filter: JSON.parse(r.filter_json) }));
}

function create({ name, module, filter, user_id = null }) {
  if (!name || !name.trim()) throw new Error('A name is required to save this filter.');
  if (!module) throw new Error('A module is required.');
  const db = getDb();
  const result = db
    .prepare('INSERT INTO saved_filters (name, module, filter_json, user_id) VALUES (?, ?, ?, ?)')
    .run(name.trim(), module, JSON.stringify(filter || {}), user_id);
  return { id: result.lastInsertRowid };
}

function remove(id) {
  const db = getDb();
  db.prepare('DELETE FROM saved_filters WHERE id = ?').run(id);
  return { success: true };
}

module.exports = { list, create, remove };
