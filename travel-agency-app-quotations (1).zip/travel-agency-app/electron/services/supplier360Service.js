const { getDb } = require('../../src/database/db');
const supplierLedgerService = require('./supplierLedgerService');

// Supplier 360 (master prompt: Supplier Dossier / services / bookings / payables).
// READ-ONLY. Every figure is derived from real rows every time:
//   supplier_invoices, supplier_payments, supplier_ledger_entries and the five
//   booking-service tables (flights, hotels, visa_applications, transportation,
//   other_services) via their supplier_id.
//
// Two different "cost" ideas are kept apart on purpose, never summed together:
//   - service_cost   = what the booking-service rows say this supplier costs (estimate)
//   - invoiced       = what the supplier actually billed (supplier_invoices)
// Payable / balance always come from the invoices + ledger (the real money).

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function requireSupplier(db, id) {
  const s = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(id);
  if (!s) throw new Error('Supplier not found.');
  return s;
}

// One row per booking service assigned to a supplier. `?`-free: uses @s.
const SERVICE_ROWS = `
  SELECT 'Flight' AS service_type, f.id AS service_id, f.booking_id, f.supplier_id,
         TRIM(COALESCE(f.airline,'') || ' ' || COALESCE(f.flight_number,'')) AS description,
         f.departure_date AS service_date, COALESCE(f.cost,0) AS cost, COALESCE(f.selling_price,0) AS selling_price, f.status
    FROM flights f WHERE f.supplier_id = @s
  UNION ALL
  SELECT 'Hotel', h.id, h.booking_id, h.supplier_id,
         TRIM(COALESCE(h.hotel_name,'') || CASE WHEN h.city IS NOT NULL AND h.city <> '' THEN ' - ' || h.city ELSE '' END),
         h.check_in, COALESCE(h.cost,0), COALESCE(h.selling_price,0), COALESCE(h.status,'Confirmed')
    FROM hotels h WHERE h.supplier_id = @s
  UNION ALL
  SELECT 'Visa', v.id, v.booking_id, v.supplier_id,
         TRIM(COALESCE(v.country,'') || ' ' || COALESCE(v.visa_type,'')),
         COALESCE(v.application_date, v.submission_date), COALESCE(v.cost,0), COALESCE(v.selling_price,0), v.status
    FROM visa_applications v WHERE v.supplier_id = @s
  UNION ALL
  SELECT 'Transport', t.id, t.booking_id, t.supplier_id,
         TRIM(COALESCE(t.pickup_location,'') || ' > ' || COALESCE(t.drop_location,'')),
         t.pickup_date, COALESCE(t.cost,0), COALESCE(t.selling_price,0), t.status
    FROM transportation t WHERE t.supplier_id = @s
  UNION ALL
  SELECT o.service_type, o.id, o.booking_id, o.supplier_id, COALESCE(o.description,''),
         o.service_date, COALESCE(o.cost,0), COALESCE(o.selling_price,0), o.status
    FROM other_services o WHERE o.supplier_id = @s
`;

const SERVICE_SORT = {
  service_type: 'service_type', service_date: 'service_date', booking_code: 'booking_code',
  customer_name: 'customer_name', cost: 'cost', selling_price: 'selling_price', profit: 'profit', status: 'status'
};

function header(supplierId) {
  const db = getDb();
  const s = requireSupplier(db, supplierId);
  return {
    id: s.id, supplier_code: s.supplier_code, name: s.name, company: s.company || null,
    contact_person: s.contact_person || null, phone: s.phone || null, email: s.email || null,
    address: s.address || null, service_type: s.service_type || null, currency: s.currency || 'PKR',
    payment_terms: s.payment_terms || null, opening_balance: round2(s.opening_balance),
    status: s.status, notes: s.notes || null, created_at: s.created_at
  };
}

function summary(supplierId) {
  const db = getDb();
  const s = requireSupplier(db, supplierId);

  const inv = db.prepare(
    `SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS billed, COALESCE(SUM(paid_amount),0) AS paid_on_invoices,
            COALESCE(SUM(CASE WHEN status <> 'Paid' THEN remaining_amount ELSE 0 END),0) AS payable,
            COALESCE(SUM(CASE WHEN status = 'Overdue' THEN remaining_amount ELSE 0 END),0) AS overdue,
            SUM(CASE WHEN status = 'Overdue' THEN 1 ELSE 0 END) AS overdue_count
     FROM supplier_invoices WHERE supplier_id = ?`
  ).get(supplierId);

  const pay = db.prepare(
    `SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS paid,
            COALESCE(SUM(CASE WHEN supplier_invoice_id IS NULL THEN amount ELSE 0 END),0) AS not_against_invoice,
            MAX(payment_date) AS last_payment_date
     FROM supplier_payments WHERE supplier_id = ?`
  ).get(supplierId);

  const sv = db.prepare(
    `SELECT COUNT(*) AS n, COUNT(DISTINCT booking_id) AS bookings,
            COALESCE(SUM(cost),0) AS cost, COALESCE(SUM(selling_price),0) AS selling
     FROM (${SERVICE_ROWS})`
  ).get({ s: supplierId });

  const byType = db.prepare(
    `SELECT service_type, COUNT(*) AS n, COALESCE(SUM(cost),0) AS cost, COALESCE(SUM(selling_price),0) AS selling
     FROM (${SERVICE_ROWS}) GROUP BY service_type ORDER BY cost DESC`
  ).all({ s: supplierId });

  const balance = supplierLedgerService.getBalance(supplierId);

  return {
    invoices: {
      count: inv.n, total_billed: round2(inv.billed), paid_on_invoices: round2(inv.paid_on_invoices),
      payable: round2(inv.payable), overdue: round2(inv.overdue), overdue_count: inv.overdue_count || 0
    },
    payments: {
      count: pay.n, total_paid: round2(pay.paid),
      not_against_invoice: round2(pay.not_against_invoice), last_payment_date: pay.last_payment_date || null
    },
    ledger_balance: round2(balance),
    services: {
      count: sv.n, bookings: sv.bookings, service_cost: round2(sv.cost), service_selling: round2(sv.selling),
      service_profit: round2(sv.selling - sv.cost),
      margin_percent: sv.selling > 0 ? round2(((sv.selling - sv.cost) / sv.selling) * 100) : null,
      by_type: byType.map((r) => ({ service_type: r.service_type, count: r.n, cost: round2(r.cost), selling: round2(r.selling) }))
    },
    // Estimate vs actual, shown side by side and never added together.
    cost_check: {
      estimated_service_cost: round2(sv.cost),
      actually_invoiced: round2(inv.billed),
      difference: round2(inv.billed - sv.cost)
    },
    opening_balance: round2(s.opening_balance)
  };
}

/** Filtered / sorted / paginated list of every booking service this supplier fulfils. pageSize 0 = all. */
function serviceUsage(supplierId, opts = {}) {
  const db = getDb();
  requireSupplier(db, supplierId);
  const {
    search = '', serviceType = 'All', bookingId = null, dateFrom = '', dateTo = '',
    sortBy = 'service_date', sortDir = 'desc', page = 1, pageSize = 15
  } = opts;

  const where = [];
  const params = { s: supplierId };
  if (search && String(search).trim()) {
    where.push(`(booking_code LIKE @q OR customer_name LIKE @q OR description LIKE @q)`);
    params.q = `%${String(search).trim()}%`;
  }
  if (serviceType && serviceType !== 'All') { where.push('service_type = @st'); params.st = serviceType; }
  if (bookingId) { where.push('booking_id = @bid'); params.bid = Number(bookingId); }
  if (dateFrom) { where.push('date(service_date) >= date(@df)'); params.df = dateFrom; }
  if (dateTo) { where.push('date(service_date) <= date(@dt)'); params.dt = dateTo; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const base = `
    WITH svc AS (
      SELECT x.*, bk.booking_code, bk.customer_id, c.full_name AS customer_name, (x.selling_price - x.cost) AS profit
      FROM (${SERVICE_ROWS}) x
      LEFT JOIN bookings bk ON bk.id = x.booking_id
      LEFT JOIN customers c ON c.id = bk.customer_id
    )`;
  const total = db.prepare(`${base} SELECT COUNT(*) AS c FROM svc ${whereSql}`).get(params).c;
  const orderCol = SERVICE_SORT[sortBy] || 'service_date';
  const dir = String(sortDir).toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  let sql = `${base} SELECT * FROM svc ${whereSql} ORDER BY ${orderCol} ${dir}, service_id DESC`;
  const size = Number(pageSize) || 0;
  if (size > 0) {
    sql += ' LIMIT @lim OFFSET @off';
    params.lim = size;
    params.off = (Math.max(1, Number(page) || 1) - 1) * size;
  }
  const items = db.prepare(sql).all(params).map((r) => ({
    ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2(r.profit)
  }));
  return { items, total, page: Number(page) || 1, pageSize: size };
}

/** Bookings this supplier is involved in (through services or invoices/payments), with money per booking. */
function bookings(supplierId) {
  const db = getDb();
  requireSupplier(db, supplierId);
  const rows = db.prepare(
    `WITH ids AS (
       SELECT booking_id FROM (${SERVICE_ROWS}) WHERE booking_id IS NOT NULL
       UNION SELECT booking_id FROM supplier_invoices WHERE supplier_id = @s AND booking_id IS NOT NULL
       UNION SELECT booking_id FROM supplier_payments WHERE supplier_id = @s AND booking_id IS NOT NULL
     )
     SELECT bk.id, bk.booking_code, bk.booking_type, bk.status, bk.departure_date, c.full_name AS customer_name,
       (SELECT COUNT(*) FROM (${SERVICE_ROWS}) z WHERE z.booking_id = bk.id) AS services,
       (SELECT COALESCE(SUM(cost),0) FROM (${SERVICE_ROWS}) z WHERE z.booking_id = bk.id) AS service_cost,
       (SELECT COALESCE(SUM(selling_price),0) FROM (${SERVICE_ROWS}) z WHERE z.booking_id = bk.id) AS service_selling,
       (SELECT COALESCE(SUM(total),0) FROM supplier_invoices si WHERE si.supplier_id = @s AND si.booking_id = bk.id) AS invoiced,
       ((SELECT COALESCE(SUM(amount),0) FROM supplier_payments sp WHERE sp.supplier_id = @s AND sp.booking_id = bk.id)
        + (SELECT COALESCE(SUM(saa.amount),0) FROM supplier_advance_applications saa
             WHERE saa.supplier_invoice_id IN (SELECT id FROM supplier_invoices WHERE supplier_id = @s AND booking_id = bk.id))) AS paid
     FROM bookings bk
     JOIN ids ON ids.booking_id = bk.id
     LEFT JOIN customers c ON c.id = bk.customer_id
     ORDER BY bk.id DESC`
  ).all({ s: supplierId });
  return rows.map((r) => ({
    ...r, service_cost: round2(r.service_cost), service_selling: round2(r.service_selling),
    invoiced: round2(r.invoiced), paid: round2(r.paid), payable: round2(r.invoiced - r.paid)
  }));
}

function invoices(supplierId) {
  const db = getDb();
  requireSupplier(db, supplierId);
  return db.prepare(
    `SELECT si.*, bk.booking_code FROM supplier_invoices si
     LEFT JOIN bookings bk ON bk.id = si.booking_id
     WHERE si.supplier_id = ? ORDER BY si.invoice_date DESC, si.id DESC`
  ).all(supplierId);
}

function payments(supplierId) {
  const db = getDb();
  requireSupplier(db, supplierId);
  return db.prepare(
    `SELECT sp.*, si.invoice_number, bk.booking_code FROM supplier_payments sp
     LEFT JOIN supplier_invoices si ON si.id = sp.supplier_invoice_id
     LEFT JOIN bookings bk ON bk.id = sp.booking_id
     WHERE sp.supplier_id = ? ORDER BY sp.payment_date DESC, sp.id DESC`
  ).all(supplierId);
}

function timeline(supplierId, { page = 1, pageSize = 50 } = {}) {
  const db = getDb();
  requireSupplier(db, supplierId);
  const all = db.prepare(
    `WITH ev AS (
       SELECT created_at AS at, 'Supplier created' AS event, NULL AS reference, NULL AS notes FROM suppliers WHERE id = @s
       UNION ALL SELECT invoice_date, 'Supplier invoice recorded', invoice_number, printf('%.2f', total) FROM supplier_invoices WHERE supplier_id = @s
       UNION ALL SELECT payment_date, 'Payment made', COALESCE(NULLIF(reference,''), 'SPAY-' || id), payment_method || ' - ' || printf('%.2f', amount) FROM supplier_payments WHERE supplier_id = @s
       UNION ALL SELECT f.created_at, 'Flight assigned', COALESCE(f.pnr, f.flight_number), NULL FROM flights f WHERE f.supplier_id = @s
       UNION ALL SELECT h.created_at, 'Hotel assigned', h.hotel_name, NULL FROM hotels h WHERE h.supplier_id = @s
       UNION ALL SELECT v.created_at, 'Visa assigned', v.application_number, v.country FROM visa_applications v WHERE v.supplier_id = @s
       UNION ALL SELECT t.created_at, 'Transport assigned', t.vehicle_number, t.pickup_location FROM transportation t WHERE t.supplier_id = @s
       UNION ALL SELECT o.created_at, o.service_type || ' assigned', NULL, o.description FROM other_services o WHERE o.supplier_id = @s
     ) SELECT * FROM ev WHERE at IS NOT NULL ORDER BY at DESC`
  ).all({ s: supplierId });
  const size = Number(pageSize) || all.length || 1;
  const p = Math.max(1, Number(page) || 1);
  return { items: all.slice((p - 1) * size, p * size), total: all.length, page: p, pageSize: size };
}

function serviceTypes(supplierId) {
  const db = getDb();
  requireSupplier(db, supplierId);
  return db.prepare(`SELECT DISTINCT service_type FROM (${SERVICE_ROWS}) ORDER BY service_type`).all({ s: supplierId }).map((r) => r.service_type);
}

function getDossier(supplierId) {
  return { header: header(supplierId), summary: summary(supplierId), serviceTypes: serviceTypes(supplierId) };
}

module.exports = { header, summary, serviceUsage, bookings, invoices, payments, timeline, serviceTypes, getDossier };
