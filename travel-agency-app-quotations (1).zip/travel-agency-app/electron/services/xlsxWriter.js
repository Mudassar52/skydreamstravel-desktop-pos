// Minimal, dependency-free .xlsx writer.
//
// Why hand-rolled instead of a library (exceljs/xlsx): this app's build has
// no network access to add a new npm dependency to in this environment, and
// a dependency this code can't actually execute and verify here would be a
// blind bet. Node's built-in zlib (crc32) and Buffer are enough to produce a
// correct, standard OOXML .xlsx: a ZIP container (stored, uncompressed -
// files here are small, so no need for deflate) holding a handful of XML
// parts. Every part below follows the ECMA-376 / OOXML spreadsheet spec.
// Text cells use inline strings (<is><t>...</t></is>) instead of a shared
// strings table, which is valid OOXML and far simpler to get right.

const zlib = require('zlib');

function escapeXml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function colLetter(n) {
  // 1-indexed column number -> spreadsheet column letters (1=A, 26=Z, 27=AA, ...)
  let s = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

/** Sheet names: max 31 chars, no \ / ? * [ ] : and can't be blank. */
function sanitizeSheetName(name, index) {
  const cleaned = String(name || `Sheet${index + 1}`).replace(/[\\/?*[\]:]/g, ' ').trim().slice(0, 31);
  return cleaned || `Sheet${index + 1}`;
}

function buildSheetXml(sheet) {
  const cols = sheet.columns;
  const colsXml = `<cols>${cols.map((c, i) => `<col min="${i + 1}" max="${i + 1}" width="${Math.min(40, Math.max(10, (c.label || '').length + 4))}" customWidth="1"/>`).join('')}</cols>`;

  const headerRow = `<row r="1">${cols.map((c, i) => `<c r="${colLetter(i + 1)}1" s="1" t="inlineStr"><is><t>${escapeXml(c.label)}</t></is></c>`).join('')}</row>`;

  const dataRows = sheet.rows
    .map((row, rIdx) => {
      const r = rIdx + 2; // header is row 1
      const cells = cols
        .map((c, cIdx) => {
          const ref = `${colLetter(cIdx + 1)}${r}`;
          const raw = row[c.key];
          if (raw === null || raw === undefined || raw === '') return `<c r="${ref}"></c>`;
          if (c.money || (typeof raw === 'number' && !Number.isNaN(raw))) {
            const num = Number(raw);
            if (!Number.isNaN(num)) return `<c r="${ref}" s="${c.money ? 2 : 0}"><v>${num}</v></c>`;
          }
          return `<c r="${ref}" t="inlineStr"><is><t>${escapeXml(raw)}</t></is></c>`;
        })
        .join('');
      return `<row r="${r}">${cells}</row>`;
    })
    .join('');

  let totalsRow = '';
  if (sheet.totals) {
    const r = sheet.rows.length + 2;
    const cells = cols
      .map((c, cIdx) => {
        const ref = `${colLetter(cIdx + 1)}${r}`;
        const v = sheet.totals[c.key];
        if (v === undefined) return `<c r="${ref}" s="1"></c>`;
        if (typeof v === 'number') return `<c r="${ref}" s="3"><v>${v}</v></c>`;
        return `<c r="${ref}" s="1" t="inlineStr"><is><t>${escapeXml(v)}</t></is></c>`;
      })
      .join('');
    totalsRow = `<row r="${r}">${cells}</row>`;
  }

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
${colsXml}
<sheetData>${headerRow}${dataRows}${totalsRow}</sheetData>
</worksheet>`;
}

const STYLES_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>
  <fonts count="2">
    <font><sz val="10"/><name val="Calibri"/></font>
    <font><b/><sz val="10"/><color rgb="FF1E4FA3"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="4">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
    <xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

const CONTENT_TYPES_HEAD = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>`;

const ROOT_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

/**
 * Builds a real multi-sheet .xlsx as a Buffer, from a plain description:
 *   sheets: [{ name, columns: [{key,label,money?}], rows: [...], totals?: {...} }]
 * Only pass the sheets that are actually relevant - callers decide that
 * (e.g. skip an empty section rather than create a blank sheet).
 */
function buildXlsx(sheets) {
  if (!sheets || sheets.length === 0) throw new Error('At least one sheet is required.');
  const names = sheets.map((s, i) => sanitizeSheetName(s.name, i));

  const sheetEntries = sheets.map((s, i) => ({
    path: `xl/worksheets/sheet${i + 1}.xml`,
    data: Buffer.from(buildSheetXml(s), 'utf-8')
  }));

  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${names.map((n, i) => `<sheet name="${escapeXml(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets>
</workbook>`;

  const stylesRid = sheets.length + 1;
  const workbookRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('\n')}
<Relationship Id="rId${stylesRid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const contentTypesXml = `${CONTENT_TYPES_HEAD}
${sheetEntries.map((s) => `<Override PartName="/${s.path}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('\n')}
</Types>`;

  const parts = [
    { path: '[Content_Types].xml', data: Buffer.from(contentTypesXml, 'utf-8') },
    { path: '_rels/.rels', data: Buffer.from(ROOT_RELS, 'utf-8') },
    { path: 'xl/workbook.xml', data: Buffer.from(workbookXml, 'utf-8') },
    { path: 'xl/_rels/workbook.xml.rels', data: Buffer.from(workbookRelsXml, 'utf-8') },
    { path: 'xl/styles.xml', data: Buffer.from(STYLES_XML, 'utf-8') },
    ...sheetEntries
  ];

  return zipStore(parts);
}

// ---------------------------------------------------------------- ZIP (store)
// A minimal, correct ZIP container using the STORE method (no compression -
// fine for report-sized files, and removes an entire class of bugs that
// come with implementing deflate by hand). Built per the PKWARE APPNOTE:
// local file header + data, repeated, then a central directory, then the
// end-of-central-directory record.

function dosDateTime(date) {
  const time = ((date.getHours() & 0x1f) << 11) | ((date.getMinutes() & 0x3f) << 5) | ((date.getSeconds() >> 1) & 0x1f);
  const day = ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

function zipStore(parts) {
  const { time, day } = dosDateTime(new Date());
  const localChunks = [];
  const centralChunks = [];
  let offset = 0;

  for (const part of parts) {
    const nameBuf = Buffer.from(part.path, 'utf-8');
    const crc = zlib.crc32(part.data) >>> 0;
    const size = part.data.length;

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);       // version needed
    local.writeUInt16LE(0, 6);        // flags
    local.writeUInt16LE(0, 8);        // method: store
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(day, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(size, 18);    // compressed size == size (store)
    local.writeUInt32LE(size, 22);    // uncompressed size
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);       // extra field length
    localChunks.push(local, nameBuf, part.data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);     // version made by
    central.writeUInt16LE(20, 6);     // version needed
    central.writeUInt16LE(0, 8);      // flags
    central.writeUInt16LE(0, 10);     // method
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(day, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(size, 20);
    central.writeUInt32LE(size, 24);
    central.writeUInt16LE(nameBuf.length, 28);
    central.writeUInt16LE(0, 30);     // extra field length
    central.writeUInt16LE(0, 32);     // comment length
    central.writeUInt16LE(0, 34);     // disk number
    central.writeUInt16LE(0, 36);     // internal attrs
    central.writeUInt32LE(0, 38);     // external attrs
    central.writeUInt32LE(offset, 42); // offset of local header
    centralChunks.push(central, nameBuf);

    offset += local.length + nameBuf.length + part.data.length;
  }

  const centralDirStart = offset;
  const centralDir = Buffer.concat(centralChunks);
  const centralDirSize = centralDir.length;

  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(parts.length, 8);
  end.writeUInt16LE(parts.length, 10);
  end.writeUInt32LE(centralDirSize, 12);
  end.writeUInt32LE(centralDirStart, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...localChunks, centralDir, end]);
}

module.exports = { buildXlsx, colLetter, sanitizeSheetName, escapeXml };
