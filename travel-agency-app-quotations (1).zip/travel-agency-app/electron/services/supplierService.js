const { getDb } = require('../../src/database/db');

const SERVICE_TYPES = ['Airline', 'Hotel', 'Transport', 'Visa Agent', 'Tour Operator', 'Other'];

const SUPPLIER_FIELDS = [
  'name', 'company', 'contact_person', 'phone', 'email', 'address',
  'service_type', 'currency', 'payment_terms', 'opening_balance', 'notes', 'status'
];

function validate(payload) {
  if (!payload.name || !payload.name.trim()) throw new Error('Supplier name is required.');
  if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email.trim())) {
    throw new Error('Please provide a valid email address.');
  }
}

function nextSupplierCode(db) {
  const last = db.prepare('SELECT supplier_code FROM suppliers ORDER BY id DESC LIMIT 1').get();
  let nextNum = 1;
  if (last?.supplier_code) {
    const match = last.supplier_code.match(/(\d+)$/);
    if (match) nextNum = Number(match[1]) + 1;
  }
  return `SUP-${String(nextNum).padStart(5, '0')}`;
}

function list({ search = '', serviceType = 'All', status = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(name LIKE @q OR company LIKE @q OR contact_person LIKE @q OR phone LIKE @q OR email LIKE @q OR supplier_code LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (serviceType && serviceType !== 'All') {
    conditions.push('service_type = @serviceType');
    params.serviceType = serviceType;
  }
  if (status && status !== 'All') {
    conditions.push('status = @status');
    params.status = status;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM suppliers ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT s.*, 
        (SELECT COALESCE(running_balance,0) FROM supplier_ledger_entries WHERE supplier_id = s.id ORDER BY id DESC LIMIT 1) AS current_balance
       FROM suppliers s ${where}
       ORDER BY s.created_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(id);
  if (!supplier) throw new Error('Supplier not found.');

  const invoiceCount = db.prepare('SELECT COUNT(*) AS c FROM supplier_invoices WHERE supplier_id = ?').get(id).c;
  const payable = db
    .prepare("SELECT COALESCE(SUM(remaining_amount),0) AS s FROM supplier_invoices WHERE supplier_id = ? AND status != 'Paid'")
    .get(id).s;
  const lastLedger = db
    .prepare('SELECT running_balance FROM supplier_ledger_entries WHERE supplier_id = ? ORDER BY id DESC LIMIT 1')
    .get(id);

  return {
    ...supplier,
    invoiceCount,
    payable,
    currentBalance: lastLedger ? lastLedger.running_balance : (supplier.opening_balance || 0)
  };
}

function create(payload) {
  validate(payload);
  const db = getDb();

  const tx = db.transaction(() => {
    const code = nextSupplierCode(db);
    const params = { supplier_code: code };
    for (const f of SUPPLIER_FIELDS) params[f] = payload[f] ?? null;
    if (!params.status) params.status = 'Active';
    if (!params.currency) params.currency = 'PKR';
    params.opening_balance = Number(payload.opening_balance || 0);

    const cols = ['supplier_code', ...SUPPLIER_FIELDS];
    const placeholders = cols.map((c) => `@${c}`).join(', ');
    const result = db.prepare(`INSERT INTO suppliers (${cols.join(', ')}) VALUES (${placeholders})`).run(params);
    const supplierId = result.lastInsertRowid;

    if (params.opening_balance !== 0) {
      const supplierLedgerService = require('./supplierLedgerService');
      supplierLedgerService.addEntry(db, {
        supplier_id: supplierId,
        description: 'Opening balance',
        debit: params.opening_balance > 0 ? params.opening_balance : 0,
        credit: params.opening_balance < 0 ? Math.abs(params.opening_balance) : 0
      });
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Created', 'supplier', ?, ?)`
    ).run(supplierId, `Supplier "${payload.name}" (${code}) created`);

    return supplierId;
  });

  return { id: tx() };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM suppliers WHERE id = ?').get(id);
  if (!existing) throw new Error('Supplier not found.');

  const params = { id };
  const sets = [];
  for (const f of SUPPLIER_FIELDS) {
    if (payload[f] !== undefined) {
      sets.push(`${f} = @${f}`);
      params[f] = f === 'opening_balance' ? Number(payload[f] || 0) : payload[f];
    }
  }
  sets.push("updated_at = datetime('now')");

  db.prepare(`UPDATE suppliers SET ${sets.join(', ')} WHERE id = @id`).run(params);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Updated', 'supplier', ?, ?)`
  ).run(id, `Supplier #${id} updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const invoiceCount = db.prepare('SELECT COUNT(*) AS c FROM supplier_invoices WHERE supplier_id = ?').get(id).c;
  const paymentCount = db.prepare('SELECT COUNT(*) AS c FROM supplier_payments WHERE supplier_id = ?').get(id).c;
  if (invoiceCount > 0 || paymentCount > 0) {
    throw new Error('This supplier has existing invoices or payments and cannot be deleted. Consider marking them Inactive instead.');
  }
  const supplier = db.prepare('SELECT name FROM suppliers WHERE id = ?').get(id);
  db.prepare('DELETE FROM suppliers WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'supplier', ?, ?)`
  ).run(id, `Supplier "${supplier?.name || id}" deleted`);
  return { success: true };
}

function options() {
  const db = getDb();
  return db.prepare("SELECT id, name, supplier_code, service_type, currency FROM suppliers WHERE status = 'Active' ORDER BY name").all();
}

module.exports = { SERVICE_TYPES, list, get, create, update, remove, options };
