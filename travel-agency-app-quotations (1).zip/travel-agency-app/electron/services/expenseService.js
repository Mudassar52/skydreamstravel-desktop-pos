const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const accountService = require('./accountService');

const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];

// ------------------------------------------------------------- Categories
function listCategories() {
  const db = getDb();
  return db.prepare('SELECT * FROM expense_categories ORDER BY name').all();
}

function createCategory(name) {
  if (!name || !name.trim()) throw new Error('Category name is required.');
  const db = getDb();
  const existing = db.prepare('SELECT id FROM expense_categories WHERE name = ?').get(name.trim());
  if (existing) throw new Error('That category already exists.');
  const result = db.prepare('INSERT INTO expense_categories (name) VALUES (?)').run(name.trim());
  return { id: result.lastInsertRowid };
}

function removeCategory(id) {
  const db = getDb();
  const inUse = db.prepare('SELECT COUNT(*) AS c FROM expenses WHERE category_id = ?').get(id).c;
  if (inUse > 0) throw new Error('This category has expenses recorded against it and cannot be deleted.');
  db.prepare('DELETE FROM expense_categories WHERE id = ?').run(id);
  return { success: true };
}

// --------------------------------------------------------------- Expenses
function validate(payload) {
  if (!payload.category_id) throw new Error('A category must be selected.');
  if (!payload.expense_date) throw new Error('Expense date is required.');
  if (!(Number(payload.amount) > 0)) throw new Error('Amount must be greater than zero.');
  if (payload.payment_method && !PAYMENT_METHODS.includes(payload.payment_method)) {
    throw new Error('Please select a valid payment method.');
  }
}

function list({ categoryId = null, bookingId = null, startDate = null, endDate = null, page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (categoryId) { conditions.push('e.category_id = @categoryId'); params.categoryId = categoryId; }
  if (bookingId) { conditions.push('e.related_booking_id = @bookingId'); params.bookingId = bookingId; }
  if (startDate) { conditions.push('date(e.expense_date) >= date(@startDate)'); params.startDate = startDate; }
  if (endDate) { conditions.push('date(e.expense_date) <= date(@endDate)'); params.endDate = endDate; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const agg = db.prepare(`SELECT COUNT(*) AS c, COALESCE(SUM(e.amount), 0) AS s FROM expenses e ${where}`).get(params);
  const total = agg.c;
  const totalAmount = agg.s; // sum over ALL matching rows, not just the current page
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT e.*, ec.name AS category_name, b.booking_code
       FROM expenses e
       LEFT JOIN expense_categories ec ON ec.id = e.category_id
       LEFT JOIN bookings b ON b.id = e.related_booking_id
       ${where}
       ORDER BY e.expense_date DESC, e.created_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, totalAmount, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT e.*, ec.name AS category_name, b.booking_code
       FROM expenses e
       LEFT JOIN expense_categories ec ON ec.id = e.category_id
       LEFT JOIN bookings b ON b.id = e.related_booking_id
       WHERE e.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Expense not found.');
  return row;
}

function create(payload) {
  validate(payload);
  const db = getDb();
  periodLock.assertOpen(payload.expense_date, 'This expense');
  const result = db
    .prepare(
      `INSERT INTO expenses (expense_date, category_id, description, amount, payment_method, related_booking_id, related_package_type, related_package_id, notes, account_type, account_id)
       VALUES (@expense_date, @category_id, @description, @amount, @payment_method, @related_booking_id, @related_package_type, @related_package_id, @notes, @account_type, @account_id)`
    )
    .run({
      expense_date: payload.expense_date,
      category_id: payload.category_id,
      description: payload.description || null,
      amount: Number(payload.amount),
      payment_method: payload.payment_method || 'Cash',
      related_booking_id: payload.related_booking_id || null,
      related_package_type: payload.related_package_type || null,
      related_package_id: payload.related_package_id || null,
      notes: payload.notes || null,
      account_type: payload.account_type || null,
      account_id: payload.account_id || null
    });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Expense Added', 'expense', ?, ?)`
  ).run(result.lastInsertRowid, payload.description || 'Expense recorded');

  accountService.postTransaction(db, {
    account_type: payload.account_type,
    account_id: payload.account_id,
    amount: Number(payload.amount),
    direction: 'Out',
    transaction_type: 'Expense',
    reference_type: 'expenses',
    reference_id: result.lastInsertRowid,
    description: payload.description || 'Expense recorded'
  });

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  if (require('./commissionService').commissionForExpense(id)) {
    throw new Error('This expense is an agent commission payment and cannot be edited here. Reverse the payment from Commissions instead.');
  }
  const existing = db.prepare('SELECT id, expense_date FROM expenses WHERE id = ?').get(id);
  if (!existing) throw new Error('Expense not found.');
  periodLock.assertOpen(existing.expense_date, `Expense #${id}`);
  periodLock.assertOpen(payload.expense_date, `Expense #${id}`);

  db.prepare(
    `UPDATE expenses SET expense_date = @expense_date, category_id = @category_id, description = @description,
      amount = @amount, payment_method = @payment_method, related_booking_id = @related_booking_id,
      related_package_type = @related_package_type, related_package_id = @related_package_id, notes = @notes
     WHERE id = @id`
  ).run({
    id,
    expense_date: payload.expense_date,
    category_id: payload.category_id,
    description: payload.description || null,
    amount: Number(payload.amount),
    payment_method: payload.payment_method || 'Cash',
    related_booking_id: payload.related_booking_id || null,
    related_package_type: payload.related_package_type || null,
    related_package_id: payload.related_package_id || null,
    notes: payload.notes || null
  });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Expense Updated', 'expense', ?, ?)`
  ).run(id, `Expense #${id} updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id);
  if (!expense) throw new Error('Expense not found.');
  periodLock.assertOpen(expense.expense_date, `Expense #${id}`);
  // An expense created by paying an agent commission is owned by that commission. commissionService.reversePayment
  // detaches the link BEFORE calling this, so only a direct delete from the Expenses screen is blocked here.
  if (require('./commissionService').commissionForExpense(id)) {
    throw new Error('This expense is an agent commission payment. Reverse the payment from Commissions instead of deleting it here.');
  }
  db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'expense', ?, ?)`
  ).run(id, `Expense "${expense.description || id}" deleted`);

  accountService.postTransaction(db, {
    account_type: expense.account_type,
    account_id: expense.account_id,
    amount: expense.amount,
    direction: 'In',
    transaction_type: 'Reversal',
    reference_type: 'expenses',
    reference_id: id,
    description: `Expense #${id} deleted`
  });

  return { success: true };
}

module.exports = {
  PAYMENT_METHODS,
  listCategories,
  createCategory,
  removeCategory,
  list,
  get,
  create,
  update,
  remove
};
