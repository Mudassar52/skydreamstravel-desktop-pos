const { getDb } = require('../../src/database/db');
const paymentService = require('./paymentService');

/**
 * Refunds reuse paymentService's existing payment_type='Refund' handling
 * (Section 63: don't duplicate working calculations) for the invoice/
 * booking balance and customer ledger math, which is already tested and
 * correct. This service adds the structured fields Section 39 asks for
 * (reason, refund date, staff) on top, in the dedicated `refunds` table.
 */
function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!(Number(payload.refund_amount) > 0)) throw new Error('Refund amount must be greater than zero.');
}

function list({ customerId = null, page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (customerId) { conditions.push('r.customer_id = @customerId'); params.customerId = customerId; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM refunds r ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT r.*, c.full_name AS customer_name, b.booking_code, i.invoice_number
       FROM refunds r
       JOIN customers c ON c.id = r.customer_id
       LEFT JOIN bookings b ON b.id = r.booking_id
       LEFT JOIN invoices i ON i.id = r.invoice_id
       ${where} ORDER BY r.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(payload.customer_id);
  if (!customer) throw new Error('Selected customer does not exist.');

  const amount = Number(payload.refund_amount);

  // Reuse paymentService's Refund path for correct invoice/booking/ledger math.
  const { id: paymentId } = paymentService.create({
    customer_id: payload.customer_id,
    booking_id: payload.booking_id || null,
    invoice_id: payload.invoice_id || null,
    amount,
    payment_method: payload.payment_method || 'Bank Transfer',
    payment_type: 'Refund',
    reference: payload.notes ? `Refund: ${payload.notes.slice(0, 60)}` : 'Refund',
    notes: payload.reason || null,
    account_type: payload.account_type || null,
    account_id: payload.account_id || null,
    received_amount: payload.received_amount || null
  });

  const result = db
    .prepare(
      `INSERT INTO refunds (customer_id, booking_id, invoice_id, payment_id, refund_amount, refund_date, reason, payment_method, account_type, account_id, notes, staff_id)
       VALUES (@customer_id, @booking_id, @invoice_id, @payment_id, @refund_amount, datetime('now'), @reason, @payment_method, @account_type, @account_id, @notes, @staff_id)`
    )
    .run({
      customer_id: payload.customer_id,
      booking_id: payload.booking_id || null,
      invoice_id: payload.invoice_id || null,
      payment_id: paymentId,
      refund_amount: amount,
      reason: payload.reason || null,
      payment_method: payload.payment_method || 'Bank Transfer',
      account_type: payload.account_type || null,
      account_id: payload.account_id || null,
      notes: payload.notes || null,
      staff_id: payload.staff_id || null
    });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Refund Issued', 'refund', ?, ?)`
  ).run(result.lastInsertRowid, `Refund of ${amount} issued to customer #${payload.customer_id}`);

  return { id: result.lastInsertRowid, paymentId };
}

/** Voids a refund by voiding its underlying payment (reverses invoice/booking/ledger/account), then removes the refund record. */
function remove(id) {
  const db = getDb();
  const refund = db.prepare('SELECT * FROM refunds WHERE id = ?').get(id);
  if (!refund) throw new Error('Refund not found.');

  // Detach the FK reference before voiding the underlying payment, so
  // paymentService.remove() can delete that payment row without a
  // foreign-key conflict from this refund still pointing at it.
  db.prepare('UPDATE refunds SET payment_id = NULL WHERE id = ?').run(id);

  if (refund.payment_id) {
    paymentService.remove(refund.payment_id);
  }
  db.prepare('DELETE FROM refunds WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Refund Voided', 'refund', ?, ?)`
  ).run(id, `Refund #${id} voided`);

  return { success: true };
}

module.exports = { list, create, remove };
