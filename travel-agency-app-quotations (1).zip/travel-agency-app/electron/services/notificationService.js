const { getDb } = require('../../src/database/db');

function list({ unreadOnly = false, limit = 50 } = {}) {
  const db = getDb();
  const where = unreadOnly ? 'WHERE is_read = 0' : '';
  return db.prepare(`SELECT * FROM notifications ${where} ORDER BY created_at DESC LIMIT ?`).all(limit);
}

function unreadCount() {
  const db = getDb();
  return db.prepare('SELECT COUNT(*) AS c FROM notifications WHERE is_read = 0').get().c;
}

function markRead(id) {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(id);
  return { success: true };
}

function markAllRead() {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE is_read = 0').run();
  return { success: true };
}

function create({ notif_type, title, message, record_type, record_id, user_id = null }) {
  const db = getDb();
  const result = db
    .prepare('INSERT INTO notifications (notif_type, title, message, record_type, record_id, user_id) VALUES (?, ?, ?, ?, ?, ?)')
    .run(notif_type, title, message || null, record_type || null, record_id || null, user_id);
  return { id: result.lastInsertRowid };
}

/**
 * Scans the real, current state of the database for anything Section 55
 * calls a notification-worthy condition, and creates a notification row
 * for any that don't already have one. Idempotent: safe to call on every
 * app start or on a timer, since it checks `record_type`+`record_id`
 * before inserting so nothing gets duplicated.
 */
function generate() {
  const db = getDb();
  const exists = db.prepare('SELECT id FROM notifications WHERE notif_type = ? AND record_type = ? AND record_id = ? AND is_read = 0');
  let created = 0;

  function notifyOnce(notif_type, record_type, record_id, title, message) {
    if (exists.get(notif_type, record_type, record_id)) return;
    create({ notif_type, title, message, record_type, record_id });
    created += 1;
  }

  // Overdue customer payments (unpaid/partial invoices past due date)
  db.prepare(
    `SELECT i.id, i.invoice_number, i.remaining_amount, c.full_name FROM invoices i
     JOIN customers c ON c.id = i.customer_id
     WHERE i.status IN ('Unpaid','Partially Paid','Overdue') AND i.due_date IS NOT NULL AND date(i.due_date) < date('now')`
  ).all().forEach((i) => {
    notifyOnce('PaymentOverdue', 'invoices', i.id, `Payment overdue — ${i.invoice_number}`, `${i.full_name} owes Rs. ${i.remaining_amount.toLocaleString()} on invoice ${i.invoice_number}.`);
  });

  // Pending supplier payments (unpaid/partial supplier invoices past due date)
  db.prepare(
    `SELECT si.id, si.invoice_number, si.remaining_amount, s.name FROM supplier_invoices si
     JOIN suppliers s ON s.id = si.supplier_id
     WHERE si.status IN ('Unpaid','Partially Paid','Overdue') AND si.due_date IS NOT NULL AND date(si.due_date) < date('now')`
  ).all().forEach((si) => {
    notifyOnce('SupplierPaymentPending', 'supplier_invoices', si.id, `Supplier payment due — ${si.invoice_number}`, `Rs. ${si.remaining_amount.toLocaleString()} owed to ${si.name} on ${si.invoice_number}.`);
  });

  // Visa deadlines within 7 days
  db.prepare(
    `SELECT id, deadline_type, title, due_date, booking_id FROM deadlines
     WHERE deadline_type = 'Visa' AND status = 'Pending' AND due_date <= date('now', '+7 days')`
  ).all().forEach((d) => {
    notifyOnce('VisaDeadline', 'deadlines', d.id, d.title || 'Visa deadline approaching', `Due ${d.due_date}.`);
  });

  // Passport expiry within 90 days
  db.prepare(
    `SELECT id, full_name, passport_expiry_date FROM travellers
     WHERE passport_expiry_date IS NOT NULL AND date(passport_expiry_date) <= date('now', '+90 days') AND date(passport_expiry_date) >= date('now')`
  ).all().forEach((t) => {
    notifyOnce('PassportExpiry', 'travellers', t.id, `Passport expiring soon — ${t.full_name}`, `Expires ${t.passport_expiry_date}.`);
  });

  // Flight/ticketing and hotel-cancellation deadlines
  db.prepare(
    `SELECT id, deadline_type, title, due_date FROM deadlines
     WHERE deadline_type IN ('Ticketing','HotelCancellation') AND status = 'Pending' AND due_date <= date('now', '+7 days')`
  ).all().forEach((d) => {
    notifyOnce(d.deadline_type === 'Ticketing' ? 'FlightDeadline' : 'HotelDeadline', 'deadlines', d.id, d.title || `${d.deadline_type} deadline approaching`, `Due ${d.due_date}.`);
  });

  // Follow-ups due today or overdue
  db.prepare(
    `SELECT f.id, c.full_name FROM follow_ups f LEFT JOIN customers c ON c.id = f.customer_id
     WHERE f.status = 'Pending' AND f.follow_up_date <= date('now')`
  ).all().forEach((f) => {
    notifyOnce('FollowUpDue', 'follow_ups', f.id, 'Follow-up due', f.full_name ? `Follow up with ${f.full_name}.` : 'A scheduled follow-up is due.');
  });

  // Overdue staff tasks
  db.prepare(
    `SELECT id, title FROM tasks WHERE status NOT IN ('Completed','Cancelled') AND due_date IS NOT NULL AND date(due_date) < date('now')`
  ).all().forEach((t) => {
    notifyOnce('TaskOverdue', 'tasks', t.id, `Task overdue — ${t.title}`, 'This task is past its due date.');
  });

  // Bookings still pending confirmation
  db.prepare(`SELECT id, booking_code FROM bookings WHERE status = 'Pending'`).all().forEach((b) => {
    notifyOnce('BookingConfirmationPending', 'bookings', b.id, `Booking confirmation pending — ${b.booking_code}`, 'This booking is still awaiting confirmation.');
  });

  return { created };
}

module.exports = { list, unreadCount, markRead, markAllRead, create, generate };
