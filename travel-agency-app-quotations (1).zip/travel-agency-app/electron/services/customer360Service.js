const { getDb } = require('../../src/database/db');
const exchangeRates = require('./exchangeRateService');

// Customer 360 (master prompt sections 4-7, 18, 20).
//
// Everything here is READ-ONLY and computed from the existing tables
// (customers, bookings, invoices, payments, ledger_entries, supplier_invoices,
// flights, hotels, transportation, visa_applications, other_services,
// documents, follow_ups, leads, quotations). No new financial tables and no
// stored totals: each number is derived from real transactions every time,
// so it can never drift out of sync with the Payments / Ledger modules.
//
// Money rules (kept consistent with paymentService / ledgerService):
//  - A Refund is a payments row with payment_type = 'Refund'. It is NOT
//    counted as a payment; it is reported separately and reduces net received.
//  - An "Advance" is a payments row with payment_type = 'Advance'. Advance
//    that is tied to a booking or invoice counts as USED; advance tied to
//    neither is REMAINING. An advance is never counted twice: total paid is
//    the sum of payment rows (an advance row is one row), and advance figures
//    are only a breakdown of that same sum.
//  - Outstanding balance is the customer ledger balance (what the customer
//    owes the agency), identical to the Customer Ledger screen.
//  - Cost never mixes estimate and actual for the same booking: if supplier
//    invoices exist for the booking, they ARE the cost; otherwise the
//    per-service estimated costs are used.

const ACTIVE_STATUSES = ['Inquiry', 'Pending', 'Confirmed'];
const NON_REFUND = `p.payment_type <> 'Refund'`;

function customerCode(id) {
  return `CUST-${String(id).padStart(5, '0')}`;
}

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function requireCustomer(db, customerId) {
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!c) throw new Error('Customer not found.');
  return c;
}

// SQL fragment: one row per booking of a customer, with every financial figure
// derived from real transactions. `?` = customer id.
const BOOKING_ROWS_CTE = `
  WITH rows AS (
    SELECT
      bk.id, bk.booking_code, bk.booking_date, bk.booking_type, bk.departure_date, bk.return_date,
      bk.status, bk.total_price AS selling, bk.destination, bk.package_id,
      COALESCE(NULLIF(json_extract(bk.package_snapshot, '$.package_name'), ''), pk.package_name) AS package_name,
      COALESCE(bk.currency, pk.currency, (SELECT value FROM settings WHERE key = 'default_currency'), 'PKR') AS currency,
      (SELECT COALESCE(SUM(p.amount), 0) FROM payments p
        WHERE ${NON_REFUND} AND (p.booking_id = bk.id OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id))) AS paid,
      (SELECT COALESCE(SUM(p.amount), 0) FROM payments p
        WHERE p.payment_type = 'Refund' AND (p.booking_id = bk.id OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id))) AS refunded,
      (SELECT COALESCE(SUM(p.amount), 0) FROM payments p
        WHERE p.payment_type = 'Advance' AND (p.booking_id = bk.id OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id))) AS advance,
      (SELECT COALESCE(SUM(aa.amount), 0) FROM advance_applications aa
        WHERE aa.invoice_id IN (SELECT id FROM invoices WHERE booking_id = bk.id)) AS advance_applied,
      (SELECT COALESCE(SUM(si.total), 0) FROM supplier_invoices si WHERE si.booking_id = bk.id) AS cost_actual,
      (SELECT COALESCE(SUM(f.cost), 0) FROM flights f WHERE f.booking_id = bk.id) AS c_flight,
      (SELECT COALESCE(SUM(h.cost), 0) FROM hotels h WHERE h.booking_id = bk.id) AS c_hotel,
      (SELECT COALESCE(SUM(v.cost), 0) FROM visa_applications v WHERE v.booking_id = bk.id) AS c_visa,
      (SELECT COALESCE(SUM(t.cost), 0) FROM transportation t WHERE t.booking_id = bk.id) AS c_transport,
      (SELECT COALESCE(SUM(o.cost), 0) FROM other_services o WHERE o.booking_id = bk.id AND o.service_type = 'Ziyarat') AS c_ziyarat,
      (SELECT COALESCE(SUM(o.cost), 0) FROM other_services o WHERE o.booking_id = bk.id AND o.service_type <> 'Ziyarat') AS c_other
    FROM bookings bk
    LEFT JOIN packages pk ON pk.id = bk.package_id
    WHERE bk.customer_id = ?
  ),
  calc AS (
    SELECT rows.*,
      (c_flight + c_hotel + c_visa + c_transport + c_ziyarat + c_other) AS cost_estimated,
      CASE WHEN cost_actual > 0 THEN cost_actual
           WHEN status = 'Cancelled' THEN 0
           ELSE (c_flight + c_hotel + c_visa + c_transport + c_ziyarat + c_other) END AS cost,
      (paid + advance_applied - refunded) AS net_paid,
      (selling - (paid + advance_applied - refunded)) AS outstanding
    FROM rows
  ),
  final AS (
    SELECT calc.*,
      (selling - cost) AS profit,
      CASE WHEN selling > 0 AND outstanding <= 0.005 THEN 'Paid'
           WHEN net_paid <= 0.005 THEN 'Unpaid'
           ELSE 'Partial' END AS payment_status
    FROM calc
  )
`;

const SORTABLE = {
  booking_code: 'booking_code',
  booking_date: 'booking_date',
  booking_type: 'booking_type',
  departure_date: 'departure_date',
  return_date: 'return_date',
  selling: 'selling',
  paid: 'net_paid',
  outstanding: 'outstanding',
  cost: 'cost',
  profit: 'profit',
  status: 'status',
  package_name: 'package_name'
};

/**
 * Filtered / sorted / paginated booking history for one customer.
 * Filtering, sorting and paging all happen in SQL. Pass pageSize = 0 to get
 * every matching row (used for export).
 */
function bookingHistory(customerId, opts = {}) {
  const db = getDb();
  requireCustomer(db, customerId);
  const {
    search = '', bookingType = 'All', status = 'All', paymentStatus = 'All', currency = 'All',
    dateFrom = '', dateTo = '', minAmount = '', maxAmount = '',
    sortBy = 'booking_date', sortDir = 'desc', page = 1, pageSize = 15
  } = opts;

  const where = [];
  const params = [customerId];
  if (search && String(search).trim()) {
    const q = `%${String(search).trim()}%`;
    where.push('(booking_code LIKE ? OR IFNULL(package_name,\'\') LIKE ? OR IFNULL(destination,\'\') LIKE ?)');
    params.push(q, q, q);
  }
  if (bookingType && bookingType !== 'All') { where.push('booking_type = ?'); params.push(bookingType); }
  if (status && status !== 'All') { where.push('status = ?'); params.push(status); }
  if (paymentStatus && paymentStatus !== 'All') { where.push('payment_status = ?'); params.push(paymentStatus); }
  if (currency && currency !== 'All') { where.push('currency = ?'); params.push(currency); }
  if (dateFrom) { where.push('date(booking_date) >= date(?)'); params.push(dateFrom); }
  if (dateTo) { where.push('date(booking_date) <= date(?)'); params.push(dateTo); }
  if (minAmount !== '' && minAmount !== null && !Number.isNaN(Number(minAmount))) { where.push('selling >= ?'); params.push(Number(minAmount)); }
  if (maxAmount !== '' && maxAmount !== null && !Number.isNaN(Number(maxAmount))) { where.push('selling <= ?'); params.push(Number(maxAmount)); }

  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const orderCol = SORTABLE[sortBy] || 'booking_date';
  const dir = String(sortDir).toLowerCase() === 'asc' ? 'ASC' : 'DESC';

  const total = db.prepare(`${BOOKING_ROWS_CTE} SELECT COUNT(*) AS c FROM final ${whereSql}`).get(...params).c;

  let sql = `${BOOKING_ROWS_CTE} SELECT * FROM final ${whereSql} ORDER BY ${orderCol} ${dir}, id DESC`;
  const runParams = [...params];
  const size = Number(pageSize) || 0;
  if (size > 0) {
    sql += ' LIMIT ? OFFSET ?';
    runParams.push(size, (Math.max(1, Number(page) || 1) - 1) * size);
  }
  const items = db.prepare(sql).all(...runParams).map((r) => ({
    id: r.id,
    booking_code: r.booking_code,
    booking_date: r.booking_date,
    booking_type: r.booking_type,
    package_name: r.package_name || null,
    destination: r.destination || null,
    departure_date: r.departure_date,
    return_date: r.return_date,
    currency: r.currency,
    selling: round2(r.selling),
    paid: round2(r.net_paid),
    advance: round2(r.advance + r.advance_applied),
    outstanding: round2(r.outstanding),
    cost: round2(r.cost),
    cost_source: r.cost_actual > 0 ? 'actual' : 'estimated',
    profit: round2(r.profit),
    payment_status: r.payment_status,
    status: r.status
  }));

  return { items, total, page: Number(page) || 1, pageSize: size };
}

/** Distinct currencies used by this customer's bookings (for the filter dropdown). */
function bookingCurrencies(customerId) {
  const db = getDb();
  return db
    .prepare(`${BOOKING_ROWS_CTE} SELECT DISTINCT currency FROM final ORDER BY currency`)
    .all(customerId)
    .map((r) => r.currency);
}

/** Financial summary + profitability. Every value is derived from transactions. */
function summary(customerId, { today = null } = {}) {
  const db = getDb();
  requireCustomer(db, customerId);
  const todayStr = today || db.prepare(`SELECT date('now') AS d`).get().d;

  const rows = db.prepare(`${BOOKING_ROWS_CTE} SELECT * FROM final`).all(customerId);

  const counts = {
    total: rows.length,
    active: rows.filter((r) => ACTIVE_STATUSES.includes(r.status)).length,
    completed: rows.filter((r) => r.status === 'Completed').length,
    cancelled: rows.filter((r) => r.status === 'Cancelled').length
  };

  // Currency transparency (master prompt section 53): this app records a currency per booking/package
  // but has no exchange-rate table, and never converts. When one customer has bookings in more than one
  // currency, a single "total" would silently add PKR to USD - so the breakdown is reported per
  // currency and `mixed_currency` lets the screen say so plainly.
  const byCurrency = {};
  for (const r of rows) {
    if (r.status === 'Cancelled') continue;
    const c = (byCurrency[r.currency] = byCurrency[r.currency] || { currency: r.currency, bookings: 0, selling: 0, paid: 0, outstanding: 0 });
    c.bookings += 1; c.selling += r.selling; c.paid += r.net_paid; c.outstanding += r.outstanding;
  }
  const currencies = Object.values(byCurrency).map((c) => ({ ...c, selling: round2(c.selling), paid: round2(c.paid), outstanding: round2(c.outstanding) }));

  // Phase 21: when the admin has entered exchange rates, a mixed-currency customer also gets ONE converted
  // total in the agency's base currency. A currency with no rate is left out of that total and listed in
  // `missing`, never guessed - `complete` says whether the converted figure covers everything.
  const baseCurrency = exchangeRates.getBaseCurrency();
  let converted = null;
  if (currencies.length > 1) {
    const rateDate = todayStr;
    const part = (field) => exchangeRates.convertTotals(currencies.map((c) => ({ currency: c.currency, amount: c[field] })), baseCurrency, rateDate);
    const sel = part('selling');
    const paid = part('paid');
    const out = part('outstanding');
    converted = {
      currency: baseCurrency,
      as_of: rateDate,
      complete: sel.complete,
      missing: sel.missing,
      selling: sel.total,
      paid: paid.total,
      outstanding: out.total,
      rates: sel.rates
    };
  }

  const inv = db
    .prepare(
      `SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS billed, COALESCE(SUM(remaining_amount), 0) AS open
       FROM invoices WHERE customer_id = ? AND status <> 'Cancelled'`
    )
    .get(customerId);

  const pay = db
    .prepare(
      `SELECT
         COALESCE(SUM(CASE WHEN payment_type <> 'Refund' THEN amount ELSE 0 END), 0) AS paid,
         COALESCE(SUM(CASE WHEN payment_type = 'Refund' THEN amount ELSE 0 END), 0) AS refunds,
         COALESCE(SUM(CASE WHEN payment_type = 'Advance' THEN amount ELSE 0 END), 0) AS advance_received,
         COALESCE(SUM(CASE WHEN payment_type = 'Advance' AND (invoice_id IS NOT NULL OR booking_id IS NOT NULL) THEN amount ELSE 0 END), 0) AS advance_used_at_receipt,
         MAX(CASE WHEN payment_type <> 'Refund' THEN payment_date END) AS last_payment_date
       FROM payments WHERE customer_id = ?`
    )
    .get(customerId);
  // Advances applied later (advanceService.applyToInvoice) are also "used",
  // on top of any that were tied to a booking/invoice at the moment they
  // were received - see advanceService.js for why the two never overlap.
  const advanceAppliedLater = db.prepare(
    `SELECT COALESCE(SUM(aa.amount), 0) AS s FROM advance_applications aa
     JOIN payments p ON p.id = aa.payment_id WHERE p.customer_id = ?`
  ).get(customerId).s;
  pay.advance_used = pay.advance_used_at_receipt + advanceAppliedLater;

  const lastBalanceRow = db
    .prepare('SELECT running_balance FROM ledger_entries WHERE customer_id = ? ORDER BY id DESC LIMIT 1')
    .get(customerId);
  const ledgerBalance = lastBalanceRow ? lastBalanceRow.running_balance : 0;

  const live = rows.filter((r) => r.status !== 'Cancelled');
  const lastTravel = live
    .map((r) => r.departure_date)
    .filter((d) => d && d <= todayStr)
    .sort()
    .pop() || null;
  const nextTravel = live
    .map((r) => r.departure_date)
    .filter((d) => d && d >= todayStr)
    .sort()[0] || null;

  // Profitability (section 18): cost breakdown by service type. A booking with
  // supplier invoices contributes its ACTUAL figure as one line; otherwise its
  // per-service estimates are split by type.
  const breakdown = { flight: 0, visa: 0, hotel: 0, transport: 0, ziyarat: 0, other: 0, supplier_invoices: 0 };
  for (const r of rows) {
    if (r.cost_actual > 0) {
      breakdown.supplier_invoices += r.cost_actual;
    } else if (r.status !== 'Cancelled') {
      breakdown.flight += r.c_flight;
      breakdown.hotel += r.c_hotel;
      breakdown.visa += r.c_visa;
      breakdown.transport += r.c_transport;
      breakdown.ziyarat += r.c_ziyarat;
      breakdown.other += r.c_other;
    }
  }
  const totalCost = Object.values(breakdown).reduce((a, b) => a + b, 0);
  const billed = inv.billed;
  const grossProfit = billed - totalCost;

  return {
    bookings: counts,
    currencies,
    mixed_currency: currencies.length > 1,
    base_currency: baseCurrency,
    converted,
    invoices: { count: inv.n, total_billed: round2(billed), open_on_invoices: round2(inv.open) },
    payments: {
      total_paid: round2(pay.paid),
      total_refunds: round2(pay.refunds),
      net_received: round2(pay.paid - pay.refunds),
      last_payment_date: pay.last_payment_date || null
    },
    advance: {
      received: round2(pay.advance_received),
      used: round2(pay.advance_used),
      remaining: round2(pay.advance_received - pay.advance_used)
    },
    outstanding_balance: round2(ledgerBalance),
    travel: { last_travel_date: lastTravel, next_travel_date: nextTravel },
    profitability: {
      revenue: round2(billed),
      cost_breakdown: Object.fromEntries(Object.entries(breakdown).map(([k, v]) => [k, round2(v)])),
      total_cost: round2(totalCost),
      gross_profit: round2(grossProfit),
      margin_percent: billed > 0 ? round2((grossProfit / billed) * 100) : null
    }
  };
}

/** Header block (section 4). City/country are not separate columns in this schema, so address is shown whole. */
function header(customerId) {
  const db = getDb();
  const c = requireCustomer(db, customerId);
  let staff = null;
  if (c.salesperson_id) {
    const u = db.prepare('SELECT full_name FROM users WHERE id = ?').get(c.salesperson_id);
    staff = u ? u.full_name : null;
  }
  return {
    id: c.id,
    customer_code: customerCode(c.id),
    full_name: c.full_name,
    phone: c.phone || null,
    whatsapp: c.whatsapp || null,
    email: c.email || null,
    address: c.address || null,
    cnic: c.cnic || null,
    passport_number: c.passport_number || null,
    passport_expiry_date: c.passport_expiry_date || null,
    nationality: c.nationality || null,
    customer_type: c.customer_type || 'Individual',
    registration_date: c.created_at,
    status: c.status,
    assigned_staff: staff,
    notes: c.notes || null
  };
}

/**
 * Chronological travel timeline (section 20), newest first, built from the real
 * records. `staff` is only filled where the source row records who did it
 * (quotation creator, follow-up assignee); it is null elsewhere rather than guessed.
 */
function timeline(customerId, { page = 1, pageSize = 50 } = {}) {
  const db = getDb();
  requireCustomer(db, customerId);
  const sql = `
    WITH ev AS (
      SELECT created_at AS at, 'Customer created' AS event, 'customer' AS kind, NULL AS reference, NULL AS notes, NULL AS staff
        FROM customers WHERE id = @c
      UNION ALL
      SELECT l.created_at, 'Inquiry created', 'lead', l.lead_code, l.notes, u.full_name
        FROM leads l LEFT JOIN users u ON u.id = l.assigned_agent_id WHERE l.converted_customer_id = @c
      UNION ALL
      SELECT q.created_at, 'Quotation created', 'quotation', q.quotation_number, q.notes, u.full_name
        FROM quotations q LEFT JOIN users u ON u.id = q.created_by WHERE q.customer_id = @c
      UNION ALL
      SELECT bk.booking_date, 'Booking created', 'booking', bk.booking_code, bk.notes, NULL
        FROM bookings bk WHERE bk.customer_id = @c
      UNION ALL
      SELECT bk.updated_at, 'Booking ' || LOWER(bk.status), 'booking', bk.booking_code, NULL, NULL
        FROM bookings bk WHERE bk.customer_id = @c AND bk.status IN ('Completed', 'Cancelled')
      UNION ALL
      SELECT i.invoice_date, 'Invoice generated', 'invoice', i.invoice_number, NULL, NULL
        FROM invoices i WHERE i.customer_id = @c
      UNION ALL
      SELECT p.payment_date,
             CASE p.payment_type WHEN 'Refund' THEN 'Refund issued' WHEN 'Advance' THEN 'Advance received' ELSE 'Payment received' END,
             'payment', COALESCE(NULLIF(p.reference, ''), 'PAY-' || p.id),
             p.payment_method || ' - ' || printf('%.2f', p.amount) || COALESCE(' - ' || NULLIF(p.notes, ''), ''), NULL
        FROM payments p WHERE p.customer_id = @c
      UNION ALL
      SELECT COALESCE(v.submission_date, v.application_date), 'Visa submitted', 'visa', v.application_number, v.visa_type, NULL
        FROM visa_applications v WHERE v.customer_id = @c AND COALESCE(v.submission_date, v.application_date) IS NOT NULL
      UNION ALL
      SELECT v.approval_date, 'Visa issued', 'visa', v.application_number, v.visa_type, NULL
        FROM visa_applications v WHERE v.customer_id = @c AND v.approval_date IS NOT NULL AND v.status = 'Approved'
      UNION ALL
      SELECT f.created_at, 'Flight booked', 'flight', COALESCE(f.pnr, f.flight_number), f.departure_airport || ' > ' || f.arrival_airport, NULL
        FROM flights f JOIN bookings bk ON bk.id = f.booking_id WHERE bk.customer_id = @c
      UNION ALL
      SELECT h.created_at, 'Hotel booked', 'hotel', COALESCE(h.confirmation_number, h.booking_reference), h.hotel_name, NULL
        FROM hotels h JOIN bookings bk ON bk.id = h.booking_id WHERE bk.customer_id = @c
      UNION ALL
      SELECT t.created_at, 'Transport arranged', 'transport', t.vehicle_number, t.pickup_location || ' > ' || t.drop_location, NULL
        FROM transportation t JOIN bookings bk ON bk.id = t.booking_id WHERE bk.customer_id = @c
      UNION ALL
      SELECT d.uploaded_at, 'Document uploaded', 'document', d.file_name, d.document_type, NULL
        FROM documents d WHERE d.customer_id = @c
      UNION ALL
      SELECT fu.created_at, 'Follow-up scheduled', 'followup', NULL, fu.notes, u.full_name
        FROM follow_ups fu LEFT JOIN users u ON u.id = fu.assigned_user_id WHERE fu.customer_id = @c
    )
    SELECT * FROM ev WHERE at IS NOT NULL`;

  const all = db.prepare(`${sql} ORDER BY at DESC`).all({ c: customerId });
  const size = Number(pageSize) || all.length || 1;
  const p = Math.max(1, Number(page) || 1);
  return { items: all.slice((p - 1) * size, p * size), total: all.length, page: p, pageSize: size };
}

/** One call for the dossier page: header + summary + timeline preview. */
function getDossier(customerId, opts = {}) {
  return {
    header: header(customerId),
    summary: summary(customerId, opts),
    currencies: bookingCurrencies(customerId)
  };
}

module.exports = {
  customerCode,
  header,
  summary,
  bookingHistory,
  bookingCurrencies,
  timeline,
  getDossier
};
