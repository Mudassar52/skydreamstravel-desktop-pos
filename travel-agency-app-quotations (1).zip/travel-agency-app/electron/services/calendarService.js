const { getDb } = require('../../src/database/db');

const EVENT_TYPES = [
  'FlightDeparture', 'FlightArrival', 'HotelCheckIn', 'HotelCheckOut', 'VisaDeadline',
  'PaymentDeadline', 'SupplierPaymentDeadline', 'BookingDeadline', 'CustomerFollowUp', 'StaffTask', 'TravelDate'
];

const DEADLINE_TYPE_TO_EVENT = {
  Visa: 'VisaDeadline',
  Payment: 'PaymentDeadline',
  Reservation: 'BookingDeadline',
  Confirmation: 'BookingDeadline',
  Ticketing: 'BookingDeadline',
  Cancellation: 'BookingDeadline',
  HotelCancellation: 'BookingDeadline'
};

/**
 * Pulls every calendar-relevant event from its real source table within
 * [from, to] and normalizes it to {id, type, title, date, bookingId,
 * customerId, status, meta}, so the calendar always reflects live data
 * rather than a separate events table that could drift out of sync.
 */
function list({ from, to, eventType = 'All', destination = null, customerId = null, bookingId = null } = {}) {
  const db = getDb();
  const range = { from: from || '1970-01-01', to: to || '2999-12-31' };
  const events = [];

  const bookingFilter = bookingId ? 'AND b.id = @bookingId' : '';
  const customerFilter = customerId ? 'AND b.customer_id = @customerId' : '';
  const destinationFilter = destination ? 'AND b.destination LIKE @destination' : '';
  const params = { ...range, bookingId, customerId, destination: destination ? `%${destination}%` : null };

  // Flights
  db.prepare(
    `SELECT f.id, f.departure_date, f.arrival_date, f.airline, f.departure_airport, f.arrival_airport,
      f.booking_id, b.booking_code, b.customer_id, c.full_name AS customer_name, b.destination
     FROM flights f JOIN bookings b ON b.id = f.booking_id JOIN customers c ON c.id = b.customer_id
     WHERE ((f.departure_date BETWEEN @from AND @to) OR (f.arrival_date BETWEEN @from AND @to))
       ${bookingFilter} ${customerFilter} ${destinationFilter}`
  ).all(params).forEach((f) => {
    if (f.departure_date) events.push({ id: `flight-dep-${f.id}`, type: 'FlightDeparture', title: `${f.airline || 'Flight'} departs ${f.departure_airport || ''}`.trim(), date: f.departure_date, bookingId: f.booking_id, bookingCode: f.booking_code, customerId: f.customer_id, customerName: f.customer_name, destination: f.destination });
    if (f.arrival_date) events.push({ id: `flight-arr-${f.id}`, type: 'FlightArrival', title: `${f.airline || 'Flight'} arrives ${f.arrival_airport || ''}`.trim(), date: f.arrival_date, bookingId: f.booking_id, bookingCode: f.booking_code, customerId: f.customer_id, customerName: f.customer_name, destination: f.destination });
  });

  // Hotels
  db.prepare(
    `SELECT h.id, h.check_in, h.check_out, h.hotel_name, h.city,
      h.booking_id, b.booking_code, b.customer_id, c.full_name AS customer_name, b.destination
     FROM hotels h JOIN bookings b ON b.id = h.booking_id JOIN customers c ON c.id = b.customer_id
     WHERE ((h.check_in BETWEEN @from AND @to) OR (h.check_out BETWEEN @from AND @to))
       ${bookingFilter} ${customerFilter} ${destinationFilter}`
  ).all(params).forEach((h) => {
    if (h.check_in) events.push({ id: `hotel-in-${h.id}`, type: 'HotelCheckIn', title: `Check-in — ${h.hotel_name || h.city || 'Hotel'}`, date: h.check_in, bookingId: h.booking_id, bookingCode: h.booking_code, customerId: h.customer_id, customerName: h.customer_name, destination: h.destination });
    if (h.check_out) events.push({ id: `hotel-out-${h.id}`, type: 'HotelCheckOut', title: `Check-out — ${h.hotel_name || h.city || 'Hotel'}`, date: h.check_out, bookingId: h.booking_id, bookingCode: h.booking_code, customerId: h.customer_id, customerName: h.customer_name, destination: h.destination });
  });

  // Deadlines (visa/payment/booking-related)
  db.prepare(
    `SELECT d.id, d.deadline_type, d.title, d.due_date, d.status,
      d.booking_id, b.booking_code, b.customer_id, c.full_name AS customer_name, b.destination
     FROM deadlines d
     LEFT JOIN bookings b ON b.id = d.booking_id
     LEFT JOIN customers c ON c.id = b.customer_id
     WHERE d.due_date BETWEEN @from AND @to ${bookingFilter} ${customerFilter} ${destinationFilter}`
  ).all(params).forEach((d) => {
    events.push({
      id: `deadline-${d.id}`, type: DEADLINE_TYPE_TO_EVENT[d.deadline_type] || 'BookingDeadline',
      title: d.title || `${d.deadline_type} Deadline`, date: d.due_date, bookingId: d.booking_id,
      bookingCode: d.booking_code, customerId: d.customer_id, customerName: d.customer_name,
      destination: d.destination, status: d.status
    });
  });

  // Customer follow-ups
  db.prepare(
    `SELECT f.id, f.follow_up_date, f.status, f.customer_id, c.full_name AS customer_name, f.booking_id, b.booking_code, b.destination
     FROM follow_ups f
     LEFT JOIN customers c ON c.id = f.customer_id
     LEFT JOIN bookings b ON b.id = f.booking_id
     WHERE f.follow_up_date BETWEEN @from AND @to ${bookingFilter} ${customerFilter} ${destinationFilter}`
  ).all(params).forEach((f) => {
    events.push({ id: `followup-${f.id}`, type: 'CustomerFollowUp', title: `Follow-up — ${f.customer_name || 'Customer'}`, date: f.follow_up_date, bookingId: f.booking_id, bookingCode: f.booking_code, customerId: f.customer_id, customerName: f.customer_name, destination: f.destination, status: f.status });
  });

  // Staff tasks
  db.prepare(
    `SELECT t.id, t.title, t.due_date, t.status, t.booking_id, b.booking_code, t.customer_id, c.full_name AS customer_name, b.destination
     FROM tasks t
     LEFT JOIN bookings b ON b.id = t.booking_id
     LEFT JOIN customers c ON c.id = t.customer_id
     WHERE t.due_date BETWEEN @from AND @to ${bookingFilter} ${customerFilter} ${destinationFilter}`
  ).all(params).forEach((t) => {
    events.push({ id: `task-${t.id}`, type: 'StaffTask', title: t.title, date: t.due_date, bookingId: t.booking_id, bookingCode: t.booking_code, customerId: t.customer_id, customerName: t.customer_name, destination: t.destination, status: t.status });
  });

  // Travel dates (booking departure/return)
  db.prepare(
    `SELECT b.id, b.departure_date, b.return_date, b.booking_code, b.customer_id, c.full_name AS customer_name, b.destination
     FROM bookings b JOIN customers c ON c.id = b.customer_id
     WHERE ((b.departure_date BETWEEN @from AND @to) OR (b.return_date BETWEEN @from AND @to))
       ${bookingId ? 'AND b.id = @bookingId' : ''} ${customerId ? 'AND b.customer_id = @customerId' : ''} ${destinationFilter}`
  ).all(params).forEach((b) => {
    if (b.departure_date) events.push({ id: `travel-dep-${b.id}`, type: 'TravelDate', title: `Departure — ${b.booking_code}`, date: b.departure_date, bookingId: b.id, bookingCode: b.booking_code, customerId: b.customer_id, customerName: b.customer_name, destination: b.destination });
    if (b.return_date) events.push({ id: `travel-ret-${b.id}`, type: 'TravelDate', title: `Return — ${b.booking_code}`, date: b.return_date, bookingId: b.id, bookingCode: b.booking_code, customerId: b.customer_id, customerName: b.customer_name, destination: b.destination });
  });

  const filtered = eventType === 'All' ? events : events.filter((e) => e.type === eventType);
  return filtered.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

module.exports = { EVENT_TYPES, list };
