const { dialog } = require('electron');
const fs = require('fs');
const pdfService = require('./pdfService');
const { escapeHtml } = require('./templateEngine');

function csvEscape(value) {
  const str = value === null || value === undefined ? '' : String(value);
  if (/[",\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
  return str;
}

function toCsv({ columns, rows }) {
  const header = columns.map((c) => csvEscape(c.label)).join(',');
  const lines = rows.map((row) => columns.map((c) => csvEscape(row[c.key])).join(','));
  return [header, ...lines].join('\r\n');
}

async function exportCsv({ title, columns, rows }) {
  const csv = toCsv({ columns, rows });
  const result = await dialog.showSaveDialog({
    title: 'Save Report as CSV',
    defaultPath: `${(title || 'report').replace(/[^\w\- ]/g, '')}.csv`,
    filters: [{ name: 'CSV Files', extensions: ['csv'] }]
  });
  if (result.canceled || !result.filePath) return { saved: false };
  fs.writeFileSync(result.filePath, csv, 'utf-8');
  return { saved: true, filePath: result.filePath };
}

function moneyFormat(n) {
  return `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
}

function buildReportHtml({ title, columns, rows, totals }) {
  const headerCells = columns.map((c) => `<th>${escapeHtml(c.label)}</th>`).join('');
  const bodyRows = rows
    .map((row) => {
      const cells = columns
        .map((c) => {
          const raw = row[c.key];
          const display = c.money ? moneyFormat(raw) : (raw ?? '');
          return `<td class="${c.money ? 'num' : ''}">${escapeHtml(display)}</td>`;
        })
        .join('');
      return `<tr>${cells}</tr>`;
    })
    .join('');

  let totalsRow = '';
  if (totals) {
    const cells = columns
      .map((c) => (totals[c.key] !== undefined ? `<td class="num">${escapeHtml(c.money ? moneyFormat(totals[c.key]) : totals[c.key])}</td>` : '<td></td>'))
      .join('');
    totalsRow = `<tr class="totals-row">${cells}</tr>`;
  }

  return `<!doctype html>
<html><head><meta charset="utf-8"><style>
  @page { size: A4 landscape; margin: 14mm; }
  body { font-family: Arial, Helvetica, sans-serif; color: #16233F; font-size: 11px; }
  h1 { font-size: 17px; color: #1E4FA3; margin-bottom: 4px; }
  .meta { color: #5B6B8C; font-size: 10.5px; margin-bottom: 14px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 6px 8px; border-bottom: 1px solid #E4E9F2; text-align: left; }
  th { background: #EAF1FC; color: #1E4FA3; text-transform: uppercase; font-size: 9.5px; }
  td.num, th.num { text-align: right; }
  .totals-row td { font-weight: 700; border-top: 2px solid #1E4FA3; }
</style></head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <div class="meta">Generated ${escapeHtml(new Date().toLocaleString())} &middot; ${rows.length} row${rows.length === 1 ? '' : 's'}</div>
  <table>
    <thead><tr>${headerCells}</tr></thead>
    <tbody>${bodyRows}</tbody>
    ${totalsRow ? `<tfoot>${totalsRow}</tfoot>` : ''}
  </table>
</body></html>`;
}

async function exportPdf(reportData) {
  const html = buildReportHtml(reportData);
  return pdfService.saveInvoicePdf(html, `${(reportData.title || 'report').replace(/[^\w\- ]/g, '')}.pdf`);
}

async function printReport(reportData) {
  const html = buildReportHtml(reportData);
  return pdfService.printHtml(html);
}

/**
 * A single PDF/print document containing several section tables one after
 * another - the Custom Report Builder's composed output (master prompt
 * section 33: title, date range, filters summary, per-section subtotal,
 * grand totals, generated-on footer). Each section is {title, columns, rows, totals}.
 */
function buildMultiSectionReportHtml({ title, dateRangeLabel, filtersSummary, sections, grandTotals, orientation = 'landscape' }) {
  const pageSize = orientation === 'portrait' ? 'A4 portrait' : 'A4 landscape';
  const sectionsHtml = sections
    .map((sec) => {
      if (!sec.rows || sec.rows.length === 0) {
        return `<h2>${escapeHtml(sec.title)}</h2><p class="empty">No records.</p>`;
      }
      const headerCells = sec.columns.map((c) => `<th class="${c.money ? 'num' : ''}">${escapeHtml(c.label)}</th>`).join('');
      const bodyRows = sec.rows
        .map((row) => `<tr>${sec.columns.map((c) => {
          const raw = row[c.key];
          const display = c.money ? moneyFormat(raw) : (raw ?? '');
          return `<td class="${c.money ? 'num' : ''}">${escapeHtml(display)}</td>`;
        }).join('')}</tr>`)
        .join('');
      let totalsRow = '';
      if (sec.totals) {
        const cells = sec.columns.map((c) => (sec.totals[c.key] !== undefined ? `<td class="num">${escapeHtml(c.money ? moneyFormat(sec.totals[c.key]) : sec.totals[c.key])}</td>` : '<td></td>')).join('');
        totalsRow = `<tfoot><tr class="totals-row">${cells}</tr></tfoot>`;
      }
      return `<h2>${escapeHtml(sec.title)}</h2>
        <table><thead><tr>${headerCells}</tr></thead><tbody>${bodyRows}</tbody>${totalsRow}</table>`;
    })
    .join('');

  const grandTotalsHtml = grandTotals && Object.keys(grandTotals).length
    ? `<div class="grand-totals"><strong>Totals:</strong> ${Object.entries(grandTotals).map(([k, v]) => `${escapeHtml(k)}: ${typeof v === 'number' ? moneyFormat(v) : escapeHtml(v)}`).join(' &nbsp;|&nbsp; ')}</div>`
    : '';

  return `<!doctype html>
<html><head><meta charset="utf-8"><style>
  @page { size: ${pageSize}; margin: 14mm; }
  body { font-family: Arial, Helvetica, sans-serif; color: #16233F; font-size: 10.5px; }
  h1 { font-size: 18px; color: #1E4FA3; margin-bottom: 2px; }
  h2 { font-size: 13px; color: #1E4FA3; margin: 18px 0 6px; border-bottom: 2px solid #1E4FA3; padding-bottom: 3px; }
  .meta { color: #5B6B8C; font-size: 10px; margin-bottom: 6px; }
  .empty { color: #9aa6bd; font-size: 11px; margin: 4px 0 10px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 4px; }
  th, td { padding: 5px 7px; border-bottom: 1px solid #E4E9F2; text-align: left; }
  th { background: #EAF1FC; color: #1E4FA3; text-transform: uppercase; font-size: 9px; }
  td.num, th.num { text-align: right; }
  .totals-row td { font-weight: 700; border-top: 2px solid #1E4FA3; }
  .grand-totals { margin-top: 16px; padding-top: 10px; border-top: 2px solid #1E4FA3; font-size: 11.5px; }
  .footer { margin-top: 24px; font-size: 9px; color: #9aa6bd; }
</style></head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <div class="meta">${dateRangeLabel ? escapeHtml(dateRangeLabel) + ' &middot; ' : ''}Generated ${escapeHtml(new Date().toLocaleString())}</div>
  ${filtersSummary ? `<div class="meta">${escapeHtml(filtersSummary)}</div>` : ''}
  ${sectionsHtml}
  ${grandTotalsHtml}
  <div class="footer">Custom Report Builder - this report reflects live data at the time it was generated.</div>
</body></html>`;
}

async function exportMultiSectionPdf(reportData) {
  const html = buildMultiSectionReportHtml(reportData);
  return pdfService.saveInvoicePdf(html, `${(reportData.title || 'report').replace(/[^\w\- ]/g, '')}.pdf`);
}

async function printMultiSectionReport(reportData) {
  const html = buildMultiSectionReportHtml(reportData);
  return pdfService.printHtml(html);
}

module.exports = {
  toCsv, exportCsv, exportPdf, printReport, buildReportHtml,
  buildMultiSectionReportHtml, exportMultiSectionPdf, printMultiSectionReport
};
