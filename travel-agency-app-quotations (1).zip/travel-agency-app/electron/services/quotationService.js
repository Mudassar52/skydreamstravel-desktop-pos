const { getDb } = require('../../src/database/db');

// 'Converted' is set by the system when a quotation becomes a booking; the other five are chosen by staff.
const STATUSES = ['Draft', 'Sent', 'Accepted', 'Rejected', 'Expired', 'Converted'];
const TYPES = ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transport', 'Custom Package'];
const TRAVEL_CLASSES = ['Economy', 'Business', 'First Class'];
const CATEGORIES = ['Flight', 'Hotel', 'Visa', 'Transport', 'Package', 'Other'];
const CURRENCIES = ['PKR', 'SAR', 'USD', 'AED', 'GBP', 'EUR'];
const SENT_VIA = ['WhatsApp', 'Email', 'Printed', 'Other'];
const UMRAH_DETAIL_KEYS = ['makkah_hotel', 'madinah_hotel', 'room_type', 'makkah_nights', 'madinah_nights', 'visa_details', 'transport_type', 'ziyarat'];

// Quotation type -> booking type used when converting.
const BOOKING_TYPE_FOR = {
  Umrah: 'Umrah', Hajj: 'Hajj', Tour: 'Tour', Flight: 'Flight', Hotel: 'Hotel', Visa: 'Visa',
  Transport: 'Transportation', 'Custom Package': 'Custom'
};

// Columns the form writes directly. Totals (subtotal, discount, selling_price, balance_due, cost,
// expected_profit) are NOT in this list - they are always computed here, never trusted from the screen.
const HEADER_FIELDS = [
  'customer_id', 'lead_id', 'booking_id', 'supplier_id', 'quotation_type', 'quotation_date', 'customer_phone',
  'departure_city', 'destination', 'travel_date_from', 'travel_date_to', 'total_nights',
  'adults', 'children', 'infants', 'travel_class', 'notes',
  'currency', 'terms', 'valid_until', 'status', 'sent_via', 'sent_at', 'customer_response', 'internal_notes'
];
const NULLABLE_ID_FIELDS = ['customer_id', 'lead_id', 'booking_id', 'supplier_id'];
const PRICING_INPUTS = ['discount_type', 'discount_value', 'advance_required', 'tax'];

const pad = (n) => String(n).padStart(2, '0');
const localToday = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const localNow = () => { const d = new Date(); return `${localToday()}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const num = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const blankToNull = (v) => (v === '' || v === undefined ? null : v);
const nightsBetween = (from, to) => Math.round((new Date(to) - new Date(from)) / 86400000);

function nextQuotationNumber(db) {
  const last = db.prepare('SELECT quotation_number FROM quotations ORDER BY id DESC LIMIT 1').get();
  let nextNum = 1;
  if (last?.quotation_number) {
    const match = last.quotation_number.match(/(\d+)$/);
    if (match) nextNum = Number(match[1]) + 1;
  }
  return `QT-${String(nextNum).padStart(6, '0')}`;
}

/** A Sent quotation whose "valid until" date has passed becomes Expired. Cheap; runs before every read. */
function expireOverdue(db) {
  db.prepare(
    `UPDATE quotations SET status = 'Expired', updated_at = datetime('now')
     WHERE status = 'Sent' AND valid_until IS NOT NULL AND valid_until <> '' AND valid_until < ?`
  ).run(localToday());
}

function normaliseItem(raw, index, opts, previousById) {
  const row = index + 1;
  const name = String(raw.name || '').trim();
  if (!name) throw new Error(`Service row ${row}: enter a service / package name.`);
  const quantity = raw.quantity === undefined || raw.quantity === '' ? 1 : num(raw.quantity);
  if (!(quantity > 0)) throw new Error(`Service row ${row}: quantity must be more than zero.`);
  const unitPrice = num(raw.unit_price);
  if (unitPrice < 0) throw new Error(`Service row ${row}: unit price cannot be negative.`);
  const gross = quantity * unitPrice;
  const discount = num(raw.discount);
  if (discount < 0) throw new Error(`Service row ${row}: discount cannot be negative.`);
  if (discount > gross + 0.0001) throw new Error(`Service row ${row}: discount cannot be more than the row amount.`);

  // Internal cost. A user without View Profit never sees it, so what the screen sends back is blank - keep what is stored.
  let costPrice = num(raw.cost_price);
  if (costPrice < 0) throw new Error(`Service row ${row}: cost price cannot be negative.`);
  if (!opts.canSeeCost) {
    const prev = raw.id ? previousById.get(Number(raw.id)) : null;
    costPrice = prev ? num(prev.cost_price) : 0;
  }

  let details = null;
  if (raw.details && typeof raw.details === 'object') {
    const kept = {};
    for (const k of UMRAH_DETAIL_KEYS) {
      const v = raw.details[k];
      if (v !== undefined && v !== null && String(v).trim() !== '') kept[k] = typeof v === 'number' ? v : String(v).trim();
    }
    if (Object.keys(kept).length) details = JSON.stringify(kept);
  }

  return {
    // Only an id that really belongs to this quotation is kept; the row is then updated in place (stable ids).
    id: raw.id && previousById.has(Number(raw.id)) ? Number(raw.id) : null,
    category: CATEGORIES.includes(raw.category) ? raw.category : 'Other',
    name,
    description: blankToNull(raw.description),
    service_date: blankToNull(raw.service_date),
    quantity,
    unit: blankToNull(raw.unit),
    unit_price: unitPrice,
    discount: r2(discount),
    line_total: r2(gross - discount),
    cost_price: costPrice,
    details
  };
}

/**
 * Validates the merged header + service rows and works out every total.
 * `m` is the full merged record (existing row overlaid with the payload on update).
 * Returns { row, items } where `row` has only the columns to write.
 */
function finalise(m, itemsIn, opts, previousById) {
  if (!m.customer_id) throw new Error('A customer must be selected.');
  if (m.status && !STATUSES.includes(m.status)) throw new Error('Invalid quotation status.');
  if (m.quotation_type && !TYPES.includes(m.quotation_type)) throw new Error('Invalid quotation type.');
  if (m.currency && !CURRENCIES.includes(m.currency)) throw new Error('Invalid currency.');
  if (m.travel_class && !TRAVEL_CLASSES.includes(m.travel_class)) throw new Error('Invalid travel class.');
  if (m.sent_via && !SENT_VIA.includes(m.sent_via)) throw new Error('Invalid "sent via" option.');
  if (m.travel_date_from && m.travel_date_to && new Date(m.travel_date_to) < new Date(m.travel_date_from)) {
    throw new Error('Travel end date cannot be before the start date.');
  }
  if (m.quotation_date && m.valid_until && m.valid_until < m.quotation_date) {
    throw new Error('"Valid until" cannot be before the quotation date.');
  }
  for (const field of ['adults', 'children', 'infants']) {
    const v = m[field] === null || m[field] === undefined || m[field] === '' ? 0 : Number(m[field]);
    if (!Number.isInteger(v) || v < 0) throw new Error(`Number of ${field} must be a whole number, zero or more.`);
    m[field] = v;
  }
  if (m.total_nights !== null && m.total_nights !== undefined && m.total_nights !== '') {
    const n = Number(m.total_nights);
    if (!Number.isInteger(n) || n < 0) throw new Error('Total nights must be a whole number, zero or more.');
    m.total_nights = n;
  } else if (m.travel_date_from && m.travel_date_to) {
    m.total_nights = nightsBetween(m.travel_date_from, m.travel_date_to);
  } else {
    m.total_nights = null;
  }

  const tax = num(m.tax);
  if (tax < 0) throw new Error('Taxes / additional charges cannot be negative.');

  let items = null;
  let subtotal; let discount; let total; let cost; let hasCost;
  let discountType = m.discount_type === 'percent' ? 'percent' : 'amount';
  let discountValue = num(m.discount_value);

  if (Array.isArray(itemsIn)) {
    if (itemsIn.length === 0) throw new Error('Add at least one service row to the quotation.');
    items = itemsIn.map((it, i) => normaliseItem(it, i, opts, previousById));
    subtotal = r2(items.reduce((s, it) => s + it.line_total, 0));
    if (discountValue < 0) throw new Error('Overall discount cannot be negative.');
    if (discountType === 'percent' && discountValue > 100) throw new Error('Overall discount cannot be more than 100%.');
    discount = discountType === 'percent' ? r2((subtotal * discountValue) / 100) : r2(discountValue);
    if (discount > subtotal + 0.0001) throw new Error('Overall discount cannot be more than the subtotal.');
    total = r2(subtotal - discount + tax);
    cost = r2(items.reduce((s, it) => s + it.quantity * it.cost_price, 0));
    hasCost = items.some((it) => it.cost_price > 0);
  } else {
    // Older callers that only pass a single selling price (no service rows).
    total = num(m.selling_price);
    if (total < 0 || num(m.cost) < 0) throw new Error('Cost and selling price cannot be negative.');
    subtotal = total;
    discount = num(m.discount);
    discountType = 'amount';
    discountValue = discount;
    cost = num(m.cost);
    hasCost = cost > 0;
  }

  const advance = num(m.advance_required);
  if (advance < 0) throw new Error('Advance required cannot be negative.');
  if (advance > total + 0.0001) throw new Error('Advance required cannot be more than the quotation total.');

  // Sending a quotation stamps the time if the person did not enter one.
  if (m.status === 'Sent' && !m.sent_at) m.sent_at = localNow();

  const row = {
    ...Object.fromEntries(HEADER_FIELDS.map((f) => [f, m[f] === undefined ? null : m[f]])),
    tax,
    discount_type: discountType,
    discount_value: discountValue,
    advance_required: r2(advance),
    subtotal,
    discount,
    selling_price: total,
    balance_due: r2(total - advance),
    cost,
    expected_profit: hasCost ? r2(total - cost) : null
  };
  return { row, items };
}

/**
 * Saves the service rows. Rows that already exist (matched by id) are updated in place so their ids - and the
 * internal cost a limited user cannot see - survive; new rows are inserted; rows no longer sent are deleted.
 */
function saveItems(db, quotationId, items) {
  const insert = db.prepare(
    `INSERT INTO quotation_items (quotation_id, sort_order, category, name, description, service_date, quantity, unit, unit_price, discount, line_total, cost_price, details)
     VALUES (@quotation_id, @sort_order, @category, @name, @description, @service_date, @quantity, @unit, @unit_price, @discount, @line_total, @cost_price, @details)`
  );
  const updateRow = db.prepare(
    `UPDATE quotation_items SET sort_order = @sort_order, category = @category, name = @name, description = @description,
       service_date = @service_date, quantity = @quantity, unit = @unit, unit_price = @unit_price, discount = @discount,
       line_total = @line_total, cost_price = @cost_price, details = @details
     WHERE id = @id AND quotation_id = @quotation_id`
  );
  const kept = [];
  items.forEach((it, i) => {
    const params = { ...it, quotation_id: quotationId, sort_order: i };
    if (it.id) { updateRow.run(params); kept.push(it.id); } else { const { id, ...rest } = params; kept.push(Number(insert.run(rest).lastInsertRowid)); }
  });
  const existing = db.prepare('SELECT id FROM quotation_items WHERE quotation_id = ?').all(quotationId).map((r) => r.id);
  const del = db.prepare('DELETE FROM quotation_items WHERE id = ?');
  for (const id of existing) if (!kept.includes(id)) del.run(id);
}

function list({ search = '', status = 'All', type = 'All', page = 1, pageSize = 15 } = {}) {
  const db = getDb();
  expireOverdue(db);
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(q.quotation_number LIKE @q OR c.full_name LIKE @q OR q.destination LIKE @q OR q.customer_phone LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') { conditions.push('q.status = @status'); params.status = status; }
  if (type && type !== 'All') { conditions.push('q.quotation_type = @type'); params.type = type; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM quotations q JOIN customers c ON c.id = q.customer_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT q.*, c.full_name AS customer_name, s.name AS supplier_name
       FROM quotations q
       JOIN customers c ON c.id = q.customer_id
       LEFT JOIN suppliers s ON s.id = q.supplier_id
       ${where} ORDER BY q.created_at DESC, q.id DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  expireOverdue(db);
  const row = db
    .prepare(
      `SELECT q.*, c.full_name AS customer_name, s.name AS supplier_name,
              b.booking_code AS converted_booking_code, rb.booking_code AS booking_code,
              l.lead_code AS lead_code, u.full_name AS prepared_by_name
       FROM quotations q
       JOIN customers c ON c.id = q.customer_id
       LEFT JOIN suppliers s ON s.id = q.supplier_id
       LEFT JOIN bookings b ON b.id = q.converted_booking_id
       LEFT JOIN bookings rb ON rb.id = q.booking_id
       LEFT JOIN leads l ON l.id = q.lead_id
       LEFT JOIN users u ON u.id = q.created_by
       WHERE q.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Quotation not found.');

  const items = db
    .prepare('SELECT * FROM quotation_items WHERE quotation_id = ? ORDER BY sort_order, id')
    .all(id)
    .map((it) => {
      let details = {};
      try { details = it.details ? JSON.parse(it.details) : {}; } catch (_) { details = {}; }
      return { ...it, details };
    });

  const travellers = db
    .prepare(`SELECT t.* FROM quotation_travellers qt JOIN travellers t ON t.id = qt.traveller_id WHERE qt.quotation_id = ?`)
    .all(id);

  return { ...row, items, travellers };
}

/** Bookings and inquiries that belong to a customer, for the two optional reference dropdowns. */
function referenceOptions({ customer_id } = {}) {
  const db = getDb();
  if (!customer_id) return { bookings: [], leads: [] };
  const customer = db.prepare('SELECT phone, whatsapp FROM customers WHERE id = ?').get(customer_id);
  const bookings = db
    .prepare(`SELECT id, booking_code, booking_type, destination FROM bookings WHERE customer_id = ? ORDER BY created_at DESC LIMIT 100`)
    .all(customer_id)
    .map((b) => ({ id: b.id, label: `${b.booking_code} — ${[b.booking_type, b.destination].filter(Boolean).join(' · ')}` }));

  const phones = [customer && customer.phone, customer && customer.whatsapp].filter(Boolean);
  const leads = db
    .prepare(
      `SELECT id, lead_code, service_type, destination, travel_date FROM leads
       WHERE converted_customer_id = @c ${phones.length ? 'OR phone IN (' + phones.map((_, i) => `@p${i}`).join(',') + ')' : ''}
       ORDER BY created_at DESC LIMIT 100`
    )
    .all({ c: customer_id, ...Object.fromEntries(phones.map((p, i) => [`p${i}`, p])) })
    .map((l) => ({
      id: l.id,
      label: `${l.lead_code} — ${[l.service_type, l.destination].filter(Boolean).join(' · ') || 'Inquiry'}`,
      destination: l.destination, travel_date: l.travel_date, service_type: l.service_type
    }));
  return { bookings, leads };
}

function mergeForSave(base, payload, opts) {
  const m = { ...base };
  for (const f of [...HEADER_FIELDS, ...PRICING_INPUTS, 'selling_price', 'discount']) {
    if (payload[f] !== undefined) m[f] = payload[f];
  }
  if (opts.canSeeCost && payload.cost !== undefined) m.cost = payload.cost;
  for (const f of HEADER_FIELDS) if (typeof m[f] === 'string' && !NULLABLE_ID_FIELDS.includes(f)) m[f] = blankToNull(m[f]);
  for (const f of NULLABLE_ID_FIELDS) m[f] = m[f] === '' || m[f] === undefined || m[f] === null ? null : Number(m[f]);
  return m;
}

function create(payload, opts = {}) {
  const options = { canSeeCost: opts.canSeeCost !== false, userId: opts.userId || null };
  const db = getDb();

  const m = mergeForSave(
    { status: 'Draft', currency: 'PKR', quotation_type: 'Custom Package', quotation_date: localToday(), adults: 1, children: 0, infants: 0, cost: 0 },
    payload, options
  );
  if (!m.quotation_date) m.quotation_date = localToday();
  if (!options.canSeeCost) m.cost = 0;
  const { row, items } = finalise(m, payload.items, options, new Map());

  if (!db.prepare('SELECT id FROM customers WHERE id = ?').get(row.customer_id)) throw new Error('Selected customer does not exist.');

  const tx = db.transaction(() => {
    const number = nextQuotationNumber(db);
    const cols = ['quotation_number', 'created_by', 'revision_number', ...Object.keys(row)];
    const result = db
      .prepare(`INSERT INTO quotations (${cols.join(', ')}) VALUES (${cols.map((c) => `@${c}`).join(', ')})`)
      .run({ ...row, quotation_number: number, created_by: options.userId, revision_number: 0 });
    const quotationId = result.lastInsertRowid;

    if (items) saveItems(db, quotationId, items);

    if (Array.isArray(payload.traveller_ids)) {
      for (const travellerId of payload.traveller_ids) {
        db.prepare('INSERT INTO quotation_travellers (quotation_id, traveller_id) VALUES (?, ?)').run(quotationId, travellerId);
      }
    }

    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Quotation Created', 'quotation', ?, ?)`)
      .run(quotationId, `Quotation ${number} created`);
    return quotationId;
  });

  return { id: tx() };
}

function update(id, payload, opts = {}) {
  const options = { canSeeCost: opts.canSeeCost !== false, userId: opts.userId || null };
  const db = getDb();
  const existing = db.prepare('SELECT * FROM quotations WHERE id = ?').get(id);
  if (!existing) throw new Error('Quotation not found.');
  if (existing.status === 'Converted') throw new Error('A converted quotation cannot be edited.');

  const previousById = new Map(db.prepare('SELECT id, cost_price FROM quotation_items WHERE quotation_id = ?').all(id).map((r) => [r.id, r]));
  const m = mergeForSave(existing, payload, options);
  if (m.status === 'Converted') m.status = existing.status; // only convertToBooking may set this
  if (!m.quotation_date) m.quotation_date = localToday();
  const { row, items } = finalise(m, payload.items, options, previousById);

  const tx = db.transaction(() => {
    const sets = Object.keys(row).map((c) => `${c} = @${c}`);
    sets.push("updated_at = datetime('now')");
    db.prepare(`UPDATE quotations SET ${sets.join(', ')} WHERE id = @id`).run({ ...row, id });

    if (items) saveItems(db, id, items);

    const statusNote = existing.status !== row.status ? ` (status ${existing.status} → ${row.status})` : '';
    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Quotation Updated', 'quotation', ?, ?)`)
      .run(id, `Quotation ${existing.quotation_number} updated${statusNote}`);
  });
  tx();
  return { success: true };
}

/**
 * Starts a new revision of the same quotation: the revision number goes up, the status goes back to Draft so it
 * is re-sent, and the previous total is kept in the audit log. The quotation number stays the same.
 */
function revise(id) {
  const db = getDb();
  const q = db.prepare('SELECT * FROM quotations WHERE id = ?').get(id);
  if (!q) throw new Error('Quotation not found.');
  if (q.status === 'Converted') throw new Error('A converted quotation cannot be revised.');
  const next = (q.revision_number || 0) + 1;
  db.transaction(() => {
    db.prepare(`UPDATE quotations SET revision_number = ?, status = 'Draft', sent_at = NULL, sent_via = NULL, updated_at = datetime('now') WHERE id = ?`).run(next, id);
    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Quotation Revised', 'quotation', ?, ?)`)
      .run(id, `Quotation ${q.quotation_number} revised to Rev ${next} (previous total ${q.currency || 'PKR'} ${q.selling_price}, status ${q.status})`);
  })();
  return { revision_number: next };
}

/**
 * Converts a quotation into a booking, reusing customer, travellers, dates, destination, total and notes without
 * re-entering them. Nothing is recorded as paid: the advance on a quotation is only a proposed payment term, and
 * real receipts are entered in Payments.
 */
function convertToBooking(id) {
  const db = getDb();
  const quotation = db.prepare('SELECT * FROM quotations WHERE id = ?').get(id);
  if (!quotation) throw new Error('Quotation not found.');
  if (quotation.status === 'Converted') return { bookingId: quotation.converted_booking_id, alreadyConverted: true };

  const bookingService = require('./bookingService');

  const tx = db.transaction(() => {
    const passengers = (quotation.adults || 0) + (quotation.children || 0);
    const { id: bookingId } = bookingService.create({
      customer_id: quotation.customer_id,
      booking_type: BOOKING_TYPE_FOR[quotation.quotation_type] || 'Custom',
      destination: quotation.destination,
      departure_date: quotation.travel_date_from,
      return_date: quotation.travel_date_to,
      number_of_passengers: passengers > 0 ? passengers : 1,
      total_price: quotation.selling_price,
      status: 'Pending',
      notes: quotation.notes
    });

    const travellerIds = db.prepare('SELECT traveller_id FROM quotation_travellers WHERE quotation_id = ?').all(id);
    for (const { traveller_id } of travellerIds) {
      db.prepare('INSERT INTO booking_travellers (booking_id, traveller_id) VALUES (?, ?)').run(bookingId, traveller_id);
    }

    db.prepare(`UPDATE quotations SET status = 'Converted', converted_booking_id = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(bookingId, id);

    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Quotation Converted', 'quotation', ?, ?)`)
      .run(id, `Quotation ${quotation.quotation_number} converted to booking #${bookingId}`);

    return bookingId;
  });

  return { bookingId: tx(), alreadyConverted: false };
}

function remove(id) {
  const db = getDb();
  const quotation = db.prepare('SELECT status, quotation_number FROM quotations WHERE id = ?').get(id);
  if (!quotation) throw new Error('Quotation not found.');
  if (quotation.status === 'Converted') throw new Error('A converted quotation cannot be deleted.');
  db.prepare('DELETE FROM quotations WHERE id = ?').run(id);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'quotation', ?, ?)`)
    .run(id, `Quotation ${quotation.quotation_number} deleted`);
  return { success: true };
}

/** Dropdown values for the screen, so the lists live in one place. */
function meta() {
  return { statuses: STATUSES, types: TYPES, travelClasses: TRAVEL_CLASSES, categories: CATEGORIES, currencies: CURRENCIES, sentVia: SENT_VIA };
}

module.exports = {
  STATUSES, TYPES, TRAVEL_CLASSES, CATEGORIES, CURRENCIES, SENT_VIA,
  list, get, create, update, revise, convertToBooking, remove, referenceOptions, meta
};
