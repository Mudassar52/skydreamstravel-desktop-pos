const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const documentCurrency = require('./documentCurrency');
const supplierLedgerService = require('./supplierLedgerService');
const accountService = require('./accountService');
const { deriveStatus } = require('./supplierInvoiceService');
const { assertRecordExists, assertValidDate } = require('./validation');

const PAYMENT_METHODS = ['Bank Transfer', 'Cash', 'Card', 'Cheque', 'Other'];

function validate(payload) {
  if (!payload.supplier_id) throw new Error('A supplier must be selected.');
  if (!(Number(payload.amount) > 0)) throw new Error('Amount must be greater than zero.');
  assertRecordExists('bookings', payload.booking_id, 'booking');
  assertValidDate(payload.payment_date, 'Payment date');
}


function list({ supplierId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (supplierId) {
    conditions.push('sp.supplier_id = @supplierId');
    params.supplierId = supplierId;
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM supplier_payments sp ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT sp.*, s.name AS supplier_name, si.invoice_number, b.booking_code
       FROM supplier_payments sp
       JOIN suppliers s ON s.id = sp.supplier_id
       LEFT JOIN supplier_invoices si ON si.id = sp.supplier_invoice_id
       LEFT JOIN bookings b ON b.id = sp.booking_id
       ${where}
       ORDER BY sp.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const supplier = db.prepare('SELECT id, currency FROM suppliers WHERE id = ?').get(payload.supplier_id);
  if (!supplier) throw new Error('Selected supplier does not exist.');
  periodLock.assertOpen(null, 'This supplier payment');

  const amount = Number(payload.amount);

  // Currency (Phase 21c): a payment against a supplier invoice is in THAT invoice's currency; otherwise what was typed,
  // else the account the money leaves, else the supplier's own, else the base. When the account holds a different
  // currency the amount that really left it must be given as `account_amount` (e.g. USD 1,000 settled by PKR 285,000).
  const accCur = documentCurrency.accountCurrency(db, payload.account_type, payload.account_id);
  const explicit = payload.currency ? String(payload.currency).toUpperCase() : null;
  const linkedSi = payload.supplier_invoice_id ? db.prepare('SELECT currency FROM supplier_invoices WHERE id = ?').get(payload.supplier_invoice_id) : null;
  const invoiceCur = linkedSi && linkedSi.currency ? String(linkedSi.currency).toUpperCase() : null;
  if (invoiceCur && explicit && explicit !== invoiceCur) {
    throw new Error(`That supplier invoice is in ${invoiceCur}, so the payment must be in ${invoiceCur} too (not ${explicit}).`);
  }
  const currency = invoiceCur || explicit || accCur || (supplier.currency ? String(supplier.currency).toUpperCase() : null) || documentCurrency.baseCurrency(db);
  const cross = !!(accCur && accCur !== currency);
  let accountAmount = amount;
  if (cross) {
    accountAmount = Number(payload.account_amount);
    if (!(accountAmount > 0)) throw new Error(`This payment is in ${currency} but the selected account holds ${accCur}. Enter the amount that actually left the account in ${accCur}.`);
  }

  // Double-payment guard: same supplier + reference + amount + method is a resubmission.
  const ref = payload.reference ? String(payload.reference).trim() : '';
  if (ref) {
    const dup = db.prepare(
      `SELECT id FROM supplier_payments WHERE supplier_id = ? AND LOWER(TRIM(reference)) = LOWER(?)
         AND payment_method = ? AND ABS(amount - ?) < 0.005 LIMIT 1`
    ).get(payload.supplier_id, ref, payload.payment_method, amount);
    if (dup) throw new Error(`A payment to this supplier with reference "${ref}" for this amount is already recorded (SPAY-${String(dup.id).padStart(5, '0')}). Use a different reference if this is a separate payment.`);
  }

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO supplier_payments
          (supplier_id, booking_id, supplier_invoice_id, payment_date, amount, currency, payment_method, account_type, account_id, reference, notes, account_amount)
         VALUES (@supplier_id, @booking_id, @supplier_invoice_id, datetime('now'), @amount, @currency, @payment_method, @account_type, @account_id, @reference, @notes, @account_amount)`
      )
      .run({
        supplier_id: payload.supplier_id,
        booking_id: payload.booking_id || null,
        supplier_invoice_id: payload.supplier_invoice_id || null,
        amount,
        currency,
        payment_method: payload.payment_method || 'Bank Transfer',
        account_type: payload.account_type || null,
        account_id: payload.account_id || null,
        reference: payload.reference || null,
        notes: payload.notes || null,
        account_amount: cross ? accountAmount : null
      });
    const paymentId = result.lastInsertRowid;
    let description = `Payment to supplier`;

    if (payload.supplier_invoice_id) {
      const invoice = db.prepare('SELECT * FROM supplier_invoices WHERE id = ?').get(payload.supplier_invoice_id);
      if (!invoice) throw new Error('Selected supplier invoice does not exist.');
      if (invoice.supplier_id !== payload.supplier_id) throw new Error('That invoice does not belong to the selected supplier.');

      const newPaid = invoice.paid_amount + amount;
      if (newPaid > invoice.total) throw new Error('Payment amount would exceed the invoice total.');

      db.prepare(
        `UPDATE supplier_invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(newPaid, invoice.total - newPaid, deriveStatus(invoice.total, newPaid, invoice.due_date), invoice.id);

      description = `Payment — Supplier Invoice ${invoice.invoice_number}`;
    }

    supplierLedgerService.addEntry(db, {
      supplier_id: payload.supplier_id,
      description,
      supplier_invoice_id: payload.supplier_invoice_id || null,
      supplier_payment_id: paymentId,
      credit: amount
    });

    accountService.postTransaction(db, {
      account_type: payload.account_type,
      account_id: payload.account_id,
      amount: accountAmount,
      direction: 'Out',
      transaction_type: 'SupplierPayment',
      reference_type: 'supplier_payments',
      reference_id: paymentId,
      description
    });
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Payment Added', 'supplier_payment', ?, ?)`
    ).run(paymentId, description);

    return paymentId;
  });

  return { id: tx() };
}

function remove(id) {
  const db = getDb();
  const payment = db.prepare('SELECT * FROM supplier_payments WHERE id = ?').get(id);
  if (!payment) throw new Error('Supplier payment not found.');
  periodLock.assertOpen(payment.payment_date, `Supplier payment #${id}`);

  const tx = db.transaction(() => {
    if (payment.supplier_invoice_id) {
      const invoice = db.prepare('SELECT * FROM supplier_invoices WHERE id = ?').get(payment.supplier_invoice_id);
      if (invoice) {
        const restoredPaid = invoice.paid_amount - payment.amount;
        db.prepare(
          `UPDATE supplier_invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(restoredPaid, invoice.total - restoredPaid, deriveStatus(invoice.total, restoredPaid, invoice.due_date), invoice.id);
      }
    }

    db.prepare('UPDATE supplier_ledger_entries SET supplier_payment_id = NULL WHERE supplier_payment_id = ?').run(id);

    supplierLedgerService.addEntry(db, {
      supplier_id: payment.supplier_id,
      description: `Supplier payment #${id} voided`,
      supplier_invoice_id: payment.supplier_invoice_id,
      debit: payment.amount
    });

    accountService.postTransaction(db, {
      account_type: payment.account_type,
      account_id: payment.account_id,
      amount: payment.account_amount || payment.amount,
      direction: 'In',
      transaction_type: 'Reversal',
      reference_type: 'supplier_payments',
      reference_id: id,
      description: `Supplier payment #${id} voided`
    });

    db.prepare('DELETE FROM supplier_payments WHERE id = ?').run(id);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Payment Voided', 'supplier_payment', ?, ?)`
    ).run(id, `Supplier payment #${id} voided`);
  });
  tx();

  return { success: true };
}

module.exports = { PAYMENT_METHODS, list, create, remove };
