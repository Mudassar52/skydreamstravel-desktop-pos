const { getDb } = require('../../src/database/db');

/**
 * Manages a junction table linking a group/tour to customers, and keeps a
 * headcount column on the parent table in sync automatically - so the
 * dashboard and list views never show a stale passenger count.
 *
 * @param {string} junctionTable  e.g. 'umrah_group_passengers'
 * @param {string} groupColumn    e.g. 'group_id'
 * @param {string} parentTable    e.g. 'umrah_groups'
 * @param {string} countColumn    e.g. 'total_passengers'
 */
function makeMembershipService(junctionTable, groupColumn, parentTable, countColumn) {
  function syncCount(db, groupId) {
    const count = db.prepare(`SELECT COUNT(*) AS c FROM ${junctionTable} WHERE ${groupColumn} = ?`).get(groupId).c;
    db.prepare(`UPDATE ${parentTable} SET ${countColumn} = ? WHERE id = ?`).run(count, groupId);
  }

  function list(groupId) {
    const db = getDb();
    return db
      .prepare(
        `SELECT jt.id AS membership_id, jt.notes, c.id AS customer_id, c.full_name, c.phone, c.passport_number
         FROM ${junctionTable} jt
         JOIN customers c ON c.id = jt.customer_id
         WHERE jt.${groupColumn} = ?
         ORDER BY jt.created_at ASC`
      )
      .all(groupId);
  }

  function add(groupId, customerId, notes) {
    const db = getDb();
    const existing = db
      .prepare(`SELECT id FROM ${junctionTable} WHERE ${groupColumn} = ? AND customer_id = ?`)
      .get(groupId, customerId);
    if (existing) throw new Error('This customer is already in the group.');

    db.prepare(`INSERT INTO ${junctionTable} (${groupColumn}, customer_id, notes) VALUES (?, ?, ?)`)
      .run(groupId, customerId, notes || null);
    syncCount(db, groupId);
    return { success: true };
  }

  function remove(membershipId, groupId) {
    const db = getDb();
    db.prepare(`DELETE FROM ${junctionTable} WHERE id = ?`).run(membershipId);
    syncCount(db, groupId);
    return { success: true };
  }

  return { list, add, remove };
}

module.exports = { makeMembershipService };
