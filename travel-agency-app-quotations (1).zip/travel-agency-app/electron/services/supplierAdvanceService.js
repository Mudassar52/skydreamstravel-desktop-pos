const { getDb } = require('../../src/database/db');
const { deriveStatus } = require('./supplierInvoiceService');

// Supplier Advance System (master prompt section 25). Mirrors advanceService.js
// on the customer side: a supplier_payments row with no supplier_invoice_id
// is an unapplied advance paid to the supplier before their invoice arrived.
// supplier_advance_applications tracks how much of it has since been
// allocated to a real supplier invoice - the payment row itself is never
// edited, so every allocation stays traceable and nothing is double counted.

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

/** Unapplied supplier advances (no supplier_invoice_id, no booking_id at receipt - see advanceService.js for why booking-tied ones are excluded). */
// See advanceService.js: one grouped subquery instead of a SUM per row (N+1).
const APPLIED_JOIN = `LEFT JOIN (SELECT supplier_payment_id, SUM(amount) AS applied FROM supplier_advance_applications GROUP BY supplier_payment_id) a ON a.supplier_payment_id = sp.id`;

function shape(row) {
  const applied = Number(row.applied) || 0;
  return { ...row, amount: round2(row.amount), applied: round2(applied), available: round2(row.amount - applied) };
}

function availableAdvances(supplierId) {
  const db = getDb();
  const rows = db.prepare(
    `SELECT sp.*, COALESCE(a.applied, 0) AS applied FROM supplier_payments sp ${APPLIED_JOIN}
     WHERE sp.supplier_id = ? AND sp.supplier_invoice_id IS NULL AND sp.booking_id IS NULL
       AND sp.amount - COALESCE(a.applied, 0) > 0.005
     ORDER BY sp.payment_date ASC`
  ).all(supplierId).map(shape);
  return { rows, total_available: round2(rows.reduce((a, r) => a + r.available, 0)) };
}

function applicationsForInvoice(supplierInvoiceId) {
  const db = getDb();
  return db.prepare(
    `SELECT saa.*, sp.payment_date, sp.reference, sp.payment_method FROM supplier_advance_applications saa
     JOIN supplier_payments sp ON sp.id = saa.supplier_payment_id WHERE saa.supplier_invoice_id = ? ORDER BY saa.applied_at DESC`
  ).all(supplierInvoiceId).map((r) => ({ ...r, amount: round2(r.amount) }));
}

function applyToInvoice({ supplierPaymentId, supplierInvoiceId, amount, notes = null }) {
  const db = getDb();
  const amt = Number(amount);
  if (!(amt > 0)) throw new Error('Amount to apply must be greater than zero.');

  const tx = db.transaction(() => {
    const payment = db.prepare('SELECT * FROM supplier_payments WHERE id = ?').get(supplierPaymentId);
    if (!payment) throw new Error('Supplier advance payment not found.');
    if (payment.supplier_invoice_id) throw new Error('This payment is already tied to a supplier invoice.');
    if (payment.booking_id) throw new Error('This advance is already tied to a booking and is applied automatically when its cost is invoiced.');

    const invoice = db.prepare('SELECT * FROM supplier_invoices WHERE id = ?').get(supplierInvoiceId);
    if (!invoice) throw new Error('Supplier invoice not found.');
    if (invoice.supplier_id !== payment.supplier_id) throw new Error('That advance does not belong to this invoice\'s supplier.');

    const alreadyApplied = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM supplier_advance_applications WHERE supplier_payment_id = ?').get(supplierPaymentId).s;
    const available = payment.amount - alreadyApplied;
    if (amt > available + 0.005) throw new Error(`Only ${round2(available)} is available on this advance.`);
    if (amt > invoice.remaining_amount + 0.005) throw new Error('Amount exceeds what remains on this supplier invoice.');

    db.prepare(
      `INSERT INTO supplier_advance_applications (supplier_payment_id, supplier_invoice_id, amount, notes) VALUES (?, ?, ?, ?)`
    ).run(supplierPaymentId, supplierInvoiceId, amt, notes);

    const newPaid = invoice.paid_amount + amt;
    const newStatus = deriveStatus(invoice.total, newPaid, invoice.due_date);
    db.prepare(
      `UPDATE supplier_invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(newPaid, invoice.total - newPaid, newStatus, invoice.id);

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Advance Applied', 'supplier_invoice', ?, ?)`
    ).run(supplierInvoiceId, `${round2(amt)} of supplier advance #${supplierPaymentId} applied to invoice ${invoice.invoice_number}`);

    return db.prepare('SELECT * FROM supplier_advance_applications WHERE supplier_payment_id = ? AND supplier_invoice_id = ? ORDER BY id DESC LIMIT 1').get(supplierPaymentId, supplierInvoiceId);
  });

  const row = tx();
  return { id: row.id, amount: round2(row.amount) };
}

function reverseApplication(applicationId) {
  const db = getDb();
  const tx = db.transaction(() => {
    const app = db.prepare('SELECT * FROM supplier_advance_applications WHERE id = ?').get(applicationId);
    if (!app) throw new Error('Supplier advance application not found.');

    const invoice = db.prepare('SELECT * FROM supplier_invoices WHERE id = ?').get(app.supplier_invoice_id);
    if (invoice) {
      const restoredPaid = invoice.paid_amount - app.amount;
      if (restoredPaid < -0.005) throw new Error('Cannot reverse: this supplier invoice has since been paid down below this amount.');
      const newStatus = deriveStatus(invoice.total, Math.max(restoredPaid, 0), invoice.due_date);
      db.prepare(
        `UPDATE supplier_invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(Math.max(restoredPaid, 0), invoice.total - Math.max(restoredPaid, 0), newStatus, invoice.id);
    }

    db.prepare('DELETE FROM supplier_advance_applications WHERE id = ?').run(applicationId);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Advance Application Reversed', 'supplier_invoice', ?, ?)`
    ).run(app.supplier_invoice_id, `Supplier advance application #${applicationId} (${round2(app.amount)}) reversed`);
  });
  tx();
  return { success: true };
}

/** Summary for Supplier 360 / Ledger: paid as advance, used, remaining. */
function summary(supplierId) {
  const db = getDb();
  const rows = db.prepare(`SELECT * FROM supplier_payments WHERE supplier_id = ? AND supplier_invoice_id IS NULL`).all(supplierId);
  const paidAsAdvance = round2(rows.reduce((a, r) => a + r.amount, 0));
  const appliedTotal = rows.reduce((a, r) => {
    const applied = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM supplier_advance_applications WHERE supplier_payment_id = ?').get(r.id).s;
    return a + applied;
  }, 0);
  const tiedAtReceipt = rows.filter((r) => r.booking_id).reduce((a, r) => a + r.amount, 0);
  const used = round2(appliedTotal + tiedAtReceipt);
  return { paid_as_advance: paidAsAdvance, used, remaining: round2(paidAsAdvance - used) };
}

/** Every standalone supplier advance across every supplier (Supplier Advances sidebar page). */
function listAll({ search = '', onlyAvailable = false, page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const where = ['sp.supplier_invoice_id IS NULL', 'sp.booking_id IS NULL'];
  const params = {};
  if (search && search.trim()) { where.push('s.name LIKE @q'); params.q = `%${search.trim()}%`; }
  const baseWhere = where.join(' AND ');
  const listWhere = onlyAvailable ? `${baseWhere} AND sp.amount - COALESCE(a.applied, 0) > 0.005` : baseWhere;
  const from = `FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id ${APPLIED_JOIN}`;

  const total = db.prepare(`SELECT COUNT(*) AS c ${from} WHERE ${listWhere}`).get(params).c;
  const totalAvailable = db.prepare(`SELECT COALESCE(SUM(sp.amount - COALESCE(a.applied, 0)), 0) AS s ${from} WHERE ${baseWhere}`).get(params).s;
  const size = Number(pageSize) || 20;
  const rows = db.prepare(
    `SELECT sp.*, s.name AS supplier_name, COALESCE(a.applied, 0) AS applied ${from}
     WHERE ${listWhere} ORDER BY sp.payment_date DESC, sp.id DESC LIMIT @limit OFFSET @offset`
  ).all({ ...params, limit: size, offset: (Math.max(1, Number(page) || 1) - 1) * size }).map(shape);

  return { rows, total, page: Number(page) || 1, pageSize: size, totalAvailable: round2(totalAvailable) };
}

module.exports = { availableAdvances, applicationsForInvoice, applyToInvoice, reverseApplication, summary, listAll };
