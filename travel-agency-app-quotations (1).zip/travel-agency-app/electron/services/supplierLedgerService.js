const { getDb } = require('../../src/database/db');

/**
 * Mirrors ledgerService.js (customer ledger) for suppliers. running_balance
 * is what the agency currently owes the supplier: a debit (a supplier
 * invoice/cost being recorded) increases it, a credit (a payment made to
 * the supplier) decreases it.
 */
function addEntry(db, { supplier_id, description, supplier_invoice_id, supplier_payment_id, debit = 0, credit = 0 }) {
  const last = db
    .prepare('SELECT running_balance FROM supplier_ledger_entries WHERE supplier_id = ? ORDER BY id DESC LIMIT 1')
    .get(supplier_id);
  const prevBalance = last ? last.running_balance : 0;
  const runningBalance = prevBalance + Number(debit || 0) - Number(credit || 0);

  db.prepare(
    `INSERT INTO supplier_ledger_entries (supplier_id, description, supplier_invoice_id, supplier_payment_id, debit, credit, running_balance)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(supplier_id, description, supplier_invoice_id || null, supplier_payment_id || null, debit || 0, credit || 0, runningBalance);

  return runningBalance;
}

function list(supplierId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT l.*, si.invoice_number FROM supplier_ledger_entries l
       LEFT JOIN supplier_invoices si ON si.id = l.supplier_invoice_id
       WHERE l.supplier_id = ? ORDER BY l.id ASC`
    )
    .all(supplierId);
}

function getBalance(supplierId) {
  const db = getDb();
  const last = db
    .prepare('SELECT running_balance FROM supplier_ledger_entries WHERE supplier_id = ? ORDER BY id DESC LIMIT 1')
    .get(supplierId);
  if (last) return last.running_balance;
  const supplier = db.prepare('SELECT opening_balance FROM suppliers WHERE id = ?').get(supplierId);
  return supplier?.opening_balance || 0;
}

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

// Supplier payments have no payment_type column (unlike customer payments):
// a payment is an "Advance" if it wasn't tied to a supplier invoice at
// receipt time, otherwise it's an ordinary "Payment".
const TXN_TYPE_SQL = `
  CASE
    WHEN l.supplier_invoice_id IS NOT NULL AND l.supplier_payment_id IS NULL THEN 'Invoice'
    WHEN sp.id IS NOT NULL AND sp.supplier_invoice_id IS NULL THEN 'Advance'
    WHEN sp.id IS NOT NULL THEN 'Payment'
    WHEN l.description LIKE '%voided%' THEN 'Adjustment'
    ELSE 'Other'
  END`;

/** Mirrors ledgerService.filteredView for suppliers (master prompt section 17 style filters). */
function filteredView(supplierId, opts = {}) {
  const db = getDb();
  const { dateFrom = '', dateTo = '', bookingId = null, invoiceId = null, paymentId = null, transactionType = 'All' } = opts;

  const base = `
    WITH classified AS (
      SELECT l.*, si.invoice_number, COALESCE(si.booking_id, sp.booking_id) AS booking_id,
             sp.reference AS payment_reference, sp.payment_method, ${TXN_TYPE_SQL} AS txn_type
      FROM supplier_ledger_entries l
      LEFT JOIN supplier_invoices si ON si.id = l.supplier_invoice_id
      LEFT JOIN supplier_payments sp ON sp.id = l.supplier_payment_id
      WHERE l.supplier_id = @supplierId
    )`;

  const where = [];
  const params = { supplierId };
  if (dateFrom) { where.push('date(entry_date) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { where.push('date(entry_date) <= date(@dateTo)'); params.dateTo = dateTo; }
  if (bookingId) { where.push('booking_id = @bookingId'); params.bookingId = Number(bookingId); }
  if (invoiceId) { where.push('supplier_invoice_id = @invoiceId'); params.invoiceId = Number(invoiceId); }
  if (paymentId) { where.push('supplier_payment_id = @paymentId'); params.paymentId = Number(paymentId); }
  if (transactionType && transactionType !== 'All') { where.push('txn_type = @txnType'); params.txnType = transactionType; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const entries = db.prepare(`${base} SELECT * FROM classified ${whereSql} ORDER BY id ASC`).all(params)
    .map((r) => ({ ...r, debit: round2(r.debit), credit: round2(r.credit), running_balance: round2(r.running_balance) }));

  let openingBalance = 0;
  if (entries.length > 0) {
    const firstId = entries[0].id;
    const prior = db.prepare('SELECT running_balance FROM supplier_ledger_entries WHERE supplier_id = ? AND id < ? ORDER BY id DESC LIMIT 1').get(supplierId, firstId);
    openingBalance = prior ? round2(prior.running_balance) : round2(db.prepare('SELECT opening_balance FROM suppliers WHERE id = ?').get(supplierId)?.opening_balance || 0);
  } else {
    openingBalance = round2(db.prepare('SELECT opening_balance FROM suppliers WHERE id = ?').get(supplierId)?.opening_balance || 0);
  }
  const totalDebit = round2(entries.reduce((a, e) => a + e.debit, 0));
  const totalCredit = round2(entries.reduce((a, e) => a + e.credit, 0));
  const closingBalance = entries.length > 0 ? entries[entries.length - 1].running_balance : openingBalance;

  return { entries, openingBalance, totalDebit, totalCredit, closingBalance };
}

function transactionTypes(supplierId) {
  const db = getDb();
  return db.prepare(
    `WITH classified AS (
       SELECT ${TXN_TYPE_SQL} AS txn_type FROM supplier_ledger_entries l
       LEFT JOIN supplier_invoices si ON si.id = l.supplier_invoice_id
       LEFT JOIN supplier_payments sp ON sp.id = l.supplier_payment_id
       WHERE l.supplier_id = ?
     ) SELECT DISTINCT txn_type FROM classified ORDER BY txn_type`
  ).all(supplierId).map((r) => r.txn_type);
}

module.exports = { addEntry, list, filteredView, transactionTypes, getBalance };
