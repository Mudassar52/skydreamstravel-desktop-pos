const { getDb } = require('../../src/database/db');

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

// Shared filter shape across reports: { dateFrom, dateTo, customerId, status, type, categoryId }
// Each report only reads what applies to it and ignores the rest.

function salesReport(f) {
  const db = getDb();
  const cond = ["i.status != 'Cancelled'"];
  const p = {};
  if (f.dateFrom) { cond.push('date(i.invoice_date) >= date(@dateFrom)'); p.dateFrom = f.dateFrom; }
  if (f.dateTo) { cond.push('date(i.invoice_date) <= date(@dateTo)'); p.dateTo = f.dateTo; }
  if (f.customerId) { cond.push('i.customer_id = @customerId'); p.customerId = f.customerId; }
  if (f.status) { cond.push('i.status = @status'); p.status = f.status; }

  const rows = db
    .prepare(
      `SELECT i.invoice_number, i.invoice_date, c.full_name AS customer, i.total, i.paid_amount, i.remaining_amount, i.status
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       WHERE ${cond.join(' AND ')} ORDER BY i.invoice_date DESC`
    )
    .all(p);

  return {
    title: 'Sales Report',
    columns: [
      { key: 'invoice_number', label: 'Invoice #' }, { key: 'invoice_date', label: 'Date' },
      { key: 'customer', label: 'Customer' }, { key: 'total', label: 'Total', money: true },
      { key: 'paid_amount', label: 'Paid', money: true }, { key: 'remaining_amount', label: 'Balance', money: true },
      { key: 'status', label: 'Status' }
    ],
    rows,
    totals: { total: rows.reduce((s, r) => s + r.total, 0), paid_amount: rows.reduce((s, r) => s + r.paid_amount, 0), remaining_amount: rows.reduce((s, r) => s + r.remaining_amount, 0) }
  };
}

function bookingReport(f) {
  const db = getDb();
  const cond = [];
  const p = {};
  if (f.dateFrom) { cond.push('date(b.booking_date) >= date(@dateFrom)'); p.dateFrom = f.dateFrom; }
  if (f.dateTo) { cond.push('date(b.booking_date) <= date(@dateTo)'); p.dateTo = f.dateTo; }
  if (f.customerId) { cond.push('b.customer_id = @customerId'); p.customerId = f.customerId; }
  if (f.status) { cond.push('b.status = @status'); p.status = f.status; }
  if (f.type) { cond.push('b.booking_type = @type'); p.type = f.type; }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';

  const rows = db
    .prepare(
      `SELECT b.booking_code, b.booking_date, c.full_name AS customer, b.booking_type, b.departure_date,
              b.total_price, b.paid_amount, b.remaining_amount, b.status
       FROM bookings b JOIN customers c ON c.id = b.customer_id ${where} ORDER BY b.booking_date DESC`
    )
    .all(p);

  return {
    title: 'Booking Report',
    columns: [
      { key: 'booking_code', label: 'Booking #' }, { key: 'booking_date', label: 'Date' }, { key: 'customer', label: 'Customer' },
      { key: 'booking_type', label: 'Type' }, { key: 'departure_date', label: 'Departure' },
      { key: 'total_price', label: 'Total', money: true }, { key: 'remaining_amount', label: 'Balance', money: true }, { key: 'status', label: 'Status' }
    ],
    rows
  };
}

function customerReport() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT c.full_name, c.phone, c.email, c.nationality, c.status,
              (SELECT COUNT(*) FROM bookings WHERE customer_id = c.id) AS bookings,
              (SELECT COALESCE(SUM(remaining_amount),0) FROM invoices WHERE customer_id = c.id AND status != 'Cancelled') AS outstanding
       FROM customers c ORDER BY c.full_name`
    )
    .all();

  return {
    title: 'Customer Report',
    columns: [
      { key: 'full_name', label: 'Name' }, { key: 'phone', label: 'Phone' }, { key: 'nationality', label: 'Nationality' },
      { key: 'status', label: 'Status' }, { key: 'bookings', label: 'Bookings' }, { key: 'outstanding', label: 'Outstanding', money: true }
    ],
    rows
  };
}

function paymentReport(f) {
  const db = getDb();
  const cond = [];
  const p = {};
  if (f.dateFrom) { cond.push('date(pay.payment_date) >= date(@dateFrom)'); p.dateFrom = f.dateFrom; }
  if (f.dateTo) { cond.push('date(pay.payment_date) <= date(@dateTo)'); p.dateTo = f.dateTo; }
  if (f.customerId) { cond.push('pay.customer_id = @customerId'); p.customerId = f.customerId; }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';

  const rows = db
    .prepare(
      `SELECT pay.payment_date, c.full_name AS customer, pay.amount, pay.payment_method, pay.payment_type,
              COALESCE(i.invoice_number, b.booking_code, '') AS linked_to
       FROM payments pay JOIN customers c ON c.id = pay.customer_id
       LEFT JOIN invoices i ON i.id = pay.invoice_id
       LEFT JOIN bookings b ON b.id = pay.booking_id
       ${where} ORDER BY pay.payment_date DESC`
    )
    .all(p);

  return {
    title: 'Payment Report',
    columns: [
      { key: 'payment_date', label: 'Date' }, { key: 'customer', label: 'Customer' }, { key: 'amount', label: 'Amount', money: true },
      { key: 'payment_method', label: 'Method' }, { key: 'payment_type', label: 'Type' }, { key: 'linked_to', label: 'Linked To' }
    ],
    rows,
    totals: { amount: rows.reduce((s, r) => s + r.amount, 0) }
  };
}

function outstandingReport(f) {
  const db = getDb();
  const cond = ["i.status != 'Cancelled'", 'i.remaining_amount > 0'];
  const p = {};
  if (f.customerId) { cond.push('i.customer_id = @customerId'); p.customerId = f.customerId; }

  const rows = db
    .prepare(
      `SELECT i.invoice_number, c.full_name AS customer, i.total, i.paid_amount, i.remaining_amount, i.due_date, i.status
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       WHERE ${cond.join(' AND ')} ORDER BY i.remaining_amount DESC`
    )
    .all(p);

  return {
    title: 'Outstanding Report',
    columns: [
      { key: 'invoice_number', label: 'Invoice #' }, { key: 'customer', label: 'Customer' }, { key: 'total', label: 'Total', money: true },
      { key: 'paid_amount', label: 'Paid', money: true }, { key: 'remaining_amount', label: 'Balance', money: true }, { key: 'due_date', label: 'Due Date' }
    ],
    rows,
    totals: { remaining_amount: rows.reduce((s, r) => s + r.remaining_amount, 0) }
  };
}

function expenseReport(f) {
  const db = getDb();
  const cond = [];
  const p = {};
  if (f.dateFrom) { cond.push('date(e.expense_date) >= date(@dateFrom)'); p.dateFrom = f.dateFrom; }
  if (f.dateTo) { cond.push('date(e.expense_date) <= date(@dateTo)'); p.dateTo = f.dateTo; }
  if (f.categoryId) { cond.push('e.category_id = @categoryId'); p.categoryId = f.categoryId; }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';

  const rows = db
    .prepare(
      `SELECT e.expense_date, ec.name AS category, e.description, e.amount, e.payment_method, b.booking_code
       FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id
       LEFT JOIN bookings b ON b.id = e.related_booking_id
       ${where} ORDER BY e.expense_date DESC`
    )
    .all(p);

  return {
    title: 'Expense Report',
    columns: [
      { key: 'expense_date', label: 'Date' }, { key: 'category', label: 'Category' }, { key: 'description', label: 'Description' },
      { key: 'amount', label: 'Amount', money: true }, { key: 'payment_method', label: 'Method' }, { key: 'booking_code', label: 'Booking' }
    ],
    rows,
    totals: { amount: rows.reduce((s, r) => s + r.amount, 0) }
  };
}

function profitReport() {
  const profitService = require('./profitService');
  const byType = profitService.getByBookingType();
  const summary = profitService.getSummary();
  return {
    title: 'Profit Report',
    columns: [
      { key: 'type', label: 'Booking Type' }, { key: 'revenue', label: 'Revenue', money: true },
      { key: 'expenses', label: 'Expenses', money: true }, { key: 'profit', label: 'Profit', money: true }
    ],
    rows: byType,
    totals: { revenue: summary.revenue, expenses: summary.expenses, profit: summary.profit }
  };
}

function umrahReport() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT g.group_name, p.package_name, g.departure_date, g.total_passengers, g.visa_status
       FROM umrah_groups g LEFT JOIN umrah_packages p ON p.id = g.package_id ORDER BY g.departure_date`
    )
    .all();
  return {
    title: 'Umrah Report',
    columns: [
      { key: 'group_name', label: 'Group' }, { key: 'package_name', label: 'Package' }, { key: 'departure_date', label: 'Departure' },
      { key: 'total_passengers', label: 'Passengers' }, { key: 'visa_status', label: 'Visa Status' }
    ],
    rows
  };
}

function hajjReport() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT g.group_name, p.package_name, g.departure_date, g.total_pilgrims, g.visa_status
       FROM hajj_groups g LEFT JOIN hajj_packages p ON p.id = g.package_id ORDER BY g.departure_date`
    )
    .all();
  return {
    title: 'Hajj Report',
    columns: [
      { key: 'group_name', label: 'Group' }, { key: 'package_name', label: 'Package' }, { key: 'departure_date', label: 'Departure' },
      { key: 'total_pilgrims', label: 'Pilgrims' }, { key: 'visa_status', label: 'Visa Status' }
    ],
    rows
  };
}

function tourReport() {
  const db = getDb();
  const rows = db
    .prepare(`SELECT tour_name, destination, country, city, start_date, end_date, total_seats, available_seats, package_price FROM tours ORDER BY start_date`)
    .all();
  return {
    title: 'Tour Report',
    columns: [
      { key: 'tour_name', label: 'Tour' }, { key: 'destination', label: 'Destination' }, { key: 'start_date', label: 'Start' },
      { key: 'end_date', label: 'End' }, { key: 'available_seats', label: 'Available' }, { key: 'total_seats', label: 'Total Seats' },
      { key: 'package_price', label: 'Price', money: true }
    ],
    rows
  };
}

function flightReport() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT f.flight_number, f.airline, f.departure_airport, f.arrival_airport, f.departure_date, f.status, b.booking_code
       FROM flights f LEFT JOIN bookings b ON b.id = f.booking_id ORDER BY f.departure_date`
    )
    .all();
  return {
    title: 'Flight Report',
    columns: [
      { key: 'flight_number', label: 'Flight #' }, { key: 'airline', label: 'Airline' }, { key: 'departure_airport', label: 'From' },
      { key: 'arrival_airport', label: 'To' }, { key: 'departure_date', label: 'Departure' }, { key: 'status', label: 'Status' }, { key: 'booking_code', label: 'Booking' }
    ],
    rows
  };
}

function hotelReport() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT h.hotel_name, h.city, h.country, h.check_in, h.check_out, h.number_of_rooms, h.number_of_nights, h.selling_price
       FROM hotels h ORDER BY h.check_in`
    )
    .all();
  return {
    title: 'Hotel Report',
    columns: [
      { key: 'hotel_name', label: 'Hotel' }, { key: 'city', label: 'City' }, { key: 'check_in', label: 'Check-in' },
      { key: 'check_out', label: 'Check-out' }, { key: 'number_of_rooms', label: 'Rooms' }, { key: 'number_of_nights', label: 'Nights' },
      { key: 'selling_price', label: 'Selling Price', money: true }
    ],
    rows
  };
}

function visaReport(f) {
  const db = getDb();
  const cond = [];
  const p = {};
  if (f.status) { cond.push('v.status = @status'); p.status = f.status; }
  if (f.customerId) { cond.push('v.customer_id = @customerId'); p.customerId = f.customerId; }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';
  const rows = db
    .prepare(
      `SELECT c.full_name AS customer, v.country, v.visa_type, v.expiry_date, v.status
       FROM visa_applications v JOIN customers c ON c.id = v.customer_id ${where} ORDER BY v.expiry_date`
    )
    .all(p);
  return {
    title: 'Visa Report',
    columns: [
      { key: 'customer', label: 'Customer' }, { key: 'country', label: 'Country' }, { key: 'visa_type', label: 'Type' },
      { key: 'expiry_date', label: 'Expiry' }, { key: 'status', label: 'Status' }
    ],
    rows
  };
}

function ledgerReport(f) {
  const db = getDb();
  if (f.customerId) {
    const ledgerService = require('./ledgerService');
    const rows = ledgerService.list(f.customerId);
    return {
      title: 'Customer Ledger Report',
      columns: [
        { key: 'entry_date', label: 'Date' }, { key: 'description', label: 'Description' },
        { key: 'debit', label: 'Debit', money: true }, { key: 'credit', label: 'Credit', money: true }, { key: 'running_balance', label: 'Balance', money: true }
      ],
      rows
    };
  }
  // No customer selected: a summary of every customer's current balance.
  const rows = db
    .prepare(
      `SELECT customer, balance FROM (
         SELECT c.full_name AS customer,
           (SELECT running_balance FROM ledger_entries WHERE customer_id = c.id ORDER BY id DESC LIMIT 1) AS balance
         FROM customers c
       )
       WHERE balance IS NOT NULL
       ORDER BY balance DESC`
    )
    .all();
  return {
    title: 'Customer Ledger Report — All Customers (select a customer for full detail)',
    columns: [{ key: 'customer', label: 'Customer' }, { key: 'balance', label: 'Current Balance', money: true }],
    rows
  };
}

const REPORTS = {
  sales: { label: 'Sales Report', run: salesReport },
  bookings: { label: 'Booking Report', run: bookingReport },
  customers: { label: 'Customer Report', run: customerReport },
  payments: { label: 'Payment Report', run: paymentReport },
  outstanding: { label: 'Outstanding Report', run: outstandingReport },
  expenses: { label: 'Expense Report', run: expenseReport },
  profit: { label: 'Profit Report', run: profitReport },
  umrah: { label: 'Umrah Report', run: umrahReport },
  hajj: { label: 'Hajj Report', run: hajjReport },
  tours: { label: 'Tour Report', run: tourReport },
  flights: { label: 'Flight Report', run: flightReport },
  hotels: { label: 'Hotel Report', run: hotelReport },
  visa: { label: 'Visa Report', run: visaReport },
  ledger: { label: 'Customer Ledger Report', run: ledgerReport }
};

function run(key, filters = {}) {
  const report = REPORTS[key];
  if (!report) throw new Error('Unknown report type.');
  return report.run(filters);
}

function listReportTypes() {
  return Object.entries(REPORTS).map(([key, r]) => ({ key, label: r.label }));
}

module.exports = { run, listReportTypes };
