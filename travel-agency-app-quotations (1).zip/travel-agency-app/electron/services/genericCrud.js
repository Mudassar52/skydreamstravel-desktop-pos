const { getDb } = require('../../src/database/db');

/**
 * Builds a small CRUD service for a simple table (no complex joins needed
 * on write). Used for umrah/hajj packages & groups and tours, which all
 * share the same shape: a flat set of columns, list/get/create/update/delete,
 * and an audit log entry per write.
 *
 * @param {string} table - table name
 * @param {string[]} fields - editable column names (matches the schema)
 * @param {object} [options]
 * @param {(payload: object) => void} [options.validate] - throws on invalid input
 * @param {string} [options.orderBy] - defaults to "created_at DESC"
 * @param {string} [options.recordLabelField] - field used in audit log text
 */
function makeCrudService(table, fields, options = {}) {
  const orderBy = options.orderBy || 'created_at DESC';
  const labelField = options.recordLabelField || fields[0];

  function validate(payload) {
    if (options.validate) options.validate(payload);
  }

  function list() {
    const db = getDb();
    return db.prepare(`SELECT * FROM ${table} ORDER BY ${orderBy}`).all();
  }

  function get(id) {
    const db = getDb();
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    if (!row) throw new Error('Record not found.');
    return row;
  }

  function create(payload) {
    validate(payload);
    const db = getDb();
    const cols = fields.filter((f) => payload[f] !== undefined);
    const params = {};
    for (const f of fields) params[f] = payload[f] ?? null;

    const result = db
      .prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map((c) => `@${c}`).join(', ')})`)
      .run(params);

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES (?, ?, ?, ?)`
    ).run(`${table}:create`, table, result.lastInsertRowid, `${payload[labelField] || table} created`);

    return { id: result.lastInsertRowid };
  }

  function update(id, payload) {
    validate(payload);
    const db = getDb();
    const existing = db.prepare(`SELECT id FROM ${table} WHERE id = ?`).get(id);
    if (!existing) throw new Error('Record not found.');

    const params = { id };
    const sets = [];
    for (const f of fields) {
      if (payload[f] !== undefined) {
        sets.push(`${f} = @${f}`);
        params[f] = payload[f];
      }
    }
    if (!sets.length) return { success: true };

    db.prepare(`UPDATE ${table} SET ${sets.join(', ')} WHERE id = @id`).run(params);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES (?, ?, ?, ?)`
    ).run(`${table}:update`, table, id, `${payload[labelField] || `#${id}`} updated`);

    return { success: true };
  }

  function remove(id, guard) {
    const db = getDb();
    if (guard) guard(db, id);
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES (?, ?, ?, ?)`
    ).run(`${table}:delete`, table, id, `${row?.[labelField] || `#${id}`} deleted`);
    return { success: true };
  }

  return { list, get, create, update, remove };
}

module.exports = { makeCrudService };
