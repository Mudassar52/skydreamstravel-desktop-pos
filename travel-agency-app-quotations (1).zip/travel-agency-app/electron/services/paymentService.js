const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const documentCurrency = require('./documentCurrency');
const ledgerService = require('./ledgerService');
const accountService = require('./accountService');
const { deriveStatus } = require('./invoiceService');

const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];
const PAYMENT_TYPES = ['Advance', 'Partial', 'Full', 'Refund'];

function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!(Number(payload.amount) > 0)) throw new Error('Amount must be greater than zero.');
  if (!PAYMENT_METHODS.includes(payload.payment_method)) throw new Error('Please select a valid payment method.');
  if (!PAYMENT_TYPES.includes(payload.payment_type)) throw new Error('Please select a valid payment type.');
}

function list({ customerId = null, dateFrom = null, dateTo = null, page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (customerId) {
    conditions.push('p.customer_id = @customerId');
    params.customerId = customerId;
  }
  if (dateFrom) { conditions.push('date(p.payment_date) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('date(p.payment_date) <= date(@dateTo)'); params.dateTo = dateTo; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM payments p ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT p.*, c.full_name AS customer_name, i.invoice_number, b.booking_code
       FROM payments p
       JOIN customers c ON c.id = p.customer_id
       LEFT JOIN invoices i ON i.id = p.invoice_id
       LEFT JOIN bookings b ON b.id = p.booking_id
       ${where}
       ORDER BY p.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT p.*, c.full_name AS customer_name, i.invoice_number, b.booking_code
       FROM payments p
       JOIN customers c ON c.id = p.customer_id
       LEFT JOIN invoices i ON i.id = p.invoice_id
       LEFT JOIN bookings b ON b.id = p.booking_id
       WHERE p.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Payment not found.');
  return row;
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(payload.customer_id);
  if (!customer) throw new Error('Selected customer does not exist.');
  periodLock.assertOpen(null, 'This payment');

  const amount = Number(payload.amount);
  const isRefund = payload.payment_type === 'Refund';
  const delta = isRefund ? -amount : amount;

  // Double-payment guard (master prompt: "Prevent double payment"). A real
  // cheque number / bank transaction id is the one thing that identifies a
  // payment, so the same customer + reference + amount + method + type is a
  // resubmission, not a second payment. Blank references are never compared
  // (two cash instalments of the same amount are legitimate).
  const ref = payload.reference ? String(payload.reference).trim() : '';
  if (ref) {
    const dup = db.prepare(
      `SELECT id FROM payments WHERE customer_id = ? AND LOWER(TRIM(reference)) = LOWER(?)
         AND payment_method = ? AND payment_type = ? AND ABS(amount - ?) < 0.005 LIMIT 1`
    ).get(payload.customer_id, ref, payload.payment_method, payload.payment_type, amount);
    if (dup) throw new Error(`A payment with reference "${ref}" for this amount is already recorded (PAY-${String(dup.id).padStart(5, '0')}). Use a different reference if this is a separate payment.`);
  }

  // Currency of this payment (invoice's, else booking's, else the account's, else the base currency). Refused when the
  // chosen account holds a different currency than what is being paid.
  const linkedInvoice = payload.invoice_id ? db.prepare('SELECT currency, booking_id FROM invoices WHERE id = ?').get(payload.invoice_id) : null;
  const cur = documentCurrency.forPayment(db, { invoice: linkedInvoice, bookingId: payload.booking_id, accountType: payload.account_type, accountId: payload.account_id, amount, receivedAmount: payload.received_amount });
  const currency = cur.currency;

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO payments (customer_id, booking_id, invoice_id, payment_date, amount, payment_method, payment_type, reference, notes, account_type, account_id, currency, received_amount)
         VALUES (@customer_id, @booking_id, @invoice_id, datetime('now'), @amount, @payment_method, @payment_type, @reference, @notes, @account_type, @account_id, @currency, @received_amount)`
      )
      .run({
        customer_id: payload.customer_id,
        booking_id: payload.booking_id || null,
        invoice_id: payload.invoice_id || null,
        amount,
        payment_method: payload.payment_method,
        payment_type: payload.payment_type,
        reference: payload.reference || null,
        notes: payload.notes || null,
        account_type: payload.account_type || null,
        account_id: payload.account_id || null,
        currency,
        received_amount: cur.cross ? cur.received : null
      });
    const paymentId = result.lastInsertRowid;
    let description = `${payload.payment_type} payment`;

    if (payload.invoice_id) {
      const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(payload.invoice_id);
      if (!invoice) throw new Error('Selected invoice does not exist.');
      if (invoice.customer_id !== payload.customer_id) throw new Error('That invoice does not belong to the selected customer.');

      const newPaid = invoice.paid_amount + delta;
      if (newPaid < 0) throw new Error('Refund amount exceeds what has been paid on this invoice.');
      if (newPaid > invoice.total) throw new Error('Payment amount would exceed the invoice total.');

      const newStatus = invoice.status === 'Cancelled' ? 'Cancelled' : deriveStatus(invoice.total, newPaid);
      db.prepare(
        `UPDATE invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(newPaid, invoice.total - newPaid, newStatus, invoice.id);

      description = `${payload.payment_type} payment — Invoice ${invoice.invoice_number}`;
      ledgerService.addEntry(db, {
        customer_id: payload.customer_id,
        description,
        invoice_id: invoice.id,
        payment_id: paymentId,
        debit: isRefund ? amount : 0,
        credit: isRefund ? 0 : amount
      });
    } else if (payload.booking_id) {
      const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(payload.booking_id);
      if (!booking) throw new Error('Selected booking does not exist.');
      if (booking.customer_id !== payload.customer_id) throw new Error('That booking does not belong to the selected customer.');

      const newPaid = booking.paid_amount + delta;
      if (newPaid < 0) throw new Error('Refund amount exceeds what has been paid on this booking.');
      if (newPaid > booking.total_price) throw new Error('Payment amount would exceed the booking total.');

      db.prepare(`UPDATE bookings SET paid_amount = ?, remaining_amount = ?, updated_at = datetime('now') WHERE id = ?`)
        .run(newPaid, booking.total_price - newPaid, booking.id);

      description = `${payload.payment_type} payment — Booking ${booking.booking_code}`;
      ledgerService.addEntry(db, {
        customer_id: payload.customer_id,
        description,
        payment_id: paymentId,
        debit: isRefund ? amount : 0,
        credit: isRefund ? 0 : amount
      });
    } else {
      // General/advance payment, not yet tied to an invoice or booking.
      ledgerService.addEntry(db, {
        customer_id: payload.customer_id,
        description,
        payment_id: paymentId,
        debit: isRefund ? amount : 0,
        credit: isRefund ? 0 : amount
      });
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES (?, 'payment', ?, ?)`
    ).run(isRefund ? 'Payment Refunded' : 'Payment Added', paymentId, description);

    accountService.postTransaction(db, {
      account_type: payload.account_type,
      account_id: payload.account_id,
      amount: cur.received,
      direction: isRefund ? 'Out' : 'In',
      transaction_type: isRefund ? 'Refund' : 'CustomerPayment',
      reference_type: 'payments',
      reference_id: paymentId,
      description
    });

    return paymentId;
  });

  const id = tx();
  return { id };
}

/**
 * Voids a payment: reverses its effect on the linked invoice/booking and
 * adds an offsetting ledger entry, then removes the payment row. Payments
 * are never edited in place - editing a historical financial record quietly
 * would make the ledger untrustworthy, so a correction is always a new,
 * visible reversal.
 */
function remove(id) {
  const db = getDb();
  const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(id);
  if (!payment) throw new Error('Payment not found.');
  periodLock.assertOpen(payment.payment_date, `Payment #${id}`);

  const isRefund = payment.payment_type === 'Refund';
  const delta = isRefund ? -payment.amount : payment.amount;

  const tx = db.transaction(() => {
    if (payment.invoice_id) {
      const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(payment.invoice_id);
      if (invoice) {
        const restoredPaid = invoice.paid_amount - delta;
        const newStatus = invoice.status === 'Cancelled' ? 'Cancelled' : deriveStatus(invoice.total, restoredPaid);
        db.prepare(`UPDATE invoices SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`)
          .run(restoredPaid, invoice.total - restoredPaid, newStatus, invoice.id);
      }
    } else if (payment.booking_id) {
      const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(payment.booking_id);
      if (booking) {
        const restoredPaid = booking.paid_amount - delta;
        db.prepare(`UPDATE bookings SET paid_amount = ?, remaining_amount = ?, updated_at = datetime('now') WHERE id = ?`)
          .run(restoredPaid, booking.total_price - restoredPaid, booking.id);
      }
    }

    // The original ledger entry for this payment references it via
    // payment_id; detach that reference before deleting the payment row so
    // the foreign key doesn't block the delete. The entry itself stays
    // (it's the historical record of what happened), it just stops
    // pointing at a payment row that no longer exists.
    db.prepare('UPDATE ledger_entries SET payment_id = NULL WHERE payment_id = ?').run(id);

    // Offsetting ledger entry: opposite of what the original payment did.
    ledgerService.addEntry(db, {
      customer_id: payment.customer_id,
      description: `Payment #${id} voided`,
      invoice_id: payment.invoice_id,
      debit: isRefund ? 0 : payment.amount,
      credit: isRefund ? payment.amount : 0
    });

    db.prepare('DELETE FROM payments WHERE id = ?').run(id);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Payment Voided', 'payment', ?, ?)`
    ).run(id, `Payment #${id} voided`);

    accountService.postTransaction(db, {
      account_type: payment.account_type,
      account_id: payment.account_id,
      amount: payment.received_amount || payment.amount,
      direction: isRefund ? 'In' : 'Out',
      transaction_type: 'Reversal',
      reference_type: 'payments',
      reference_id: id,
      description: `Payment #${id} voided`
    });
  });
  tx();

  return { success: true };
}

function listByBooking(bookingId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT p.*, c.full_name AS customer_name FROM payments p JOIN customers c ON c.id = p.customer_id
       WHERE p.booking_id = ? ORDER BY p.created_at DESC`
    )
    .all(bookingId);
}

module.exports = { PAYMENT_METHODS, PAYMENT_TYPES, list, listByBooking, get, create, remove };
