const { app, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');
const { getDb, closeDatabase, initDatabase } = require('../../src/database/db');
const settingsService = require('./settingsService');

function getPaths() {
  const userDataPath = app.getPath('userData');
  return {
    userDataPath,
    dbDir: path.join(userDataPath, 'database'),
    dbPath: path.join(userDataPath, 'database', 'agency.db'),
    documentsDir: path.join(userDataPath, 'storage', 'documents')
  };
}

/**
 * Builds the zip in memory: a consistent snapshot of the live database
 * (via SQLite's own backup API, not a raw file copy, so it's safe even
 * while the app has the file open) plus every file in document storage.
 */
async function buildZip() {
  const { documentsDir } = getPaths();
  const db = getDb();

  const tmpDbPath = path.join(app.getPath('temp'), `agency-backup-${Date.now()}.db`);
  await db.backup(tmpDbPath);

  const zip = new AdmZip();
  zip.addLocalFile(tmpDbPath, '', 'agency.db');
  if (fs.existsSync(documentsDir)) {
    zip.addLocalFolder(documentsDir, 'documents');
  }
  zip.addFile(
    'manifest.json',
    Buffer.from(JSON.stringify({ createdAt: new Date().toISOString(), appVersion: app.getVersion() }, null, 2))
  );

  fs.unlinkSync(tmpDbPath);
  return zip;
}

async function createBackup() {
  const zip = await buildZip();
  const result = await dialog.showSaveDialog({
    title: 'Save Backup',
    defaultPath: `travel-agency-backup-${new Date().toISOString().slice(0, 10)}.zip`,
    filters: [{ name: 'Backup Archive', extensions: ['zip'] }]
  });
  if (result.canceled || !result.filePath) return { saved: false };

  zip.writeZip(result.filePath);
  settingsService.set('last_manual_backup_at', new Date().toISOString());
  return { saved: true, filePath: result.filePath };
}

async function restoreBackup() {
  const result = await dialog.showOpenDialog({
    title: 'Select Backup to Restore',
    properties: ['openFile'],
    filters: [{ name: 'Backup Archive', extensions: ['zip'] }]
  });
  if (result.canceled || result.filePaths.length === 0) return { restored: false };

  const zip = new AdmZip(result.filePaths[0]);
  const entries = zip.getEntries();
  if (!entries.some((e) => e.entryName === 'agency.db')) {
    throw new Error('This does not look like a valid backup file - agency.db was not found inside it.');
  }

  const { dbDir, dbPath, documentsDir } = getPaths();

  // Release the file lock before overwriting the database file.
  closeDatabase();

  fs.mkdirSync(dbDir, { recursive: true });
  zip.extractEntryTo('agency.db', dbDir, false, true);
  // Remove any leftover WAL/SHM journal files from the database that was
  // just replaced, so nothing stale gets replayed on top of the restore.
  for (const ext of ['-wal', '-shm']) {
    const p = dbPath + ext;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }

  fs.rmSync(documentsDir, { recursive: true, force: true });
  fs.mkdirSync(documentsDir, { recursive: true });
  const storageRoot = path.dirname(documentsDir);
  for (const entry of entries) {
    if (!entry.isDirectory && entry.entryName.startsWith('documents/')) {
      // maintainEntryPath=true recreates the "documents/" folder under
      // storageRoot from the entry name itself, landing the file at
      // storageRoot/documents/<name> - i.e. back inside documentsDir.
      zip.extractEntryTo(entry.entryName, storageRoot, true, true);
    }
  }

  // Reopen the database (schema is idempotent - CREATE TABLE IF NOT EXISTS
  // - so re-running it against the restored file is harmless either way).
  initDatabase(app.getPath('userData'));
  require('./authService').ensureDefaults();
  require('./invoiceTemplateService').ensureDefaultTemplate();

  return { restored: true };
}

function relaunchApp() {
  app.relaunch();
  app.exit(0);
}

async function chooseBackupFolder() {
  const result = await dialog.showOpenDialog({ title: 'Choose Backup Folder', properties: ['openDirectory', 'createDirectory'] });
  if (result.canceled || result.filePaths.length === 0) return { chosen: false };
  settingsService.set('backup_location', result.filePaths[0]);
  return { chosen: true, path: result.filePaths[0] };
}

function getConfig() {
  return {
    backupLocation: settingsService.get('backup_location', ''),
    autoBackupEnabled: settingsService.get('auto_backup_enabled', 'false') === 'true',
    lastManualBackupAt: settingsService.get('last_manual_backup_at', ''),
    lastAutoBackupAt: settingsService.get('last_auto_backup_at', '')
  };
}

function setAutoBackupEnabled(enabled) {
  settingsService.set('auto_backup_enabled', enabled ? 'true' : 'false');
  return { success: true };
}

/**
 * Runs a silent backup straight to the configured folder if auto-backup is
 * on and it's been at least a day since the last one. Called once at
 * startup (Section 27 - "Automatic Backup") - deliberately simple (a
 * due-check on launch) rather than a background scheduler daemon, which
 * would need to run even while the app is closed and is out of scope for
 * a desktop app with no background service.
 */
async function runAutomaticBackupIfDue() {
  const enabled = settingsService.get('auto_backup_enabled', 'false') === 'true';
  const folder = settingsService.get('backup_location', '');
  if (!enabled || !folder || !fs.existsSync(folder)) return { ran: false };

  const last = settingsService.get('last_auto_backup_at', '');
  const dueByTime = !last || Date.now() - new Date(last).getTime() > 24 * 60 * 60 * 1000;
  if (!dueByTime) return { ran: false };

  const zip = await buildZip();
  const fileName = `travel-agency-auto-backup-${new Date().toISOString().replace(/[:.]/g, '-')}.zip`;
  zip.writeZip(path.join(folder, fileName));
  settingsService.set('last_auto_backup_at', new Date().toISOString());
  return { ran: true, fileName };
}

function getBackupInfo() {
  const { dbPath, documentsDir } = getPaths();
  const dbSizeBytes = fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0;

  let documentCount = 0;
  let documentsSizeBytes = 0;
  if (fs.existsSync(documentsDir)) {
    for (const f of fs.readdirSync(documentsDir)) {
      const stat = fs.statSync(path.join(documentsDir, f));
      if (stat.isFile()) { documentCount += 1; documentsSizeBytes += stat.size; }
    }
  }
  return { dbSizeBytes, documentCount, documentsSizeBytes };
}

module.exports = {
  createBackup,
  restoreBackup,
  relaunchApp,
  chooseBackupFolder,
  getConfig,
  setAutoBackupEnabled,
  runAutomaticBackupIfDue,
  getBackupInfo
};
