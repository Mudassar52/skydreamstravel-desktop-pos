const { getDb } = require('../../src/database/db');

/**
 * Profit is always Revenue (invoiced sales, excluding cancelled invoices)
 * minus Expenses - never cash Payments received minus Expenses. Payments
 * only tell you how much cash has moved; an unpaid invoice is still a real
 * sale, and a fully-paid one that gets refunded later shouldn't have
 * counted as profit in the first place. Keeping Sales / Payments /
 * Expenses / Profit as separate concepts is an explicit spec requirement
 * (Section 19/21).
 */
function getSummary() {
  const db = getDb();
  const revenue = db.prepare("SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE status != 'Cancelled'").get().s;
  const expenses = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM expenses').get().s;
  return { revenue, expenses, profit: revenue - expenses };
}

function getMonthly(months = 6) {
  const db = getDb();
  const list = [];
  const now = new Date();
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    list.push({ key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, label: d.toLocaleString('en-US', { month: 'short', year: '2-digit' }) });
  }

  const revenueRows = db
    .prepare("SELECT strftime('%Y-%m', invoice_date) AS ym, SUM(total) AS s FROM invoices WHERE status != 'Cancelled' GROUP BY ym")
    .all();
  const expenseRows = db.prepare("SELECT strftime('%Y-%m', expense_date) AS ym, SUM(amount) AS s FROM expenses GROUP BY ym").all();

  const toMap = (rows) => Object.fromEntries(rows.map((r) => [r.ym, r.s]));
  const revenueMap = toMap(revenueRows);
  const expenseMap = toMap(expenseRows);

  return list.map((m) => ({
    month: m.label,
    revenue: revenueMap[m.key] || 0,
    expenses: expenseMap[m.key] || 0,
    profit: (revenueMap[m.key] || 0) - (expenseMap[m.key] || 0)
  }));
}

/**
 * Groups by the booking type an invoice's booking belongs to (Umrah, Hajj,
 * Tour, Flight, Hotel, Visa, Transportation), plus "Custom / Not Linked"
 * for invoices with no booking. Expenses are matched the same way via
 * related_package_type/related_booking_id.
 */
function getByBookingType() {
  const db = getDb();
  const revenueRows = db
    .prepare(
      `SELECT COALESCE(b.booking_type, 'Custom / Not Linked') AS type, SUM(i.total) AS revenue
       FROM invoices i LEFT JOIN bookings b ON b.id = i.booking_id
       WHERE i.status != 'Cancelled'
       GROUP BY type`
    )
    .all();

  const expenseRows = db
    .prepare(
      `SELECT COALESCE(b.booking_type, e.related_package_type, 'General / Overhead') AS type, SUM(e.amount) AS expenses
       FROM expenses e LEFT JOIN bookings b ON b.id = e.related_booking_id
       GROUP BY type`
    )
    .all();

  const map = {};
  for (const r of revenueRows) map[r.type] = { type: r.type, revenue: r.revenue || 0, expenses: 0 };
  for (const r of expenseRows) {
    if (!map[r.type]) map[r.type] = { type: r.type, revenue: 0, expenses: 0 };
    map[r.type].expenses = r.expenses || 0;
  }

  return Object.values(map)
    .map((r) => ({ ...r, profit: r.revenue - r.expenses }))
    .sort((a, b) => b.revenue - a.revenue);
}

function getByCustomer(customerId) {
  const db = getDb();
  const revenue = db
    .prepare("SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE customer_id = ? AND status != 'Cancelled'")
    .get(customerId).s;
  const expenses = db
    .prepare(
      `SELECT COALESCE(SUM(e.amount),0) AS s FROM expenses e
       JOIN bookings b ON b.id = e.related_booking_id
       WHERE b.customer_id = ?`
    )
    .get(customerId).s;
  return { revenue, expenses, profit: revenue - expenses };
}

/**
 * Per-booking profit (Section 21/40): Estimated is the booking's sold price
 * vs. its supplier costs; Actual folds in real invoiced revenue and any
 * expenses tagged to this specific booking. All real, database-driven - no
 * assumed markup or fabricated numbers.
 */
function getByBooking(bookingId) {
  const db = getDb();
  const booking = db.prepare('SELECT total_price FROM bookings WHERE id = ?').get(bookingId);

  const revenue = db
    .prepare("SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE booking_id = ? AND status != 'Cancelled'")
    .get(bookingId).s;
  const expenses = db.prepare('SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE related_booking_id = ?').get(bookingId).s;
  const supplierCost = db.prepare('SELECT COALESCE(SUM(total),0) AS s FROM supplier_invoices WHERE booking_id = ?').get(bookingId).s;

  const estimatedRevenue = booking ? booking.total_price : 0;
  const estimatedProfit = estimatedRevenue - supplierCost;
  const actualProfit = revenue - supplierCost - expenses;

  return {
    revenue, expenses, profit: revenue - expenses, // kept for backward compatibility with existing callers
    estimatedRevenue, estimatedCost: supplierCost, estimatedProfit,
    actualRevenue: revenue, actualCost: supplierCost, actualProfit,
    profitMargin: revenue > 0 ? (actualProfit / revenue) * 100 : 0
  };
}

module.exports = { getSummary, getMonthly, getByBookingType, getByCustomer, getByBooking };
