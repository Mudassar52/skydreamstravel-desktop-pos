const { getDb } = require('../../src/database/db');

const CUSTOMER_FIELDS = [
  'full_name', 'father_husband_name', 'cnic', 'passport_number',
  'passport_issue_date', 'passport_expiry_date', 'date_of_birth', 'gender',
  'nationality', 'phone', 'whatsapp', 'email', 'address', 'emergency_contact',
  'notes', 'status', 'profile_picture_path'
];

function validate(payload) {
  if (!payload.full_name || !payload.full_name.trim()) {
    throw new Error('Full name is required.');
  }
  if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email.trim())) {
    throw new Error('Please provide a valid email address.');
  }
  if (payload.passport_issue_date && payload.passport_expiry_date) {
    if (new Date(payload.passport_expiry_date) < new Date(payload.passport_issue_date)) {
      throw new Error('Passport expiry date cannot be before the issue date.');
    }
  }
}

/**
 * Paginated, searchable customer list. Never loads the whole table into
 * memory - required by Section 38 (performance with 1,000+ customers).
 */
function list({ search = '', status = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(
      full_name LIKE @q OR cnic LIKE @q OR passport_number LIKE @q OR
      phone LIKE @q OR whatsapp LIKE @q OR email LIKE @q
    )`);
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') {
    conditions.push('status = @status');
    params.status = status;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM customers ${where}`).get(params).c;

  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT id, full_name, cnic, passport_number, phone, whatsapp, email, nationality, status, created_at
       FROM customers ${where}
       ORDER BY created_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
  if (!customer) throw new Error('Customer not found.');

  // Related-module counts. Bookings already exist in the schema; the rest
  // (invoices/payments/documents) light up once their phases are built -
  // shown as 0 for now rather than fabricated numbers.
  const bookingsCount = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE customer_id = ?').get(id).c;
  const invoicesCount = db.prepare('SELECT COUNT(*) AS c FROM invoices WHERE customer_id = ?').get(id).c;
  const documentsCount = db.prepare('SELECT COUNT(*) AS c FROM documents WHERE customer_id = ?').get(id).c;
  const outstanding = db
    .prepare("SELECT COALESCE(SUM(remaining_amount),0) AS s FROM invoices WHERE customer_id = ? AND status != 'Cancelled'")
    .get(id).s;

  return { ...customer, bookingsCount, invoicesCount, documentsCount, outstanding };
}

function create(payload) {
  validate(payload);
  const db = getDb();

  const cols = CUSTOMER_FIELDS.filter((f) => payload[f] !== undefined);
  const placeholders = cols.map((c) => `@${c}`).join(', ');
  const columnList = cols.join(', ');

  const params = {};
  for (const f of CUSTOMER_FIELDS) params[f] = payload[f] ?? null;
  if (!params.status) params.status = 'Active';

  const result = db
    .prepare(`INSERT INTO customers (${columnList}) VALUES (${placeholders})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES (?, 'customer', ?, ?)`
  ).run('Customer Created', result.lastInsertRowid, `Customer "${payload.full_name}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM customers WHERE id = ?').get(id);
  if (!existing) throw new Error('Customer not found.');

  const params = { id };
  const sets = [];
  for (const f of CUSTOMER_FIELDS) {
    if (payload[f] !== undefined) {
      sets.push(`${f} = @${f}`);
      params[f] = payload[f];
    }
  }
  sets.push("updated_at = datetime('now')");

  db.prepare(`UPDATE customers SET ${sets.join(', ')} WHERE id = @id`).run(params);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Customer Updated', 'customer', ?, ?)`
  ).run(id, `Customer #${id} updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const bookingCount = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE customer_id = ?').get(id).c;
  if (bookingCount > 0) {
    throw new Error('This customer has existing bookings and cannot be deleted. Consider marking them Inactive instead.');
  }
  const customer = db.prepare('SELECT full_name FROM customers WHERE id = ?').get(id);
  db.prepare('DELETE FROM customers WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'customer', ?, ?)`
  ).run(id, `Customer "${customer?.full_name || id}" deleted`);
  return { success: true };
}

module.exports = { list, get, create, update, remove };
