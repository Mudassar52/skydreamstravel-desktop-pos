const { getDb } = require('../../src/database/db');

/**
 * Which currency a customer invoice / payment is in (Phase 21b).
 *
 * Bookings already carry a currency (their own, else their package's). An invoice inherits it from its booking and a
 * payment from its invoice or booking, so a USD booking is invoiced and paid in USD and the ledgers can convert it
 * correctly. A payment that lands in a bank/cash account is recorded in that account's currency; if the invoice/booking
 * is in a different currency than the account, that cannot be recorded correctly (the account balance moves by the same
 * number), so it is refused with a plain explanation instead of silently mixing currencies.
 */

function baseCurrency(db = getDb()) {
  const row = db.prepare("SELECT value FROM settings WHERE key = 'default_currency'").get();
  return String((row && row.value) || 'PKR').toUpperCase();
}

function bookingCurrency(db, bookingId) {
  if (!bookingId) return null;
  const row = db.prepare(
    `SELECT COALESCE(NULLIF(bk.currency, ''), NULLIF(pk.currency, '')) AS currency
     FROM bookings bk LEFT JOIN packages pk ON pk.id = bk.package_id WHERE bk.id = ?`
  ).get(bookingId);
  return row && row.currency ? String(row.currency).toUpperCase() : null;
}

function accountCurrency(db, type, id) {
  if (!type || !id) return null;
  const table = type === 'Bank' ? 'bank_accounts' : type === 'Cash' ? 'cash_accounts' : null;
  if (!table) return null;
  const row = db.prepare(`SELECT currency FROM ${table} WHERE id = ?`).get(id);
  return row && row.currency ? String(row.currency).toUpperCase() : null;
}

function forInvoice(db, { bookingId = null, explicit = null } = {}) {
  return (explicit && String(explicit).toUpperCase()) || bookingCurrency(db, bookingId) || baseCurrency(db);
}

/**
 * Currency details for a new customer payment.
 *   currency        - what the amount is in (the invoice's, else the booking's, else the account's, else the base)
 *   accountCurrency - what the chosen bank/cash account holds (null if none)
 *   received        - amount that really moved through the account: `amount` when the currencies agree, otherwise the
 *                     caller-supplied `receivedAmount` (e.g. the customer paid PKR 285,000 against a USD 1,000 invoice).
 * Throws when the currencies differ and no received amount was given.
 */
function forPayment(db, { invoice = null, bookingId = null, accountType = null, accountId = null, amount, receivedAmount = null } = {}) {
  const docCur = (invoice && invoice.currency ? String(invoice.currency).toUpperCase() : null) || bookingCurrency(db, bookingId || (invoice && invoice.booking_id));
  const accCur = accountCurrency(db, accountType, accountId);
  const cross = !!(docCur && accCur && docCur !== accCur);
  let received = Number(amount);
  if (cross) {
    received = Number(receivedAmount);
    if (!(received > 0)) {
      throw new Error(`This payment settles a ${docCur} ${invoice ? 'invoice' : 'booking'} but the selected account holds ${accCur}. Enter the amount actually received in ${accCur}.`);
    }
  }
  return { currency: docCur || accCur || baseCurrency(db), accountCurrency: accCur, cross, received };
}

module.exports = { baseCurrency, bookingCurrency, accountCurrency, forInvoice, forPayment };
