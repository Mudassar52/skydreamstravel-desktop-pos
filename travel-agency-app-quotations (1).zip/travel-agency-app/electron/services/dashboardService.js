const { getDb } = require('../../src/database/db');

/**
 * Returns the top-level stat card numbers for the dashboard.
 * All values are computed directly from SQLite - nothing here is mocked.
 * Until later phases populate real bookings/invoices/payments, an empty
 * database will correctly show zeros rather than fake numbers.
 *
 * @param {{from?: string, to?: string}} [range] - optional inclusive date
 *   range (YYYY-MM-DD). When given, every period-based figure (sales,
 *   payments, expenses, profit, leads, new bookings, supplier payments/
 *   payables) is limited to that window - this is what the dashboard's
 *   date filter drives. Live-state figures that don't belong to any one
 *   period (current cash/bank balance, total customers on file, active
 *   bookings right now, pending visas, upcoming flights/tours) always
 *   reflect the present regardless of the filter, since a past date range
 *   can't change "how much cash is in the account today".
 */
function getStats(range) {
  const db = getDb();
  const hasRange = !!(range && range.from && range.to);
  const rp = hasRange ? { from: range.from, to: range.to } : {};
  const dateFilter = (col) => (hasRange ? `AND date(${col}) BETWEEN date(@from) AND date(@to)` : '');

  const totalCustomers = db.prepare('SELECT COUNT(*) AS c FROM customers').get().c;
  const totalBookings = db.prepare('SELECT COUNT(*) AS c FROM bookings').get().c;
  const activeBookings = db
    .prepare("SELECT COUNT(*) AS c FROM bookings WHERE status IN ('Pending','Confirmed')")
    .get().c;
  const upcomingTrips = db
    .prepare("SELECT COUNT(*) AS c FROM bookings WHERE date(departure_date) >= date('now') AND status = 'Confirmed'")
    .get().c;

  // "Total Sales" and profit both mean completed sales, so both exclude
  // cancelled invoices - a cancelled invoice was never a real sale. This
  // one query backs both totalSales and estimatedProfit below, so the two
  // stat cards can't drift apart the way totalSales briefly did before
  // this fix (it was summing every invoice, cancelled or not, while
  // estimatedProfit correctly excluded them). When a date range is set,
  // both are limited to invoices raised in that window.
  const totalSales = db
    .prepare(`SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE status != 'Cancelled' ${dateFilter('invoice_date')}`)
    .get(rp).s;
  const totalReceived = db
    .prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE 1=1 ${dateFilter('payment_date')}`)
    .get(rp).s;
  const totalOutstanding = db
    .prepare(`SELECT COALESCE(SUM(remaining_amount),0) AS s FROM invoices WHERE status != 'Cancelled' ${dateFilter('invoice_date')}`)
    .get(rp).s;
  const totalExpenses = db
    .prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE 1=1 ${dateFilter('expense_date')}`)
    .get(rp).s;
  // Profit = Sales - Expenses (revenue earned, not cash collected) per the
  // spec's explicit instruction not to treat every payment as profit.
  const estimatedProfit = totalSales - totalExpenses;

  const pendingVisas = db
    .prepare("SELECT COUNT(*) AS c FROM visa_applications WHERE status NOT IN ('Approved','Rejected','Expired')")
    .get().c;
  const upcomingFlights = db
    .prepare("SELECT COUNT(*) AS c FROM flights WHERE date(departure_date) >= date('now')")
    .get().c;
  const upcomingTours = db
    .prepare("SELECT COUNT(*) AS c FROM tours WHERE date(start_date) >= date('now')")
    .get().c;

  // Phase 19 additions: Customer/Supplier Payments, Leads, Payables, Cash/Bank balances, Actual Profit
  const customerPayments = totalReceived;
  const supplierPayments = db
    .prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM supplier_payments WHERE 1=1 ${dateFilter('payment_date')}`)
    .get(rp).s;
  const newLeadsThisMonth = hasRange
    ? db.prepare(`SELECT COUNT(*) AS c FROM leads WHERE 1=1 ${dateFilter('created_at')}`).get(rp).c
    : db.prepare("SELECT COUNT(*) AS c FROM leads WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')").get().c;
  const newBookingsThisMonth = hasRange
    ? db.prepare(`SELECT COUNT(*) AS c FROM bookings WHERE 1=1 ${dateFilter('booking_date')}`).get(rp).c
    : db.prepare("SELECT COUNT(*) AS c FROM bookings WHERE strftime('%Y-%m', booking_date) = strftime('%Y-%m', 'now')").get().c;
  const customerReceivables = totalOutstanding;
  const supplierPayables = db
    .prepare(`SELECT COALESCE(SUM(remaining_amount),0) AS s FROM supplier_invoices WHERE status != 'Paid' ${dateFilter('invoice_date')}`)
    .get(rp).s;
  const cashBalance = db.prepare("SELECT COALESCE(SUM(current_balance),0) AS s FROM cash_accounts WHERE status = 'Active'").get().s;
  const bankBalance = db.prepare("SELECT COALESCE(SUM(current_balance),0) AS s FROM bank_accounts WHERE status = 'Active'").get().s;
  // Actual profit = actual revenue collected... no: per spec, Actual Profit = Actual Customer Revenue - Actual Supplier Cost - Relevant Expenses.
  const actualSupplierCost = db
    .prepare(`SELECT COALESCE(SUM(total),0) AS s FROM supplier_invoices WHERE 1=1 ${dateFilter('invoice_date')}`)
    .get(rp).s;
  const actualProfit = totalSales - actualSupplierCost - totalExpenses;

  // Always-current figures (master prompt section 41): these do not move
  // with the dashboard's own date filter, the same way cashBalance/
  // bankBalance above don't - "today" and "this month" mean the real today
  // and the real this-month regardless of what period the user is browsing.
  // Range comparisons against the RAW date column (function calls only on the
  // bounds) instead of strftime('%Y-%m', col) = ... so SQLite can use the
  // existing idx_payments_date / idx_invoices_date / idx_supplier_invoices_date
  // / idx_expenses_date indexes rather than scanning every row.
  const todayPayments = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE payment_date >= date('now') AND payment_date < date('now','+1 day')`).get().s;
  const thisMonthSales = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE status != 'Cancelled' AND invoice_date >= date('now','start of month') AND invoice_date < date('now','start of month','+1 month')`).get().s;
  const thisMonthSupplierCost = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM supplier_invoices WHERE invoice_date >= date('now','start of month') AND invoice_date < date('now','start of month','+1 month')`).get().s;
  const thisMonthExpenses = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE expense_date >= date('now','start of month') AND expense_date < date('now','start of month','+1 month')`).get().s;
  const thisMonthProfit = thisMonthSales - thisMonthSupplierCost - thisMonthExpenses;
  const pendingPaymentsCount = db.prepare(`SELECT COUNT(*) AS c FROM invoices WHERE status IN ('Unpaid','Partially Paid')`).get().c;
  const pendingSupplierPaymentsCount = db.prepare(`SELECT COUNT(*) AS c FROM supplier_invoices WHERE status != 'Paid'`).get().c;

  return {
    totalCustomers,
    totalBookings,
    activeBookings,
    upcomingTrips,
    totalSales,
    totalReceived,
    totalOutstanding,
    totalExpenses,
    estimatedProfit,
    pendingVisas,
    upcomingFlights,
    upcomingTours,
    customerPayments,
    supplierPayments,
    newLeadsThisMonth,
    newBookingsThisMonth,
    customerReceivables,
    supplierPayables,
    cashBalance,
    bankBalance,
    actualProfit,
    todayPayments,
    thisMonthSales,
    thisMonthProfit,
    pendingPaymentsCount,
    pendingSupplierPaymentsCount
  };
}

/**
 * Monthly sales / payments / expenses for the trailing 6 months, for the
 * dashboard charts. Returns zero-filled months so the chart always renders
 * a sensible shape even with no data yet.
 */
function getMonthlyFinancials() {
  const db = getDb();

  const months = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({
      key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`,
      label: d.toLocaleString('en-US', { month: 'short' })
    });
  }

  const salesRows = db
    .prepare("SELECT strftime('%Y-%m', invoice_date) AS ym, SUM(total) AS s FROM invoices WHERE status != 'Cancelled' GROUP BY ym")
    .all();
  const paymentRows = db
    .prepare("SELECT strftime('%Y-%m', payment_date) AS ym, SUM(amount) AS s FROM payments GROUP BY ym")
    .all();
  const expenseRows = db
    .prepare("SELECT strftime('%Y-%m', expense_date) AS ym, SUM(amount) AS s FROM expenses GROUP BY ym")
    .all();

  const toMap = (rows) => Object.fromEntries(rows.map((r) => [r.ym, r.s]));
  const salesMap = toMap(salesRows);
  const paymentMap = toMap(paymentRows);
  const expenseMap = toMap(expenseRows);

  return months.map((m) => ({
    month: m.label,
    sales: salesMap[m.key] || 0,
    payments: paymentMap[m.key] || 0,
    expenses: expenseMap[m.key] || 0,
    // Profit tracks Sales, not cash Payments received - see getStats() above.
    profit: (salesMap[m.key] || 0) - (expenseMap[m.key] || 0)
  }));
}

/**
 * Action Required Center (Section 11): every item is a live query against
 * its real source table, capped so the panel stays scannable, each with a
 * route so clicking it opens the actual record.
 */
function getActionRequired() {
  const db = getDb();
  const items = [];

  db.prepare(
    `SELECT i.id, i.invoice_number, i.remaining_amount, c.full_name FROM invoices i
     JOIN customers c ON c.id = i.customer_id
     WHERE i.status IN ('Unpaid','Partially Paid') AND i.due_date IS NOT NULL AND date(i.due_date) < date('now')
     ORDER BY i.due_date LIMIT 5`
  ).all().forEach((i) => items.push({ type: 'Overdue Customer Payment', label: `${i.invoice_number} — ${i.full_name}`, amount: i.remaining_amount, route: '/invoices' }));

  db.prepare(
    `SELECT si.id, si.invoice_number, si.remaining_amount, s.name FROM supplier_invoices si
     JOIN suppliers s ON s.id = si.supplier_id
     WHERE si.status IN ('Unpaid','Partially Paid') ORDER BY si.due_date LIMIT 5`
  ).all().forEach((si) => items.push({ type: 'Pending Supplier Payment', label: `${si.invoice_number} — ${si.name}`, amount: si.remaining_amount, route: '/supplier-invoices' }));

  db.prepare(
    `SELECT id, title, due_date FROM deadlines WHERE deadline_type = 'Visa' AND status = 'Pending' AND due_date <= date('now', '+14 days') ORDER BY due_date LIMIT 5`
  ).all().forEach((d) => items.push({ type: 'Visa Deadline', label: d.title || `Due ${d.due_date}`, route: '/deadlines' }));

  db.prepare(
    `SELECT id, full_name, passport_expiry_date FROM travellers WHERE passport_expiry_date IS NOT NULL AND date(passport_expiry_date) <= date('now', '+90 days') AND date(passport_expiry_date) >= date('now') ORDER BY passport_expiry_date LIMIT 5`
  ).all().forEach((t) => items.push({ type: 'Passport Expiry', label: `${t.full_name} — expires ${t.passport_expiry_date}`, route: '/travellers' }));

  db.prepare(
    `SELECT id, title, due_date FROM deadlines WHERE deadline_type = 'Ticketing' AND status = 'Pending' AND due_date <= date('now', '+7 days') ORDER BY due_date LIMIT 5`
  ).all().forEach((d) => items.push({ type: 'Ticketing Deadline', label: d.title || `Due ${d.due_date}`, route: '/deadlines' }));

  db.prepare(
    `SELECT id, title, due_date FROM deadlines WHERE deadline_type = 'HotelCancellation' AND status = 'Pending' AND due_date <= date('now', '+7 days') ORDER BY due_date LIMIT 5`
  ).all().forEach((d) => items.push({ type: 'Hotel Cancellation Deadline', label: d.title || `Due ${d.due_date}`, route: '/deadlines' }));

  db.prepare(`SELECT id, booking_code FROM bookings WHERE status = 'Pending' ORDER BY created_at DESC LIMIT 5`).all().forEach((b) =>
    items.push({ type: 'Booking Confirmation Pending', label: b.booking_code, route: '/bookings' })
  );

  db.prepare(
    `SELECT f.id, c.full_name FROM follow_ups f LEFT JOIN customers c ON c.id = f.customer_id
     WHERE f.status = 'Pending' AND f.follow_up_date <= date('now') ORDER BY f.follow_up_date LIMIT 5`
  ).all().forEach((f) => items.push({ type: 'Follow-up Due', label: f.full_name ? `Follow up — ${f.full_name}` : 'Follow-up due', route: '/followups' }));

  db.prepare(
    `SELECT id, title FROM tasks WHERE status NOT IN ('Completed','Cancelled') AND due_date IS NOT NULL AND date(due_date) < date('now') ORDER BY due_date LIMIT 5`
  ).all().forEach((t) => items.push({ type: 'Staff Task Overdue', label: t.title, route: '/tasks' }));

  return items;
}

/**
 * Real-data chart series for the dashboard (Section 10): destination
 * performance, bookings by service type, booking status split, and
 * receivables vs payables. Accepts the same optional {from, to} range as
 * getStats() so the charts move together with the dashboard's date filter.
 */
function getCharts(range) {
  const db = getDb();
  const hasRange = !!(range && range.from && range.to);
  const rp = hasRange ? { from: range.from, to: range.to } : {};
  const dateFilter = (col) => (hasRange ? `AND date(${col}) BETWEEN date(@from) AND date(@to)` : '');

  const bookingsByServiceType = db
    .prepare(`SELECT booking_type AS label, COUNT(*) AS value FROM bookings WHERE 1=1 ${dateFilter('booking_date')} GROUP BY booking_type ORDER BY value DESC`)
    .all(rp);

  const bookingStatus = db
    .prepare(`SELECT status AS label, COUNT(*) AS value FROM bookings WHERE 1=1 ${dateFilter('booking_date')} GROUP BY status ORDER BY value DESC`)
    .all(rp);

  const destinationPerformance = db
    .prepare(
      `SELECT destination AS label, COUNT(*) AS bookings, COALESCE(SUM(total_price),0) AS revenue
       FROM bookings WHERE destination IS NOT NULL AND destination != '' ${dateFilter('booking_date')} GROUP BY destination ORDER BY revenue DESC LIMIT 8`
    )
    .all(rp);

  const receivables = db
    .prepare(`SELECT COALESCE(SUM(remaining_amount),0) AS s FROM invoices WHERE status != 'Cancelled' ${dateFilter('invoice_date')}`)
    .get(rp).s;
  const payables = db
    .prepare(`SELECT COALESCE(SUM(remaining_amount),0) AS s FROM supplier_invoices WHERE status != 'Paid' ${dateFilter('invoice_date')}`)
    .get(rp).s;

  return { bookingsByServiceType, bookingStatus, destinationPerformance, receivablesVsPayables: [{ label: 'Receivables', value: receivables }, { label: 'Payables', value: payables }] };
}

/** Real (never mock) rows for the dashboard's "upcoming" panels (flights + Umrah groups). */
function getUpcomingPanels() {
  const db = getDb();

  const flightSelect = `SELECT f.id, f.flight_number, f.airline, f.pnr, f.class, f.status,
              f.departure_airport, f.arrival_airport,
              f.departure_date, f.departure_time, f.arrival_date, f.arrival_time,
              (SELECT COUNT(*) FROM flight_passengers fp WHERE fp.flight_id = f.id) AS passengers
       FROM flights f`;
  let flights = db
    .prepare(`${flightSelect} WHERE date(f.departure_date) >= date('now') AND COALESCE(f.status,'') != 'Cancelled'
              ORDER BY f.departure_date ASC, f.departure_time ASC LIMIT 6`)
    .all();
  // Nothing ahead? Show the most recent flights instead of a blank panel, flagged so the UI can label them.
  if (flights.length === 0) {
    flights = db
      .prepare(`${flightSelect} WHERE f.departure_date IS NOT NULL AND f.departure_date != ''
                ORDER BY f.departure_date DESC, f.departure_time DESC LIMIT 4`)
      .all()
      .map((f) => ({ ...f, is_past: 1 }));
  }

  const groupSelect = `SELECT g.id, g.group_name, g.departure_date, g.return_date, g.total_passengers, g.visa_status,
              p.package_name, p.makkah_nights, p.madinah_nights,
              f.airline, f.flight_number, f.departure_airport, f.arrival_airport, f.departure_time, f.arrival_time
       FROM umrah_groups g
       LEFT JOIN umrah_packages p ON p.id = g.package_id
       LEFT JOIN flights f ON f.id = g.flight_id`;
  let umrahGroups = db
    .prepare(`${groupSelect} WHERE date(g.departure_date) >= date('now') ORDER BY g.departure_date ASC LIMIT 6`)
    .all();
  if (umrahGroups.length === 0) {
    umrahGroups = db
      .prepare(`${groupSelect} WHERE g.departure_date IS NOT NULL AND g.departure_date != '' ORDER BY g.departure_date DESC LIMIT 4`)
      .all()
      .map((g) => ({ ...g, is_past: 1 }));
  }

  // Kept for backward compatibility with older callers; the dashboard no
  // longer renders a "Pending Payments" panel.
  const pendingPayments = db
    .prepare(
      `SELECT i.invoice_number, i.remaining_amount, c.full_name FROM invoices i JOIN customers c ON c.id = i.customer_id
       WHERE i.status IN ('Unpaid','Partially Paid') ORDER BY i.remaining_amount DESC LIMIT 5`
    )
    .all();

  return { flights, umrahGroups, pendingPayments };
}


/**
 * Operations panels for the dashboard: tours + Hajj groups with seats, this
 * week's departures (with a "leaving tomorrow" flag), hotel check-ins /
 * check-outs and today's transport pickups. Every row is a live query -
 * nothing is fabricated - and every list is capped so the panels stay light.
 */
function getOperationsPanels() {
  const db = getDb();

  // Tours: seats are tracked on the tour itself (total_seats / available_seats).
  const tours = db.prepare(
    `SELECT t.id, t.tour_name, t.destination, t.country, t.city, t.start_date, t.end_date, t.duration,
            COALESCE(t.total_seats,0) AS total_seats, COALESCE(t.available_seats,0) AS available_seats,
            (SELECT COUNT(*) FROM tour_passengers tp WHERE tp.tour_id = t.id) AS passengers
     FROM tours t WHERE date(t.start_date) >= date('now')
     ORDER BY t.start_date ASC LIMIT 5`
  ).all().map((t) => {
    const total = Number(t.total_seats) || 0;
    const free = Math.min(Math.max(Number(t.available_seats) || 0, 0), total || Infinity);
    return { ...t, seats_filled: total ? Math.max(total - free, 0) : t.passengers, seats_free: total ? free : 0 };
  });

  // Hajj seats: total_seats 0 = no limit set yet, so no free-seat figure is shown for that group.
  const hajjGroups = db.prepare(
    `SELECT g.id, g.group_name, g.departure_date, g.return_date, g.visa_status,
            COALESCE(g.total_pilgrims,0) AS total_pilgrims, COALESCE(g.total_seats,0) AS total_seats, p.package_name
     FROM hajj_groups g LEFT JOIN hajj_packages p ON p.id = g.package_id
     WHERE date(g.departure_date) >= date('now')
     ORDER BY g.departure_date ASC LIMIT 5`
  ).all().map((g) => ({ ...g, seats_filled: g.total_pilgrims, seats_free: g.total_seats ? Math.max(g.total_seats - g.total_pilgrims, 0) : 0 }));

  // Departures in the next 7 days, from every source that has a departure date.
  const departures = [
    ...db.prepare(`SELECT id, departure_airport, arrival_airport, flight_number, airline, departure_date AS date, departure_time AS time
                   FROM flights WHERE date(departure_date) BETWEEN date('now') AND date('now','+7 days') AND COALESCE(status,'') != 'Cancelled'`)
      .all().map((r) => ({ kind: 'Flight', id: r.id, title: `${r.airline || 'Flight'} ${r.flight_number || ''}`.trim(), detail: [r.departure_airport, r.arrival_airport].filter(Boolean).join(' → '), date: r.date, time: r.time, route: '/flights' })),
    ...db.prepare(`SELECT id, group_name, departure_date AS date, total_passengers AS pax FROM umrah_groups
                   WHERE date(departure_date) BETWEEN date('now') AND date('now','+7 days')`)
      .all().map((r) => ({ kind: 'Umrah', id: r.id, title: r.group_name, detail: `${r.pax || 0} pilgrims`, date: r.date, route: '/umrah' })),
    ...db.prepare(`SELECT id, group_name, departure_date AS date, total_pilgrims AS pax FROM hajj_groups
                   WHERE date(departure_date) BETWEEN date('now') AND date('now','+7 days')`)
      .all().map((r) => ({ kind: 'Hajj', id: r.id, title: r.group_name, detail: `${r.pax || 0} pilgrims`, date: r.date, route: '/hajj' })),
    ...db.prepare(`SELECT id, tour_name, destination, start_date AS date FROM tours
                   WHERE date(start_date) BETWEEN date('now') AND date('now','+7 days')`)
      .all().map((r) => ({ kind: 'Tour', id: r.id, title: r.tour_name, detail: r.destination || '', date: r.date, route: '/tours' }))
  ].sort((a, b) => String(a.date).localeCompare(String(b.date)) || String(a.time || '').localeCompare(String(b.time || ''))).slice(0, 12);

  const hotelSelect = `SELECT h.id, h.hotel_name, h.city, h.check_in, h.check_out, h.number_of_rooms, h.booking_id,
            (SELECT COUNT(*) FROM hotel_guests hg WHERE hg.hotel_id = h.id) AS guests
     FROM hotels h`;
  const hotelCheckIns = db.prepare(`${hotelSelect} WHERE date(h.check_in) BETWEEN date('now') AND date('now','+3 days') ORDER BY h.check_in ASC LIMIT 6`).all();
  const hotelCheckOuts = db.prepare(`${hotelSelect} WHERE date(h.check_out) BETWEEN date('now') AND date('now','+3 days') ORDER BY h.check_out ASC LIMIT 6`).all();

  const transportToday = db.prepare(
    `SELECT id, vehicle, vehicle_number, driver, driver_phone, pickup_location, drop_location, pickup_date, pickup_time, status
     FROM transportation WHERE date(pickup_date) = date('now') AND COALESCE(status,'') != 'Cancelled'
     ORDER BY pickup_time ASC LIMIT 8`
  ).all();

  return { tours, hajjGroups, departures, hotelCheckIns, hotelCheckOuts, transportToday };
}

/**
 * Dashboard Calendar (master prompt section 41): every real, dated event
 * that belongs on a travel-agency calendar, for one month. `month` is
 * 1-indexed (1=January). Each event carries just enough to render a dot on
 * its day and a short label in the day's popover - the calendar links back
 * to the real record rather than duplicating its detail.
 */
function getCalendarEvents(year, month) {
  const db = getDb();
  const pad = String(month).padStart(2, '0');
  // Half-open [start, nextStart) range on the raw date columns (sargable -
  // uses the existing date indexes) rather than strftime('%Y-%m', col) = ...,
  // which wraps the column in a function and forces a full scan every time
  // someone flips the dashboard calendar to another month.
  const start = `${year}-${pad}-01`;
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  const end = `${nextYear}-${String(nextMonth).padStart(2, '0')}-01`;
  const range = { start, end };

  const departures = db.prepare(
    `SELECT bk.id, bk.booking_code, bk.departure_date AS date, c.full_name AS label
     FROM bookings bk JOIN customers c ON c.id = bk.customer_id
     WHERE bk.status <> 'Cancelled' AND bk.departure_date >= @start AND bk.departure_date < @end`
  ).all(range).map((r) => ({ type: 'Departure', date: r.date, label: `${r.booking_code} — ${r.label}`, link: `/bookings/${r.id}/360` }));

  const arrivals = db.prepare(
    `SELECT bk.id, bk.booking_code, bk.return_date AS date, c.full_name AS label
     FROM bookings bk JOIN customers c ON c.id = bk.customer_id
     WHERE bk.status <> 'Cancelled' AND bk.return_date >= @start AND bk.return_date < @end`
  ).all(range).map((r) => ({ type: 'Arrival', date: r.date, label: `${r.booking_code} — ${r.label}`, link: `/bookings/${r.id}/360` }));

  const checkIns = db.prepare(
    `SELECT h.booking_id, h.hotel_name, h.check_in AS date FROM hotels h WHERE h.check_in >= @start AND h.check_in < @end`
  ).all(range).map((r) => ({ type: 'Hotel Check-in', date: r.date, label: r.hotel_name, link: r.booking_id ? `/bookings/${r.booking_id}/360` : null }));

  const checkOuts = db.prepare(
    `SELECT h.booking_id, h.hotel_name, h.check_out AS date FROM hotels h WHERE h.check_out >= @start AND h.check_out < @end`
  ).all(range).map((r) => ({ type: 'Hotel Check-out', date: r.date, label: r.hotel_name, link: r.booking_id ? `/bookings/${r.booking_id}/360` : null }));

  const visaExpiry = db.prepare(
    `SELECT v.customer_id, c.full_name AS label, v.expiry_date AS date FROM visa_applications v
     JOIN customers c ON c.id = v.customer_id WHERE v.expiry_date >= @start AND v.expiry_date < @end`
  ).all(range).map((r) => ({ type: 'Visa Expiry', date: r.date, label: r.label, link: r.customer_id ? `/customers/${r.customer_id}/360` : null }));

  // One event PER DAY (count + total) rather than one per payment: a busy
  // month has thousands of payments, and a calendar cell/popover needs "how
  // much came in that day", not thousands of rows shipped over IPC. Refunds
  // are money going out, so they aren't counted as payments received.
  const payments = db.prepare(
    `SELECT date(p.payment_date) AS date, COUNT(*) AS n, COALESCE(SUM(p.amount), 0) AS total
     FROM payments p WHERE p.payment_type <> 'Refund' AND p.payment_date >= @start AND p.payment_date < @end
     GROUP BY date(p.payment_date)`
  ).all(range).map((r) => ({ type: 'Payment', date: r.date, label: `${r.n} payment${r.n === 1 ? '' : 's'} received - ${Math.round(r.total).toLocaleString('en-PK')}`, link: '/payments' }));

  const followUps = db.prepare(
    `SELECT fu.id, fu.follow_up_date AS date, fu.notes, fu.customer_id, c.full_name AS customer_name
     FROM follow_ups fu LEFT JOIN customers c ON c.id = fu.customer_id
     WHERE fu.status = 'Pending' AND fu.follow_up_date >= @start AND fu.follow_up_date < @end`
  ).all(range).map((r) => ({ type: 'Follow-up', date: r.date, label: r.customer_name ? `${r.customer_name}${r.notes ? ' — ' + r.notes : ''}` : (r.notes || 'Follow-up'), link: r.customer_id ? `/customers/${r.customer_id}/360` : null }));

  const all = [...departures, ...arrivals, ...checkIns, ...checkOuts, ...visaExpiry, ...payments, ...followUps].filter((e) => e.date);

  const byDay = {};
  for (const e of all) {
    const day = String(e.date).slice(0, 10);
    if (!byDay[day]) byDay[day] = [];
    byDay[day].push(e);
  }
  return byDay;
}

module.exports = { getStats, getMonthlyFinancials, getActionRequired, getCharts, getUpcomingPanels, getOperationsPanels, getCalendarEvents };
