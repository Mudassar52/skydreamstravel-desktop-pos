const { getDb } = require('../../src/database/db');

const RELATIONSHIPS = ['Self', 'Spouse', 'Child', 'Parent', 'Sibling', 'Other'];

const TRAVELLER_FIELDS = [
  'customer_id', 'full_name', 'relationship', 'date_of_birth', 'gender', 'nationality',
  'passport_number', 'passport_issue_date', 'passport_expiry_date', 'visa_status', 'notes'
];

function validate(payload) {
  if (!payload.full_name || !payload.full_name.trim()) throw new Error('Traveller name is required.');
  if (payload.passport_issue_date && payload.passport_expiry_date) {
    if (new Date(payload.passport_expiry_date) < new Date(payload.passport_issue_date)) {
      throw new Error('Passport expiry date cannot be before the issue date.');
    }
  }
}

function list({ search = '', customerId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(t.full_name LIKE @q OR t.passport_number LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (customerId) { conditions.push('t.customer_id = @customerId'); params.customerId = customerId; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM travellers t ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT t.*, c.full_name AS customer_name,
        (SELECT COUNT(*) FROM booking_travellers bt WHERE bt.traveller_id = t.id) AS bookings_count
       FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id
       ${where} ORDER BY t.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const traveller = db
    .prepare(`SELECT t.*, c.full_name AS customer_name FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id WHERE t.id = ?`)
    .get(id);
  if (!traveller) throw new Error('Traveller not found.');

  const bookings = db
    .prepare(
      `SELECT b.id, b.booking_code, b.booking_type, b.status, b.departure_date
       FROM booking_travellers bt JOIN bookings b ON b.id = bt.booking_id
       WHERE bt.traveller_id = ? ORDER BY b.created_at DESC`
    )
    .all(id);

  return { ...traveller, bookings };
}

function listByCustomer(customerId) {
  const db = getDb();
  return db.prepare('SELECT * FROM travellers WHERE customer_id = ? ORDER BY full_name').all(customerId);
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of TRAVELLER_FIELDS) params[f] = payload[f] ?? null;

  const result = db
    .prepare(`INSERT INTO travellers (${TRAVELLER_FIELDS.join(', ')}) VALUES (${TRAVELLER_FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Traveller Created', 'traveller', ?, ?)`
  ).run(result.lastInsertRowid, `Traveller "${payload.full_name}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM travellers WHERE id = ?').get(id);
  if (!existing) throw new Error('Traveller not found.');

  const params = { id };
  const sets = [];
  for (const f of TRAVELLER_FIELDS) {
    if (payload[f] !== undefined) { sets.push(`${f} = @${f}`); params[f] = payload[f]; }
  }
  sets.push("updated_at = datetime('now')");
  db.prepare(`UPDATE travellers SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Traveller Updated', 'traveller', ?, ?)`
  ).run(id, `Traveller #${id} updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const linked = db.prepare('SELECT COUNT(*) AS c FROM booking_travellers WHERE traveller_id = ?').get(id).c;
  if (linked > 0) throw new Error('This traveller is linked to existing bookings and cannot be deleted.');
  const traveller = db.prepare('SELECT full_name FROM travellers WHERE id = ?').get(id);
  db.prepare('DELETE FROM travellers WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'traveller', ?, ?)`
  ).run(id, `Traveller "${traveller?.full_name || id}" deleted`);
  return { success: true };
}

function addToBooking(bookingId, travellerId, notes) {
  const db = getDb();
  const exists = db.prepare('SELECT id FROM booking_travellers WHERE booking_id = ? AND traveller_id = ?').get(bookingId, travellerId);
  if (exists) throw new Error('This traveller is already on that booking.');
  const result = db.prepare('INSERT INTO booking_travellers (booking_id, traveller_id, notes) VALUES (?, ?, ?)').run(bookingId, travellerId, notes || null);
  return { id: result.lastInsertRowid };
}

function removeFromBooking(membershipId) {
  const db = getDb();
  const m = db.prepare('SELECT booking_id, traveller_id FROM booking_travellers WHERE id = ?').get(membershipId);
  db.transaction(() => {
    if (m) {
      // keep the booking's flights / hotel stays consistent: someone no longer on the booking can't stay on them
      db.prepare('DELETE FROM flight_travellers WHERE traveller_id = ? AND flight_id IN (SELECT id FROM flights WHERE booking_id = ?)').run(m.traveller_id, m.booking_id);
      db.prepare('DELETE FROM hotel_guests WHERE traveller_id = ? AND hotel_id IN (SELECT id FROM hotels WHERE booking_id = ?)').run(m.traveller_id, m.booking_id);
    }
    db.prepare('DELETE FROM booking_travellers WHERE id = ?').run(membershipId);
  })();
  return { success: true };
}

function listForBooking(bookingId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT bt.id AS membership_id, t.* FROM booking_travellers bt
       JOIN travellers t ON t.id = bt.traveller_id
       WHERE bt.booking_id = ? ORDER BY t.full_name`
    )
    .all(bookingId);
}

module.exports = {
  RELATIONSHIPS, list, get, listByCustomer, create, update, remove,
  addToBooking, removeFromBooking, listForBooking
};
