/**
 * Who is signed in, as far as the main process is concerned (Phase 21).
 *
 * The renderer used to be the only place that knew the user, so every permission check lived in the UI and an IPC
 * call made any other way was unchecked. Now `auth:login` records the user here, `auth:logout` clears it, and the
 * IPC guard (electron/ipc/accessControl.js) consults it on every call.
 *
 * Only the user id is remembered. Role, permissions, capabilities and the active flag are read fresh from the
 * database on each check, so an admin's change to a permission, or deactivating an account, takes effect on the
 * very next action instead of waiting for the person to sign out and in again.
 *
 * This app is a single-window desktop program, so there is one session, not one per connection.
 */
const { getDb } = require('../../src/database/db');

let currentUserId = null;

function signIn(userId) { currentUserId = userId; }
function signOut() { currentUserId = null; }
function isSignedIn() { return currentUserId !== null; }

/** Returns { id, roleId, roleName, fullName, permissions, capabilities } or null (nobody signed in / account gone or deactivated). */
function current() {
  if (currentUserId === null) return null;
  const authService = require('./authService');
  const db = getDb();
  const u = db.prepare('SELECT u.id, u.full_name, u.is_active, u.role_id, r.name AS role_name FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.id = ?').get(currentUserId);
  if (!u || !u.is_active) { currentUserId = null; return null; }
  return {
    id: u.id,
    fullName: u.full_name,
    roleId: u.role_id,
    roleName: u.role_name,
    permissions: authService.getPermissionsForRole(u.role_id),
    capabilities: authService.getCapabilitiesForRole(u.role_id)
  };
}

module.exports = { signIn, signOut, isSignedIn, current };
