const { getDb } = require('../../src/database/db');

const SERVICE_TYPES = [
  'Ziyarat', 'Food', 'Meals', 'Insurance', 'Tours', 'Excursions', 'Guide',
  'Sightseeing', 'Hajj Services', 'Tickets', 'Miscellaneous'
];
const STATUSES = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];

const FIELDS = [
  'service_type', 'booking_id', 'customer_id', 'traveller_id', 'supplier_id',
  'description', 'service_date', 'cost', 'selling_price', 'currency', 'status', 'notes',
  'package_component_id'
];

function validate(payload) {
  if (!payload.service_type || !SERVICE_TYPES.includes(payload.service_type)) {
    throw new Error('A valid service type is required.');
  }
}

function list({ search = '', serviceType = 'All', bookingId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(os.description LIKE @q OR c.full_name LIKE @q OR b.booking_code LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (serviceType && serviceType !== 'All') { conditions.push('os.service_type = @serviceType'); params.serviceType = serviceType; }
  if (bookingId) { conditions.push('os.booking_id = @bookingId'); params.bookingId = bookingId; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const baseFrom = `FROM other_services os
    LEFT JOIN customers c ON c.id = os.customer_id
    LEFT JOIN bookings b ON b.id = os.booking_id
    LEFT JOIN suppliers s ON s.id = os.supplier_id`;

  const total = db.prepare(`SELECT COUNT(*) AS c ${baseFrom} ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT os.*, c.full_name AS customer_name, b.booking_code, s.name AS supplier_name
       ${baseFrom} ${where} ORDER BY os.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT os.*, c.full_name AS customer_name, b.booking_code, s.name AS supplier_name
       FROM other_services os
       LEFT JOIN customers c ON c.id = os.customer_id
       LEFT JOIN bookings b ON b.id = os.booking_id
       LEFT JOIN suppliers s ON s.id = os.supplier_id
       WHERE os.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Service not found.');
  return row;
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of FIELDS) params[f] = payload[f] ?? null;
  params.cost = Number(payload.cost || 0);
  params.selling_price = Number(payload.selling_price || 0);
  if (!params.currency) params.currency = 'PKR';
  if (!params.status) params.status = 'Pending';

  const result = db
    .prepare(`INSERT INTO other_services (${FIELDS.join(', ')}) VALUES (${FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Other Service Created', 'other_service', ?, ?)`
  ).run(result.lastInsertRowid, `${payload.service_type} service added`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM other_services WHERE id = ?').get(id);
  if (!existing) throw new Error('Service not found.');

  const params = { id };
  const sets = [];
  for (const f of FIELDS) {
    if (payload[f] !== undefined) {
      sets.push(`${f} = @${f}`);
      params[f] = ['cost', 'selling_price'].includes(f) ? Number(payload[f] || 0) : payload[f];
    }
  }
  db.prepare(`UPDATE other_services SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Other Service Updated', 'other_service', ?, ?)`
  ).run(id, `${payload.service_type || `#${id}`} service updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  db.prepare('DELETE FROM other_services WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'other_service', ?, ?)`
  ).run(id, `Other service #${id} deleted`);
  return { success: true };
}

module.exports = { SERVICE_TYPES, STATUSES, list, get, create, update, remove };
