const { getDb } = require('../../src/database/db');

// Report History (master prompt section 42): every time a custom report is
// generated (previewed, exported to PDF/CSV, or printed), the SPEC that
// produced it is stored here - never the rendered output - so an authorized
// user can reopen it and have customReportService.run() regenerate it fresh
// against current data, or exactly reproduce what was seen at the time by
// keeping the same filters.

function record({ reportName, reportType, userId = null, spec, dateFrom = null, dateTo = null, generatedFormat = 'Preview', relatedCustomerId = null, relatedSupplierId = null, relatedBookingId = null, fileReference = null }) {
  const db = getDb();
  if (!reportName || !reportName.trim()) throw new Error('Report name is required.');
  if (!reportType) throw new Error('Report type is required.');
  const result = db.prepare(
    `INSERT INTO report_history (report_name, report_type, user_id, spec, date_from, date_to, generated_format, related_customer_id, related_supplier_id, related_booking_id, file_reference)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(reportName.trim(), reportType, userId, JSON.stringify(spec || {}), dateFrom, dateTo, generatedFormat, relatedCustomerId, relatedSupplierId, relatedBookingId, fileReference);

  // Master prompt section 49's audit log explicitly lists "Report generated"
  // as its own event, distinct from this history row (which exists so the
  // report can be reopened/regenerated) - this is that audit trail entry.
  db.prepare(
    `INSERT INTO audit_logs (user_id, action, record_type, record_id, description) VALUES (?, 'Report Generated', 'report_history', ?, ?)`
  ).run(userId, result.lastInsertRowid, `${reportName.trim()} (${reportType}, ${generatedFormat})`);

  return { id: result.lastInsertRowid };
}

function list({ reportType = 'All', search = '', page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const where = [];
  const params = {};
  if (reportType && reportType !== 'All') { where.push('h.report_type = @reportType'); params.reportType = reportType; }
  if (search && search.trim()) { where.push('h.report_name LIKE @q'); params.q = `%${search.trim()}%`; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM report_history h ${whereSql}`).get(params).c;
  const size = Number(pageSize) || 20;
  const rows = db.prepare(
    `SELECT h.*, u.full_name AS user_name, c.full_name AS customer_name, s.name AS supplier_name, bk.booking_code
     FROM report_history h
     LEFT JOIN users u ON u.id = h.user_id
     LEFT JOIN customers c ON c.id = h.related_customer_id
     LEFT JOIN suppliers s ON s.id = h.related_supplier_id
     LEFT JOIN bookings bk ON bk.id = h.related_booking_id
     ${whereSql} ORDER BY h.id DESC LIMIT @limit OFFSET @offset`
  ).all({ ...params, limit: size, offset: (Math.max(1, Number(page) || 1) - 1) * size });

  return { rows: rows.map((r) => ({ ...r, spec: JSON.parse(r.spec) })), total, page: Number(page) || 1, pageSize: size };
}

function get(id) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM report_history WHERE id = ?').get(id);
  if (!row) throw new Error('Report history entry not found.');
  return { ...row, spec: JSON.parse(row.spec) };
}

/** Re-runs the stored spec against current data - the "reopen/regenerate" action. */
function regenerate(id) {
  const customReportService = require('./customReportService');
  const entry = get(id);
  return { entry, result: customReportService.run(entry.spec) };
}

function remove(id) {
  const db = getDb();
  const result = db.prepare('DELETE FROM report_history WHERE id = ?').run(id);
  if (result.changes === 0) throw new Error('Report history entry not found.');
  return { success: true };
}

module.exports = { record, list, get, regenerate, remove };
