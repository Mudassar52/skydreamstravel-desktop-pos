const { getDb } = require('../../src/database/db');
const { assertValidCurrency } = require('./validation');

const PACKAGE_TYPES = ['Umrah', 'Hajj', 'Tour', 'Custom'];
const STATUSES = ['Active', 'Inactive'];

// Component types allowed per package type, matching the service list each
// product line can contain. 'Custom' packages may use anything from any list.
const COMPONENT_TYPES_BY_TYPE = {
  Umrah: [
    'Flight', 'Visa', 'Makkah Hotel', 'Madinah Hotel', 'Other Hotels',
    'Airport Pickup / Drop', 'Intercity Transport', 'Ziyarat', 'Food',
    'Insurance', 'Other Services'
  ],
  Hajj: [
    'Flight', 'Visa', 'Hotel', 'Transport', 'Hajj Services', 'Ziyarat',
    'Food', 'Insurance', 'Other Services'
  ],
  Tour: [
    'Flight', 'Hotel', 'Airport Transfers', 'Local Transport',
    'Tours / Activities', 'Sightseeing', 'Guide Services', 'Meals',
    'Insurance', 'Other Services'
  ]
};
COMPONENT_TYPES_BY_TYPE.Custom = Array.from(
  new Set(Object.values(COMPONENT_TYPES_BY_TYPE).flat())
);

// Where an auto-created booking-level service for a component ends up.
// `serviceType` is only used for the other_services table, whose
// service_type column is itself a constrained enum (see otherServiceService).
const COMPONENT_TYPE_GROUPS = {
  Flight: { table: 'flights' },
  Visa: { table: 'visa_applications' },
  'Makkah Hotel': { table: 'hotels' },
  'Madinah Hotel': { table: 'hotels' },
  'Other Hotels': { table: 'hotels' },
  Hotel: { table: 'hotels' },
  Hotels: { table: 'hotels' },
  'Airport Pickup / Drop': { table: 'transportation' },
  'Intercity Transport': { table: 'transportation' },
  Transport: { table: 'transportation' },
  'Airport Transfers': { table: 'transportation' },
  'Local Transport': { table: 'transportation' },
  Ziyarat: { table: 'other_services', serviceType: 'Ziyarat' },
  Food: { table: 'other_services', serviceType: 'Food' },
  Meals: { table: 'other_services', serviceType: 'Meals' },
  Insurance: { table: 'other_services', serviceType: 'Insurance' },
  'Hajj Services': { table: 'other_services', serviceType: 'Hajj Services' },
  'Guide Services': { table: 'other_services', serviceType: 'Guide' },
  Sightseeing: { table: 'other_services', serviceType: 'Sightseeing' },
  'Tours / Activities': { table: 'other_services', serviceType: 'Tours' },
  'Other Services': { table: 'other_services', serviceType: 'Miscellaneous' }
};

function validate(payload) {
  if (!payload.package_name || !payload.package_name.trim()) throw new Error('Package name is required.');
  const packageType = payload.package_type || 'Custom';
  if (!PACKAGE_TYPES.includes(packageType)) throw new Error('Please select a valid package type.');
  assertValidCurrency(payload.currency, 'Package currency');
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
  const allowed = COMPONENT_TYPES_BY_TYPE[packageType] || COMPONENT_TYPES_BY_TYPE.Custom;
  for (const comp of payload.components || []) {
    if (comp.component_type && !allowed.includes(comp.component_type)) {
      throw new Error(`"${comp.component_type}" is not a valid component for a ${packageType} package.`);
    }
  }
}

// ---------------------------------------------------------------------------
// Legacy mirror: the Umrah/Hajj pages' Groups & Pilgrims features predate the
// central Package Management module and still store group.package_id against
// the old umrah_packages/hajj_packages tables. Rather than change those
// foreign keys, every Umrah/Hajj package edited here is mirrored into the
// matching legacy table so it keeps showing up in the Groups dropdown -
// package editing itself always happens on the central row.
// ---------------------------------------------------------------------------

function legacyUmrahFieldsFrom(pkg) {
  const has = (types) => pkg.components.some((c) => types.includes(c.component_type));
  const find = (types) => pkg.components.find((c) => types.includes(c.component_type));
  const transport = find(['Intercity Transport', 'Airport Pickup / Drop']);
  return {
    package_name: pkg.package_name,
    departure_date: pkg.departure_date || null,
    return_date: pkg.return_date || null,
    number_of_days: pkg.number_of_days || null,
    visa_included: has(['Visa']) ? 1 : 0,
    flight_included: has(['Flight']) ? 1 : 0,
    hotel_included: has(['Makkah Hotel', 'Madinah Hotel', 'Other Hotels']) ? 1 : 0,
    transport_included: has(['Intercity Transport', 'Airport Pickup / Drop']) ? 1 : 0,
    food_included: has(['Food']) ? 1 : 0,
    ziyarat_included: has(['Ziyarat']) ? 1 : 0,
    makkah_hotel: find(['Makkah Hotel'])?.description || null,
    madinah_hotel: find(['Madinah Hotel'])?.description || null,
    transport_details: transport?.description || null,
    package_cost: pkg.estimated_cost,
    selling_price: pkg.selling_price,
    description: pkg.description || null
  };
}

function legacyHajjFieldsFrom(pkg) {
  const hotels = pkg.components.filter((c) => c.component_type === 'Hotel');
  return {
    package_name: pkg.package_name,
    departure_date: pkg.departure_date || null,
    return_date: pkg.return_date || null,
    makkah_hotel: hotels[0]?.description || null,
    madinah_hotel: hotels[1]?.description || null,
    package_cost: pkg.estimated_cost,
    selling_price: pkg.selling_price,
    description: pkg.description || null
  };
}

// Creates or updates the legacy mirror row for a just-saved Umrah/Hajj
// central package, and stamps legacy_mirror_table/legacy_mirror_id back onto
// the central row if this is the first time it gets one (e.g. it was
// switched from Custom to Umrah, or predates this feature).
function syncLegacyMirror(db, packageId) {
  const pkg = withComponents(db, db.prepare('SELECT * FROM packages WHERE id = ?').get(packageId));
  if (pkg.package_type === 'Umrah') {
    const fields = legacyUmrahFieldsFrom(pkg);
    if (pkg.legacy_mirror_table === 'umrah_packages' && pkg.legacy_mirror_id) {
      db.prepare(
        `UPDATE umrah_packages SET package_name=@package_name, departure_date=@departure_date, return_date=@return_date,
          number_of_days=@number_of_days, visa_included=@visa_included, flight_included=@flight_included,
          hotel_included=@hotel_included, transport_included=@transport_included, food_included=@food_included,
          ziyarat_included=@ziyarat_included, makkah_hotel=@makkah_hotel, madinah_hotel=@madinah_hotel,
          transport_details=@transport_details, package_cost=@package_cost, selling_price=@selling_price,
          description=@description WHERE id=@id`
      ).run({ ...fields, id: pkg.legacy_mirror_id });
    } else {
      const mirrorId = db
        .prepare(
          `INSERT INTO umrah_packages (
            package_name, package_type, departure_date, return_date, number_of_days,
            visa_included, flight_included, hotel_included, transport_included, food_included, ziyarat_included,
            makkah_hotel, madinah_hotel, transport_details, package_cost, selling_price, description
          ) VALUES (@package_name, 'Custom', @departure_date, @return_date, @number_of_days,
            @visa_included, @flight_included, @hotel_included, @transport_included, @food_included, @ziyarat_included,
            @makkah_hotel, @madinah_hotel, @transport_details, @package_cost, @selling_price, @description)`
        )
        .run(fields).lastInsertRowid;
      db.prepare('UPDATE packages SET legacy_mirror_table = ?, legacy_mirror_id = ? WHERE id = ?').run('umrah_packages', mirrorId, packageId);
    }
  } else if (pkg.package_type === 'Hajj') {
    const fields = legacyHajjFieldsFrom(pkg);
    if (pkg.legacy_mirror_table === 'hajj_packages' && pkg.legacy_mirror_id) {
      db.prepare(
        `UPDATE hajj_packages SET package_name=@package_name, departure_date=@departure_date, return_date=@return_date,
          makkah_hotel=@makkah_hotel, madinah_hotel=@madinah_hotel, package_cost=@package_cost,
          selling_price=@selling_price, description=@description WHERE id=@id`
      ).run({ ...fields, id: pkg.legacy_mirror_id });
    } else {
      const mirrorId = db
        .prepare(
          `INSERT INTO hajj_packages (package_name, departure_date, return_date, makkah_hotel, madinah_hotel, package_cost, selling_price, description)
           VALUES (@package_name, @departure_date, @return_date, @makkah_hotel, @madinah_hotel, @package_cost, @selling_price, @description)`
        )
        .run(fields).lastInsertRowid;
      db.prepare('UPDATE packages SET legacy_mirror_table = ?, legacy_mirror_id = ? WHERE id = ?').run('hajj_packages', mirrorId, packageId);
    }
  }
}

// Best-effort cleanup: only removes the mirror row if nothing (a Group)
// still points at it - if it does, the mirror is left in place (orphaned
// from this central package, but the Group keeps working) rather than
// risk a foreign-key error or a broken Group.
function removeLegacyMirrorIfUnused(db, pkg) {
  if (!pkg.legacy_mirror_table || !pkg.legacy_mirror_id) return;
  try {
    if (pkg.legacy_mirror_table === 'umrah_packages') {
      db.prepare('DELETE FROM umrah_packages WHERE id = ?').run(pkg.legacy_mirror_id);
    } else if (pkg.legacy_mirror_table === 'hajj_packages') {
      db.prepare('DELETE FROM hajj_packages WHERE id = ?').run(pkg.legacy_mirror_id);
    }
  } catch {
    // Referenced by an existing Group - leave the mirror row in place.
  }
}

function withComponents(db, pkg) {
  const components = db
    .prepare(
      `SELECT pc.*, s.name AS supplier_name
       FROM package_components pc LEFT JOIN suppliers s ON s.id = pc.supplier_id
       WHERE pc.package_id = ? ORDER BY pc.id`
    )
    .all(pkg.id);
  const estimatedCost = components.reduce((sum, c) => sum + Number(c.cost || 0), 0);
  return {
    ...pkg,
    components,
    package_price: pkg.selling_price,
    estimated_cost: estimatedCost,
    estimated_profit: Number(pkg.selling_price || 0) - estimatedCost
  };
}

function list({ search = '', packageType = 'All', status = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push('(package_name LIKE @q OR destination LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (packageType && packageType !== 'All') { conditions.push('package_type = @packageType'); params.packageType = packageType; }
  if (status && status !== 'All') { conditions.push('status = @status'); params.status = status; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM packages ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT p.*, (SELECT COUNT(*) FROM package_components pc WHERE pc.package_id = p.id) AS component_count
       FROM packages p ${where} ORDER BY p.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows: rows.map((r) => ({ ...r, package_price: r.selling_price })), total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const pkg = db.prepare('SELECT * FROM packages WHERE id = ?').get(id);
  if (!pkg) throw new Error('Package not found.');
  return withComponents(db, pkg);
}

function create(payload) {
  validate(payload);
  const db = getDb();

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO packages (
          package_name, package_type, destination, duration, departure_date, return_date, number_of_days,
          description, supplier_cost, selling_price, markup, currency, status
        ) VALUES (
          @package_name, @package_type, @destination, @duration, @departure_date, @return_date, @number_of_days,
          @description, @supplier_cost, @selling_price, @markup, @currency, @status
        )`
      )
      .run({
        package_name: payload.package_name.trim(),
        package_type: payload.package_type || 'Custom',
        destination: payload.destination || null,
        duration: payload.duration || null,
        departure_date: payload.departure_date || null,
        return_date: payload.return_date || null,
        number_of_days: payload.number_of_days || null,
        description: payload.description || null,
        supplier_cost: Number(payload.supplier_cost || 0),
        selling_price: Number(payload.selling_price || 0),
        markup: Number(payload.markup || 0),
        currency: payload.currency || 'PKR',
        status: payload.status || 'Active'
      });
    const packageId = result.lastInsertRowid;

    for (const comp of payload.components || []) {
      if (!comp.component_type) continue;
      db.prepare(
        `INSERT INTO package_components (package_id, component_type, description, cost, selling_price, supplier_id)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(
        packageId,
        comp.component_type,
        comp.description || null,
        Number(comp.cost || 0),
        Number(comp.selling_price || 0),
        comp.supplier_id || null
      );
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Package Created', 'package', ?, ?)`
    ).run(packageId, `${payload.package_type || 'Custom'} package "${payload.package_name}" created`);

    if (payload.package_type === 'Umrah' || payload.package_type === 'Hajj') {
      syncLegacyMirror(db, packageId);
    }

    return packageId;
  });

  return { id: tx() };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM packages WHERE id = ?').get(id);
  if (!existing) throw new Error('Package not found.');

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE packages SET package_name=@package_name, package_type=@package_type, destination=@destination, duration=@duration,
        departure_date=@departure_date, return_date=@return_date, number_of_days=@number_of_days, description=@description,
        supplier_cost=@supplier_cost, selling_price=@selling_price, markup=@markup, currency=@currency, status=@status,
        updated_at=datetime('now') WHERE id=@id`
    ).run({
      id,
      package_name: payload.package_name.trim(),
      package_type: payload.package_type || 'Custom',
      destination: payload.destination || null,
      duration: payload.duration || null,
      departure_date: payload.departure_date || null,
      return_date: payload.return_date || null,
      number_of_days: payload.number_of_days || null,
      description: payload.description || null,
      supplier_cost: Number(payload.supplier_cost || 0),
      selling_price: Number(payload.selling_price || 0),
      markup: Number(payload.markup || 0),
      currency: payload.currency || 'PKR',
      status: payload.status || 'Active'
    });

    if (Array.isArray(payload.components)) {
      db.prepare('DELETE FROM package_components WHERE package_id = ?').run(id);
      for (const comp of payload.components) {
        if (!comp.component_type) continue;
        db.prepare(
          `INSERT INTO package_components (package_id, component_type, description, cost, selling_price, supplier_id)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(
          id,
          comp.component_type,
          comp.description || null,
          Number(comp.cost || 0),
          Number(comp.selling_price || 0),
          comp.supplier_id || null
        );
      }
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Package Updated', 'package', ?, ?)`
    ).run(id, `Package #${id} updated`);

    if (payload.package_type === 'Umrah' || payload.package_type === 'Hajj') {
      syncLegacyMirror(db, id);
    }
  });
  tx();

  return { success: true };
}

// Historical bookings keep their own frozen snapshot (see bookingService),
// so a package can always be edited or archived freely without touching
// anything already sold - deleting it only removes it as a future option.
function remove(id) {
  const db = getDb();
  const pkg = db.prepare('SELECT * FROM packages WHERE id = ?').get(id);
  if (!pkg) throw new Error('Package not found.');
  const bookingCount = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE package_id = ?').get(id).c;
  if (bookingCount > 0) {
    throw new Error('This package has bookings linked to it. Set it to Inactive instead of deleting it.');
  }
  db.prepare('DELETE FROM packages WHERE id = ?').run(id);
  removeLegacyMirrorIfUnused(db, pkg);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'package', ?, ?)`
  ).run(id, `Package "${pkg.package_name}" deleted`);
  return { success: true };
}

function options() {
  const db = getDb();
  return db.prepare("SELECT id, package_name, package_type, destination, selling_price, currency FROM packages WHERE status = 'Active' ORDER BY package_name").all();
}

// Used by the "Create Booking" flow's Select Package step, once a booking
// type (Umrah/Hajj/Tour/Custom) has been chosen.
function optionsByType(packageType) {
  const db = getDb();
  if (!packageType || !PACKAGE_TYPES.includes(packageType)) return options();
  return db
    .prepare(
      "SELECT id, package_name, package_type, destination, duration, departure_date, return_date, selling_price, currency FROM packages WHERE status = 'Active' AND package_type = ? ORDER BY package_name"
    )
    .all(packageType);
}

// Full package + components, used by bookingService to build a booking's
// frozen snapshot and to auto-create the linked flights/visa/hotel/etc rows.
function getForBooking(id) {
  return get(id);
}

module.exports = {
  PACKAGE_TYPES,
  STATUSES,
  COMPONENT_TYPES_BY_TYPE,
  COMPONENT_TYPE_GROUPS,
  // Backwards-compatible alias: the original generic package builder only
  // ever offered one flat list of component types.
  COMPONENT_TYPES: COMPONENT_TYPES_BY_TYPE.Custom,
  list,
  get,
  create,
  update,
  remove,
  options,
  optionsByType,
  getForBooking
};
