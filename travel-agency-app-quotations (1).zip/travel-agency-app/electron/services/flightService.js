const { getDb } = require('../../src/database/db');
const { makeCrudService } = require('./genericCrud');

const FIELDS = [
  'booking_id', 'airline', 'flight_number', 'pnr', 'departure_airport', 'arrival_airport',
  'departure_date', 'departure_time', 'arrival_date', 'arrival_time', 'class',
  'ticket_number', 'status', 'notes', 'supplier_id', 'package_component_id',
  'cost', 'selling_price', 'baggage', 'seat', 'booking_reference'
];

function validate(payload) {
  if (!payload.flight_number || !payload.flight_number.trim()) {
    throw new Error('Flight number is required.');
  }
  if (payload.departure_date && payload.arrival_date && new Date(payload.arrival_date) < new Date(payload.departure_date)) {
    throw new Error('Arrival date cannot be before the departure date.');
  }
}

const crud = makeCrudService('flights', FIELDS, { validate, recordLabelField: 'flight_number' });

/**
 * Paginated/searchable, overriding the generic crud's plain list() -
 * flights scale with booking volume (Section 38: 5,000+ bookings), so an
 * unbounded SELECT * here would be exactly what that section warns against.
 */
function list({ search = '', page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push('(flight_number LIKE @q OR airline LIKE @q OR pnr LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM flights ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`SELECT * FROM flights ${where} ORDER BY created_at DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

// flights can carry several passengers - no headcount column to sync here,
// just a straightforward join table.
function listPassengers(flightId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT fp.id AS membership_id, c.id AS customer_id, c.full_name, c.phone, c.passport_number
       FROM flight_passengers fp JOIN customers c ON c.id = fp.customer_id
       WHERE fp.flight_id = ? ORDER BY fp.id ASC`
    )
    .all(flightId);
}

function addPassenger(flightId, customerId) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM flight_passengers WHERE flight_id = ? AND customer_id = ?').get(flightId, customerId);
  if (existing) throw new Error('This customer is already on the flight.');
  db.prepare('INSERT INTO flight_passengers (flight_id, customer_id) VALUES (?, ?)').run(flightId, customerId);
  return { success: true };
}

function removePassenger(membershipId) {
  const db = getDb();
  db.prepare('DELETE FROM flight_passengers WHERE id = ?').run(membershipId);
  return { success: true };
}

// ---- Travellers (family / group members of the booking) on a flight --------------------------------------------
function listTravellers(flightId) {
  return getDb().prepare(
    `SELECT ft.id AS membership_id, t.id AS traveller_id, t.full_name, t.relationship, t.passport_number
     FROM flight_travellers ft JOIN travellers t ON t.id = ft.traveller_id WHERE ft.flight_id = ? ORDER BY ft.id`
  ).all(flightId);
}

function requireFlight(db, flightId) {
  const f = db.prepare('SELECT id, booking_id FROM flights WHERE id = ?').get(flightId);
  if (!f) throw new Error('Flight not found.');
  return f;
}

function addTraveller(flightId, travellerId) {
  const db = getDb();
  const f = requireFlight(db, flightId);
  if (f.booking_id) {
    const onBooking = db.prepare('SELECT id FROM booking_travellers WHERE booking_id = ? AND traveller_id = ?').get(f.booking_id, travellerId);
    if (!onBooking) throw new Error('Add this person to the booking (Travellers) first.');
  }
  if (db.prepare('SELECT id FROM flight_travellers WHERE flight_id = ? AND traveller_id = ?').get(flightId, travellerId)) {
    throw new Error('This traveller is already on the flight.');
  }
  db.prepare('INSERT INTO flight_travellers (flight_id, traveller_id) VALUES (?, ?)').run(flightId, travellerId);
  return { success: true };
}

/** One click: put every traveller of the flight's booking on this flight (people already on it are skipped). */
function addAllFromBooking(flightId) {
  const db = getDb();
  const f = requireFlight(db, flightId);
  if (!f.booking_id) throw new Error('This flight is not linked to a booking.');
  const ids = db.prepare('SELECT traveller_id FROM booking_travellers WHERE booking_id = ?').all(f.booking_id).map((r) => r.traveller_id);
  const ins = db.prepare('INSERT OR IGNORE INTO flight_travellers (flight_id, traveller_id) VALUES (?, ?)');
  let added = 0;
  db.transaction(() => { for (const id of ids) added += ins.run(flightId, id).changes; })();
  return { added, total: ids.length };
}

function removeTraveller(membershipId) {
  getDb().prepare('DELETE FROM flight_travellers WHERE id = ?').run(membershipId);
  return { success: true };
}

function listByBooking(bookingId) {
  const db = getDb();
  return db.prepare('SELECT * FROM flights WHERE booking_id = ? ORDER BY departure_date').all(bookingId);
}

module.exports = {
  ...crud,
  list,
  listByBooking,
  passengers: { list: listPassengers, add: addPassenger, remove: removePassenger },
  travellers: { list: listTravellers, add: addTraveller, addAll: addAllFromBooking, remove: removeTraveller }
};
