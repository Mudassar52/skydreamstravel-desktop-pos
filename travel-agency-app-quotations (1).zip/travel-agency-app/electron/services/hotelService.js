const { getDb } = require('../../src/database/db');
const { makeCrudService } = require('./genericCrud');

const FIELDS = [
  'booking_id', 'hotel_name', 'country', 'city', 'address', 'contact',
  'check_in', 'check_out', 'room_type', 'number_of_rooms', 'number_of_nights',
  'booking_reference', 'cost', 'selling_price', 'notes', 'supplier_id', 'package_component_id',
  'location_type', 'room_number', 'bed_type', 'meal_plan', 'number_of_guests', 'confirmation_number', 'status'
];

function validate(payload) {
  if (!payload.hotel_name || !payload.hotel_name.trim()) {
    throw new Error('Hotel name is required.');
  }
  if (payload.check_in && payload.check_out && new Date(payload.check_out) < new Date(payload.check_in)) {
    throw new Error('Check-out date cannot be before check-in date.');
  }
}

const crud = makeCrudService('hotels', FIELDS, { validate, recordLabelField: 'hotel_name' });

/** Paginated/searchable - see the matching note in flightService.js. */
function list({ search = '', page = 1, pageSize = 20 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push('(hotel_name LIKE @q OR city LIKE @q OR country LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM hotels ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`SELECT * FROM hotels ${where} ORDER BY created_at DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function listByBooking(bookingId) {
  const db = getDb();
  return db.prepare('SELECT * FROM hotels WHERE booking_id = ? ORDER BY check_in').all(bookingId);
}

/**
 * Everyone who could stay in this hotel (the booking's lead customer + its travellers), each flagged with whether they are
 * on this stay and which room they are in.
 */
function listGuests(hotelId) {
  const db = getDb();
  const hotel = db.prepare('SELECT id, booking_id FROM hotels WHERE id = ?').get(hotelId);
  if (!hotel) throw new Error('Hotel record not found.');
  if (!hotel.booking_id) return { linked: false, guests: [] };
  const lead = db.prepare('SELECT c.id, c.full_name FROM bookings b JOIN customers c ON c.id = b.customer_id WHERE b.id = ?').get(hotel.booking_id);
  const saved = db.prepare('SELECT * FROM hotel_guests WHERE hotel_id = ?').all(hotelId);
  const hasSaved = saved.length > 0;
  const guests = [];
  const leadRow = saved.find((g) => g.is_lead);
  guests.push({ is_lead: 1, traveller_id: null, name: lead.full_name, relationship: 'Lead (booking holder)', selected: hasSaved ? !!leadRow : true, room_number: leadRow ? leadRow.room_number || '' : '' });
  const travellers = db.prepare(
    `SELECT t.id, t.full_name, t.relationship FROM booking_travellers bt JOIN travellers t ON t.id = bt.traveller_id
     WHERE bt.booking_id = ? ORDER BY bt.id`
  ).all(hotel.booking_id);
  for (const t of travellers) {
    const row = saved.find((g) => g.traveller_id === t.id);
    guests.push({ is_lead: 0, traveller_id: t.id, name: t.full_name, relationship: t.relationship || 'Traveller', selected: hasSaved ? !!row : true, room_number: row ? row.room_number || '' : '' });
  }
  return { linked: true, guests };
}

/** Replace the hotel's guest list. `guests` = [{ is_lead, traveller_id, selected, room_number }]. */
function saveGuests(hotelId, guests) {
  const db = getDb();
  const hotel = db.prepare('SELECT id, booking_id FROM hotels WHERE id = ?').get(hotelId);
  if (!hotel) throw new Error('Hotel record not found.');
  if (!hotel.booking_id) throw new Error('Link this hotel to a booking first.');
  const onBooking = new Set(db.prepare('SELECT traveller_id FROM booking_travellers WHERE booking_id = ?').all(hotel.booking_id).map((r) => r.traveller_id));
  db.transaction(() => {
    db.prepare('DELETE FROM hotel_guests WHERE hotel_id = ?').run(hotelId);
    const ins = db.prepare('INSERT INTO hotel_guests (hotel_id, traveller_id, is_lead, room_number) VALUES (?, ?, ?, ?)');
    for (const g of guests || []) {
      if (!g.selected) continue;
      if (!g.is_lead && !onBooking.has(g.traveller_id)) throw new Error('A guest is not a traveller of this booking.');
      ins.run(hotelId, g.is_lead ? null : g.traveller_id, g.is_lead ? 1 : 0, (g.room_number || '').trim() || null);
    }
  })();
  return { success: true };
}

module.exports = { ...crud, list, listByBooking, guests: { list: listGuests, save: saveGuests } };
