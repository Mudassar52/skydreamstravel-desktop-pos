const { getDb } = require('../../src/database/db');

// Booking 360 (master prompt section 26 / 60-A.9). READ-ONLY, assembled from
// the real tables of ONE booking: flights, hotels, visa_applications,
// transportation, other_services (Ziyarat), invoices, payments, ledger_entries,
// supplier_invoices, supplier_payments, documents, travellers, package_snapshot.
//
// "Estimated" (booking-service cost/selling) and "Actual" (real supplier
// invoices, real customer invoices/payments) are always kept apart, exactly
// like Customer 360 / Supplier 360 / Package 360, and are never summed.

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function requireBooking(db, id) {
  const b = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
  if (!b) throw new Error('Booking not found.');
  return b;
}

function header(bookingId) {
  const db = getDb();
  const b = requireBooking(db, bookingId);
  const customer = db.prepare('SELECT id, full_name, phone, whatsapp, email FROM customers WHERE id = ?').get(b.customer_id);
  let packageSnapshot = null;
  if (b.package_snapshot) {
    try { packageSnapshot = JSON.parse(b.package_snapshot); } catch (_) { packageSnapshot = null; }
  }
  return {
    id: b.id, booking_code: b.booking_code, booking_type: b.booking_type, status: b.status,
    booking_date: b.booking_date, departure_date: b.departure_date, return_date: b.return_date,
    destination: b.destination || null, number_of_passengers: b.number_of_passengers || null,
    total_price: round2(b.total_price), currency: b.currency || packageSnapshot?.currency || 'PKR',
    notes: b.notes || null, package_id: b.package_id || null, package_snapshot: packageSnapshot,
    customer
  };
}

/** Everyone travelling on this booking (booking_travellers -> travellers). */
function travellers(bookingId) {
  const db = getDb();
  requireBooking(db, bookingId);
  return db.prepare(
    `SELECT t.*, bt.notes AS booking_notes FROM booking_travellers bt
     JOIN travellers t ON t.id = bt.traveller_id WHERE bt.booking_id = ? ORDER BY t.full_name`
  ).all(bookingId);
}

function flights(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT f.*, s.name AS supplier_name FROM flights f LEFT JOIN suppliers s ON s.id = f.supplier_id
     WHERE f.booking_id = ? ORDER BY f.departure_date`
  ).all(bookingId).map((r) => ({ ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2((r.selling_price || 0) - (r.cost || 0)) }));
}

function hotels(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT h.*, s.name AS supplier_name FROM hotels h LEFT JOIN suppliers s ON s.id = h.supplier_id
     WHERE h.booking_id = ? ORDER BY h.check_in`
  ).all(bookingId).map((r) => ({ ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2((r.selling_price || 0) - (r.cost || 0)) }));
}

function visa(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT v.*, s.name AS supplier_name FROM visa_applications v LEFT JOIN suppliers s ON s.id = v.supplier_id
     WHERE v.booking_id = ? ORDER BY v.created_at`
  ).all(bookingId).map((r) => ({ ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2((r.selling_price || 0) - (r.cost || 0)) }));
}

function transport(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT t.*, s.name AS supplier_name FROM transportation t LEFT JOIN suppliers s ON s.id = t.supplier_id
     WHERE t.booking_id = ? ORDER BY t.pickup_date`
  ).all(bookingId).map((r) => ({ ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2((r.selling_price || 0) - (r.cost || 0)) }));
}

/** Ziyarat + all other non-core services on this booking. */
function ziyarat(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT o.*, s.name AS supplier_name FROM other_services o LEFT JOIN suppliers s ON s.id = o.supplier_id
     WHERE o.booking_id = ? ORDER BY o.service_date`
  ).all(bookingId).map((r) => ({ ...r, cost: round2(r.cost), selling_price: round2(r.selling_price), profit: round2((r.selling_price || 0) - (r.cost || 0)) }));
}

/** Suppliers directory: one row per supplier touching this booking, with their service lines. */
function suppliers(bookingId) {
  const db = getDb();
  const rows = db.prepare(
    `SELECT s.id, s.supplier_code, s.name, s.service_type, s.phone, s.email,
       (SELECT COUNT(*) FROM (
          SELECT booking_id, supplier_id FROM flights WHERE booking_id = @b
          UNION ALL SELECT booking_id, supplier_id FROM hotels WHERE booking_id = @b
          UNION ALL SELECT booking_id, supplier_id FROM visa_applications WHERE booking_id = @b
          UNION ALL SELECT booking_id, supplier_id FROM transportation WHERE booking_id = @b
          UNION ALL SELECT booking_id, supplier_id FROM other_services WHERE booking_id = @b
        ) z WHERE z.supplier_id = s.id) AS service_count
     FROM suppliers s
     WHERE s.id IN (
       SELECT supplier_id FROM flights WHERE booking_id = @b AND supplier_id IS NOT NULL
       UNION SELECT supplier_id FROM hotels WHERE booking_id = @b AND supplier_id IS NOT NULL
       UNION SELECT supplier_id FROM visa_applications WHERE booking_id = @b AND supplier_id IS NOT NULL
       UNION SELECT supplier_id FROM transportation WHERE booking_id = @b AND supplier_id IS NOT NULL
       UNION SELECT supplier_id FROM other_services WHERE booking_id = @b AND supplier_id IS NOT NULL
       UNION SELECT supplier_id FROM supplier_invoices WHERE booking_id = @b AND supplier_id IS NOT NULL
     )
     ORDER BY s.name`
  ).all({ b: bookingId });
  return rows;
}

function invoices(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT id, invoice_number, invoice_date, total, paid_amount, remaining_amount, status
     FROM invoices WHERE booking_id = ? ORDER BY invoice_date DESC`
  ).all(bookingId).map((r) => ({ ...r, total: round2(r.total), paid_amount: round2(r.paid_amount), remaining_amount: round2(r.remaining_amount) }));
}

function payments(bookingId) {
  const db = getDb();
  return db.prepare(
    `SELECT p.*, i.invoice_number FROM payments p LEFT JOIN invoices i ON i.id = p.invoice_id
     WHERE p.booking_id = @b OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = @b)
     ORDER BY p.payment_date DESC`
  ).all({ b: bookingId }).map((r) => ({ ...r, amount: round2(r.amount) }));
}

/** Advances received against this booking (received vs used) - never double counted with payments. */
function advances(bookingId) {
  const db = getDb();
  const rows = db.prepare(
    `SELECT * FROM payments WHERE payment_type = 'Advance' AND (booking_id = ? OR invoice_id IN (SELECT id FROM invoices WHERE booking_id = ?)) ORDER BY payment_date DESC`
  ).all(bookingId, bookingId).map((r) => ({ ...r, amount: round2(r.amount) }));
  const received = round2(rows.reduce((a, r) => a + r.amount, 0));
  const used = round2(rows.filter((r) => r.invoice_id || r.booking_id).reduce((a, r) => a + r.amount, 0));
  return { rows, received, used, remaining: round2(received - used) };
}

/** Outstanding = booking sale total minus real payments (net of refunds) received against it. */
function outstanding(bookingId) {
  const db = getDb();
  const b = requireBooking(db, bookingId);
  const paid = db.prepare(
    `SELECT COALESCE(SUM(CASE WHEN payment_type <> 'Refund' THEN amount ELSE -amount END),0) AS s
     FROM payments WHERE booking_id = ? OR invoice_id IN (SELECT id FROM invoices WHERE booking_id = ?)`
  ).get(bookingId, bookingId).s;
  return { selling: round2(b.total_price), paid: round2(paid), outstanding: round2(b.total_price - paid) };
}

/** Supplier-side cost ledger for this booking only: invoices, payments, payable. */
function supplierCosts(bookingId) {
  const db = getDb();
  const invRows = db.prepare(
    `SELECT si.*, s.name AS supplier_name FROM supplier_invoices si JOIN suppliers s ON s.id = si.supplier_id
     WHERE si.booking_id = ? ORDER BY si.invoice_date DESC`
  ).all(bookingId).map((r) => ({ ...r, total: round2(r.total), paid_amount: round2(r.paid_amount), remaining_amount: round2(r.remaining_amount) }));
  const payRows = db.prepare(
    `SELECT sp.*, s.name AS supplier_name FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id
     WHERE sp.booking_id = ? ORDER BY sp.payment_date DESC`
  ).all(bookingId).map((r) => ({ ...r, amount: round2(r.amount) }));
  const invoiced = round2(invRows.reduce((a, r) => a + r.total, 0));
  // paid = what's actually settled on those invoices (si.paid_amount already
  // reflects any advance applied via supplierAdvanceService) plus any payment
  // tied to this booking that isn't against an invoice yet (an uninvoiced advance).
  const paidOnInvoices = round2(invRows.reduce((a, r) => a + r.paid_amount, 0));
  const uninvoicedPayments = round2(payRows.filter((r) => !r.supplier_invoice_id).reduce((a, r) => a + r.amount, 0));
  const paid = round2(paidOnInvoices + uninvoicedPayments);
  const payable = round2(invRows.reduce((a, r) => a + r.remaining_amount, 0));
  return { invoices: invRows, payments: payRows, invoiced, paid, payable };
}

/** Estimated service cost from the five booking-service tables (used when no supplier invoice exists). */
function estimatedServiceCost(bookingId) {
  const db = getDb();
  const sum = (table) => db.prepare(`SELECT COALESCE(SUM(cost),0) AS s, COALESCE(SUM(selling_price),0) AS sp FROM ${table} WHERE booking_id = ?`).get(bookingId);
  const parts = ['flights', 'hotels', 'visa_applications', 'transportation', 'other_services'].map(sum);
  return {
    cost: round2(parts.reduce((a, p) => a + p.s, 0)),
    selling: round2(parts.reduce((a, p) => a + p.sp, 0))
  };
}

/** Profit: estimated (service cost vs sold price) side by side with actual (real invoices/supplier invoices/expenses). */
function profit(bookingId) {
  const db = getDb();
  const b = requireBooking(db, bookingId);
  const est = estimatedServiceCost(bookingId);
  const invoiced = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE booking_id = ? AND status <> 'Cancelled'`).get(bookingId).s;
  const supplierInvoiced = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM supplier_invoices WHERE booking_id = ?`).get(bookingId).s;
  const expenses = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE related_booking_id = ?`).get(bookingId).s;
  const actualCost = supplierInvoiced > 0 ? supplierInvoiced : (b.status === 'Cancelled' ? 0 : est.cost);
  const estimatedProfit = round2(b.total_price - est.cost);
  const actualProfit = round2(invoiced - actualCost - expenses);
  return {
    estimated_revenue: round2(b.total_price), estimated_cost: est.cost, estimated_profit: estimatedProfit,
    actual_revenue: round2(invoiced), actual_supplier_cost: round2(actualCost), expenses: round2(expenses), actual_profit: actualProfit,
    margin_percent: invoiced > 0 ? round2((actualProfit / invoiced) * 100) : null
  };
}

function documents(bookingId) {
  const db = getDb();
  return db.prepare('SELECT * FROM documents WHERE booking_id = ? ORDER BY uploaded_at DESC').all(bookingId);
}

/** Combined timeline + activity history: every real event tied to this booking, newest first. */
function timeline(bookingId) {
  const db = getDb();
  requireBooking(db, bookingId);
  const rows = db.prepare(
    `WITH ev AS (
       SELECT booking_date AS at, 'Booking created' AS event, booking_code AS reference, notes FROM bookings WHERE id = @b
       UNION ALL SELECT updated_at, 'Booking ' || LOWER(status), booking_code, NULL FROM bookings WHERE id = @b AND status IN ('Completed', 'Cancelled')
       UNION ALL SELECT invoice_date, 'Invoice generated', invoice_number, NULL FROM invoices WHERE booking_id = @b
       UNION ALL SELECT payment_date, CASE payment_type WHEN 'Refund' THEN 'Refund issued' WHEN 'Advance' THEN 'Advance received' ELSE 'Payment received' END,
              COALESCE(NULLIF(reference,''), 'PAY-' || id), payment_method || ' - ' || printf('%.2f', amount) FROM payments p
              WHERE p.booking_id = @b OR p.invoice_id IN (SELECT id FROM invoices WHERE booking_id = @b)
       UNION ALL SELECT si.invoice_date, 'Supplier invoice recorded', si.invoice_number, s.name FROM supplier_invoices si JOIN suppliers s ON s.id = si.supplier_id WHERE si.booking_id = @b
       UNION ALL SELECT sp.payment_date, 'Supplier payment made', COALESCE(NULLIF(sp.reference,''), 'SPAY-' || sp.id), s.name FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id WHERE sp.booking_id = @b
       UNION ALL SELECT f.created_at, 'Flight added', COALESCE(f.pnr, f.flight_number), NULL FROM flights f WHERE f.booking_id = @b
       UNION ALL SELECT h.created_at, 'Hotel added', h.hotel_name, NULL FROM hotels h WHERE h.booking_id = @b
       UNION ALL SELECT v.created_at, 'Visa added', v.application_number, v.country FROM visa_applications v WHERE v.booking_id = @b
       UNION ALL SELECT t.created_at, 'Transport added', t.vehicle_number, t.pickup_location FROM transportation t WHERE t.booking_id = @b
       UNION ALL SELECT o.created_at, o.service_type || ' added', NULL, o.description FROM other_services o WHERE o.booking_id = @b
       UNION ALL SELECT d.uploaded_at, 'Document uploaded', d.file_name, d.document_type FROM documents d WHERE d.booking_id = @b
     ) SELECT * FROM ev WHERE at IS NOT NULL ORDER BY at DESC`
  ).all({ b: bookingId });
  return rows;
}

function getDossier(bookingId) {
  return {
    header: header(bookingId),
    travellers: travellers(bookingId),
    flights: flights(bookingId),
    hotels: hotels(bookingId),
    visa: visa(bookingId),
    transport: transport(bookingId),
    ziyarat: ziyarat(bookingId),
    suppliers: suppliers(bookingId),
    invoices: invoices(bookingId),
    payments: payments(bookingId),
    advances: advances(bookingId),
    outstanding: outstanding(bookingId),
    supplierCosts: supplierCosts(bookingId),
    profit: profit(bookingId),
    documents: documents(bookingId),
    timeline: timeline(bookingId)
  };
}

module.exports = {
  header, travellers, flights, hotels, visa, transport, ziyarat, suppliers,
  invoices, payments, advances, outstanding, supplierCosts, estimatedServiceCost,
  profit, documents, timeline, getDossier
};
