const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');

function validate(payload) {
  if (!payload.account || !payload.account.trim()) throw new Error('An account name is required.');
  const debit = Number(payload.debit || 0);
  const credit = Number(payload.credit || 0);
  if (debit === 0 && credit === 0) throw new Error('Enter either a debit or a credit amount.');
  if (debit > 0 && credit > 0) throw new Error('An entry can be a debit or a credit, not both.');
}

function list({ account = null, bookingId = null, dateFrom = null, dateTo = null, page = 1, pageSize = 30 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (account) { conditions.push('e.account = @account'); params.account = account; }
  if (bookingId) { conditions.push('e.booking_id = @bookingId'); params.bookingId = bookingId; }
  if (dateFrom) { conditions.push('date(e.entry_date) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('date(e.entry_date) <= date(@dateTo)'); params.dateTo = dateTo; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM accounting_entries e ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT e.*, b.booking_code, c.full_name AS customer_name, s.name AS supplier_name
       FROM accounting_entries e
       LEFT JOIN bookings b ON b.id = e.booking_id
       LEFT JOIN customers c ON c.id = e.customer_id
       LEFT JOIN suppliers s ON s.id = e.supplier_id
       ${where} ORDER BY e.entry_date DESC, e.id DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function listAccounts() {
  const db = getDb();
  return db.prepare('SELECT DISTINCT account FROM accounting_entries ORDER BY account').all().map((r) => r.account);
}

/** Trial-balance-style summary: net debit/credit per account. */
function summary({ dateFrom = null, dateTo = null } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (dateFrom) { conditions.push('date(entry_date) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('date(entry_date) <= date(@dateTo)'); params.dateTo = dateTo; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const rows = db
    .prepare(
      `SELECT account, COALESCE(SUM(debit),0) AS total_debit, COALESCE(SUM(credit),0) AS total_credit,
        COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS net
       FROM accounting_entries ${where} GROUP BY account ORDER BY account`
    )
    .all(params);

  const columns = [
    { key: 'account', label: 'Account' },
    { key: 'total_debit', label: 'Total Debit', money: true },
    { key: 'total_credit', label: 'Total Credit', money: true },
    { key: 'net', label: 'Net', money: true }
  ];
  return { columns, rows };
}

function create(payload) {
  periodLock.assertOpen(payload.entry_date, 'This accounting entry');
  validate(payload);
  const db = getDb();
  const result = db
    .prepare(
      `INSERT INTO accounting_entries (entry_date, account, debit, credit, reference, booking_id, customer_id, supplier_id, payment_id, expense_id, created_by)
       VALUES (@entry_date, @account, @debit, @credit, @reference, @booking_id, @customer_id, @supplier_id, @payment_id, @expense_id, @created_by)`
    )
    .run({
      entry_date: payload.entry_date || new Date().toISOString(),
      account: payload.account.trim(),
      debit: Number(payload.debit || 0),
      credit: Number(payload.credit || 0),
      reference: payload.reference || null,
      booking_id: payload.booking_id || null,
      customer_id: payload.customer_id || null,
      supplier_id: payload.supplier_id || null,
      payment_id: payload.payment_id || null,
      expense_id: payload.expense_id || null,
      created_by: payload.created_by || null
    });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Accounting Entry Created', 'accounting_entry', ?, ?)`
  ).run(result.lastInsertRowid, `Manual entry on "${payload.account}"`);

  return { id: result.lastInsertRowid };
}

/**
 * Financial records are never hard-deleted (Section 41/54) - a "removal"
 * posts an equal-and-opposite reversal entry, linked back to the original,
 * and leaves both rows in place as the audit trail.
 */
function reverse(id) {
  const db = getDb();
  const original = db.prepare('SELECT * FROM accounting_entries WHERE id = ?').get(id);
  if (!original) throw new Error('Entry not found.');
  if (original.is_reversal) throw new Error('A reversal entry cannot itself be reversed.');
  const alreadyReversed = db.prepare('SELECT id FROM accounting_entries WHERE reversed_entry_id = ?').get(id);
  if (alreadyReversed) throw new Error('This entry has already been reversed.');

  const result = db
    .prepare(
      `INSERT INTO accounting_entries (entry_date, account, debit, credit, reference, booking_id, customer_id, supplier_id, payment_id, expense_id, is_reversal, reversed_entry_id)
       VALUES (datetime('now'), @account, @debit, @credit, @reference, @booking_id, @customer_id, @supplier_id, @payment_id, @expense_id, 1, @original_id)`
    )
    .run({
      account: original.account,
      debit: original.credit, // swapped: exact opposite of the original
      credit: original.debit,
      reference: `Reversal of #${id}${original.reference ? ` (${original.reference})` : ''}`,
      booking_id: original.booking_id,
      customer_id: original.customer_id,
      supplier_id: original.supplier_id,
      payment_id: original.payment_id,
      expense_id: original.expense_id,
      original_id: id
    });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Accounting Entry Reversed', 'accounting_entry', ?, ?)`
  ).run(id, `Entry #${id} reversed by new entry #${result.lastInsertRowid}`);

  return { id: result.lastInsertRowid };
}

module.exports = { list, listAccounts, summary, create, reverse };
