const { getDb } = require('../../src/database/db');

// Report Templates (master prompt section 43): a saved report SPEC (data
// selection, date field, sections) a user can reuse without rebuilding it
// from scratch every time - e.g. "Customer Complete Travel Report".

function create({ name, reportType, spec, createdBy = null }) {
  const db = getDb();
  if (!name || !name.trim()) throw new Error('Template name is required.');
  if (!reportType) throw new Error('Report type is required.');
  const result = db.prepare(
    `INSERT INTO report_templates (name, report_type, spec, created_by) VALUES (?, ?, ?, ?)`
  ).run(name.trim(), reportType, JSON.stringify(spec || {}), createdBy);
  return { id: result.lastInsertRowid };
}

function list(reportType = null) {
  const db = getDb();
  const rows = reportType
    ? db.prepare('SELECT t.*, u.full_name AS created_by_name FROM report_templates t LEFT JOIN users u ON u.id = t.created_by WHERE t.report_type = ? ORDER BY t.name').all(reportType)
    : db.prepare('SELECT t.*, u.full_name AS created_by_name FROM report_templates t LEFT JOIN users u ON u.id = t.created_by ORDER BY t.report_type, t.name').all();
  return rows.map((r) => ({ ...r, spec: JSON.parse(r.spec) }));
}

function get(id) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM report_templates WHERE id = ?').get(id);
  if (!row) throw new Error('Report template not found.');
  return { ...row, spec: JSON.parse(row.spec) };
}

function remove(id) {
  const db = getDb();
  const result = db.prepare('DELETE FROM report_templates WHERE id = ?').run(id);
  if (result.changes === 0) throw new Error('Report template not found.');
  return { success: true };
}

module.exports = { create, list, get, remove };
