const { getDb } = require('../../src/database/db');

const REPORT_TYPES = [
  { key: 'balances', label: 'Supplier Balances' },
  { key: 'payables', label: 'Supplier Payables' },
  { key: 'payment_history', label: 'Supplier Payment History' },
  { key: 'costs', label: 'Supplier Costs' },
  { key: 'profitability', label: 'Supplier Profitability' },
  { key: 'service_usage', label: 'Supplier Service Usage' }
];

function listReportTypes() {
  return REPORT_TYPES;
}

function balances({ supplierId = null } = {}) {
  const db = getDb();
  const params = {};
  let where = '';
  if (supplierId) { where = 'WHERE s.id = @supplierId'; params.supplierId = supplierId; }

  const rows = db
    .prepare(
      `SELECT s.supplier_code, s.name, s.service_type, s.currency, s.opening_balance,
        COALESCE((SELECT running_balance FROM supplier_ledger_entries WHERE supplier_id = s.id ORDER BY id DESC LIMIT 1), s.opening_balance) AS current_balance
       FROM suppliers s ${where}
       ORDER BY s.name`
    )
    .all(params);

  const columns = [
    { key: 'supplier_code', label: 'Code' },
    { key: 'name', label: 'Supplier' },
    { key: 'service_type', label: 'Type' },
    { key: 'currency', label: 'Currency' },
    { key: 'opening_balance', label: 'Opening Balance', money: true },
    { key: 'current_balance', label: 'Current Balance', money: true }
  ];
  const totals = { current_balance: rows.reduce((s, r) => s + r.current_balance, 0) };
  return { columns, rows, totals };
}

function payables({ supplierId = null } = {}) {
  const db = getDb();
  const params = {};
  let where = "WHERE si.status != 'Paid'";
  if (supplierId) { where += ' AND si.supplier_id = @supplierId'; params.supplierId = supplierId; }

  const rows = db
    .prepare(
      `SELECT s.supplier_code, s.name AS supplier_name, si.invoice_number, si.invoice_date, si.due_date, si.total, si.paid_amount, si.remaining_amount, si.status
       FROM supplier_invoices si JOIN suppliers s ON s.id = si.supplier_id
       ${where} ORDER BY si.due_date IS NULL, si.due_date ASC`
    )
    .all(params);

  const columns = [
    { key: 'supplier_code', label: 'Code' },
    { key: 'supplier_name', label: 'Supplier' },
    { key: 'invoice_number', label: 'Invoice #' },
    { key: 'due_date', label: 'Due Date' },
    { key: 'total', label: 'Total', money: true },
    { key: 'paid_amount', label: 'Paid', money: true },
    { key: 'remaining_amount', label: 'Payable', money: true },
    { key: 'status', label: 'Status' }
  ];
  const totals = { remaining_amount: rows.reduce((s, r) => s + r.remaining_amount, 0) };
  return { columns, rows, totals };
}

function paymentHistory({ supplierId = null, dateFrom = null, dateTo = null } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (supplierId) { conditions.push('sp.supplier_id = @supplierId'); params.supplierId = supplierId; }
  if (dateFrom) { conditions.push('sp.payment_date >= @dateFrom'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('sp.payment_date <= @dateTo'); params.dateTo = dateTo; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const rows = db
    .prepare(
      `SELECT s.supplier_code, s.name AS supplier_name, sp.payment_date, sp.amount, sp.payment_method, sp.reference, si.invoice_number
       FROM supplier_payments sp
       JOIN suppliers s ON s.id = sp.supplier_id
       LEFT JOIN supplier_invoices si ON si.id = sp.supplier_invoice_id
       ${where} ORDER BY sp.payment_date DESC`
    )
    .all(params);

  const columns = [
    { key: 'supplier_code', label: 'Code' },
    { key: 'supplier_name', label: 'Supplier' },
    { key: 'payment_date', label: 'Date' },
    { key: 'invoice_number', label: 'Invoice #' },
    { key: 'amount', label: 'Amount', money: true },
    { key: 'payment_method', label: 'Method' },
    { key: 'reference', label: 'Reference' }
  ];
  const totals = { amount: rows.reduce((s, r) => s + r.amount, 0) };
  return { columns, rows, totals };
}

function costs({ supplierId = null } = {}) {
  const db = getDb();
  const params = {};
  let where = '';
  if (supplierId) { where = 'WHERE si.supplier_id = @supplierId'; params.supplierId = supplierId; }

  const rows = db
    .prepare(
      `SELECT s.supplier_code, s.name AS supplier_name, COUNT(si.id) AS invoice_count,
        COALESCE(SUM(si.total),0) AS total_cost, COALESCE(SUM(si.paid_amount),0) AS total_paid
       FROM suppliers s LEFT JOIN supplier_invoices si ON si.supplier_id = s.id
       ${where}
       GROUP BY s.id ORDER BY total_cost DESC`
    )
    .all(params);

  const columns = [
    { key: 'supplier_code', label: 'Code' },
    { key: 'supplier_name', label: 'Supplier' },
    { key: 'invoice_count', label: 'Invoices' },
    { key: 'total_cost', label: 'Total Cost', money: true },
    { key: 'total_paid', label: 'Total Paid', money: true }
  ];
  const totals = { total_cost: rows.reduce((s, r) => s + r.total_cost, 0), total_paid: rows.reduce((s, r) => s + r.total_paid, 0) };
  return { columns, rows, totals };
}

/**
 * Supplier profitability: for each supplier, total booking revenue on
 * bookings where at least one supplier invoice references them, vs. the
 * supplier's actual cost. A simple, real, database-driven approximation -
 * true per-booking attribution happens in Booking 360° (a later phase).
 */
function profitability() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT s.supplier_code, s.name AS supplier_name,
        COALESCE(SUM(si.total),0) AS supplier_cost,
        COALESCE((
          SELECT SUM(b.total_price) FROM bookings b
          WHERE b.id IN (SELECT DISTINCT booking_id FROM supplier_invoices WHERE supplier_id = s.id AND booking_id IS NOT NULL)
        ), 0) AS linked_booking_revenue
       FROM suppliers s LEFT JOIN supplier_invoices si ON si.supplier_id = s.id
       GROUP BY s.id ORDER BY supplier_cost DESC`
    )
    .all();

  rows.forEach((r) => { r.estimated_margin = r.linked_booking_revenue - r.supplier_cost; });

  const columns = [
    { key: 'supplier_code', label: 'Code' },
    { key: 'supplier_name', label: 'Supplier' },
    { key: 'linked_booking_revenue', label: 'Linked Booking Revenue', money: true },
    { key: 'supplier_cost', label: 'Supplier Cost', money: true },
    { key: 'estimated_margin', label: 'Estimated Margin', money: true }
  ];
  return { columns, rows, totals: null };
}

function serviceUsage() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT service_type, COUNT(*) AS supplier_count,
        (SELECT COUNT(*) FROM supplier_invoices si JOIN suppliers s2 ON s2.id = si.supplier_id WHERE s2.service_type = s.service_type) AS invoice_count
       FROM suppliers s GROUP BY service_type ORDER BY supplier_count DESC`
    )
    .all();

  const columns = [
    { key: 'service_type', label: 'Service Type' },
    { key: 'supplier_count', label: 'Suppliers' },
    { key: 'invoice_count', label: 'Invoices Issued' }
  ];
  return { columns, rows, totals: null };
}

function run(key, filters = {}) {
  const type = REPORT_TYPES.find((t) => t.key === key);
  let result;
  switch (key) {
    case 'balances': result = balances(filters); break;
    case 'payables': result = payables(filters); break;
    case 'payment_history': result = paymentHistory(filters); break;
    case 'costs': result = costs(filters); break;
    case 'profitability': result = profitability(filters); break;
    case 'service_usage': result = serviceUsage(filters); break;
    default: throw new Error('Unknown supplier report type.');
  }
  return { title: type ? type.label : 'Supplier Report', ...result };
}

module.exports = { listReportTypes, run };
