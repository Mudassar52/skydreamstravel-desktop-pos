const { getDb } = require('../../src/database/db');

/**
 * Period lock and year-end close (Phase 21c).
 *
 * Two things can lock the books through a date:
 *   - a manual lock date (setting `books_locked_through`) - "nothing before this changes any more", no accounting entry;
 *   - year-end closes (table year_end_closes) - the same lock PLUS a closing entry in the General Ledger that moves the
 *     period's revenue and expenses into Retained Earnings.
 * The effective lock is the later of the two. Any record dated on or before it cannot be added, changed, voided or
 * deleted. A mistake in a locked period is corrected with a NEW entry dated today (a reversal / adjusting entry), which
 * is exactly how a locked ledger is supposed to behave.
 */

const SETTING = 'books_locked_through';
const isDate = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d));
const dateOf = (v) => String(v || '').slice(0, 10);
const today = (db) => db.prepare("SELECT date('now') AS d").get().d;

function manualLock(db) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(SETTING);
  return row && row.value ? dateOf(row.value) : null;
}
function lastClose(db) {
  const row = db.prepare('SELECT close_date FROM year_end_closes ORDER BY close_date DESC LIMIT 1').get();
  return row ? row.close_date : null;
}

/** The date through which the books are locked, or null. */
function getLockDate(db = getDb()) {
  const a = manualLock(db); const b = lastClose(db);
  if (a && b) return a > b ? a : b;
  return a || b || null;
}

function status() {
  const db = getDb();
  return { locked_through: getLockDate(db), manual_lock: manualLock(db), closes: listCloses(), today: today(db) };
}

/** Throws when `date` falls inside the locked period. `what` names the action for the message. */
function assertOpen(date, what = 'This entry') {
  const db = getDb();
  const lock = getLockDate(db);
  const d = dateOf(date) || today(db);
  if (lock && d <= lock) {
    throw new Error(`${what} is dated ${d}, but the books are locked through ${lock}. Locked periods cannot be changed - record a correcting entry dated today instead.`);
  }
}

function audit(db, userId, action, description) {
  db.prepare("INSERT INTO audit_logs (user_id, action, record_type, description) VALUES (?, ?, 'period_lock', ?)").run(userId || null, action, description);
}

function setManualLock(date, userId = null) {
  const db = getDb();
  if (date === null || date === '' || date === undefined) {
    db.prepare("INSERT INTO settings (key, value) VALUES (?, '') ON CONFLICT(key) DO UPDATE SET value = ''").run(SETTING);
    audit(db, userId, 'Period Lock Cleared', 'Manual lock date cleared');
    return { success: true };
  }
  const d = dateOf(date);
  if (!isDate(d)) throw new Error('Please enter a valid lock date.');
  if (d >= today(db)) throw new Error('The lock date must be before today, otherwise today\'s own entries would be blocked.');
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(SETTING, d);
  audit(db, userId, 'Period Locked', `Books locked through ${d}`);
  return { success: true };
}

function listCloses() {
  return getDb().prepare('SELECT c.*, u.full_name AS created_by_name FROM year_end_closes c LEFT JOIN users u ON u.id = c.created_by ORDER BY c.close_date DESC').all();
}

/** Close dates (ascending) - used by the General Ledger to post the closing entries. */
function closeDates(db = getDb()) {
  return db.prepare('SELECT close_date FROM year_end_closes ORDER BY close_date').all().map((r) => r.close_date);
}

function closeYear({ closeDate, notes = null, userId = null }) {
  const db = getDb();
  const d = dateOf(closeDate);
  if (!isDate(d)) throw new Error('Please enter a valid year-end date.');
  if (d >= today(db)) throw new Error('A year-end date must be before today.');
  const last = lastClose(db);
  if (last && d <= last) throw new Error(`The books are already closed through ${last}. Choose a later date.`);
  const manual = manualLock(db);
  if (manual && d <= manual) {
    // allowed: closing inside an already manually-locked stretch is fine - it just adds the closing entry.
  }
  db.prepare('INSERT INTO year_end_closes (close_date, notes, created_by) VALUES (?, ?, ?)').run(d, notes, userId);
  audit(db, userId, 'Year-End Closed', `Books closed through ${d}`);
  return { success: true, close_date: d };
}

/** Undo the NEWEST close only (undoing an older one would change figures already carried forward). */
function reopenLastClose(userId = null) {
  const db = getDb();
  const last = db.prepare('SELECT * FROM year_end_closes ORDER BY close_date DESC LIMIT 1').get();
  if (!last) throw new Error('There is no year-end close to undo.');
  db.prepare('DELETE FROM year_end_closes WHERE id = ?').run(last.id);
  audit(db, userId, 'Year-End Close Undone', `Close of ${last.close_date} undone`);
  return { success: true, reopened: last.close_date };
}

module.exports = { getLockDate, status, assertOpen, setManualLock, listCloses, closeDates, closeYear, reopenLastClose };
