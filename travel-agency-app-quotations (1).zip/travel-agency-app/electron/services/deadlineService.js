const { getDb } = require('../../src/database/db');

const DEADLINE_TYPES = ['Reservation', 'Ticketing', 'Payment', 'Cancellation', 'HotelCancellation', 'Visa', 'Confirmation'];
const STATUSES = ['Pending', 'Completed', 'Overdue', 'Cancelled'];
const REMINDER_THRESHOLDS = [30, 14, 7, 3, 1];

const FIELDS = ['deadline_type', 'title', 'due_date', 'booking_id', 'traveller_id', 'supplier_id', 'notes'];

function validate(payload) {
  if (!payload.deadline_type || !DEADLINE_TYPES.includes(payload.deadline_type)) throw new Error('A valid deadline type is required.');
  if (!payload.due_date) throw new Error('Due date is required.');
}

/** Days remaining until due_date; negative once overdue. Drives the reminder badge in the UI. */
function daysUntil(dueDate) {
  const due = new Date(dueDate);
  const now = new Date();
  return Math.ceil((due.setHours(0, 0, 0, 0) - now.setHours(0, 0, 0, 0)) / 86400000);
}

function reminderLevel(days) {
  if (days < 0) return 'Overdue';
  const ascending = [...REMINDER_THRESHOLDS].sort((a, b) => a - b);
  const level = ascending.find((t) => days <= t);
  return level ? `${level} days` : null;
}

const EFFECTIVE_STATUS_SQL = `
  CASE
    WHEN d.status IN ('Completed', 'Cancelled') THEN d.status
    WHEN d.due_date < date('now') THEN 'Overdue'
    ELSE 'Pending'
  END
`;

function list({ search = '', status = 'All', deadlineType = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(d.title LIKE @q OR b.booking_code LIKE @q OR t.full_name LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (deadlineType && deadlineType !== 'All') { conditions.push('d.deadline_type = @deadlineType'); params.deadlineType = deadlineType; }

  let having = '';
  if (status && status !== 'All') { having = 'HAVING effective_status = @status'; params.status = status; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const baseQuery = `
    SELECT d.*, b.booking_code, t.full_name AS traveller_name, s.name AS supplier_name,
      ${EFFECTIVE_STATUS_SQL} AS effective_status
    FROM deadlines d
    LEFT JOIN bookings b ON b.id = d.booking_id
    LEFT JOIN travellers t ON t.id = d.traveller_id
    LEFT JOIN suppliers s ON s.id = d.supplier_id
    ${where}
  `;

  const total = db.prepare(`SELECT COUNT(*) AS c FROM (${baseQuery} ${having})`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`${baseQuery} ${having} ORDER BY d.due_date ASC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset })
    .map((r) => ({ ...r, daysUntil: daysUntil(r.due_date), reminderLevel: reminderLevel(daysUntil(r.due_date)) }));

  return { rows, total, page, pageSize };
}

/** Pending deadlines within N days, for Dashboard/Action Required/Calendar. */
function dueSoon(days = 30) {
  const db = getDb();
  return db
    .prepare(
      `SELECT d.*, b.booking_code, t.full_name AS traveller_name, ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM deadlines d
       LEFT JOIN bookings b ON b.id = d.booking_id
       LEFT JOIN travellers t ON t.id = d.traveller_id
       WHERE d.status = 'Pending' AND d.due_date <= date('now', '+' || ? || ' days')
       ORDER BY d.due_date ASC`
    )
    .all(days)
    .map((r) => ({ ...r, daysUntil: daysUntil(r.due_date), reminderLevel: reminderLevel(daysUntil(r.due_date)) }));
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT d.*, b.booking_code, t.full_name AS traveller_name, s.name AS supplier_name,
        ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM deadlines d
       LEFT JOIN bookings b ON b.id = d.booking_id
       LEFT JOIN travellers t ON t.id = d.traveller_id
       LEFT JOIN suppliers s ON s.id = d.supplier_id
       WHERE d.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Deadline not found.');
  return { ...row, daysUntil: daysUntil(row.due_date), reminderLevel: reminderLevel(daysUntil(row.due_date)) };
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of FIELDS) params[f] = payload[f] ?? null;

  const result = db
    .prepare(`INSERT INTO deadlines (${FIELDS.join(', ')}) VALUES (${FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Deadline Created', 'deadline', ?, ?)`
  ).run(result.lastInsertRowid, `${payload.deadline_type} deadline set for ${payload.due_date}`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM deadlines WHERE id = ?').get(id);
  if (!existing) throw new Error('Deadline not found.');

  const params = { id };
  const sets = [];
  for (const f of [...FIELDS, 'status']) {
    if (payload[f] !== undefined) {
      if (f === 'status' && !STATUSES.includes(payload.status)) throw new Error('Invalid deadline status.');
      sets.push(`${f} = @${f}`);
      params[f] = payload[f];
    }
  }
  db.prepare(`UPDATE deadlines SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Deadline Updated', 'deadline', ?, ?)`
  ).run(id, `Deadline #${id} updated`);

  return { success: true };
}

function markStatus(id, status) {
  return update(id, { status });
}

function remove(id) {
  const db = getDb();
  db.prepare('DELETE FROM deadlines WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'deadline', ?, ?)`
  ).run(id, `Deadline #${id} deleted`);
  return { success: true };
}

module.exports = { DEADLINE_TYPES, STATUSES, REMINDER_THRESHOLDS, list, dueSoon, get, create, update, markStatus, remove };
