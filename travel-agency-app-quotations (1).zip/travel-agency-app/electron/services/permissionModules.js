// Canonical list of modules that participate in role-based permissions.
// Keep this in sync with `key`/`module` values used in src/utils/navConfig.js.
// Duplicated (rather than imported) across the main process (CommonJS) and
// renderer (ESM) because Electron's main process isn't set up for ESM yet -
// if that changes later, collapse both into one file under a real shared/ folder.
const PERMISSION_MODULES = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'customers', label: 'Customers' },
  { key: 'bookings', label: 'Bookings' },
  { key: 'umrah', label: 'Umrah' },
  { key: 'hajj', label: 'Hajj' },
  { key: 'tours', label: 'Tours' },
  { key: 'flights', label: 'Flights' },
  { key: 'hotels', label: 'Hotels' },
  { key: 'visa', label: 'Visa' },
  { key: 'transportation', label: 'Transportation' },
  { key: 'invoices', label: 'Invoices' },
  { key: 'payments', label: 'Payments' },
  { key: 'ledger', label: 'Ledger' },
  { key: 'expenses', label: 'Expenses' },
  { key: 'documents', label: 'Documents' },
  { key: 'reports', label: 'Reports' },
  { key: 'staff', label: 'Staff & Users' },
  { key: 'invoice_templates', label: 'Invoice Templates' },
  { key: 'settings', label: 'Settings' },
  { key: 'backup', label: 'Backup & Restore' },

  // Added Phase 19 (upgrade to full Travel Agency Management OS).
  { key: 'leads', label: 'Leads' },
  { key: 'travellers', label: 'Travellers' },
  { key: 'followups', label: 'Follow-ups' },
  { key: 'quotations', label: 'Quotations' },
  { key: 'packages', label: 'Packages' },
  { key: 'other_services', label: 'Other Services' },
  { key: 'tasks', label: 'Tasks' },
  { key: 'deadlines', label: 'Deadlines' },
  { key: 'upcoming_travel', label: 'Upcoming Travel' },
  { key: 'travel_calendar', label: 'Travel Calendar' },
  { key: 'suppliers', label: 'Suppliers' },
  { key: 'supplier_ledger', label: 'Supplier Ledger' },
  { key: 'supplier_invoices', label: 'Supplier Invoices' },
  { key: 'supplier_payments', label: 'Supplier Payments' },
  { key: 'supplier_reports', label: 'Supplier Reports' },
  { key: 'bank_accounts', label: 'Bank Accounts' },
  { key: 'cash_accounts', label: 'Cash Accounts' },
  { key: 'refunds', label: 'Refunds' },
  { key: 'accounting', label: 'Accounting' },
  { key: 'notifications', label: 'Notifications' },
  { key: 'audit_logs', label: 'Audit Logs' },

  // Added Phase 21.
  { key: 'exchange_rates', label: 'Exchange Rates' },
  { key: 'agents', label: 'Agents' },
  { key: 'commissions', label: 'Commissions' },
  { key: 'financial_statements', label: 'Financial Statements' }
];

// Default permission grants seeded the first time the app runs.
// Admin gets everything; Manager and Staff get sensible day-to-day defaults
// that the Admin can change afterwards from Staff & Users > Permissions.
const DEFAULT_GRANTS = {
  Admin: () => ({ can_view: 1, can_create: 1, can_edit: 1, can_delete: 1 }),
  Manager: (key) => {
    const restricted = ['staff', 'settings', 'backup', 'audit_logs', 'exchange_rates', 'financial_statements'];
    if (restricted.includes(key)) return { can_view: 1, can_create: 0, can_edit: 0, can_delete: 0 };
    return { can_view: 1, can_create: 1, can_edit: 1, can_delete: 0 };
  },
  Staff: (key) => {
    const noAccess = [
      'ledger', 'reports', 'staff', 'invoice_templates', 'settings', 'backup',
      'accounting', 'audit_logs', 'supplier_ledger', 'bank_accounts', 'cash_accounts',
      'exchange_rates', 'commissions', 'financial_statements'
    ];
    if (noAccess.includes(key)) return { can_view: 0, can_create: 0, can_edit: 0, can_delete: 0 };
    return { can_view: 1, can_create: 1, can_edit: 0, can_delete: 0 };
  }
};

// Global capabilities (master prompt section 48), distinct from the
// per-module view/create/edit/delete matrix above: these gate sensitive
// financial figures and actions that cut across many modules at once
// (Customer/Supplier/Booking/Package 360, Custom Report Builder, Ledger,
// legacy Reports) rather than belonging to one screen.
const CAPABILITIES = [
  { key: 'view_profit', label: 'View Profit' },
  { key: 'view_supplier_costs', label: 'View Supplier Costs' },
  { key: 'export_reports', label: 'Export Reports' }
];

// Admin always gets everything. Manager sees financials day-to-day. Staff -
// a front-desk/booking role - does not see profit or supplier cost figures
// and cannot export reports, matching "do not expose sensitive financial
// information to unauthorized users". An Admin can change any of this
// afterwards from Staff & Users > Permissions.
const DEFAULT_CAPABILITY_GRANTS = {
  Admin: () => true,
  Manager: () => true,
  Staff: () => false
};

module.exports = { PERMISSION_MODULES, DEFAULT_GRANTS, CAPABILITIES, DEFAULT_CAPABILITY_GRANTS };
