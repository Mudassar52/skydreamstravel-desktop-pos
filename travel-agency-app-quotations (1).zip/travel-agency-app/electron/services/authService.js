const bcrypt = require('bcryptjs');
const { getDb } = require('../../src/database/db');
const { PERMISSION_MODULES, DEFAULT_GRANTS, CAPABILITIES, DEFAULT_CAPABILITY_GRANTS } = require('./permissionModules');

const DEFAULT_ADMIN_PASSWORD = 'admin123';

/**
 * Runs once at startup (called from main.js after initDatabase). Creates a
 * default Admin login and fills in any missing role/module permission rows
 * so the permissions matrix is always complete, even after a schema update
 * adds a new module.
 */
function ensureDefaults() {
  const db = getDb();

  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) {
    const adminRole = db.prepare("SELECT id FROM roles WHERE name = 'Admin'").get();
    const passwordHash = bcrypt.hashSync(DEFAULT_ADMIN_PASSWORD, 10);
    db.prepare(
      `INSERT INTO users (full_name, username, password_hash, role_id, is_active)
       VALUES (?, ?, ?, ?, 1)`
    ).run('Administrator', 'admin', passwordHash, adminRole.id);
  }

  const roles = db.prepare('SELECT id, name FROM roles').all();
  const existing = db.prepare('SELECT role_id, module FROM permissions').all();
  const existingSet = new Set(existing.map((r) => `${r.role_id}:${r.module}`));

  const insert = db.prepare(
    `INSERT INTO permissions (module, role_id, can_view, can_create, can_edit, can_delete)
     VALUES (@module, @role_id, @can_view, @can_create, @can_edit, @can_delete)`
  );

  const insertMany = db.transaction((rows) => {
    rows.forEach((row) => insert.run(row));
  });

  const toInsert = [];
  for (const role of roles) {
    const grantFn = DEFAULT_GRANTS[role.name] || (() => ({ can_view: 0, can_create: 0, can_edit: 0, can_delete: 0 }));
    for (const mod of PERMISSION_MODULES) {
      if (!existingSet.has(`${role.id}:${mod.key}`)) {
        toInsert.push({ module: mod.key, role_id: role.id, ...grantFn(mod.key) });
      }
    }
  }
  if (toInsert.length) insertMany(toInsert);

  // Same backfill idea for the global capabilities table, so adding a new
  // capability later (or a new role) never leaves a role with no row -
  // getCapabilitiesForRole always has something to read.
  const existingCaps = new Set(db.prepare('SELECT role_id, capability FROM role_capabilities').all().map((r) => `${r.role_id}:${r.capability}`));
  const insertCap = db.prepare('INSERT INTO role_capabilities (role_id, capability, granted) VALUES (?, ?, ?)');
  const insertCapsMany = db.transaction((rows) => { rows.forEach((row) => insertCap.run(row.role_id, row.capability, row.granted)); });
  const capsToInsert = [];
  for (const role of roles) {
    const grantFn = DEFAULT_CAPABILITY_GRANTS[role.name] || (() => false);
    for (const cap of CAPABILITIES) {
      if (!existingCaps.has(`${role.id}:${cap.key}`)) {
        capsToInsert.push({ role_id: role.id, capability: cap.key, granted: grantFn(cap.key) ? 1 : 0 });
      }
    }
  }
  if (capsToInsert.length) insertCapsMany(capsToInsert);
}

function logAudit(userId, action, description) {
  const db = getDb();
  db.prepare(
    `INSERT INTO audit_logs (user_id, action, record_type, description) VALUES (?, ?, 'auth', ?)`
  ).run(userId || null, action, description || null);
}

function getCapabilitiesForRole(roleId) {
  const db = getDb();
  const rows = db.prepare('SELECT capability, granted FROM role_capabilities WHERE role_id = ?').all(roleId);
  const out = {};
  for (const cap of CAPABILITIES) out[cap.key] = false;
  for (const r of rows) out[r.capability] = !!r.granted;
  return out;
}

function getCapabilitiesMatrix() {
  const db = getDb();
  const roles = getRoles();
  const rows = db.prepare('SELECT role_id, capability, granted FROM role_capabilities').all();
  return { capabilities: CAPABILITIES, roles, grants: rows };
}

/** Updates one role's capability flag and records the change (old -> new value) for the audit trail. */
function updateCapability({ roleId, capability, granted, actingUserId = null }) {
  const db = getDb();
  if (!CAPABILITIES.some((c) => c.key === capability)) throw new Error(`Unknown capability: ${capability}`);
  const role = db.prepare('SELECT name FROM roles WHERE id = ?').get(roleId);
  if (!role) throw new Error('Role not found.');
  const before = db.prepare('SELECT granted FROM role_capabilities WHERE role_id = ? AND capability = ?').get(roleId, capability);
  const oldValue = before ? !!before.granted : false;
  const newValue = !!granted;

  db.prepare(
    `INSERT INTO role_capabilities (role_id, capability, granted) VALUES (?, ?, ?)
     ON CONFLICT(role_id, capability) DO UPDATE SET granted = excluded.granted`
  ).run(roleId, capability, newValue ? 1 : 0);

  if (oldValue !== newValue) {
    logAudit(actingUserId, 'Permission Changed', `${role.name}: "${capability}" changed from ${oldValue} to ${newValue}`);
  }
  return { success: true };
}

function getPermissionsForRole(roleId) {
  const db = getDb();
  const rows = db.prepare('SELECT module, can_view, can_create, can_edit, can_delete FROM permissions WHERE role_id = ?').all(roleId);
  const map = {};
  for (const r of rows) {
    map[r.module] = {
      view: !!r.can_view,
      create: !!r.can_create,
      edit: !!r.can_edit,
      delete: !!r.can_delete
    };
  }
  return map;
}

function login(username, password) {
  const db = getDb();
  const user = db
    .prepare(
      `SELECT u.*, r.name AS role_name FROM users u
       LEFT JOIN roles r ON r.id = u.role_id
       WHERE u.username = ?`
    )
    .get(username);

  if (!user) {
    throw new Error('Invalid username or password.');
  }
  if (!user.is_active) {
    throw new Error('This account has been deactivated. Contact your administrator.');
  }
  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid) {
    logAudit(user.id, 'Login Failed', `Failed login attempt for ${username}`);
    throw new Error('Invalid username or password.');
  }

  logAudit(user.id, 'Login', `${user.full_name} logged in`);

  return {
    id: user.id,
    fullName: user.full_name,
    username: user.username,
    role: user.role_name,
    roleId: user.role_id,
    permissions: getPermissionsForRole(user.role_id),
    capabilities: getCapabilitiesForRole(user.role_id)
  };
}

function listUsers() {
  const db = getDb();
  return db
    .prepare(
      `SELECT u.id, u.full_name, u.username, u.phone, u.email, u.is_active,
              r.id AS role_id, r.name AS role_name, u.created_at
       FROM users u LEFT JOIN roles r ON r.id = u.role_id
       ORDER BY u.created_at DESC`
    )
    .all();
}

function createUser({ fullName, username, password, roleId, phone, email }) {
  if (!fullName || !username || !password || !roleId) {
    throw new Error('Full name, username, password and role are required.');
  }
  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) throw new Error('That username is already taken.');

  const passwordHash = bcrypt.hashSync(password, 10);
  const result = db
    .prepare(
      `INSERT INTO users (full_name, username, password_hash, role_id, phone, email, is_active)
       VALUES (?, ?, ?, ?, ?, ?, 1)`
    )
    .run(fullName, username, passwordHash, roleId, phone || null, email || null);

  logAudit(null, 'User Created', `User "${username}" created`);
  return { id: result.lastInsertRowid };
}

function updateUser(id, { fullName, roleId, phone, email, isActive }) {
  const db = getDb();
  db.prepare(
    `UPDATE users SET full_name = ?, role_id = ?, phone = ?, email = ?, is_active = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(fullName, roleId, phone || null, email || null, isActive ? 1 : 0, id);
  logAudit(null, 'User Updated', `User #${id} updated`);
  return { success: true };
}

function resetPassword(id, newPassword) {
  if (!newPassword || newPassword.length < 6) {
    throw new Error('Password must be at least 6 characters.');
  }
  const db = getDb();
  const passwordHash = bcrypt.hashSync(newPassword, 10);
  db.prepare(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`).run(passwordHash, id);
  logAudit(null, 'Password Reset', `Password reset for user #${id}`);
  return { success: true };
}

function getRoles() {
  const db = getDb();
  return db.prepare('SELECT id, name, description FROM roles ORDER BY id').all();
}

function getPermissionsMatrix() {
  const db = getDb();
  const roles = getRoles();
  const rows = db.prepare('SELECT module, role_id, can_view, can_create, can_edit, can_delete FROM permissions').all();
  return {
    modules: PERMISSION_MODULES,
    roles,
    grants: rows
  };
}

function updatePermission({ roleId, module, can_view, can_create, can_edit, can_delete, actingUserId = null }) {
  const db = getDb();
  const role = db.prepare('SELECT name FROM roles WHERE id = ?').get(roleId);
  const before = db.prepare('SELECT can_view, can_create, can_edit, can_delete FROM permissions WHERE role_id = ? AND module = ?').get(roleId, module);
  const next = { can_view: can_view ? 1 : 0, can_create: can_create ? 1 : 0, can_edit: can_edit ? 1 : 0, can_delete: can_delete ? 1 : 0 };

  db.prepare(
    `UPDATE permissions SET can_view = ?, can_create = ?, can_edit = ?, can_delete = ?
     WHERE role_id = ? AND module = ?`
  ).run(next.can_view, next.can_create, next.can_edit, next.can_delete, roleId, module);

  const changed = !before || ['can_view', 'can_create', 'can_edit', 'can_delete'].some((k) => !!before[k] !== !!next[k]);
  if (changed && role) {
    const fmt = (p) => `view:${p.can_view ? 'Y' : 'N'} create:${p.can_create ? 'Y' : 'N'} edit:${p.can_edit ? 'Y' : 'N'} delete:${p.can_delete ? 'Y' : 'N'}`;
    logAudit(actingUserId, 'Permission Changed', `${role.name} / ${module}: ${before ? fmt(before) : 'none'} -> ${fmt(next)}`);
  }
  return { success: true };
}

module.exports = {
  ensureDefaults,
  login,
  listUsers,
  createUser,
  updateUser,
  resetPassword,
  getRoles,
  getPermissionsMatrix,
  updatePermission,
  getPermissionsForRole,
  getCapabilitiesForRole,
  getCapabilitiesMatrix,
  updateCapability
};
