const { getDb } = require('../../src/database/db');
const settingsService = require('./settingsService');
const { escapeHtml, buildLogoHtml } = require('./templateEngine');

// Voucher Generator (master prompt section 12 + Vouchers tab of Booking 360).
// Vouchers are their own simple document type — deliberately NOT built on the
// invoice template engine, so nothing here can ever affect the invoice's
// design. They print/PDF through the same generic pdfService the invoices use.

function money(n, currency = 'PKR') {
  const v = Number(n || 0);
  try { return new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v); }
  catch (_) { return `${currency} ${v.toLocaleString()}`; }
}

function requireBooking(db, id) {
  const b = db.prepare(
    `SELECT bk.*, c.full_name AS customer_name, c.phone AS customer_phone, c.email AS customer_email
     FROM bookings bk JOIN customers c ON c.id = bk.customer_id WHERE bk.id = ?`
  ).get(id);
  if (!b) throw new Error('Booking not found.');
  return b;
}

/** Other people travelling on the booking (family / group members), so the voucher lists everyone and not only the lead customer. */
function otherTravellersHtml(db, bookingId) {
  const rows = db.prepare(
    `SELECT t.full_name, t.relationship, t.passport_number FROM booking_travellers bt
     JOIN travellers t ON t.id = bt.traveller_id WHERE bt.booking_id = ? ORDER BY bt.id`
  ).all(bookingId);
  if (rows.length === 0) return '';
  const lines = rows.map((r, i) => [`Traveller ${i + 2}`, [r.full_name, r.relationship && `(${r.relationship})`, r.passport_number && `Passport ${r.passport_number}`].filter(Boolean).join(' ')]);
  return `<p class="section-title">Other Travellers / Guests</p>${kv(lines)}`;
}

/** Guests staying at THIS hotel with their room numbers (when a guest list was saved); otherwise everyone on the booking. */
function hotelGuestsHtml(db, hotel, booking) {
  const saved = db.prepare(
    `SELECT hg.is_lead, hg.room_number, t.full_name, t.relationship, t.passport_number
     FROM hotel_guests hg LEFT JOIN travellers t ON t.id = hg.traveller_id WHERE hg.hotel_id = ? ORDER BY hg.is_lead DESC, hg.id`
  ).all(hotel.id);
  if (saved.length === 0) return otherTravellersHtml(db, booking.id);
  const lines = saved.map((g, i) => [
    `Guest ${i + 1}`,
    [g.is_lead ? booking.customer_name : g.full_name, g.is_lead ? '(Lead)' : g.relationship && `(${g.relationship})`, g.room_number && `— Room ${g.room_number}`].filter(Boolean).join(' ')
  ]);
  return `<p class="section-title">Guests &amp; Room Allocation</p>${kv(lines)}`;
}

function shell(title, agencyHtml, bodyHtml, footerNote) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8" />
<title>${escapeHtml(title)}</title>
<style>
  @page { size: A4; margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a2333; margin: 0; font-size: 13px; }
  .voucher-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1b4f91; padding-bottom: 14px; margin-bottom: 20px; }
  .agency-name { font-size: 20px; font-weight: 700; color: #0d2b4e; margin: 0 0 4px; }
  .agency-line { font-size: 11.5px; color: #55617a; margin: 1px 0; }
  .voucher-badge { text-align: right; }
  .voucher-badge h1 { font-size: 22px; color: #1b4f91; margin: 0; letter-spacing: 1px; }
  .voucher-badge div { font-size: 11.5px; color: #55617a; margin-top: 4px; }
  .section-title { font-size: 12.5px; font-weight: 700; color: #1b4f91; text-transform: uppercase; letter-spacing: 0.4px; margin: 20px 0 8px; }
  table.kv { width: 100%; border-collapse: collapse; }
  table.kv td { padding: 6px 10px; border: 1px solid #e2e7f0; font-size: 12.5px; }
  table.kv td.label { width: 34%; background: #f5f8fc; font-weight: 600; color: #3a4a63; }
  .notice { margin-top: 22px; padding: 10px 14px; background: #fff7e6; border: 1px solid #f0d9a6; border-radius: 4px; font-size: 12px; color: #6b4f16; }
  .footer { margin-top: 30px; font-size: 10.5px; color: #8a93a6; border-top: 1px solid #e2e7f0; padding-top: 10px; }
</style></head><body>
  <div class="voucher-header">
    <div>${agencyHtml}</div>
    <div class="voucher-badge"><h1>${escapeHtml(title)}</h1></div>
  </div>
  ${bodyHtml}
  ${footerNote ? `<div class="notice">${escapeHtml(footerNote)}</div>` : ''}
  <div class="footer">Generated on ${new Date().toISOString().slice(0, 10)} - this voucher is not a financial invoice.</div>
</body></html>`;
}

function agencyBlockHtml(settings) {
  const logo = buildLogoHtml(settings);
  return `
    ${logo}
    <p class="agency-name">${escapeHtml(settings.agency_name || 'Travel Agency')}</p>
    ${settings.agency_address ? `<p class="agency-line">${escapeHtml(settings.agency_address)}</p>` : ''}
    ${settings.agency_phone ? `<p class="agency-line">Tel: ${escapeHtml(settings.agency_phone)}</p>` : ''}
    ${settings.agency_email ? `<p class="agency-line">${escapeHtml(settings.agency_email)}</p>` : ''}`;
}

function kv(rows) {
  return `<table class="kv">${rows
    .filter(([, v]) => v !== undefined)
    .map(([label, value]) => `<tr><td class="label">${escapeHtml(label)}</td><td>${escapeHtml(value || '—')}</td></tr>`)
    .join('')}</table>`;
}

/** Builds the printable HTML for one hotel row on a booking. */
function buildHotelVoucherHtml(bookingId, hotelId) {
  const db = getDb();
  const booking = requireBooking(db, bookingId);
  const hotel = db.prepare('SELECT * FROM hotels WHERE id = ? AND booking_id = ?').get(hotelId, bookingId);
  if (!hotel) throw new Error('Hotel record not found for this booking.');
  const settings = settingsService.getAll();
  const currency = booking.currency || settings.default_currency || 'PKR';

  const body = `
    <p class="section-title">Customer</p>
    ${kv([['Guest Name', booking.customer_name], ['Phone', booking.customer_phone], ['Booking #', booking.booking_code]])}
    ${hotelGuestsHtml(db, hotel, booking)}
    <p class="section-title">Hotel Details</p>
    ${kv([
      ['Hotel Name', hotel.hotel_name], ['City / Country', [hotel.city, hotel.country].filter(Boolean).join(', ')],
      ['Address', hotel.address], ['Confirmation Number', hotel.confirmation_number || hotel.booking_reference]
    ])}
    <p class="section-title">Stay Details</p>
    ${kv([
      ['Check-in', hotel.check_in], ['Check-out', hotel.check_out], ['Nights', hotel.number_of_nights],
      ['Room Type', hotel.room_type], ['Room Number', hotel.room_number], ['Bed Type', hotel.bed_type],
      ['Meal Plan', hotel.meal_plan], ['Number of Rooms', hotel.number_of_rooms], ['Number of Guests', hotel.number_of_guests]
    ])}
    ${hotel.notes ? `<p class="section-title">Special Instructions</p><p>${escapeHtml(hotel.notes)}</p>` : ''}`;

  return {
    html: shell('Hotel Voucher', agencyBlockHtml(settings), body, 'Please present this voucher at check-in. Rates and payment are settled directly with the agency, not the hotel.'),
    suggestedName: `Hotel-Voucher-${booking.booking_code}-${(hotel.hotel_name || 'hotel').replace(/[^\w-]+/g, '-')}.pdf`
  };
}

/** Builds the printable HTML for one transport row on a booking. */
function buildTransportVoucherHtml(bookingId, transportId) {
  const db = getDb();
  const booking = requireBooking(db, bookingId);
  const t = db.prepare('SELECT * FROM transportation WHERE id = ? AND booking_id = ?').get(transportId, bookingId);
  if (!t) throw new Error('Transport record not found for this booking.');
  const settings = settingsService.getAll();

  const body = `
    <p class="section-title">Customer</p>
    ${kv([['Guest Name', booking.customer_name], ['Phone', booking.customer_phone], ['Booking #', booking.booking_code]])}
    ${otherTravellersHtml(db, bookingId)}
    <p class="section-title">Transport Details</p>
    ${kv([
      ['Service Type', t.transport_type], ['Vehicle', t.vehicle], ['Vehicle Number', t.vehicle_number],
      ['Driver', t.driver], ['Driver Phone', t.driver_phone]
    ])}
    <p class="section-title">Pickup / Drop</p>
    ${kv([
      ['Pickup Location', t.pickup_location], ['Drop Location', t.drop_location],
      ['Pickup Date', t.pickup_date], ['Pickup Time', t.pickup_time]
    ])}
    ${t.notes ? `<p class="section-title">Special Instructions</p><p>${escapeHtml(t.notes)}</p>` : ''}`;

  return {
    html: shell('Transport Voucher', agencyBlockHtml(settings), body, 'Please present this voucher to the driver/transport company on arrival.'),
    suggestedName: `Transport-Voucher-${booking.booking_code}.pdf`
  };
}

/** Which hotels/transport rows on this booking can have a voucher generated. */
function availableVouchers(bookingId) {
  const db = getDb();
  requireBooking(db, bookingId);
  const hotels = db.prepare('SELECT id, hotel_name, check_in, check_out FROM hotels WHERE booking_id = ? ORDER BY check_in').all(bookingId);
  const transportRows = db.prepare('SELECT id, pickup_location, drop_location, pickup_date FROM transportation WHERE booking_id = ? ORDER BY pickup_date').all(bookingId);
  return { hotels, transport: transportRows };
}

module.exports = { buildHotelVoucherHtml, buildTransportVoucherHtml, availableVouchers, money };
