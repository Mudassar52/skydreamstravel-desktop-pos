const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');

const TXN_TYPES = ['Deposit', 'Withdrawal', 'CustomerPayment', 'SupplierPayment', 'Expense', 'Transfer', 'Refund', 'Reversal'];

function table(type) {
  if (type !== 'Bank' && type !== 'Cash') throw new Error('Account type must be Bank or Cash.');
  return type === 'Bank' ? 'bank_accounts' : 'cash_accounts';
}

function validate(type, payload) {
  if (!payload.account_name || !payload.account_name.trim()) throw new Error('Account name is required.');
  if (type === 'Bank' && !payload.bank_name) throw new Error('Bank name is required for a bank account.');
}

// ------------------------------------------------------------- CRUD
function list(type, { includeInactive = false } = {}) {
  const db = getDb();
  const t = table(type);
  const where = includeInactive ? '' : "WHERE status = 'Active'";
  return db.prepare(`SELECT * FROM ${t} ${where} ORDER BY account_name`).all();
}

function listBank(opts) { return list('Bank', opts); }
function listCash(opts) { return list('Cash', opts); }

function get(type, id) {
  const db = getDb();
  const t = table(type);
  const account = db.prepare(`SELECT * FROM ${t} WHERE id = ?`).get(id);
  if (!account) throw new Error('Account not found.');
  const transactions = db
    .prepare(`SELECT * FROM account_transactions WHERE account_type = ? AND account_id = ? ORDER BY transaction_date DESC, id DESC`)
    .all(type, id);
  return { ...account, transactions };
}

function create(type, payload) {
  validate(type, payload);
  const db = getDb();
  const t = table(type);
  const opening = Number(payload.opening_balance || 0);

  const result = db
    .prepare(
      type === 'Bank'
        ? `INSERT INTO bank_accounts (account_name, bank_name, account_number, currency, opening_balance, current_balance, status)
           VALUES (@account_name, @bank_name, @account_number, @currency, @opening_balance, @opening_balance, @status)`
        : `INSERT INTO cash_accounts (account_name, currency, opening_balance, current_balance, status)
           VALUES (@account_name, @currency, @opening_balance, @opening_balance, @status)`
    )
    .run({
      account_name: payload.account_name.trim(),
      bank_name: payload.bank_name || null,
      account_number: payload.account_number || null,
      currency: payload.currency || 'PKR',
      opening_balance: opening,
      status: payload.status || 'Active'
    });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Account Created', ?, ?, ?)`
  ).run(t, result.lastInsertRowid, `${type} account "${payload.account_name}" created with opening balance ${opening}`);

  return { id: result.lastInsertRowid };
}

function update(type, id, payload) {
  validate(type, payload);
  const db = getDb();
  const t = table(type);
  const existing = db.prepare(`SELECT id FROM ${t} WHERE id = ?`).get(id);
  if (!existing) throw new Error('Account not found.');

  db.prepare(
    type === 'Bank'
      ? `UPDATE bank_accounts SET account_name=@account_name, bank_name=@bank_name, account_number=@account_number, currency=@currency, status=@status WHERE id=@id`
      : `UPDATE cash_accounts SET account_name=@account_name, currency=@currency, status=@status WHERE id=@id`
  ).run({
    id,
    account_name: payload.account_name.trim(),
    bank_name: payload.bank_name || null,
    account_number: payload.account_number || null,
    currency: payload.currency || 'PKR',
    status: payload.status || 'Active'
  });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Account Updated', ?, ?, ?)`
  ).run(t, id, `${type} account "${payload.account_name}" updated`);

  return { success: true };
}

function remove(type, id) {
  const db = getDb();
  const t = table(type);
  const inUse = db.prepare('SELECT COUNT(*) AS c FROM account_transactions WHERE account_type = ? AND account_id = ?').get(type, id).c;
  if (inUse > 0) throw new Error('This account has transaction history and cannot be deleted. Mark it Inactive instead.');
  db.prepare(`DELETE FROM ${t} WHERE id = ?`).run(id);
  return { success: true };
}

// ------------------------------------------------------- Transactions
/** Posts a transaction and updates the account's running balance. direction is 'In' or 'Out'. Used both by this service's manual entries and by other services (payments, expenses, refunds) posting against a real account. */
function postTransaction(db, { account_type, account_id, amount, direction, transaction_type, reference_type = 'manual', reference_id = null, description }) {
  if (!account_type || !account_id) return;
  const t = table(account_type);
  const account = db.prepare(`SELECT * FROM ${t} WHERE id = ?`).get(account_id);
  if (!account) throw new Error(`Selected ${account_type.toLowerCase()} account does not exist.`);

  const inserted = db.prepare(
    `INSERT INTO account_transactions (account_type, account_id, transaction_type, amount, direction, reference_type, reference_id, description)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(account_type, account_id, transaction_type, amount, direction, reference_type, reference_id, description || null);

  const delta = direction === 'In' ? amount : -amount;
  db.prepare(`UPDATE ${t} SET current_balance = current_balance + ? WHERE id = ?`).run(delta, account_id);
  return inserted.lastInsertRowid;
}

function manualDeposit({ account_type, account_id, amount, description }) {
  periodLock.assertOpen(null, 'This deposit');
  if (!(Number(amount) > 0)) throw new Error('Amount must be greater than zero.');
  const db = getDb();
  postTransaction(db, { account_type, account_id, amount: Number(amount), direction: 'In', transaction_type: 'Deposit', description: description || 'Manual deposit' });
  return { success: true };
}

function manualWithdrawal({ account_type, account_id, amount, description }) {
  periodLock.assertOpen(null, 'This withdrawal');
  if (!(Number(amount) > 0)) throw new Error('Amount must be greater than zero.');
  const db = getDb();
  const account = get(account_type, account_id);
  if (account.current_balance < Number(amount)) throw new Error('Withdrawal exceeds the current account balance.');
  postTransaction(db, { account_type, account_id, amount: Number(amount), direction: 'Out', transaction_type: 'Withdrawal', description: description || 'Manual withdrawal' });
  return { success: true };
}

function transfer({ from_type, from_id, to_type, to_id, amount, to_amount, description }) {
  periodLock.assertOpen(null, 'This transfer');
  if (!(Number(amount) > 0)) throw new Error('Amount must be greater than zero.');
  if (from_type === to_type && from_id === to_id) throw new Error('Source and destination accounts must be different.');
  const db = getDb();
  const source = get(from_type, from_id);
  const dest = get(to_type, to_id);
  if (source.current_balance < Number(amount)) throw new Error('Transfer exceeds the source account balance.');

  // Phase 21c: between accounts of different currencies the two sides are different numbers - the amount that left the
  // source (`amount`, in its currency) and the amount that arrived (`to_amount`, in the destination's). Both are required.
  const sc = String(source.currency || '').toUpperCase();
  const dc = String(dest.currency || '').toUpperCase();
  const cross = !!(sc && dc && sc !== dc);
  let inAmount = Number(amount);
  if (cross) {
    inAmount = Number(to_amount);
    if (!(inAmount > 0)) throw new Error(`These accounts hold different currencies (${sc} and ${dc}). Enter the amount that arrives in ${dc}.`);
  }

  const tx = db.transaction(() => {
    // Both legs share one reference (the outgoing leg's id) so the General Ledger can treat them as one transfer.
    const outId = postTransaction(db, { account_type: from_type, account_id: from_id, amount: Number(amount), direction: 'Out', transaction_type: 'Transfer', reference_type: 'transfer', description: description || `Transfer to ${to_type} account #${to_id}` });
    if (outId) db.prepare('UPDATE account_transactions SET reference_id = ? WHERE id = ?').run(outId, outId);
    postTransaction(db, { account_type: to_type, account_id: to_id, amount: inAmount, direction: 'In', transaction_type: 'Transfer', reference_type: 'transfer', reference_id: outId, description: description || `Transfer from ${from_type} account #${from_id}` });
  });
  tx();
  return { success: true };
}

module.exports = {
  TXN_TYPES, list, listBank, listCash, get, create, update, remove,
  postTransaction, manualDeposit, manualWithdrawal, transfer
};
