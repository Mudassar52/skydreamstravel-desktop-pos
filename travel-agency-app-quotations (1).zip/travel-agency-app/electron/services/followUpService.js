const { getDb } = require('../../src/database/db');

const PRIORITIES = ['Low', 'Medium', 'High'];
const STATUSES = ['Pending', 'Completed', 'Overdue', 'Cancelled'];

const FOLLOWUP_FIELDS = [
  'follow_up_date', 'customer_id', 'lead_id', 'booking_id', 'assigned_user_id', 'priority', 'notes',
  'contact_name', 'contact_phone', 'purpose', 'contact_method', 'reminder_time'
];

// Suggested values for the form dropdowns (the UI also lets the user type a custom value).
const CONTACT_METHODS = ['WhatsApp', 'Phone Call', 'In Person', 'Other'];
const ACTIVITIES = ['Message sent', 'Follow-up call completed', 'Customer replied', 'No response'];
const PURPOSES = [
  'Booking confirmation', 'Quotation follow-up', 'Payment reminder', 'Document collection',
  'Visa update', 'Travel reminder', 'Feedback / Review', 'General check-in'
];
const OUTCOMES = [
  'Interested', 'Not interested', 'Needs more time', 'Will confirm later',
  'Booked / Confirmed', 'Callback requested', 'No answer'
];

function validate(payload) {
  if (!payload.follow_up_date) throw new Error('Follow-up date is required.');
  if (!payload.customer_id && !payload.lead_id && !payload.booking_id && !(payload.contact_name || '').trim()) {
    throw new Error('A follow-up must be linked to a customer, lead, or booking.');
  }
}

/**
 * Stored status stays Pending/Completed/Cancelled - "Overdue" is derived
 * at query time from follow_up_date vs today, rather than requiring a
 * background job to flip it, so it's always accurate.
 */
const EFFECTIVE_STATUS_SQL = `
  CASE
    WHEN f.status IN ('Completed', 'Cancelled') THEN f.status
    WHEN f.follow_up_date < date('now') THEN 'Overdue'
    ELSE 'Pending'
  END
`;

function list({ search = '', status = 'All', assignedUserId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(c.full_name LIKE @q OR l.full_name LIKE @q OR l.lead_code LIKE @q OR b.booking_code LIKE @q OR f.notes LIKE @q OR f.contact_name LIKE @q OR f.contact_phone LIKE @q OR f.purpose LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (assignedUserId) { conditions.push('f.assigned_user_id = @assignedUserId'); params.assignedUserId = assignedUserId; }

  let having = '';
  if (status && status !== 'All') {
    having = `HAVING effective_status = @status`;
    params.status = status;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const baseQuery = `
    SELECT f.*, c.full_name AS customer_name, l.full_name AS lead_name, l.lead_code, b.booking_code, u.full_name AS agent_name,
      ${EFFECTIVE_STATUS_SQL} AS effective_status
    FROM follow_ups f
    LEFT JOIN customers c ON c.id = f.customer_id
    LEFT JOIN leads l ON l.id = f.lead_id
    LEFT JOIN bookings b ON b.id = f.booking_id
    LEFT JOIN users u ON u.id = f.assigned_user_id
    ${where}
  `;

  const total = db.prepare(`SELECT COUNT(*) AS c FROM (${baseQuery} ${having})`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(`${baseQuery} ${having} ORDER BY f.follow_up_date ASC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

/** Follow-ups due today or overdue, for the Dashboard/Action Required center. */
function dueSoon(days = 7) {
  const db = getDb();
  return db
    .prepare(
      `SELECT f.*, c.full_name AS customer_name, l.full_name AS lead_name, b.booking_code,
        ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM follow_ups f
       LEFT JOIN customers c ON c.id = f.customer_id
       LEFT JOIN leads l ON l.id = f.lead_id
       LEFT JOIN bookings b ON b.id = f.booking_id
       WHERE f.status = 'Pending' AND f.follow_up_date <= date('now', '+' || ? || ' days')
       ORDER BY f.follow_up_date ASC`
    )
    .all(days);
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT f.*, c.full_name AS customer_name, l.full_name AS lead_name, b.booking_code,
        ${EFFECTIVE_STATUS_SQL} AS effective_status
       FROM follow_ups f
       LEFT JOIN customers c ON c.id = f.customer_id
       LEFT JOIN leads l ON l.id = f.lead_id
       LEFT JOIN bookings b ON b.id = f.booking_id
       WHERE f.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Follow-up not found.');
  return row;
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of FOLLOWUP_FIELDS) params[f] = payload[f] ?? null;
  if (!params.priority) params.priority = 'Medium';

  const result = db
    .prepare(`INSERT INTO follow_ups (${FOLLOWUP_FIELDS.join(', ')}) VALUES (${FOLLOWUP_FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Follow-up Created', 'follow_up', ?, ?)`
  ).run(result.lastInsertRowid, `Follow-up scheduled for ${payload.follow_up_date}`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM follow_ups WHERE id = ?').get(id);
  if (!existing) throw new Error('Follow-up not found.');

  const params = { id };
  const sets = [];
  for (const f of [...FOLLOWUP_FIELDS, 'status']) {
    if (payload[f] !== undefined) {
      if (f === 'status' && !STATUSES.includes(payload.status)) throw new Error('Invalid follow-up status.');
      sets.push(`${f} = @${f}`);
      params[f] = payload[f];
    }
  }
  sets.push("updated_at = datetime('now')");
  db.prepare(`UPDATE follow_ups SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Follow-up Updated', 'follow_up', ?, ?)`
  ).run(id, `Follow-up #${id} updated`);

  return { success: true };
}

function markStatus(id, status) {
  return update(id, { status });
}

function remove(id) {
  const db = getDb();
  db.prepare('DELETE FROM follow_ups WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'follow_up', ?, ?)`
  ).run(id, `Follow-up #${id} deleted`);
  return { success: true };
}

/**
 * Logs one contact that has just happened (the "Customer Information / Follow-up Details" form):
 *  - writes a history row (Follow-up History page),
 *  - if `existing_follow_up_id` is given, marks that scheduled follow-up Completed,
 *  - if a next follow-up date is given, schedules a new Pending follow-up (the "next action").
 * Works for an inquiry, a customer, a booking - or just a typed name/phone.
 */
function logContact(payload, actingUserId = null) {
  const db = getDb();
  const name = (payload.contact_name || '').trim();
  if (!payload.customer_id && !payload.lead_id && !payload.booking_id && !name) {
    throw new Error('Please select an inquiry/customer or type a name.');
  }
  if (!payload.contact_method) throw new Error('Please choose a contact method.');
  if (!payload.activity) throw new Error('Please choose what you did.');

  const run = db.transaction(() => {
    let nextId = null;
    if (payload.next_follow_up_date) {
      const created = create({
        follow_up_date: payload.next_follow_up_date,
        customer_id: payload.customer_id || null,
        lead_id: payload.lead_id || null,
        booking_id: payload.booking_id || null,
        contact_name: name || null,
        contact_phone: payload.contact_phone || null,
        purpose: payload.purpose || null,
        contact_method: payload.contact_method || null,
        reminder_time: payload.reminder_time || null,
        priority: payload.priority || 'Medium',
        notes: payload.next_notes || null,
        assigned_user_id: actingUserId
      });
      nextId = created.id;
    }

    if (payload.existing_follow_up_id) {
      db.prepare("UPDATE follow_ups SET status = 'Completed', updated_at = datetime('now') WHERE id = ?")
        .run(payload.existing_follow_up_id);
    }

    const result = db.prepare(
      `INSERT INTO follow_up_logs
        (follow_up_id, next_follow_up_id, customer_id, lead_id, booking_id, contact_name, contact_phone, reference_code,
         contact_method, activity, purpose, outcome, notes, next_follow_up_date, reminder_time, created_by)
       VALUES (@follow_up_id, @next_follow_up_id, @customer_id, @lead_id, @booking_id, @contact_name, @contact_phone, @reference_code,
         @contact_method, @activity, @purpose, @outcome, @notes, @next_follow_up_date, @reminder_time, @created_by)`
    ).run({
      follow_up_id: payload.existing_follow_up_id || null,
      next_follow_up_id: nextId,
      customer_id: payload.customer_id || null,
      lead_id: payload.lead_id || null,
      booking_id: payload.booking_id || null,
      contact_name: name || null,
      contact_phone: payload.contact_phone || null,
      reference_code: payload.reference_code || null,
      contact_method: payload.contact_method,
      activity: payload.activity,
      purpose: payload.purpose || null,
      outcome: payload.outcome || null,
      notes: payload.notes || null,
      next_follow_up_date: payload.next_follow_up_date || null,
      reminder_time: payload.reminder_time || null,
      created_by: actingUserId
    });

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Follow-up Logged', 'follow_up_log', ?, ?)`
    ).run(result.lastInsertRowid, `${payload.contact_method}: ${payload.activity}${name ? ' - ' + name : ''}`);

    return { id: result.lastInsertRowid, next_follow_up_id: nextId };
  });
  return run();
}

/** Follow-up History: every contact ever logged, newest first. */
function historyList({ search = '', method = 'All', outcome = 'All', dateFrom = '', dateTo = '', customerId = null, leadId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};
  if (search && search.trim()) {
    conditions.push(`(h.contact_name LIKE @q OR c.full_name LIKE @q OR l.full_name LIKE @q OR l.lead_code LIKE @q OR h.reference_code LIKE @q
      OR h.contact_phone LIKE @q OR h.purpose LIKE @q OR h.notes LIKE @q OR h.outcome LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (method && method !== 'All') { conditions.push('h.contact_method = @method'); params.method = method; }
  if (outcome && outcome !== 'All') { conditions.push('h.outcome = @outcome'); params.outcome = outcome; }
  if (dateFrom) { conditions.push('date(h.created_at) >= @dateFrom'); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push('date(h.created_at) <= @dateTo'); params.dateTo = dateTo; }
  if (customerId) { conditions.push('h.customer_id = @customerId'); params.customerId = customerId; }
  if (leadId) { conditions.push('h.lead_id = @leadId'); params.leadId = leadId; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const from = `FROM follow_up_logs h
    LEFT JOIN customers c ON c.id = h.customer_id
    LEFT JOIN leads l ON l.id = h.lead_id
    LEFT JOIN bookings b ON b.id = h.booking_id
    LEFT JOIN users u ON u.id = h.created_by ${where}`;
  const total = db.prepare(`SELECT COUNT(*) AS c ${from}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db.prepare(
    `SELECT h.*, COALESCE(c.full_name, l.full_name, h.contact_name) AS display_name,
       l.lead_code, b.booking_code, u.full_name AS agent_name
     ${from} ORDER BY h.created_at DESC, h.id DESC LIMIT @limit OFFSET @offset`
  ).all({ ...params, limit: pageSize, offset });
  return { rows, total, page, pageSize };
}

function historyDelete(id) {
  const db = getDb();
  db.prepare('DELETE FROM follow_up_logs WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'follow_up_log', ?, ?)`
  ).run(id, `Follow-up history #${id} deleted`);
  return { success: true };
}

function options() {
  return { contactMethods: CONTACT_METHODS, activities: ACTIVITIES, purposes: PURPOSES, outcomes: OUTCOMES, priorities: PRIORITIES };
}

module.exports = {  CONTACT_METHODS, ACTIVITIES, PURPOSES, OUTCOMES, logContact, historyList, historyDelete, options, PRIORITIES, STATUSES, list, dueSoon, get, create, update, markStatus, remove };
