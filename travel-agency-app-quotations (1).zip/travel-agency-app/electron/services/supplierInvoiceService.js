const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const supplierLedgerService = require('./supplierLedgerService');
const { assertNonNegative, assertRecordExists, assertValidDate } = require('./validation');

function deriveStatus(total, paid, dueDate) {
  if (paid >= total && total > 0) return 'Paid';
  if (paid > 0 && paid < total) return 'Partially Paid';
  if (dueDate && new Date(dueDate) < new Date() && paid < total) return 'Overdue';
  return 'Unpaid';
}

function validate(payload) {
  if (!payload.supplier_id) throw new Error('A supplier must be selected.');
  if (!payload.invoice_number || !payload.invoice_number.trim()) throw new Error('Invoice number is required.');
  if (!(Number(payload.amount) >= 0)) throw new Error('Amount must be zero or greater.');
  // Master prompt section 47: supplier cost must be linked to a valid
  // supplier/booking, with sensible dates and amounts - and a useful message
  // rather than a raw "FOREIGN KEY constraint failed".
  assertNonNegative(payload.tax, 'Tax');
  assertRecordExists('bookings', payload.booking_id, 'booking');
  assertValidDate(payload.invoice_date, 'Invoice date');
  assertValidDate(payload.due_date, 'Due date');
  if (payload.invoice_date && payload.due_date && String(payload.due_date).slice(0, 10) < String(payload.invoice_date).slice(0, 10)) {
    throw new Error('Due date cannot be before the invoice date.');
  }
}

function list({ search = '', supplierId = null, status = 'All', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(si.invoice_number LIKE @q OR s.name LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (supplierId) {
    conditions.push('si.supplier_id = @supplierId');
    params.supplierId = supplierId;
  }
  if (status && status !== 'All') {
    conditions.push('si.status = @status');
    params.status = status;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM supplier_invoices si JOIN suppliers s ON s.id = si.supplier_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT si.*, s.name AS supplier_name, s.supplier_code, b.booking_code
       FROM supplier_invoices si
       JOIN suppliers s ON s.id = si.supplier_id
       LEFT JOIN bookings b ON b.id = si.booking_id
       ${where}
       ORDER BY si.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT si.*, s.name AS supplier_name, s.supplier_code, b.booking_code
       FROM supplier_invoices si
       JOIN suppliers s ON s.id = si.supplier_id
       LEFT JOIN bookings b ON b.id = si.booking_id
       WHERE si.id = ?`
    )
    .get(id);
  if (!row) throw new Error('Supplier invoice not found.');
  return row;
}

function listByBooking(bookingId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT si.*, s.name AS supplier_name FROM supplier_invoices si
       JOIN suppliers s ON s.id = si.supplier_id
       WHERE si.booking_id = ? ORDER BY si.created_at DESC`
    )
    .all(bookingId);
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const supplier = db.prepare('SELECT id FROM suppliers WHERE id = ?').get(payload.supplier_id);
  if (!supplier) throw new Error('Selected supplier does not exist.');
  periodLock.assertOpen(payload.invoice_date, 'This supplier invoice');

  // Duplicate supplier cost guard: a supplier's invoice numbers are unique to
  // that supplier, so recording the same number twice would double the cost
  // and the payable. (Different suppliers may reuse a number - checked per supplier.)
  const dup = db.prepare(
    `SELECT id FROM supplier_invoices WHERE supplier_id = ? AND LOWER(TRIM(invoice_number)) = LOWER(TRIM(?)) LIMIT 1`
  ).get(payload.supplier_id, payload.invoice_number);
  if (dup) throw new Error(`Invoice "${String(payload.invoice_number).trim()}" from this supplier is already recorded.`);

  const amount = Number(payload.amount || 0);
  const tax = Number(payload.tax || 0);
  const total = amount + tax;

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO supplier_invoices
          (invoice_number, supplier_id, booking_id, invoice_date, due_date, currency, amount, tax, total, paid_amount, remaining_amount, status, notes)
         VALUES (@invoice_number, @supplier_id, @booking_id, @invoice_date, @due_date, @currency, @amount, @tax, @total, 0, @total, @status, @notes)`
      )
      .run({
        invoice_number: payload.invoice_number.trim(),
        supplier_id: payload.supplier_id,
        booking_id: payload.booking_id || null,
        invoice_date: payload.invoice_date || new Date().toISOString(),
        due_date: payload.due_date || null,
        currency: payload.currency || 'PKR',
        amount,
        tax,
        total,
        status: deriveStatus(total, 0, payload.due_date),
        notes: payload.notes || null
      });
    const invoiceId = result.lastInsertRowid;

    supplierLedgerService.addEntry(db, {
      supplier_id: payload.supplier_id,
      description: `Supplier Invoice ${payload.invoice_number}`,
      supplier_invoice_id: invoiceId,
      debit: total
    });

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Supplier Invoice Created', 'supplier_invoice', ?, ?)`
    ).run(invoiceId, `Supplier invoice ${payload.invoice_number} created (${total})`);

    return invoiceId;
  });

  return { id: tx() };
}

function remove(id) {
  const db = getDb();
  const invoice = db.prepare('SELECT * FROM supplier_invoices WHERE id = ?').get(id);
  if (!invoice) throw new Error('Supplier invoice not found.');
  periodLock.assertOpen(invoice.invoice_date, `Supplier invoice ${invoice.invoice_number}`);
  if (invoice.paid_amount > 0) {
    throw new Error('This invoice has payments recorded against it and cannot be deleted. Void the payments first.');
  }

  const tx = db.transaction(() => {
    supplierLedgerService.addEntry(db, {
      supplier_id: invoice.supplier_id,
      description: `Supplier Invoice ${invoice.invoice_number} deleted`,
      credit: invoice.total
    });
    db.prepare('DELETE FROM supplier_invoices WHERE id = ?').run(id);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'supplier_invoice', ?, ?)`
    ).run(id, `Supplier invoice ${invoice.invoice_number} deleted`);
  });
  tx();

  return { success: true };
}

module.exports = { deriveStatus, list, get, listByBooking, create, remove };
