const { dialog } = require('electron');
const fs = require('fs');
const { buildXlsx } = require('./xlsxWriter');

/**
 * Builds a real .xlsx from `sheets` (see xlsxWriter.buildXlsx for the shape)
 * and lets the user pick where to save it. Generic - used by the Custom
 * Report Builder, Ledger/Supplier Ledger, and the Customer/Supplier/Booking/
 * Package 360 dossiers alike; the caller decides which sheets are relevant.
 */
async function saveWorkbook(sheets, suggestedName = 'report.xlsx') {
  const buffer = buildXlsx(sheets);
  const result = await dialog.showSaveDialog({
    title: 'Save Excel Report',
    defaultPath: suggestedName,
    filters: [{ name: 'Excel Files', extensions: ['xlsx'] }]
  });
  if (result.canceled || !result.filePath) return { saved: false };
  fs.writeFileSync(result.filePath, buffer);
  return { saved: true, filePath: result.filePath };
}

module.exports = { saveWorkbook };
