const { getDb } = require('../../src/database/db');

/**
 * Real, database-driven global search across the categories Section 5
 * calls out. Each category is capped (LIMIT 5) so the dropdown stays fast
 * and readable; the person can still open the full list from that
 * category's own page. Every result carries a `route` so the UI can open
 * the record directly - no dead ends.
 */
function search(query) {
  const db = getDb();
  const q = (query || '').trim();
  if (q.length < 2) return { query: q, groups: [] };
  const like = `%${q}%`;

  const groups = [];

  const customers = db
    .prepare(
      `SELECT id, full_name AS label, phone AS sub FROM customers
       WHERE full_name LIKE @like OR phone LIKE @like OR email LIKE @like OR passport_number LIKE @like
       ORDER BY full_name LIMIT 5`
    )
    .all({ like });
  if (customers.length) groups.push({ category: 'Customer', items: customers.map((c) => ({ id: c.id, label: c.label, sub: c.sub, route: '/customers' })) });

  const travellers = db
    .prepare(
      `SELECT id, full_name AS label, passport_number AS sub FROM travellers
       WHERE full_name LIKE @like OR passport_number LIKE @like ORDER BY full_name LIMIT 5`
    )
    .all({ like });
  if (travellers.length) groups.push({ category: 'Traveller', items: travellers.map((t) => ({ id: t.id, label: t.label, sub: t.sub, route: '/travellers' })) });

  const bookings = db
    .prepare(
      `SELECT b.id, b.booking_code AS label, c.full_name AS sub FROM bookings b JOIN customers c ON c.id = b.customer_id
       WHERE b.booking_code LIKE @like OR c.full_name LIKE @like ORDER BY b.created_at DESC LIMIT 5`
    )
    .all({ like });
  if (bookings.length) groups.push({ category: 'Booking', items: bookings.map((b) => ({ id: b.id, label: b.label, sub: b.sub, route: '/bookings' })) });

  const invoices = db
    .prepare(
      `SELECT i.id, i.invoice_number AS label, c.full_name AS sub FROM invoices i JOIN customers c ON c.id = i.customer_id
       WHERE i.invoice_number LIKE @like ORDER BY i.created_at DESC LIMIT 5`
    )
    .all({ like });
  if (invoices.length) groups.push({ category: 'Invoice', items: invoices.map((i) => ({ id: i.id, label: i.label, sub: i.sub, route: '/invoices' })) });

  const suppliers = db
    .prepare(
      `SELECT id, name AS label, supplier_code AS sub FROM suppliers
       WHERE name LIKE @like OR supplier_code LIKE @like OR phone LIKE @like ORDER BY name LIMIT 5`
    )
    .all({ like });
  if (suppliers.length) groups.push({ category: 'Supplier', items: suppliers.map((s) => ({ id: s.id, label: s.label, sub: s.sub, route: '/suppliers' })) });

  const payments = db
    .prepare(
      `SELECT p.id, ('Rs. ' || p.amount) AS label, c.full_name AS sub FROM payments p JOIN customers c ON c.id = p.customer_id
       WHERE p.reference LIKE @like ORDER BY p.created_at DESC LIMIT 5`
    )
    .all({ like });
  if (payments.length) groups.push({ category: 'Payment', items: payments.map((p) => ({ id: p.id, label: p.label, sub: p.sub, route: '/payments' })) });

  const leads = db
    .prepare(
      `SELECT id, full_name AS label, lead_code AS sub FROM leads
       WHERE full_name LIKE @like OR phone LIKE @like OR lead_code LIKE @like ORDER BY created_at DESC LIMIT 5`
    )
    .all({ like });
  if (leads.length) groups.push({ category: 'Lead', items: leads.map((l) => ({ id: l.id, label: l.label, sub: l.sub, route: '/leads' })) });

  const flights = db
    .prepare(
      `SELECT id, (COALESCE(airline,'Flight') || ' ' || COALESCE(flight_number,'')) AS label, pnr AS sub FROM flights
       WHERE pnr LIKE @like OR ticket_number LIKE @like OR flight_number LIKE @like LIMIT 5`
    )
    .all({ like });
  if (flights.length) groups.push({ category: 'Flight', items: flights.map((f) => ({ id: f.id, label: f.label, sub: f.sub, route: '/flights' })) });

  const hotels = db
    .prepare(
      `SELECT id, hotel_name AS label, booking_reference AS sub FROM hotels
       WHERE hotel_name LIKE @like OR booking_reference LIKE @like LIMIT 5`
    )
    .all({ like });
  if (hotels.length) groups.push({ category: 'Hotel', items: hotels.map((h) => ({ id: h.id, label: h.label, sub: h.sub, route: '/hotels' })) });

  return { query: q, groups };
}

module.exports = { search };
