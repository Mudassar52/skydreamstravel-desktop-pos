const { makeCrudService } = require('./genericCrud');
const { makeMembershipService } = require('./membershipService');

const PACKAGE_FIELDS = [
  'package_name', 'package_type', 'departure_date', 'return_date', 'number_of_days',
  'visa_included', 'flight_included', 'hotel_included', 'transport_included',
  'food_included', 'ziyarat_included', 'makkah_hotel', 'madinah_hotel',
  'makkah_nights', 'madinah_nights', 'transport_details', 'package_cost',
  'selling_price', 'description', 'notes'
];

const GROUP_FIELDS = [
  'group_name', 'package_id', 'departure_date', 'return_date', 'visa_status', 'notes'
];

function validatePackage(payload) {
  if (!payload.package_name || !payload.package_name.trim()) {
    throw new Error('Package name is required.');
  }
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
}

function validateGroup(payload) {
  if (!payload.group_name || !payload.group_name.trim()) {
    throw new Error('Group name is required.');
  }
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
}

const packages = makeCrudService('umrah_packages', PACKAGE_FIELDS, {
  validate: validatePackage,
  recordLabelField: 'package_name'
});

const groupsCrud = makeCrudService('umrah_groups', GROUP_FIELDS, {
  validate: validateGroup,
  recordLabelField: 'group_name'
});

const passengers = makeMembershipService('umrah_group_passengers', 'group_id', 'umrah_groups', 'total_passengers');

const groups = {
  ...groupsCrud,
  remove: (id) => groupsCrud.remove(id) // no dependents to guard yet
};

module.exports = { packages, groups, passengers };
