const { getDb } = require('../../src/database/db');
const exchangeRates = require('./exchangeRateService');
const customer360Service = require('./customer360Service');
const supplier360Service = require('./supplier360Service');
const bookingDossierService = require('./bookingDossierService');
const ledgerService = require('./ledgerService');
const supplierLedgerService = require('./supplierLedgerService');
const { assertDateRange } = require('./validation');
const supplierAdvanceService = require('./supplierAdvanceService');

// Custom Report Builder (master prompt sections 27-33, 37-38). A report SPEC
// describes what to build; run(spec) always re-derives every number from the
// real tables at call time (via the same 360/ledger services the rest of the
// app uses), so a report can never drift from what Customer 360 / Supplier
// 360 / Booking 360 / the ledgers already show. Nothing here stores a
// computed figure - report_history stores the SPEC (so a report can be
// reopened and regenerated), never a frozen result.

function round2(n) { return Math.round((Number(n) || 0) * 100) / 100; }
function day(s) { return s ? String(s).slice(0, 10) : null; }

const REPORT_TYPES = [
  { key: 'customer', label: 'Customer Report' },
  { key: 'supplier', label: 'Supplier Report' },
  { key: 'booking', label: 'Booking Report' },
  { key: 'service', label: 'Service Report' },
  { key: 'financial', label: 'Financial Report' },
  { key: 'profitability', label: 'Profitability Report' },
  { key: 'travel_ops', label: 'Travel Operations Report' },
  { key: 'payment', label: 'Payment Report' },
  { key: 'ledger', label: 'Ledger Report' }
];

const DATE_FIELDS = {
  customer: [{ value: 'booking_date', label: 'Booking Date' }, { value: 'invoice_date', label: 'Invoice Date' }, { value: 'payment_date', label: 'Payment Date' }],
  supplier: [{ value: 'invoice_date', label: 'Invoice Date' }, { value: 'payment_date', label: 'Payment Date' }],
  booking: [{ value: 'booking_date', label: 'Booking Date' }, { value: 'departure_date', label: 'Departure Date' }, { value: 'return_date', label: 'Return Date' }],
  service: [{ value: 'service_date', label: 'Service Date' }],
  financial: [{ value: 'invoice_date', label: 'Invoice Date' }, { value: 'payment_date', label: 'Payment Date' }, { value: 'expense_date', label: 'Expense Date' }],
  profitability: [{ value: 'booking_date', label: 'Booking Date' }],
  travel_ops: [{ value: 'departure_date', label: 'Departure Date' }, { value: 'return_date', label: 'Arrival Date' }, { value: 'check_in', label: 'Check-in Date' }, { value: 'check_out', label: 'Check-out Date' }, { value: 'expiry_date', label: 'Visa Expiry Date' }],
  payment: [{ value: 'payment_date', label: 'Payment Date' }],
  ledger: [{ value: 'entry_date', label: 'Entry Date' }]
};

const CUSTOMER_SECTIONS = [
  'customer_info', 'bookings', 'travellers', 'flights', 'hotels', 'visa', 'transport', 'ziyarat',
  'invoices', 'payments', 'advances', 'outstanding', 'supplier_costs', 'profit', 'documents', 'timeline', 'ledger', 'notes'
];
const SUPPLIER_SECTIONS = ['supplier_info', 'bookings', 'services', 'invoices', 'payments', 'advances', 'payable', 'ledger'];
const BOOKING_SECTIONS = [
  'booking_info', 'customer', 'travellers', 'package', 'flights', 'hotels', 'visa', 'transport', 'ziyarat',
  'suppliers', 'invoices', 'payments', 'advances', 'outstanding', 'supplier_costs', 'profit', 'documents', 'timeline', 'notes'
];
const TRAVEL_OPS_TYPES = [
  'Upcoming Departures', 'Upcoming Arrivals', 'Airport Pickups', 'Airport Drops', 'Hotel Check-ins', 'Hotel Check-outs',
  'Intercity Transfers', 'Visa Expiry', 'Ticket Departures', 'Traveller Movements', 'Active Travellers', 'Completed Travel'
];

function sectionsFor(reportType) {
  if (reportType === 'customer') return CUSTOMER_SECTIONS;
  if (reportType === 'supplier') return SUPPLIER_SECTIONS;
  if (reportType === 'booking') return BOOKING_SECTIONS;
  return [];
}

function listReportTypes() { return REPORT_TYPES; }
function listDateFields(reportType) { return DATE_FIELDS[reportType] || []; }
function listSections(reportType) { return sectionsFor(reportType); }
function listServiceTypes() { return ['Flight', 'Hotel', 'Visa', 'Transport', 'Ziyarat', 'Package', 'Other']; }
function listTravelOpsTypes() { return TRAVEL_OPS_TYPES; }

function inRange(dateStr, from, to) {
  if (!dateStr) return !from && !to;
  const d = day(dateStr);
  if (from && d < from) return false;
  if (to && d > to) return false;
  return true;
}

/** Resolves a selection { mode: 'all'|'specific'|'multiple', ids: [] } against a full id list. */
function resolveIds(selection, allIds) {
  if (!selection || selection.mode === 'all') return allIds;
  const ids = (selection.ids || []).map(Number);
  return allIds.filter((id) => ids.includes(id));
}

/**
 * Preview limit: a screen preview only ever renders a page of records, so for
 * a huge selection ("All bookings") building every record's sections just to
 * discard them from view is pure waste, and shipping tens of thousands of
 * nested records over IPC freezes the app. `spec.previewLimit` caps how many
 * records are BUILT; `truncated` says so. Exports never pass previewLimit,
 * so they always get everything. Grand totals that can't be derived exactly
 * from the shown records are computed over ALL selected ids in SQL instead
 * (or left out) - never silently partial.
 */
function applyPreviewLimit(spec, ids) {
  const limit = Number(spec.previewLimit) > 0 ? Math.floor(Number(spec.previewLimit)) : 0;
  if (!limit || ids.length <= limit) return { shown: ids, truncated: null };
  return { shown: ids.slice(0, limit), truncated: { shown: limit, total: ids.length } };
}

/** SUM(...) over a (possibly large) id list in chunks, staying well under SQLite's bound-variable limit. */
function sumOverIds(sqlWithPlaceholder, ids) {
  const db = getDb();
  let total = 0;
  for (let i = 0; i < ids.length; i += 500) {
    const chunk = ids.slice(i, i + 500);
    total += db.prepare(sqlWithPlaceholder.replace('__IDS__', chunk.map(() => '?').join(','))).get(...chunk).s;
  }
  return round2(total);
}

// ------------------------------------------------------------- Customer Report
function buildCustomerReport(spec) {
  const db = getDb();
  const sections = spec.sections?.length ? spec.sections : CUSTOMER_SECTIONS;
  const allIds = db.prepare('SELECT id FROM customers ORDER BY id').all().map((r) => r.id);
  const ids = resolveIds(spec.selection, allIds);
  const { shown, truncated } = applyPreviewLimit(spec, ids);
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';

  const records = shown.map((customerId) => {
    const dossier = customer360Service.getDossier(customerId);
    const bookings = customer360Service.bookingHistory(customerId, { pageSize: 0 }).items
      .filter((b) => inRange(b[spec.dateField === 'departure_date' ? 'departure_date' : 'booking_date'] || b.booking_date, dateFrom, dateTo));
    const bookingIds = bookings.map((b) => b.id);
    const out = { customer: dossier.header, billed: dossier.summary.invoices.total_billed, sections: {} };

    if (sections.includes('customer_info')) out.sections.customer_info = dossier.header;
    if (sections.includes('bookings')) out.sections.bookings = bookings;
    for (const key of ['travellers', 'flights', 'hotels', 'visa', 'transport', 'ziyarat', 'invoices', 'payments', 'documents', 'timeline']) {
      if (!sections.includes(key)) continue;
      out.sections[key] = bookingIds.flatMap((bid) => bookingDossierService[key](bid).map((r) => ({ ...r, booking_id: bid })));
    }
    if (sections.includes('advances')) out.sections.advances = { received: 0, used: 0, remaining: 0, ...dossier.summary.advance };
    if (sections.includes('outstanding')) out.sections.outstanding = { outstanding_balance: dossier.summary.outstanding_balance };
    if (sections.includes('supplier_costs')) {
      out.sections.supplier_costs = bookingIds.flatMap((bid) => bookingDossierService.supplierCosts(bid).invoices.map((r) => ({ ...r, booking_id: bid })));
    }
    if (sections.includes('profit')) out.sections.profit = dossier.summary.profitability;
    if (sections.includes('ledger')) out.sections.ledger = ledgerService.filteredView(customerId, { dateFrom, dateTo });
    if (sections.includes('notes')) out.sections.notes = dossier.header.notes;
    return out;
  });

  // Reuses the figure computed once per customer above - recomputing
  // customer360Service.summary() here for every record doubled the cost of
  // an "All customers" report for no benefit.
  const grandTotals = {
    total_billed: truncated
      ? sumOverIds(`SELECT COALESCE(SUM(total), 0) AS s FROM invoices WHERE status <> 'Cancelled' AND customer_id IN (__IDS__)`, ids)
      : round2(records.reduce((a, r) => a + (r.billed || 0), 0))
  };
  return { reportType: 'customer', sections, records, grandTotals, truncated };
}

// ------------------------------------------------------------- Supplier Report
function buildSupplierReport(spec) {
  const db = getDb();
  const sections = spec.sections?.length ? spec.sections : SUPPLIER_SECTIONS;
  const allIds = db.prepare('SELECT id FROM suppliers ORDER BY id').all().map((r) => r.id);
  const ids = resolveIds(spec.selection, allIds);
  const { shown, truncated } = applyPreviewLimit(spec, ids);
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';

  const records = shown.map((supplierId) => {
    const dossier = supplier360Service.getDossier(supplierId);
    const out = { supplier: dossier.header, payable: dossier.summary.invoices.payable, sections: {} };
    if (sections.includes('supplier_info')) out.sections.supplier_info = dossier.header;
    if (sections.includes('bookings')) out.sections.bookings = supplier360Service.bookings(supplierId);
    if (sections.includes('services')) out.sections.services = supplier360Service.serviceUsage(supplierId, { dateFrom, dateTo, pageSize: 0 }).items;
    if (sections.includes('invoices')) out.sections.invoices = supplier360Service.invoices(supplierId).filter((i) => inRange(i.invoice_date, dateFrom, dateTo));
    if (sections.includes('payments')) out.sections.payments = supplier360Service.payments(supplierId).filter((p) => inRange(p.payment_date, dateFrom, dateTo));
    if (sections.includes('advances')) out.sections.advances = supplierAdvanceService.summary(supplierId);
    if (sections.includes('payable')) out.sections.payable = { payable: dossier.summary.invoices.payable, ledger_balance: dossier.summary.ledger_balance };
    if (sections.includes('ledger')) out.sections.ledger = supplierLedgerService.filteredView(supplierId, { dateFrom, dateTo });
    return out;
  });

  const grandTotals = {
    total_payable: truncated
      ? sumOverIds(`SELECT COALESCE(SUM(CASE WHEN status <> 'Paid' THEN remaining_amount ELSE 0 END), 0) AS s FROM supplier_invoices WHERE supplier_id IN (__IDS__)`, ids)
      : round2(records.reduce((a, r) => a + (r.payable || 0), 0))
  };
  return { reportType: 'supplier', sections, records, grandTotals, truncated };
}

// -------------------------------------------------------------- Booking Report
function buildBookingReport(spec) {
  const db = getDb();
  const sections = spec.sections?.length ? spec.sections : BOOKING_SECTIONS;
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const dateCol = ['booking_date', 'departure_date', 'return_date'].includes(spec.dateField) ? spec.dateField : 'booking_date';

  const where = [];
  const params = {};
  if (spec.customerId) { where.push('bk.customer_id = @customerId'); params.customerId = Number(spec.customerId); }
  if (dateFrom) { where.push(`date(bk.${dateCol}) >= date(@dateFrom)`); params.dateFrom = dateFrom; }
  if (dateTo) { where.push(`date(bk.${dateCol}) <= date(@dateTo)`); params.dateTo = dateTo; }
  if (spec.status && spec.status !== 'All') { where.push('bk.status = @status'); params.status = spec.status; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  let allIds = db.prepare(`SELECT bk.id FROM bookings bk ${whereSql} ORDER BY bk.id`).all(params).map((r) => r.id);
  if (spec.serviceType && spec.serviceType !== 'All') {
    const table = { Flight: 'flights', Hotel: 'hotels', Visa: 'visa_applications', Transport: 'transportation' }[spec.serviceType];
    if (table) {
      const withService = new Set(db.prepare(`SELECT DISTINCT booking_id FROM ${table}`).all().map((r) => r.booking_id));
      allIds = allIds.filter((id) => withService.has(id));
    } else if (spec.serviceType === 'Ziyarat') {
      const withZ = new Set(db.prepare(`SELECT DISTINCT booking_id FROM other_services WHERE service_type = 'Ziyarat'`).all().map((r) => r.booking_id));
      allIds = allIds.filter((id) => withZ.has(id));
    }
  }
  const ids = resolveIds(spec.selection, allIds);
  const { shown, truncated } = applyPreviewLimit(spec, ids);

  // Compute ONLY the selected sections per booking. This used to call
  // bookingDossierService.getDossier() (all 16 sections) for every booking
  // and then discard most of it - wasteful across "All bookings".
  const records = shown.map((bookingId) => {
    const header = bookingDossierService.header(bookingId);
    const out = { booking: header, sections: {} };
    if (sections.includes('booking_info')) out.sections.booking_info = header;
    if (sections.includes('customer')) out.sections.customer = header.customer;
    if (sections.includes('package')) out.sections.package = header.package_snapshot;
    for (const key of ['travellers', 'flights', 'hotels', 'visa', 'transport', 'ziyarat', 'suppliers', 'invoices', 'payments', 'advances', 'outstanding', 'documents', 'timeline', 'profit']) {
      if (sections.includes(key)) out.sections[key] = bookingDossierService[key](bookingId);
    }
    if (sections.includes('supplier_costs')) out.sections.supplier_costs = bookingDossierService.supplierCosts(bookingId);
    if (sections.includes('notes')) out.sections.notes = header.notes;
    return out;
  });

  // total_selling is exact over every selected booking either way. total_profit
  // needs each booking's full profit calculation, so on a truncated preview it
  // is left out entirely rather than shown as a misleading partial sum - the
  // exported report (which is never truncated) carries it.
  const grandTotals = truncated
    ? { total_selling: sumOverIds(`SELECT COALESCE(SUM(total_price), 0) AS s FROM bookings WHERE id IN (__IDS__)`, ids) }
    : {
        total_selling: round2(records.reduce((a, r) => a + (r.booking?.total_price || 0), 0)),
        total_profit: round2(records.reduce((a, r) => a + (r.sections.profit?.actual_profit ?? 0), 0))
      };
  return { reportType: 'booking', sections, records, grandTotals, truncated };
}

// -------------------------------------------------------------- Service Report
function buildServiceReport(spec) {
  const db = getDb();
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const types = spec.serviceTypes?.length ? spec.serviceTypes : listServiceTypes().filter((t) => t !== 'Package' && t !== 'Other');

  const dateCol = { Flight: 'departure_date', Hotel: 'check_in', Visa: 'application_date', Transport: 'pickup_date', Ziyarat: 'service_date' };
  const table = { Flight: 'flights', Hotel: 'hotels', Visa: 'visa_applications', Transport: 'transportation', Ziyarat: 'other_services' };
  const rows = [];
  for (const t of types) {
    const tbl = table[t];
    if (!tbl) continue;
    const extra = t === 'Ziyarat' ? `AND service_type = 'Ziyarat'` : '';
    const dc = dateCol[t];
    const r = db.prepare(
      `SELECT COUNT(*) AS count, COALESCE(SUM(cost),0) AS cost, COALESCE(SUM(selling_price),0) AS selling
       FROM ${tbl} WHERE 1=1 ${extra}
       ${dateFrom ? `AND date(${dc}) >= date(@dateFrom)` : ''} ${dateTo ? `AND date(${dc}) <= date(@dateTo)` : ''}`
    ).get({ dateFrom, dateTo });
    rows.push({ service_type: t, count: r.count, purchase: round2(r.cost), sales: round2(r.selling), profit: round2(r.selling - r.cost) });
  }
  const grandTotals = {
    count: rows.reduce((a, r) => a + r.count, 0),
    purchase: round2(rows.reduce((a, r) => a + r.purchase, 0)),
    sales: round2(rows.reduce((a, r) => a + r.sales, 0)),
    profit: round2(rows.reduce((a, r) => a + r.profit, 0))
  };
  return { reportType: 'service', rows, grandTotals };
}

// ------------------------------------------------------------- Financial Report
function buildFinancialReport(spec) {
  const db = getDb();
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const dateFilter = (col) => `${dateFrom ? `AND date(${col}) >= date(@dateFrom)` : ''} ${dateTo ? `AND date(${col}) <= date(@dateTo)` : ''}`;
  const params = { dateFrom, dateTo };

  const revenue = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM invoices WHERE status <> 'Cancelled' ${dateFilter('invoice_date')}`).get(params).s;
  const collected = db.prepare(`SELECT COALESCE(SUM(CASE WHEN payment_type <> 'Refund' THEN amount ELSE -amount END),0) AS s FROM payments WHERE 1=1 ${dateFilter('payment_date')}`).get(params).s;
  const supplierInvoiced = db.prepare(`SELECT COALESCE(SUM(total),0) AS s FROM supplier_invoices WHERE 1=1 ${dateFilter('invoice_date')}`).get(params).s;
  const supplierPaid = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM supplier_payments WHERE 1=1 ${dateFilter('payment_date')}`).get(params).s;
  const expenses = db.prepare(`SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE 1=1 ${dateFilter('expense_date')}`).get(params).s;

  const grossProfit = round2(revenue - supplierInvoiced - expenses);
  const rows = [
    { line: 'Revenue (Invoiced)', amount: round2(revenue) },
    { line: 'Cash Collected', amount: round2(collected) },
    { line: 'Supplier Cost (Invoiced)', amount: round2(supplierInvoiced) },
    { line: 'Supplier Payments Made', amount: round2(supplierPaid) },
    { line: 'Operating Expenses', amount: round2(expenses) },
    { line: 'Gross Profit (Revenue - Supplier Cost - Expenses)', amount: grossProfit }
  ];
  return { reportType: 'financial', rows, grandTotals: { gross_profit: grossProfit } };
}

// ---------------------------------------------------------- Profitability Report
function buildProfitabilityReport(spec) {
  const db = getDb();
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const rows = db.prepare(
    `WITH r AS (
       SELECT bk.id, bk.booking_code, bk.booking_date, bk.status, bk.total_price AS selling, c.full_name AS customer_name,
         (SELECT COALESCE(SUM(total),0) FROM supplier_invoices WHERE booking_id = bk.id) AS cost_actual,
         ((SELECT COALESCE(SUM(cost),0) FROM flights WHERE booking_id = bk.id) + (SELECT COALESCE(SUM(cost),0) FROM hotels WHERE booking_id = bk.id)
          + (SELECT COALESCE(SUM(cost),0) FROM visa_applications WHERE booking_id = bk.id) + (SELECT COALESCE(SUM(cost),0) FROM transportation WHERE booking_id = bk.id)
          + (SELECT COALESCE(SUM(cost),0) FROM other_services WHERE booking_id = bk.id)) AS cost_estimated
       FROM bookings bk JOIN customers c ON c.id = bk.customer_id
       WHERE bk.status <> 'Cancelled'
         ${dateFrom ? `AND date(bk.booking_date) >= date(@dateFrom)` : ''} ${dateTo ? `AND date(bk.booking_date) <= date(@dateTo)` : ''}
     )
     SELECT *, CASE WHEN cost_actual > 0 THEN cost_actual ELSE cost_estimated END AS cost FROM r ORDER BY booking_date DESC`
  ).all({ dateFrom, dateTo }).map((r) => ({
    booking_code: r.booking_code, customer_name: r.customer_name, booking_date: r.booking_date, status: r.status,
    selling: round2(r.selling), cost: round2(r.cost), profit: round2(r.selling - r.cost),
    margin_percent: r.selling > 0 ? round2(((r.selling - r.cost) / r.selling) * 100) : null
  }));
  const grandTotals = {
    selling: round2(rows.reduce((a, r) => a + r.selling, 0)),
    cost: round2(rows.reduce((a, r) => a + r.cost, 0)),
    profit: round2(rows.reduce((a, r) => a + r.profit, 0))
  };
  return { reportType: 'profitability', rows, grandTotals };
}

// -------------------------------------------------------- Travel Operations Report
function buildTravelOpsReport(spec) {
  const db = getDb();
  const opsType = spec.opsType || 'Upcoming Departures';
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const df = (col) => `${dateFrom ? `AND date(${col}) >= date(@dateFrom)` : ''} ${dateTo ? `AND date(${col}) <= date(@dateTo)` : ''}`;
  const params = { dateFrom, dateTo };
  let rows = [];

  if (opsType === 'Upcoming Departures' || opsType === 'Ticket Departures') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, bk.departure_date, bk.destination, bk.status
      FROM bookings bk JOIN customers c ON c.id = bk.customer_id WHERE bk.status NOT IN ('Cancelled') AND bk.departure_date IS NOT NULL ${df('bk.departure_date')} ORDER BY bk.departure_date`).all(params);
  } else if (opsType === 'Upcoming Arrivals') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, bk.return_date, bk.destination, bk.status
      FROM bookings bk JOIN customers c ON c.id = bk.customer_id WHERE bk.status NOT IN ('Cancelled') AND bk.return_date IS NOT NULL ${df('bk.return_date')} ORDER BY bk.return_date`).all(params);
  } else if (opsType === 'Airport Pickups' || opsType === 'Airport Drops' || opsType === 'Intercity Transfers') {
    const locCol = opsType === 'Airport Drops' ? 'drop_location' : 'pickup_location';
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, t.pickup_location, t.drop_location, t.pickup_date, t.pickup_time, t.status
      FROM transportation t JOIN bookings bk ON bk.id = t.booking_id JOIN customers c ON c.id = bk.customer_id
      WHERE ${locCol} LIKE '%Airport%' ${df('t.pickup_date')} ORDER BY t.pickup_date`).all(params);
    if (opsType === 'Intercity Transfers') {
      rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, t.pickup_location, t.drop_location, t.pickup_date, t.pickup_time, t.status
        FROM transportation t JOIN bookings bk ON bk.id = t.booking_id JOIN customers c ON c.id = bk.customer_id WHERE 1=1 ${df('t.pickup_date')} ORDER BY t.pickup_date`).all(params);
    }
  } else if (opsType === 'Hotel Check-ins') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, h.hotel_name, h.check_in, h.room_type, h.status
      FROM hotels h JOIN bookings bk ON bk.id = h.booking_id JOIN customers c ON c.id = bk.customer_id WHERE 1=1 ${df('h.check_in')} ORDER BY h.check_in`).all(params);
  } else if (opsType === 'Hotel Check-outs') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, h.hotel_name, h.check_out, h.room_type, h.status
      FROM hotels h JOIN bookings bk ON bk.id = h.booking_id JOIN customers c ON c.id = bk.customer_id WHERE 1=1 ${df('h.check_out')} ORDER BY h.check_out`).all(params);
  } else if (opsType === 'Visa Expiry') {
    rows = db.prepare(`SELECT c.full_name AS customer_name, v.country, v.visa_type, v.expiry_date, v.status
      FROM visa_applications v JOIN customers c ON c.id = v.customer_id WHERE v.expiry_date IS NOT NULL ${df('v.expiry_date')} ORDER BY v.expiry_date`).all(params);
  } else if (opsType === 'Traveller Movements' || opsType === 'Active Travellers') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, bk.departure_date, bk.return_date, bk.status
      FROM bookings bk JOIN customers c ON c.id = bk.customer_id WHERE bk.status IN ('Confirmed','Pending') ${df('bk.departure_date')} ORDER BY bk.departure_date`).all(params);
  } else if (opsType === 'Completed Travel') {
    rows = db.prepare(`SELECT bk.booking_code, c.full_name AS customer_name, bk.departure_date, bk.return_date, bk.status
      FROM bookings bk JOIN customers c ON c.id = bk.customer_id WHERE bk.status = 'Completed' ${df('bk.return_date')} ORDER BY bk.return_date DESC`).all(params);
  }
  return { reportType: 'travel_ops', opsType, rows, grandTotals: { count: rows.length } };
}

// ------------------------------------------------------------- Payment Report
function buildPaymentReport(spec) {
  const db = getDb();
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const where = [];
  const params = { dateFrom, dateTo };
  if (dateFrom) where.push('date(p.payment_date) >= date(@dateFrom)');
  if (dateTo) where.push('date(p.payment_date) <= date(@dateTo)');
  if (spec.customerId) { where.push('p.customer_id = @customerId'); params.customerId = Number(spec.customerId); }
  if (spec.paymentType && spec.paymentType !== 'All') { where.push('p.payment_type = @paymentType'); params.paymentType = spec.paymentType; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const rows = db.prepare(
    `SELECT p.*, c.full_name AS customer_name, i.invoice_number, bk.booking_code FROM payments p
     JOIN customers c ON c.id = p.customer_id LEFT JOIN invoices i ON i.id = p.invoice_id LEFT JOIN bookings bk ON bk.id = p.booking_id
     ${whereSql} ORDER BY p.payment_date DESC`
  ).all(params).map((r) => ({ ...r, amount: round2(r.amount) }));
  const grandTotals = {
    total: round2(rows.filter((r) => r.payment_type !== 'Refund').reduce((a, r) => a + r.amount, 0)),
    refunds: round2(rows.filter((r) => r.payment_type === 'Refund').reduce((a, r) => a + r.amount, 0))
  };
  return { reportType: 'payment', rows, grandTotals };
}

// -------------------------------------------------------------- Ledger Report
function buildLedgerReport(spec) {
  const db = getDb();
  const dateFrom = spec.dateFrom || '', dateTo = spec.dateTo || '';
  const entity = spec.entityType === 'supplier' ? 'supplier' : 'customer';
  const table = entity === 'supplier' ? 'suppliers' : 'customers';
  const nameCol = entity === 'supplier' ? 'name' : 'full_name';
  const allIds = db.prepare(`SELECT id FROM ${table} ORDER BY id`).all().map((r) => r.id);
  const ids = resolveIds(spec.selection, allIds);
  const svc = entity === 'supplier' ? supplierLedgerService : ledgerService;

  const records = ids
    .map((id) => {
      const view = svc.filteredView(id, { dateFrom, dateTo });
      const name = db.prepare(`SELECT ${nameCol} AS name FROM ${table} WHERE id = ?`).get(id)?.name;
      return { id, name, view };
    })
    .filter((r) => r.view.entries.length > 0 || (spec.selection?.mode !== 'all'));

  const grandTotals = {
    total_debit: round2(records.reduce((a, r) => a + r.view.totalDebit, 0)),
    total_credit: round2(records.reduce((a, r) => a + r.view.totalCredit, 0))
  };
  return { reportType: 'ledger', entity, records, grandTotals };
}

const BUILDERS = {
  customer: buildCustomerReport,
  supplier: buildSupplierReport,
  booking: buildBookingReport,
  service: buildServiceReport,
  financial: buildFinancialReport,
  profitability: buildProfitabilityReport,
  travel_ops: buildTravelOpsReport,
  payment: buildPaymentReport,
  ledger: buildLedgerReport
};

/**
 * Currencies of the live bookings in the system (same rule as Customer 360: the booking's own
 * currency, else its package's, else the agency default). Reports add up amounts exactly as
 * recorded - this app has no exchange rates and never converts - so when more than one currency is
 * present the report says so instead of letting a total quietly mix them.
 */
function currencyNotice() {
  const db = getDb();
  const rows = db.prepare(
    `SELECT COALESCE(bk.currency, pk.currency, (SELECT value FROM settings WHERE key = 'default_currency'), 'PKR') AS currency,
            COALESCE(SUM(bk.total_price), 0) AS selling
     FROM bookings bk LEFT JOIN packages pk ON pk.id = bk.package_id WHERE bk.status <> 'Cancelled'
     GROUP BY 1 ORDER BY 1`
  ).all();
  if (rows.length < 2) return null;
  const list = rows.map((r) => r.currency).join(', ');

  // Phase 21: with exchange rates entered, say what the combined figure is worth in the base currency instead
  // of only warning. Rows themselves stay as recorded (a report row is one booking in its own currency).
  const base = exchangeRates.getBaseCurrency();
  const conv = exchangeRates.convertTotals(rows.map((r) => ({ currency: r.currency, amount: r.selling })), base);
  const fmt = (n) => Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 });
  const perCurrency = rows.map((r) => `${r.currency} ${fmt(r.selling)}`).join(' + ');
  if (conv.complete) {
    return `Bookings in ${list} are included. Row amounts are shown in each booking's own currency and are not converted, so a column total adds figures of different currencies together. For reference, total booking value is ${perCurrency} = ${base} ${fmt(conv.total)} at the exchange rates currently on file.`;
  }
  return `Bookings in ${list} are included. Amounts are shown as recorded and are NOT converted between currencies, so totals add figures of different currencies together. No exchange rate is on file for ${conv.missing.join(', ')} to ${base} - add one under Finance > Exchange Rates to see a converted total.`;
}

/** Runs a report spec and returns its data. This is the single entry point used by preview, export and regenerate-from-history. */
function run(spec) {
  const builder = BUILDERS[spec.reportType];
  if (!builder) throw new Error(`Unknown report type: ${spec.reportType}`);
  assertDateRange(spec.dateFrom, spec.dateTo, ['From date', 'To date']);
  return { spec, generatedAt: new Date().toISOString(), currencyNotice: currencyNotice(), ...builder(spec) };
}

module.exports = {
  listReportTypes, listDateFields, listSections, listServiceTypes, listTravelOpsTypes, run
};
