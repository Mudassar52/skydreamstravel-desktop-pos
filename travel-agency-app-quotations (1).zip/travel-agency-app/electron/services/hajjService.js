const { makeCrudService } = require('./genericCrud');
const { makeMembershipService } = require('./membershipService');
const { getDb } = require('../../src/database/db');

const PACKAGE_FIELDS = [
  'package_name', 'departure_date', 'return_date', 'makkah_hotel', 'madinah_hotel',
  'package_cost', 'selling_price', 'description', 'notes'
];

const GROUP_FIELDS = [
  'group_name', 'package_id', 'departure_date', 'return_date', 'total_seats', 'visa_status', 'notes'
];

function validatePackage(payload) {
  if (!payload.package_name || !payload.package_name.trim()) {
    throw new Error('Package name is required.');
  }
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
}

function validateGroup(payload) {
  if (!payload.group_name || !payload.group_name.trim()) {
    throw new Error('Group name is required.');
  }
  if (payload.total_seats === '' || payload.total_seats === null) payload.total_seats = 0;
  if (payload.total_seats !== undefined) {
    const seats = Number(payload.total_seats);
    if (!Number.isInteger(seats) || seats < 0) throw new Error('Total seats must be a whole number, 0 or more.');
    payload.total_seats = seats;
  }
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
}

const packages = makeCrudService('hajj_packages', PACKAGE_FIELDS, {
  validate: validatePackage,
  recordLabelField: 'package_name'
});

const groups = makeCrudService('hajj_groups', GROUP_FIELDS, {
  validate: validateGroup,
  recordLabelField: 'group_name'
});

const basePilgrims = makeMembershipService('hajj_group_pilgrims', 'group_id', 'hajj_groups', 'total_pilgrims');

// total_seats = 0 means "no seat limit set" (older groups), so only a real limit blocks adding.
const pilgrims = {
  ...basePilgrims,
  add(groupId, customerId, notes) {
    const g = getDb().prepare('SELECT total_seats, total_pilgrims FROM hajj_groups WHERE id = ?').get(groupId);
    if (!g) throw new Error('Hajj group not found.');
    if ((g.total_seats || 0) > 0 && (g.total_pilgrims || 0) >= g.total_seats) {
      throw new Error('No seats left in this Hajj group.');
    }
    return basePilgrims.add(groupId, customerId, notes);
  }
};

module.exports = { packages, groups, pilgrims };
