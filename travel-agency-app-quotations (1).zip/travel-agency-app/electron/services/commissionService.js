const { getDb } = require('../../src/database/db');
const accountService = require('./accountService');
const exchangeRates = require('./exchangeRateService');

/**
 * Agent commissions (Phase 21).
 *
 *   Pending   - created automatically when a booking is saved with an agent (or by hand). Still editable.
 *   Approved  - the agency accepts that it owes this amount. Frozen.
 *   Paid      - money went out. Paying creates a real Expense (category "Agent Commission") through the same
 *               path as any other expense, so the cash/bank account, Profit reports and the General Ledger all
 *               see it. Commission cost therefore reaches profit when it is PAID, same as every other expense.
 *   Cancelled - will not be paid. A booking that is cancelled cancels its Pending/Approved commissions.
 *
 * The rate and base amount are copied onto the commission when it is created, so changing the agent's default
 * rate later never rewrites a commission that was already promised.
 */

const STATUSES = ['Pending', 'Approved', 'Paid', 'Cancelled'];
const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];
const CATEGORY_NAME = 'Agent Commission';

function round2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }

function calcAmount(type, value, base) {
  const v = Number(value || 0);
  if (type === 'Fixed') return round2(v);
  return round2((Number(base || 0) * v) / 100);
}

function bookingCurrency(db, bookingId) {
  const row = db.prepare(
    `SELECT COALESCE(bk.currency, pk.currency, (SELECT value FROM settings WHERE key = 'default_currency'), 'PKR') AS currency
     FROM bookings bk LEFT JOIN packages pk ON pk.id = bk.package_id WHERE bk.id = ?`
  ).get(bookingId);
  return row ? row.currency : null;
}

function ensureCategory(db) {
  const row = db.prepare('SELECT id FROM expense_categories WHERE name = ?').get(CATEGORY_NAME);
  if (row) return row.id;
  return db.prepare('INSERT INTO expense_categories (name) VALUES (?)').run(CATEGORY_NAME).lastInsertRowid;
}

const SELECT_SQL = `
  SELECT c.*, a.agent_code, a.name AS agent_name, b.booking_code, b.status AS booking_status, cu.full_name AS customer_name
  FROM commissions c
  JOIN agents a ON a.id = c.agent_id
  JOIN bookings b ON b.id = c.booking_id
  JOIN customers cu ON cu.id = b.customer_id`;

function list({ agentId = null, bookingId = null, status = 'All', dateFrom = null, dateTo = null, search = '', page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const cond = [];
  const params = {};
  if (agentId) { cond.push('c.agent_id = @agentId'); params.agentId = agentId; }
  if (bookingId) { cond.push('c.booking_id = @bookingId'); params.bookingId = bookingId; }
  if (status && status !== 'All') { cond.push('c.status = @status'); params.status = status; }
  if (dateFrom) { cond.push('date(c.created_at) >= date(@dateFrom)'); params.dateFrom = dateFrom; }
  if (dateTo) { cond.push('date(c.created_at) <= date(@dateTo)'); params.dateTo = dateTo; }
  if (search && search.trim()) {
    cond.push('(a.name LIKE @q OR a.agent_code LIKE @q OR b.booking_code LIKE @q OR cu.full_name LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM commissions c JOIN agents a ON a.id = c.agent_id JOIN bookings b ON b.id = c.booking_id JOIN customers cu ON cu.id = b.customer_id ${where}`).get(params).n;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db.prepare(`${SELECT_SQL} ${where} ORDER BY c.id DESC LIMIT @limit OFFSET @offset`).all({ ...params, limit: pageSize, offset });
  return { rows, total, page, pageSize };
}

function get(id) {
  const row = getDb().prepare(`${SELECT_SQL} WHERE c.id = ?`).get(id);
  if (!row) throw new Error('Commission not found.');
  return row;
}

/**
 * Totals per currency and status. Currencies are never added together silently: when exchange rates exist the
 * result also carries one converted figure in the base currency (`converted`), otherwise it lists what's missing.
 */
function summary({ agentId = null } = {}) {
  const db = getDb();
  const rows = db.prepare(
    `SELECT COALESCE(currency, (SELECT value FROM settings WHERE key='default_currency'), 'PKR') AS currency, status,
            COUNT(*) AS n, COALESCE(SUM(commission_amount), 0) AS amount
     FROM commissions ${agentId ? 'WHERE agent_id = ?' : ''} GROUP BY 1, 2 ORDER BY 1, 2`
  ).all(...(agentId ? [agentId] : []));
  const byCurrency = {};
  for (const r of rows) {
    const c = (byCurrency[r.currency] = byCurrency[r.currency] || { currency: r.currency, pending: 0, approved: 0, paid: 0, cancelled: 0 });
    c[r.status.toLowerCase()] = round2(r.amount);
  }
  const currencies = Object.values(byCurrency);
  const base = exchangeRates.getBaseCurrency();
  let converted = null;
  if (currencies.length > 1) {
    const part = (k) => exchangeRates.convertTotals(currencies.map((c) => ({ currency: c.currency, amount: c[k] })), base);
    const pend = part('pending'); const appr = part('approved'); const paid = part('paid');
    converted = { currency: base, complete: pend.complete, missing: pend.missing, pending: pend.total, approved: appr.total, paid: paid.total };
  }
  return { currencies, mixed_currency: currencies.length > 1, converted };
}

/** Creates a commission for a booking using the agent's CURRENT default rate (frozen onto the row). */
function createRow(db, { agentId, bookingId, createdBy = null, notes = null, overrideType = null, overrideValue = null }) {
  const agent = db.prepare('SELECT * FROM agents WHERE id = ?').get(agentId);
  if (!agent) throw new Error('Agent not found.');
  const booking = db.prepare('SELECT id, booking_code, total_price FROM bookings WHERE id = ?').get(bookingId);
  if (!booking) throw new Error('Booking not found.');
  const type = overrideType || agent.commission_type;
  const value = overrideValue !== null && overrideValue !== undefined && overrideValue !== '' ? Number(overrideValue) : agent.commission_value;
  if (!(value >= 0)) throw new Error('Commission value cannot be negative.');
  if (type === 'Percentage' && value > 100) throw new Error('A percentage commission cannot be more than 100.');
  const base = Number(booking.total_price || 0);
  const amount = calcAmount(type, value, base);
  const res = db.prepare(
    `INSERT INTO commissions (agent_id, booking_id, base_amount, commission_type, commission_value, commission_amount, currency, status, notes, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)`
  ).run(agentId, bookingId, base, type, value, amount, bookingCurrency(db, bookingId), notes, createdBy);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Created', 'commission', ?, ?)`)
    .run(res.lastInsertRowid, `Commission ${amount} for ${agent.agent_code} on ${booking.booking_code}`);
  return res.lastInsertRowid;
}

function create(payload) {
  const db = getDb();
  if (!payload.agent_id) throw new Error('Please select an agent.');
  if (!payload.booking_id) throw new Error('Please select a booking.');
  const dup = db.prepare(`SELECT id FROM commissions WHERE agent_id = ? AND booking_id = ? AND status <> 'Cancelled'`).get(payload.agent_id, payload.booking_id);
  if (dup) throw new Error('This agent already has an open commission on that booking.');
  const id = createRow(db, {
    agentId: payload.agent_id, bookingId: payload.booking_id, createdBy: payload.created_by || null, notes: payload.notes || null,
    overrideType: payload.commission_type || null, overrideValue: payload.commission_value
  });
  return { id };
}

/** Only a Pending commission can be changed - rate, base amount and notes. */
function update(id, payload) {
  const db = getDb();
  const c = get(id);
  if (c.status !== 'Pending') throw new Error(`Only a Pending commission can be edited (this one is ${c.status}).`);
  const type = payload.commission_type || c.commission_type;
  const value = payload.commission_value !== undefined && payload.commission_value !== '' ? Number(payload.commission_value) : c.commission_value;
  if (!(value >= 0)) throw new Error('Commission value cannot be negative.');
  if (type === 'Percentage' && value > 100) throw new Error('A percentage commission cannot be more than 100.');
  const base = db.prepare('SELECT total_price FROM bookings WHERE id = ?').get(c.booking_id).total_price || 0;
  db.prepare(
    `UPDATE commissions SET commission_type=?, commission_value=?, base_amount=?, commission_amount=?, notes=?, updated_at=datetime('now') WHERE id=?`
  ).run(type, value, base, calcAmount(type, value, base), payload.notes !== undefined ? payload.notes : c.notes, id);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Updated', 'commission', ?, ?)`).run(id, `Commission #${id} updated`);
  return { success: true };
}

function approve(id) {
  const db = getDb();
  const c = get(id);
  if (c.status !== 'Pending') throw new Error(`Only a Pending commission can be approved (this one is ${c.status}).`);
  if (!(c.commission_amount > 0)) throw new Error('A commission of zero cannot be approved.');
  db.prepare(`UPDATE commissions SET status='Approved', approved_date=datetime('now'), updated_at=datetime('now') WHERE id=?`).run(id);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Approved', 'commission', ?, ?)`).run(id, `Commission #${id} approved`);
  return { success: true };
}

/**
 * Pays an Approved commission: creates the Expense (and, through expenseService's normal path, the bank/cash
 * transaction) in one transaction. If anything fails, nothing is left half-done.
 */
function pay(id, payload = {}) {
  const db = getDb();
  const expenseService = require('./expenseService'); // lazy: expenseService guards call back into this module
  const c = get(id);
  if (c.status !== 'Approved') throw new Error(c.status === 'Paid' ? 'This commission has already been paid.' : `Only an Approved commission can be paid (this one is ${c.status}).`);
  const method = payload.payment_method || 'Bank Transfer';
  if (!PAYMENT_METHODS.includes(method)) throw new Error('Please select a valid payment method.');
  if (payload.account_type && !payload.account_id) throw new Error('Please select the account the commission is paid from.');
  if (payload.account_type) {
    const acc = accountService.get(payload.account_type, payload.account_id);
    if (acc.current_balance < c.commission_amount) throw new Error('The selected account does not have enough balance for this commission.');
  }
  const paidDate = (payload.paid_date || '').slice(0, 10) || db.prepare("SELECT date('now') AS d").get().d;

  const tx = db.transaction(() => {
    const categoryId = ensureCategory(db);
    const exp = expenseService.create({
      expense_date: paidDate,
      category_id: categoryId,
      description: `Agent commission - ${c.agent_code} ${c.agent_name} (${c.booking_code})`,
      amount: c.commission_amount,
      payment_method: method,
      related_booking_id: c.booking_id,
      notes: payload.notes || null,
      account_type: payload.account_type || null,
      account_id: payload.account_id || null
    });
    db.prepare(
      `UPDATE commissions SET status='Paid', paid_date=?, payment_method=?, account_type=?, account_id=?, expense_id=?, updated_at=datetime('now') WHERE id=?`
    ).run(paidDate, method, payload.account_type || null, payload.account_id || null, exp.id, id);
    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Paid', 'commission', ?, ?)`)
      .run(id, `Commission #${id} paid (${c.commission_amount}) via expense #${exp.id}`);
  });
  tx();
  return { success: true };
}

/** Undo a payment: removes the expense (which posts the account reversal) and puts the commission back to Approved. */
function reversePayment(id) {
  const db = getDb();
  const expenseService = require('./expenseService');
  const c = get(id);
  if (c.status !== 'Paid') throw new Error('Only a Paid commission has a payment to reverse.');
  const tx = db.transaction(() => {
    const expenseId = c.expense_id;
    db.prepare(`UPDATE commissions SET status='Approved', paid_date=NULL, payment_method=NULL, account_type=NULL, account_id=NULL, expense_id=NULL, updated_at=datetime('now') WHERE id=?`).run(id);
    if (expenseId) expenseService.remove(expenseId);
    db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Payment Reversed', 'commission', ?, ?)`).run(id, `Payment of commission #${id} reversed`);
  });
  tx();
  return { success: true };
}

function cancel(id) {
  const db = getDb();
  const c = get(id);
  if (c.status === 'Paid') throw new Error('A paid commission cannot be cancelled. Reverse the payment first.');
  if (c.status === 'Cancelled') throw new Error('This commission is already cancelled.');
  db.prepare(`UPDATE commissions SET status='Cancelled', updated_at=datetime('now') WHERE id=?`).run(id);
  db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Cancelled', 'commission', ?, ?)`).run(id, `Commission #${id} cancelled`);
  return { success: true };
}

/**
 * Called by bookingService after a booking is created or edited. Keeps one Pending commission in step with the
 * booking's agent: creates it, refreshes its amount when the price changed, replaces it when the agent changed,
 * and cancels open commissions when the booking is cancelled. It will never touch an Approved/Paid commission
 * - it refuses a change instead, so money already promised or paid cannot silently move.
 */
function syncForBooking(db, bookingId, { previousAgentId = null } = {}) {
  const b = db.prepare('SELECT id, agent_id, status, total_price, booking_code FROM bookings WHERE id = ?').get(bookingId);
  if (!b) return;
  const open = db.prepare(`SELECT * FROM commissions WHERE booking_id = ? AND status IN ('Pending','Approved','Paid')`).all(bookingId);

  if (b.status === 'Cancelled') {
    for (const c of open.filter((x) => x.status !== 'Paid')) {
      db.prepare(`UPDATE commissions SET status='Cancelled', updated_at=datetime('now') WHERE id=?`).run(c.id);
      db.prepare(`INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Commission Cancelled', 'commission', ?, ?)`).run(c.id, `Booking ${b.booking_code} cancelled`);
    }
    return;
  }

  const stale = open.filter((c) => c.agent_id !== b.agent_id);
  if (stale.some((c) => c.status !== 'Pending')) {
    throw new Error('The previous agent already has an approved or paid commission on this booking. Cancel or reverse that commission first before changing the agent.');
  }
  for (const c of stale) {
    db.prepare(`UPDATE commissions SET status='Cancelled', updated_at=datetime('now') WHERE id=?`).run(c.id);
  }
  if (!b.agent_id) return;

  const mine = open.find((c) => c.agent_id === b.agent_id);
  if (!mine) {
    createRow(db, { agentId: b.agent_id, bookingId });
  } else if (mine.status === 'Pending' && Number(mine.base_amount) !== Number(b.total_price || 0)) {
    const amount = calcAmount(mine.commission_type, mine.commission_value, b.total_price);
    db.prepare(`UPDATE commissions SET base_amount=?, commission_amount=?, updated_at=datetime('now') WHERE id=?`).run(Number(b.total_price || 0), amount, mine.id);
  }
}

/** Used by expenseService so an expense that IS a commission payment can't be edited/deleted behind the commission's back. */
function commissionForExpense(expenseId) {
  return getDb().prepare('SELECT id FROM commissions WHERE expense_id = ?').get(expenseId) || null;
}

module.exports = { STATUSES, PAYMENT_METHODS, CATEGORY_NAME, calcAmount, list, get, summary, create, update, approve, pay, reversePayment, cancel, syncForBooking, commissionForExpense };
