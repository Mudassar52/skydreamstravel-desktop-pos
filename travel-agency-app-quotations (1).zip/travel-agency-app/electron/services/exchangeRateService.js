const { getDb } = require('../../src/database/db');

/**
 * Exchange rates (Phase 21).
 *
 * Rates are typed in by an admin - nothing is hard-coded and nothing is
 * fetched from the internet. A row means: 1 unit of `from_currency` equals
 * `rate` units of `to_currency`, effective from `effective_date` until a
 * newer row for the same pair replaces it. Rows are added or deleted, never
 * edited, so an old conversion can always be explained from the history.
 *
 * Lookup order for a pair (from -> to) on a date:
 *   1. same currency                         -> 1
 *   2. direct row   from -> to               -> rate
 *   3. inverse row  to -> from               -> 1 / rate
 *   4. cross via the base currency           -> (from -> base) * (base -> to)
 * Anything else is "no rate": the caller is told so and nothing is guessed.
 */

const CODE = /^[A-Z]{3}$/;

function normCode(c) {
  return String(c || '').trim().toUpperCase();
}

function round(n, dp = 2) {
  const f = 10 ** dp;
  return Math.round((Number(n) + Number.EPSILON) * f) / f;
}

function getBaseCurrency() {
  const row = getDb().prepare("SELECT value FROM settings WHERE key = 'default_currency'").get();
  return normCode(row && row.value) || 'PKR';
}

function validate(payload) {
  const from = normCode(payload.from_currency);
  const to = normCode(payload.to_currency);
  if (!CODE.test(from) || !CODE.test(to)) throw new Error('Currencies must be 3-letter codes, for example USD and PKR.');
  if (from === to) throw new Error('From and To currency must be different.');
  const rate = Number(payload.rate);
  if (!Number.isFinite(rate) || !(rate > 0)) throw new Error('The rate must be a number greater than zero.');
  const date = String(payload.effective_date || '').slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))) throw new Error('A valid effective date is required.');
  return { from, to, rate, date };
}

function list({ fromCurrency = null, toCurrency = null } = {}) {
  const db = getDb();
  const cond = [];
  const params = {};
  if (fromCurrency) { cond.push('from_currency = @f'); params.f = normCode(fromCurrency); }
  if (toCurrency) { cond.push('to_currency = @t'); params.t = normCode(toCurrency); }
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';
  return db.prepare(
    `SELECT r.*, u.full_name AS created_by_name FROM exchange_rates r LEFT JOIN users u ON u.id = r.created_by
     ${where} ORDER BY r.from_currency, r.to_currency, r.effective_date DESC, r.id DESC`
  ).all(params);
}

/** Latest rate for each pair as of today - what the "current rates" panel shows. */
function listCurrent(asOf = null) {
  const db = getDb();
  const date = asOf || db.prepare("SELECT date('now') AS d").get().d;
  return db.prepare(
    `SELECT r.* FROM exchange_rates r
     WHERE r.effective_date <= @d
       AND r.id = (SELECT r2.id FROM exchange_rates r2
                   WHERE r2.from_currency = r.from_currency AND r2.to_currency = r.to_currency AND r2.effective_date <= @d
                   ORDER BY r2.effective_date DESC, r2.id DESC LIMIT 1)
     ORDER BY r.from_currency, r.to_currency`
  ).all({ d: date });
}

function create(payload) {
  const { from, to, rate, date } = validate(payload);
  const db = getDb();
  const dup = db.prepare('SELECT id FROM exchange_rates WHERE from_currency = ? AND to_currency = ? AND effective_date = ?').get(from, to, date);
  if (dup) throw new Error(`A ${from} to ${to} rate already exists for ${date}. Delete it first, or use a different effective date.`);
  const result = db.prepare(
    `INSERT INTO exchange_rates (from_currency, to_currency, rate, effective_date, notes, created_by)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(from, to, rate, date, payload.notes || null, payload.created_by || null);
  db.prepare(
    `INSERT INTO audit_logs (user_id, action, record_type, record_id, description) VALUES (?, 'Exchange Rate Added', 'exchange_rate', ?, ?)`
  ).run(payload.created_by || null, result.lastInsertRowid, `1 ${from} = ${rate} ${to} from ${date}`);
  return { id: result.lastInsertRowid };
}

function remove(id, actingUserId = null) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM exchange_rates WHERE id = ?').get(id);
  if (!row) throw new Error('Exchange rate not found.');
  db.prepare('DELETE FROM exchange_rates WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (user_id, action, record_type, record_id, description) VALUES (?, 'Exchange Rate Deleted', 'exchange_rate', ?, ?)`
  ).run(actingUserId, id, `Removed 1 ${row.from_currency} = ${row.rate} ${row.to_currency} (from ${row.effective_date})`);
  return { success: true };
}

function directRate(db, from, to, date) {
  const row = db.prepare(
    `SELECT rate FROM exchange_rates WHERE from_currency = ? AND to_currency = ? AND effective_date <= ?
     ORDER BY effective_date DESC, id DESC LIMIT 1`
  ).get(from, to, date);
  return row ? row.rate : null;
}

function pairRate(db, from, to, date) {
  const d = directRate(db, from, to, date);
  if (d !== null) return d;
  const inv = directRate(db, to, from, date);
  if (inv !== null) return 1 / inv;
  return null;
}

/**
 * Rate to turn 1 `from` into `to` on `date` (default today).
 * Returns { rate, source } or null when no usable rate exists.
 */
function getRate(from, to, date = null) {
  const db = getDb();
  const f = normCode(from);
  const t = normCode(to);
  if (!f || !t) return null;
  if (f === t) return { rate: 1, source: 'same' };
  const d = (date ? String(date).slice(0, 10) : db.prepare("SELECT date('now') AS d").get().d);
  const direct = pairRate(db, f, t, d);
  if (direct !== null) return { rate: direct, source: 'direct' };
  const base = getBaseCurrency();
  if (f !== base && t !== base) {
    const a = pairRate(db, f, base, d);
    const b = pairRate(db, base, t, d);
    if (a !== null && b !== null) return { rate: a * b, source: `via ${base}` };
  }
  return null;
}

/** convert(100, 'USD', 'PKR') -> { amount, rate, converted: true } | { amount: null, rate: null, converted: false } */
function convert(amount, from, to, date = null) {
  const r = getRate(from, to, date);
  if (!r) return { amount: null, rate: null, converted: false };
  return { amount: round(Number(amount || 0) * r.rate), rate: r.rate, converted: true };
}

/**
 * Sums amounts held in several currencies into one currency.
 * items: [{ currency, amount }, ...]. Returns the converted total plus the list
 * of currencies that had no rate (those are left OUT of the total, never guessed).
 */
function convertTotals(items, toCurrency = null, date = null) {
  const target = normCode(toCurrency) || getBaseCurrency();
  let total = 0;
  const missing = [];
  const used = [];
  for (const it of items) {
    const cur = normCode(it.currency) || target;
    const r = getRate(cur, target, date);
    if (!r) {
      if (!missing.includes(cur)) missing.push(cur);
      continue;
    }
    total += Number(it.amount || 0) * r.rate;
    used.push({ currency: cur, rate: r.rate });
  }
  return { currency: target, total: round(total), complete: missing.length === 0, missing, rates: used };
}

module.exports = { getBaseCurrency, list, listCurrent, create, remove, getRate, convert, convertTotals, round };
