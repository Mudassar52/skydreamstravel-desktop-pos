const { getDb } = require('../../src/database/db');

// Shared validation helpers (master prompt section 47: valid dates, valid
// currency, positive amounts, records linked to something real, useful
// messages). Each helper throws an Error with a human-readable message - the
// IPC layer's safe() wrapper already turns that into { ok:false, error } for
// the UI to show, so callers just call the helper and move on.

const ISO_DATE = /^\d{4}-\d{2}-\d{2}/;

/** True for a real calendar date in YYYY-MM-DD (a trailing time part is fine). 2026-02-30 is rejected. */
function isValidDate(value) {
  if (typeof value !== 'string' || !ISO_DATE.test(value)) return false;
  const [y, m, d] = value.slice(0, 10).split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

/** Optional date: blank/null is fine, anything else must be a real date. */
function assertValidDate(value, label = 'Date') {
  if (value === undefined || value === null || value === '') return;
  if (!isValidDate(value)) throw new Error(`${label} is not a valid date (use YYYY-MM-DD).`);
}

/** Optional from/to pair: each must be a real date, and from must not be after to. */
function assertDateRange(from, to, labels = ['Start date', 'End date']) {
  assertValidDate(from, labels[0]);
  assertValidDate(to, labels[1]);
  if (from && to && String(from).slice(0, 10) > String(to).slice(0, 10)) {
    throw new Error(`${labels[0]} cannot be after ${labels[1].toLowerCase()}.`);
  }
}

let currencySet = null;
function knownCurrencies() {
  if (currencySet) return currencySet;
  try {
    currencySet = new Set(Intl.supportedValuesOf('currency'));
  } catch (_) {
    currencySet = null; // very old runtime - fall back to a shape check below
  }
  return currencySet;
}

/** Optional currency: blank is fine (callers apply their own default); otherwise a real ISO 4217 code. */
function assertValidCurrency(value, label = 'Currency') {
  if (value === undefined || value === null || value === '') return;
  const code = String(value).trim().toUpperCase();
  const set = knownCurrencies();
  const ok = set ? set.has(code) : /^[A-Z]{3}$/.test(code);
  if (!ok) throw new Error(`${label} "${value}" is not a valid currency code (e.g. PKR, USD, SAR).`);
}

/** A non-negative number (blank counts as 0). */
function assertNonNegative(value, label) {
  if (value === undefined || value === null || value === '') return;
  const n = Number(value);
  if (Number.isNaN(n) || n < 0) throw new Error(`${label} must be zero or greater.`);
}

/** An optional foreign key that, when given, must point at a real row - gives a useful message instead of "FOREIGN KEY constraint failed". */
function assertRecordExists(table, id, label) {
  if (id === undefined || id === null || id === '') return;
  const row = getDb().prepare(`SELECT id FROM ${table} WHERE id = ?`).get(id);
  if (!row) throw new Error(`Selected ${label} does not exist.`);
}

module.exports = { isValidDate, assertValidDate, assertDateRange, assertValidCurrency, assertNonNegative, assertRecordExists };
