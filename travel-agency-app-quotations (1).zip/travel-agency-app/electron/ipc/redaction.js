/**
 * Response filtering in the main process (Phase 21b).
 *
 * accessControl.js decides whether a call may run. This decides what a permitted call may SEE:
 *   - profit/cost figures inside the Customer, Booking and Package dossiers and the Quotation list/form are blanked (set to null) unless the
 *     user's role has the View Profit capability; the Booking dossier's supplier-cost ledger needs View Supplier Costs;
 *   - global search drops every result group the user has no View permission for.
 * Done on the response, so no renderer (or a call made some other way) ever receives the figures.
 * Revenue, paid and outstanding amounts are NOT touched - only cost and profit.
 */

const PROFIT_KEYS = new Set([
  'cost', 'cost_source', 'cost_actual', 'cost_estimated', 'profit', 'gross_profit', 'total_cost', 'cost_breakdown', 'margin_percent',
  'estimated_cost', 'estimated_profit', 'estimated_margin_percent', 'estimated_profit_per_booking', 'actual_supplier_cost', 'actual_profit',
  'expenses', 'cost_price', 'expected_profit'
]);
const PROFIT_CHANNELS = new Set(['customer360:dossier', 'customer360:bookings', 'bookingDossier:get', 'package360:dossier', 'quotations:get', 'quotations:list']);

const SEARCH_MODULE = {
  Customer: 'customers', Traveller: 'travellers', Booking: 'bookings', Invoice: 'invoices', Supplier: 'suppliers',
  Payment: 'payments', Lead: 'leads', Flight: 'flights', Hotel: 'hotels'
};

function blank(node) {
  if (Array.isArray(node)) return node.map(blank);
  if (node && typeof node === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(node)) out[k] = PROFIT_KEYS.has(k) ? null : blank(v);
    return out;
  }
  return node;
}

const can = (user, m, a) => !!(user && user.permissions && user.permissions[m] && user.permissions[m][a]);
const cap = (user, c) => !!(user && user.capabilities && user.capabilities[c]);

/** `result` is the handler's {ok, data} envelope. Returns it unchanged when nothing needs hiding. */
function apply(channel, result, user) {
  if (!result || !result.ok || !result.data || !user) return result;
  let data = result.data;
  if (PROFIT_CHANNELS.has(channel) && !cap(user, 'view_profit')) data = blank(data);
  if (channel === 'bookingDossier:get' && !cap(user, 'view_supplier_costs')) data = { ...data, supplierCosts: null };
  if (channel === 'search:query' && data.groups) {
    data = { ...data, groups: data.groups.filter((g) => !SEARCH_MODULE[g.category] || can(user, SEARCH_MODULE[g.category], 'view')) };
  }
  return data === result.data ? result : { ...result, data };
}

module.exports = { apply, blank, PROFIT_KEYS };
