const { ipcMain: electronIpc } = require('electron');
const accessControl = require('./accessControl');
const sessionService = require('../services/sessionService');
const redaction = require('./redaction');

// Every channel goes through the permission guard BEFORE its handler runs (Phase 21): the signed-in user is held in
// the main process (sessionService), and accessControl decides from the channel name + that user's live permissions.
const ipcMain = {
  handle(channel, listener) {
    electronIpc.handle(channel, async (event, ...args) => {
      let user = null;
      try { user = sessionService.current(); } catch (_) { user = null; }
      const denial = accessControl.authorize(channel, args, user);
      if (denial) return { ok: false, error: denial };
      return redaction.apply(channel, await listener(event, ...args), user);
    });
  }
};
const dashboardService = require('../services/dashboardService');
const authService = require('../services/authService');
const customerService = require('../services/customerService');
const umrahService = require('../services/umrahService');
const hajjService = require('../services/hajjService');
const tourService = require('../services/tourService');
const bookingService = require('../services/bookingService');
const flightService = require('../services/flightService');
const hotelService = require('../services/hotelService');
const visaService = require('../services/visaService');
const transportationService = require('../services/transportationService');
const invoiceTemplateService = require('../services/invoiceTemplateService');
const invoiceService = require('../services/invoiceService');
const pdfService = require('../services/pdfService');
const paymentService = require('../services/paymentService');
const ledgerService = require('../services/ledgerService');
const expenseService = require('../services/expenseService');
const profitService = require('../services/profitService');
const documentService = require('../services/documentService');
const reportService = require('../services/reportService');
const exportService = require('../services/exportService');
const customReportService = require('../services/customReportService');
const reportHistoryService = require('../services/reportHistoryService');
const reportTemplateService = require('../services/reportTemplateService');
const excelExportService = require('../services/excelExportService');
const settingsService = require('../services/settingsService');
const backupService = require('../services/backupService');
const auditLogService = require('../services/auditLogService');
const supplierService = require('../services/supplierService');
const supplierLedgerService = require('../services/supplierLedgerService');
const supplierInvoiceService = require('../services/supplierInvoiceService');
const supplierPaymentService = require('../services/supplierPaymentService');
const supplierReportService = require('../services/supplierReportService');
const leadService = require('../services/leadService');
const travellerService = require('../services/travellerService');
const followUpService = require('../services/followUpService');
const quotationService = require('../services/quotationService');
const packageService = require('../services/packageService');
const otherServiceService = require('../services/otherServiceService');
const taskService = require('../services/taskService');
const deadlineService = require('../services/deadlineService');
const calendarService = require('../services/calendarService');
const customer360Service = require('../services/customer360Service');
const supplier360Service = require('../services/supplier360Service');
const package360Service = require('../services/package360Service');
const bookingDossierService = require('../services/bookingDossierService');
const voucherService = require('../services/voucherService');
const advanceService = require('../services/advanceService');
const supplierAdvanceService = require('../services/supplierAdvanceService');

// Wraps a handler so thrown Error messages reach the renderer as readable
// text instead of an opaque "Error invoking remote method" string.
function safe(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (err) {
      return { ok: false, error: err.message || 'Something went wrong.' };
    }
  };
}

/**
 * Registers all IPC handlers. As each phase adds a service
 * (customerService, bookingService, invoiceService, ...), require it
 * here and add its channels. Keep one channel per action, namespaced
 * by module, e.g. 'customers:list', 'customers:create'.
 */
function registerIpcHandlers() {
  ipcMain.handle('dashboard:getStats', safe((_e, range) => dashboardService.getStats(range)));
  ipcMain.handle('dashboard:getMonthlyFinancials', safe(() => dashboardService.getMonthlyFinancials()));

  ipcMain.handle('dashboard:getActionRequired', safe(() => dashboardService.getActionRequired()));
  ipcMain.handle('dashboard:getCharts', safe((_e, range) => dashboardService.getCharts(range)));
  ipcMain.handle('dashboard:getUpcomingPanels', safe(() => dashboardService.getUpcomingPanels()));
  ipcMain.handle('dashboard:getOperationsPanels', safe(() => dashboardService.getOperationsPanels()));
  ipcMain.handle('dashboard:getCalendarEvents', safe((_e, year, month) => dashboardService.getCalendarEvents(year, month)));

  // ---- Global Search (Phase 19) -------------------------------------------------
  const searchService = require('../services/searchService');
  ipcMain.handle('search:query', safe((_e, query) => searchService.search(query)));

  // ---- Notifications (Phase 19) -------------------------------------------------
  const notificationService = require('../services/notificationService');
  ipcMain.handle('notifications:list', safe((_e, params) => notificationService.list(params)));
  ipcMain.handle('notifications:unreadCount', safe(() => notificationService.unreadCount()));
  ipcMain.handle('notifications:markRead', safe((_e, id) => notificationService.markRead(id)));
  ipcMain.handle('notifications:markAllRead', safe(() => notificationService.markAllRead()));
  ipcMain.handle('notifications:generate', safe(() => notificationService.generate()));

  // ---- Saved Filters (Phase 19) -------------------------------------------------
  const savedFilterService = require('../services/savedFilterService');
  ipcMain.handle('savedFilters:list', safe((_e, module) => savedFilterService.list(module)));
  ipcMain.handle('savedFilters:create', safe((_e, payload) => savedFilterService.create(payload)));
  ipcMain.handle('savedFilters:delete', safe((_e, id) => savedFilterService.remove(id)));

  // ---- Auth (Phase 3) -----------------------------------------------
  ipcMain.handle('auth:login', safe((_event, username, password) => {
    const user = authService.login(username, password);
    sessionService.signIn(user.id);
    return user;
  }));
  ipcMain.handle('auth:logout', safe(() => { sessionService.signOut(); return { success: true }; }));

  // ---- Users (Phase 3) ------------------------------------------------
  ipcMain.handle('users:list', safe(() => authService.listUsers()));
  ipcMain.handle('users:create', safe((_event, payload) => authService.createUser(payload)));
  ipcMain.handle('users:update', safe((_event, id, payload) => authService.updateUser(id, payload)));
  ipcMain.handle('users:resetPassword', safe((_event, id, newPassword) => authService.resetPassword(id, newPassword)));

  // ---- Roles & Permissions (Phase 3) -----------------------------------
  ipcMain.handle('roles:list', safe(() => authService.getRoles()));
  ipcMain.handle('permissions:getMatrix', safe(() => authService.getPermissionsMatrix()));
  ipcMain.handle('permissions:update', safe((_event, payload) => authService.updatePermission({ ...payload, actingUserId: (sessionService.current() || {}).id || null })));
  ipcMain.handle('capabilities:getMatrix', safe(() => authService.getCapabilitiesMatrix()));
  ipcMain.handle('capabilities:update', safe((_event, payload) => authService.updateCapability({ ...payload, actingUserId: (sessionService.current() || {}).id || null })));

  // ---- Customer 360 (ERP upgrade, Phase 2) ------------------------------
  ipcMain.handle('customer360:dossier', safe((_event, id, opts) => customer360Service.getDossier(id, opts)));
  ipcMain.handle('customer360:bookings', safe((_event, id, opts) => customer360Service.bookingHistory(id, opts)));
  ipcMain.handle('customer360:timeline', safe((_event, id, opts) => customer360Service.timeline(id, opts)));

  // ---- Supplier 360 + Package 360 (ERP upgrade, Phase 3) ----------------
  ipcMain.handle('supplier360:dossier', safe((_e, id) => supplier360Service.getDossier(id)));
  ipcMain.handle('supplier360:services', safe((_e, id, opts) => supplier360Service.serviceUsage(id, opts)));
  ipcMain.handle('supplier360:bookings', safe((_e, id) => supplier360Service.bookings(id)));
  ipcMain.handle('supplier360:invoices', safe((_e, id) => supplier360Service.invoices(id)));
  ipcMain.handle('supplier360:payments', safe((_e, id) => supplier360Service.payments(id)));
  ipcMain.handle('supplier360:timeline', safe((_e, id, opts) => supplier360Service.timeline(id, opts)));
  ipcMain.handle('package360:dossier', safe((_e, id) => package360Service.getDossier(id)));

  // ---- Booking 360 + Vouchers (ERP upgrade, Phase 4) ---------------------
  ipcMain.handle('bookingDossier:get', safe((_e, id) => bookingDossierService.getDossier(id)));
  ipcMain.handle('vouchers:available', safe((_e, bookingId) => voucherService.availableVouchers(bookingId)));
  ipcMain.handle('vouchers:hotel:preview', safe((_e, bookingId, hotelId) => voucherService.buildHotelVoucherHtml(bookingId, hotelId).html));
  ipcMain.handle('vouchers:hotel:print', safe(async (_e, bookingId, hotelId) => {
    const { html } = voucherService.buildHotelVoucherHtml(bookingId, hotelId);
    return pdfService.printHtml(html);
  }));
  ipcMain.handle('vouchers:hotel:pdf', safe(async (_e, bookingId, hotelId) => {
    const { html, suggestedName } = voucherService.buildHotelVoucherHtml(bookingId, hotelId);
    return pdfService.savePdf(html, suggestedName, 'Save Hotel Voucher');
  }));
  ipcMain.handle('vouchers:transport:preview', safe((_e, bookingId, transportId) => voucherService.buildTransportVoucherHtml(bookingId, transportId).html));
  ipcMain.handle('vouchers:transport:print', safe(async (_e, bookingId, transportId) => {
    const { html } = voucherService.buildTransportVoucherHtml(bookingId, transportId);
    return pdfService.printHtml(html);
  }));
  ipcMain.handle('vouchers:transport:pdf', safe(async (_e, bookingId, transportId) => {
    const { html, suggestedName } = voucherService.buildTransportVoucherHtml(bookingId, transportId);
    return pdfService.savePdf(html, suggestedName, 'Save Transport Voucher');
  }));

  // ---- Custom Report Builder (ERP upgrade, Phase 6) ----------------------
  ipcMain.handle('customReports:meta', safe(() => ({
    types: customReportService.listReportTypes(),
    serviceTypes: customReportService.listServiceTypes(),
    opsTypes: customReportService.listTravelOpsTypes()
  })));
  ipcMain.handle('customReports:dateFields', safe((_e, reportType) => customReportService.listDateFields(reportType)));
  ipcMain.handle('customReports:sections', safe((_e, reportType) => customReportService.listSections(reportType)));
  ipcMain.handle('customReports:run', safe((_e, spec) => customReportService.run(spec)));
  ipcMain.handle('customReports:exportPdf', safe(async (_e, reportData) => exportService.exportMultiSectionPdf(reportData)));
  ipcMain.handle('customReports:print', safe(async (_e, reportData) => exportService.printMultiSectionReport(reportData)));
  ipcMain.handle('customReports:exportCsv', safe(async (_e, reportData) => exportService.exportCsv(reportData)));

  // Shared report export endpoints (ERP upgrade, Phase 7): generic so the
  // Custom Report Builder, Ledger/Supplier Ledger, and the Customer/Supplier/
  // Booking/Package 360 dossiers can all save a real multi-sheet .xlsx, a
  // one-document multi-section PDF, or print, without each page needing its
  // own export plumbing.
  ipcMain.handle('reportExport:exportExcel', safe(async (_e, sheets, suggestedName) => excelExportService.saveWorkbook(sheets, suggestedName)));
  ipcMain.handle('reportExport:exportPdf', safe(async (_e, reportData) => exportService.exportMultiSectionPdf(reportData)));
  ipcMain.handle('reportExport:print', safe(async (_e, reportData) => exportService.printMultiSectionReport(reportData)));

  ipcMain.handle('reportHistory:record', safe((_e, payload) => reportHistoryService.record(payload)));
  ipcMain.handle('reportHistory:list', safe((_e, params) => reportHistoryService.list(params)));
  ipcMain.handle('reportHistory:get', safe((_e, id) => reportHistoryService.get(id)));
  ipcMain.handle('reportHistory:regenerate', safe((_e, id) => reportHistoryService.regenerate(id)));
  ipcMain.handle('reportHistory:remove', safe((_e, id) => reportHistoryService.remove(id)));

  ipcMain.handle('reportTemplates:create', safe((_e, payload) => reportTemplateService.create(payload)));
  ipcMain.handle('reportTemplates:list', safe((_e, reportType) => reportTemplateService.list(reportType)));
  ipcMain.handle('reportTemplates:get', safe((_e, id) => reportTemplateService.get(id)));
  ipcMain.handle('reportTemplates:remove', safe((_e, id) => reportTemplateService.remove(id)));

  // ---- Customers (Phase 4) ---------------------------------------------
  ipcMain.handle('customers:list', safe((_event, params) => customerService.list(params)));
  ipcMain.handle('customers:get', safe((_event, id) => customerService.get(id)));
  ipcMain.handle('customers:create', safe((_event, payload) => customerService.create(payload)));
  ipcMain.handle('customers:update', safe((_event, id, payload) => customerService.update(id, payload)));
  ipcMain.handle('customers:delete', safe((_event, id) => customerService.remove(id)));

  // Phase 5+: umrah/hajj/tours, bookings, etc.

  // ---- Umrah (Phase 5) --------------------------------------------------
  ipcMain.handle('umrah:packages:list', safe(() => umrahService.packages.list()));
  ipcMain.handle('umrah:packages:get', safe((_e, id) => umrahService.packages.get(id)));
  ipcMain.handle('umrah:packages:create', safe((_e, payload) => umrahService.packages.create(payload)));
  ipcMain.handle('umrah:packages:update', safe((_e, id, payload) => umrahService.packages.update(id, payload)));
  ipcMain.handle('umrah:packages:delete', safe((_e, id) => umrahService.packages.remove(id)));

  ipcMain.handle('umrah:groups:list', safe(() => umrahService.groups.list()));
  ipcMain.handle('umrah:groups:get', safe((_e, id) => umrahService.groups.get(id)));
  ipcMain.handle('umrah:groups:create', safe((_e, payload) => umrahService.groups.create(payload)));
  ipcMain.handle('umrah:groups:update', safe((_e, id, payload) => umrahService.groups.update(id, payload)));
  ipcMain.handle('umrah:groups:delete', safe((_e, id) => umrahService.groups.remove(id)));
  ipcMain.handle('umrah:groups:passengers:list', safe((_e, groupId) => umrahService.passengers.list(groupId)));
  ipcMain.handle('umrah:groups:passengers:add', safe((_e, groupId, customerId, notes) => umrahService.passengers.add(groupId, customerId, notes)));
  ipcMain.handle('umrah:groups:passengers:remove', safe((_e, membershipId, groupId) => umrahService.passengers.remove(membershipId, groupId)));

  // ---- Hajj (Phase 5) ----------------------------------------------------
  ipcMain.handle('hajj:packages:list', safe(() => hajjService.packages.list()));
  ipcMain.handle('hajj:packages:get', safe((_e, id) => hajjService.packages.get(id)));
  ipcMain.handle('hajj:packages:create', safe((_e, payload) => hajjService.packages.create(payload)));
  ipcMain.handle('hajj:packages:update', safe((_e, id, payload) => hajjService.packages.update(id, payload)));
  ipcMain.handle('hajj:packages:delete', safe((_e, id) => hajjService.packages.remove(id)));

  ipcMain.handle('hajj:groups:list', safe(() => hajjService.groups.list()));
  ipcMain.handle('hajj:groups:get', safe((_e, id) => hajjService.groups.get(id)));
  ipcMain.handle('hajj:groups:create', safe((_e, payload) => hajjService.groups.create(payload)));
  ipcMain.handle('hajj:groups:update', safe((_e, id, payload) => hajjService.groups.update(id, payload)));
  ipcMain.handle('hajj:groups:delete', safe((_e, id) => hajjService.groups.remove(id)));
  ipcMain.handle('hajj:groups:pilgrims:list', safe((_e, groupId) => hajjService.pilgrims.list(groupId)));
  ipcMain.handle('hajj:groups:pilgrims:add', safe((_e, groupId, customerId, notes) => hajjService.pilgrims.add(groupId, customerId, notes)));
  ipcMain.handle('hajj:groups:pilgrims:remove', safe((_e, membershipId, groupId) => hajjService.pilgrims.remove(membershipId, groupId)));

  // ---- Tours (Phase 5) ----------------------------------------------------
  ipcMain.handle('tours:list', safe(() => tourService.list()));
  ipcMain.handle('tours:get', safe((_e, id) => tourService.get(id)));
  ipcMain.handle('tours:create', safe((_e, payload) => tourService.create(payload)));
  ipcMain.handle('tours:update', safe((_e, id, payload) => tourService.update(id, payload)));
  ipcMain.handle('tours:delete', safe((_e, id) => tourService.remove(id)));
  ipcMain.handle('tours:passengers:list', safe((_e, tourId) => tourService.passengers.list(tourId)));
  ipcMain.handle('tours:passengers:add', safe((_e, tourId, customerId, notes) => tourService.passengers.add(tourId, customerId, notes)));
  ipcMain.handle('tours:passengers:remove', safe((_e, membershipId, tourId) => tourService.passengers.remove(membershipId, tourId)));

  // ---- Bookings (Phase 6) -------------------------------------------------
  ipcMain.handle('bookings:list', safe((_e, params) => bookingService.list(params)));
  ipcMain.handle('bookings:get', safe((_e, id) => bookingService.get(id)));
  ipcMain.handle('bookings:listByCustomer', safe((_e, customerId) => bookingService.listByCustomer(customerId)));
  ipcMain.handle('bookings:create', safe((_e, payload) => bookingService.create(payload)));
  ipcMain.handle('bookings:update', safe((_e, id, payload) => bookingService.update(id, payload)));
  ipcMain.handle('bookings:delete', safe((_e, id) => bookingService.remove(id)));
  ipcMain.handle('bookings:referenceOptions', safe((_e, type) => bookingService.getReferenceOptions(type)));
  ipcMain.handle('bookings:packageOptions', safe((_e, packageType) => bookingService.packageOptions(packageType)));
  ipcMain.handle('bookings:passengers:list', safe((_e, bookingId) => bookingService.passengers.list(bookingId)));
  ipcMain.handle('bookings:passengers:add', safe((_e, bookingId, customerId, notes) => bookingService.passengers.add(bookingId, customerId, notes)));
  ipcMain.handle('bookings:passengers:remove', safe((_e, membershipId, bookingId) => bookingService.passengers.remove(membershipId, bookingId)));
  ipcMain.handle('bookings:options', safe(() => bookingService.listOptions()));

  // ---- Flights (Phase 7) --------------------------------------------------
  ipcMain.handle('flights:list', safe((_e, params) => flightService.list(params)));
  ipcMain.handle('flights:get', safe((_e, id) => flightService.get(id)));
  ipcMain.handle('flights:create', safe((_e, payload) => flightService.create(payload)));
  ipcMain.handle('flights:update', safe((_e, id, payload) => flightService.update(id, payload)));
  ipcMain.handle('flights:delete', safe((_e, id) => flightService.remove(id)));
  ipcMain.handle('flights:passengers:list', safe((_e, flightId) => flightService.passengers.list(flightId)));
  ipcMain.handle('flights:passengers:add', safe((_e, flightId, customerId) => flightService.passengers.add(flightId, customerId)));
  ipcMain.handle('flights:passengers:remove', safe((_e, membershipId) => flightService.passengers.remove(membershipId)));
  ipcMain.handle('flights:travellers:list', safe((_e, flightId) => flightService.travellers.list(flightId)));
  ipcMain.handle('flights:travellers:add', safe((_e, flightId, travellerId) => flightService.travellers.add(flightId, travellerId)));
  ipcMain.handle('flights:travellers:addAll', safe((_e, flightId) => flightService.travellers.addAll(flightId)));
  ipcMain.handle('flights:travellers:remove', safe((_e, membershipId) => flightService.travellers.remove(membershipId)));
  ipcMain.handle('flights:listByBooking', safe((_e, bookingId) => flightService.listByBooking(bookingId)));

  // ---- Hotels (Phase 7) ----------------------------------------------------
  ipcMain.handle('hotels:list', safe((_e, params) => hotelService.list(params)));
  ipcMain.handle('hotels:get', safe((_e, id) => hotelService.get(id)));
  ipcMain.handle('hotels:create', safe((_e, payload) => hotelService.create(payload)));
  ipcMain.handle('hotels:update', safe((_e, id, payload) => hotelService.update(id, payload)));
  ipcMain.handle('hotels:delete', safe((_e, id) => hotelService.remove(id)));
  ipcMain.handle('hotels:guests:list', safe((_e, hotelId) => hotelService.guests.list(hotelId)));
  ipcMain.handle('hotels:guests:update', safe((_e, hotelId, guests) => hotelService.guests.save(hotelId, guests)));
  ipcMain.handle('hotels:listByBooking', safe((_e, bookingId) => hotelService.listByBooking(bookingId)));

  // ---- Visa (Phase 7) -------------------------------------------------------
  ipcMain.handle('visa:list', safe((_e, params) => visaService.list(params)));
  ipcMain.handle('visa:get', safe((_e, id) => visaService.get(id)));
  ipcMain.handle('visa:create', safe((_e, payload) => visaService.create(payload)));
  ipcMain.handle('visa:update', safe((_e, id, payload) => visaService.update(id, payload)));
  ipcMain.handle('visa:delete', safe((_e, id) => visaService.remove(id)));
  ipcMain.handle('visa:expiringSoon', safe((_e, days) => visaService.getExpiringSoon(days)));
  ipcMain.handle('visa:createForBooking', safe((_e, bookingId, options) => visaService.createForBooking(bookingId, options)));
  ipcMain.handle('visa:listByBooking', safe((_e, bookingId) => visaService.listByBooking(bookingId)));

  // ---- Transportation (Phase 7) ---------------------------------------------
  ipcMain.handle('transportation:list', safe((_e, params) => transportationService.list(params)));
  ipcMain.handle('transportation:get', safe((_e, id) => transportationService.get(id)));
  ipcMain.handle('transportation:create', safe((_e, payload) => transportationService.create(payload)));
  ipcMain.handle('transportation:update', safe((_e, id, payload) => transportationService.update(id, payload)));
  ipcMain.handle('transportation:delete', safe((_e, id) => transportationService.remove(id)));
  ipcMain.handle('transportation:listByBooking', safe((_e, bookingId) => transportationService.listByBooking(bookingId)));

  // ---- Invoice Templates (Phase 8) -----------------------------------------
  ipcMain.handle('invoiceTemplates:list', safe(() => invoiceTemplateService.list()));
  ipcMain.handle('invoiceTemplates:get', safe((_e, id) => invoiceTemplateService.get(id)));
  ipcMain.handle('invoiceTemplates:create', safe((_e, payload) => invoiceTemplateService.create(payload)));
  ipcMain.handle('invoiceTemplates:update', safe((_e, id, payload) => invoiceTemplateService.update(id, payload)));
  ipcMain.handle('invoiceTemplates:delete', safe((_e, id) => invoiceTemplateService.remove(id)));
  ipcMain.handle('invoiceTemplates:setDefault', safe((_e, id) => invoiceTemplateService.setDefault(id)));
  ipcMain.handle('invoiceTemplates:tokens', safe(() => invoiceTemplateService.AVAILABLE_TOKENS));

  // ---- Invoices (Phase 8) --------------------------------------------------
  ipcMain.handle('invoices:list', safe((_e, params) => invoiceService.list(params)));
  ipcMain.handle('invoices:get', safe((_e, id) => invoiceService.get(id)));
  ipcMain.handle('invoices:listByCustomer', safe((_e, customerId) => invoiceService.listByCustomer(customerId)));
  ipcMain.handle('invoices:listByBooking', safe((_e, bookingId) => invoiceService.listByBooking(bookingId)));
  ipcMain.handle('invoices:create', safe((_e, payload) => invoiceService.create(payload)));
  ipcMain.handle('invoices:update', safe((_e, id, payload) => invoiceService.update(id, payload)));
  ipcMain.handle('invoices:cancel', safe((_e, id) => invoiceService.cancel(id)));
  ipcMain.handle('invoices:delete', safe((_e, id) => invoiceService.remove(id)));
  ipcMain.handle('invoices:duplicate', safe((_e, id) => invoiceService.duplicate(id)));
  ipcMain.handle('invoices:createFromBooking', safe((_e, bookingId) => invoiceService.createFromBooking(bookingId)));
  ipcMain.handle('invoices:generatePdf', safe(async (_e, id) => {
    const html = invoiceService.buildInvoiceHtml(id);
    const invoice = invoiceService.get(id);
    return pdfService.saveInvoicePdf(html, `${invoice.invoice_number}.pdf`);
  }));
  // In-app preview: the exact HTML the PDF/print is made from, shown in a pane before saving or printing.
  ipcMain.handle('invoices:preview', safe((_e, id) => invoiceService.buildInvoiceHtml(id)));
  ipcMain.handle('invoices:print', safe(async (_e, id) => {
    const html = invoiceService.buildInvoiceHtml(id);
    return pdfService.printHtml(html);
  }));

  // ---- Payments (Phase 9) ---------------------------------------------------
  ipcMain.handle('payments:list', safe((_e, params) => paymentService.list(params)));
  ipcMain.handle('payments:get', safe((_e, id) => paymentService.get(id)));
  ipcMain.handle('payments:create', safe((_e, payload) => paymentService.create(payload)));
  ipcMain.handle('payments:void', safe((_e, id) => paymentService.remove(id)));
  ipcMain.handle('payments:listByBooking', safe((_e, bookingId) => paymentService.listByBooking(bookingId)));

  // ---- Customer Ledger (Phase 9) --------------------------------------------
  ipcMain.handle('ledger:list', safe((_e, customerId) => ledgerService.list(customerId)));
  ipcMain.handle('ledger:getBalance', safe((_e, customerId) => ledgerService.getBalance(customerId)));
  ipcMain.handle('ledger:filteredView', safe((_e, customerId, opts) => ledgerService.filteredView(customerId, opts)));
  ipcMain.handle('ledger:transactionTypes', safe((_e, customerId) => ledgerService.transactionTypes(customerId)));
  ipcMain.handle('ledger:exportPdf', safe(async (_e, reportData) => exportService.exportPdf(reportData)));
  ipcMain.handle('ledger:exportCsv', safe(async (_e, reportData) => exportService.exportCsv(reportData)));
  ipcMain.handle('ledger:print', safe(async (_e, reportData) => exportService.printReport(reportData)));

  ipcMain.handle('advances:available', safe((_e, customerId) => advanceService.availableAdvances(customerId)));
  ipcMain.handle('advances:listAll', safe((_e, params) => advanceService.listAll(params)));
  ipcMain.handle('advances:applicationsForInvoice', safe((_e, invoiceId) => advanceService.applicationsForInvoice(invoiceId)));
  ipcMain.handle('advances:applyToInvoice', safe((_e, payload) => advanceService.applyToInvoice(payload)));
  ipcMain.handle('advances:reverseApplication', safe((_e, applicationId) => advanceService.reverseApplication(applicationId)));
  ipcMain.handle('advances:summary', safe((_e, customerId) => advanceService.summary(customerId)));

  // ---- Expenses (Phase 10) --------------------------------------------------
  ipcMain.handle('expenses:categories:list', safe(() => expenseService.listCategories()));
  ipcMain.handle('expenses:categories:create', safe((_e, name) => expenseService.createCategory(name)));
  ipcMain.handle('expenses:categories:delete', safe((_e, id) => expenseService.removeCategory(id)));
  ipcMain.handle('expenses:list', safe((_e, params) => expenseService.list(params)));
  ipcMain.handle('expenses:get', safe((_e, id) => expenseService.get(id)));
  ipcMain.handle('expenses:create', safe((_e, payload) => expenseService.create(payload)));
  ipcMain.handle('expenses:update', safe((_e, id, payload) => expenseService.update(id, payload)));
  ipcMain.handle('expenses:delete', safe((_e, id) => expenseService.remove(id)));

  // ---- Profit (Phase 10/21) --------------------------------------------------
  ipcMain.handle('profit:getSummary', safe(() => profitService.getSummary()));
  ipcMain.handle('profit:getMonthly', safe((_e, months) => profitService.getMonthly(months)));
  ipcMain.handle('profit:getByBookingType', safe(() => profitService.getByBookingType()));
  ipcMain.handle('profit:getByCustomer', safe((_e, customerId) => profitService.getByCustomer(customerId)));
  ipcMain.handle('profit:getByBooking', safe((_e, bookingId) => profitService.getByBooking(bookingId)));

  // ---- Documents (Phase 11) --------------------------------------------------
  ipcMain.handle('documents:list', safe((_e, params) => documentService.list(params)));
  ipcMain.handle('documents:get', safe((_e, id) => documentService.get(id)));
  ipcMain.handle('documents:upload', safe((_e, payload) => documentService.upload(payload)));
  ipcMain.handle('documents:open', safe((_e, id) => documentService.openFile(id)));
  ipcMain.handle('documents:downloadAs', safe((_e, id) => documentService.downloadAs(id)));
  ipcMain.handle('documents:rename', safe((_e, id, newName) => documentService.rename(id, newName)));
  ipcMain.handle('documents:delete', safe((_e, id) => documentService.remove(id)));
  ipcMain.handle('documents:types', safe(() => documentService.DOCUMENT_TYPES));

  // ---- Reports (Phase 12) ---------------------------------------------------
  ipcMain.handle('reports:listTypes', safe(() => reportService.listReportTypes()));
  ipcMain.handle('reports:run', safe((_e, key, filters) => reportService.run(key, filters)));
  ipcMain.handle('reports:exportCsv', safe((_e, reportData) => exportService.exportCsv(reportData)));
  ipcMain.handle('reports:exportPdf', safe((_e, reportData) => exportService.exportPdf(reportData)));
  ipcMain.handle('reports:print', safe((_e, reportData) => exportService.printReport(reportData)));

  // ---- Settings (Phase 13) --------------------------------------------------
  ipcMain.handle('settings:getAll', safe(() => settingsService.getAll()));
  ipcMain.handle('settings:setMany', safe((_e, payload) => settingsService.setMany(payload)));
  ipcMain.handle('settings:uploadImage', safe((_e, fieldKey) => settingsService.uploadImage(fieldKey)));
  ipcMain.handle('settings:removeImage', safe((_e, fieldKey) => settingsService.removeImage(fieldKey)));

  // ---- Backup & Restore (Phase 14) ------------------------------------------
  ipcMain.handle('backup:create', safe(() => backupService.createBackup()));
  ipcMain.handle('backup:restore', safe(() => backupService.restoreBackup()));
  ipcMain.handle('backup:relaunch', safe(() => backupService.relaunchApp()));
  ipcMain.handle('backup:chooseFolder', safe(() => backupService.chooseBackupFolder()));
  ipcMain.handle('backup:getConfig', safe(() => backupService.getConfig()));
  ipcMain.handle('backup:setAutoEnabled', safe((_e, enabled) => backupService.setAutoBackupEnabled(enabled)));
  ipcMain.handle('backup:getInfo', safe(() => backupService.getBackupInfo()));

  // ---- Audit Log (Phase 15) --------------------------------------------------
  ipcMain.handle('auditLogs:list', safe((_e, params) => auditLogService.list(params)));
  ipcMain.handle('auditLogs:actions', safe(() => auditLogService.listDistinctActions()));
  ipcMain.handle('auditLogs:recordTypes', safe(() => auditLogService.listDistinctRecordTypes()));

  // ---- Suppliers (Phase 19) --------------------------------------------------
  ipcMain.handle('suppliers:list', safe((_e, params) => supplierService.list(params)));
  ipcMain.handle('suppliers:get', safe((_e, id) => supplierService.get(id)));
  ipcMain.handle('suppliers:create', safe((_e, payload) => supplierService.create(payload)));
  ipcMain.handle('suppliers:update', safe((_e, id, payload) => supplierService.update(id, payload)));
  ipcMain.handle('suppliers:delete', safe((_e, id) => supplierService.remove(id)));
  ipcMain.handle('suppliers:options', safe(() => supplierService.options()));
  ipcMain.handle('suppliers:serviceTypes', safe(() => supplierService.SERVICE_TYPES));

  // ---- Supplier Ledger (Phase 19) ---------------------------------------------
  ipcMain.handle('supplierLedger:list', safe((_e, supplierId) => supplierLedgerService.list(supplierId)));
  ipcMain.handle('supplierLedger:getBalance', safe((_e, supplierId) => supplierLedgerService.getBalance(supplierId)));
  ipcMain.handle('supplierLedger:filteredView', safe((_e, supplierId, opts) => supplierLedgerService.filteredView(supplierId, opts)));
  ipcMain.handle('supplierLedger:transactionTypes', safe((_e, supplierId) => supplierLedgerService.transactionTypes(supplierId)));
  ipcMain.handle('supplierLedger:exportPdf', safe(async (_e, reportData) => exportService.exportPdf(reportData)));
  ipcMain.handle('supplierLedger:exportCsv', safe(async (_e, reportData) => exportService.exportCsv(reportData)));
  ipcMain.handle('supplierLedger:print', safe(async (_e, reportData) => exportService.printReport(reportData)));

  ipcMain.handle('supplierAdvances:available', safe((_e, supplierId) => supplierAdvanceService.availableAdvances(supplierId)));
  ipcMain.handle('supplierAdvances:listAll', safe((_e, params) => supplierAdvanceService.listAll(params)));
  ipcMain.handle('supplierAdvances:applicationsForInvoice', safe((_e, invoiceId) => supplierAdvanceService.applicationsForInvoice(invoiceId)));
  ipcMain.handle('supplierAdvances:applyToInvoice', safe((_e, payload) => supplierAdvanceService.applyToInvoice(payload)));
  ipcMain.handle('supplierAdvances:reverseApplication', safe((_e, applicationId) => supplierAdvanceService.reverseApplication(applicationId)));
  ipcMain.handle('supplierAdvances:summary', safe((_e, supplierId) => supplierAdvanceService.summary(supplierId)));

  // ---- Supplier Invoices (Phase 19) -------------------------------------------
  ipcMain.handle('supplierInvoices:list', safe((_e, params) => supplierInvoiceService.list(params)));
  ipcMain.handle('supplierInvoices:get', safe((_e, id) => supplierInvoiceService.get(id)));
  ipcMain.handle('supplierInvoices:listByBooking', safe((_e, bookingId) => supplierInvoiceService.listByBooking(bookingId)));
  ipcMain.handle('supplierInvoices:create', safe((_e, payload) => supplierInvoiceService.create(payload)));
  ipcMain.handle('supplierInvoices:delete', safe((_e, id) => supplierInvoiceService.remove(id)));

  // ---- Supplier Payments (Phase 19) -------------------------------------------
  ipcMain.handle('supplierPayments:list', safe((_e, params) => supplierPaymentService.list(params)));
  ipcMain.handle('supplierPayments:create', safe((_e, payload) => supplierPaymentService.create(payload)));
  ipcMain.handle('supplierPayments:void', safe((_e, id) => supplierPaymentService.remove(id)));
  ipcMain.handle('supplierPayments:methods', safe(() => supplierPaymentService.PAYMENT_METHODS));

  // ---- Supplier Reports (Phase 19) --------------------------------------------
  ipcMain.handle('supplierReports:listTypes', safe(() => supplierReportService.listReportTypes()));
  ipcMain.handle('supplierReports:run', safe((_e, key, filters) => supplierReportService.run(key, filters)));
  ipcMain.handle('supplierReports:exportCsv', safe((_e, reportData) => exportService.exportCsv(reportData)));
  ipcMain.handle('supplierReports:exportPdf', safe((_e, reportData) => exportService.exportPdf(reportData)));
  ipcMain.handle('supplierReports:print', safe((_e, reportData) => exportService.printReport(reportData)));

  // ---- Bank & Cash Accounts (Phase 19 Finance - full module) -----------------
  const accountService = require('../services/accountService');
  ipcMain.handle('bankAccounts:list', safe((_e, opts) => accountService.listBank(opts)));
  ipcMain.handle('cashAccounts:list', safe((_e, opts) => accountService.listCash(opts)));
  ipcMain.handle('accounts:get', safe((_e, type, id) => accountService.get(type, id)));
  ipcMain.handle('accounts:create', safe((_e, type, payload) => accountService.create(type, payload)));
  ipcMain.handle('accounts:update', safe((_e, type, id, payload) => accountService.update(type, id, payload)));
  ipcMain.handle('accounts:delete', safe((_e, type, id) => accountService.remove(type, id)));
  ipcMain.handle('accounts:deposit', safe((_e, payload) => accountService.manualDeposit(payload)));
  ipcMain.handle('accounts:withdraw', safe((_e, payload) => accountService.manualWithdrawal(payload)));
  ipcMain.handle('accounts:transfer', safe((_e, payload) => accountService.transfer(payload)));

  // ---- Refunds (Phase 19 Finance) ---------------------------------------------
  const refundService = require('../services/refundService');
  ipcMain.handle('refunds:list', safe((_e, params) => refundService.list(params)));
  ipcMain.handle('refunds:create', safe((_e, payload) => refundService.create(payload)));
  ipcMain.handle('refunds:delete', safe((_e, id) => refundService.remove(id)));

  // ---- Accounting (Phase 19 Finance) -------------------------------------------
  const accountingService = require('../services/accountingService');
  ipcMain.handle('accounting:list', safe((_e, params) => accountingService.list(params)));
  ipcMain.handle('accounting:listAccounts', safe(() => accountingService.listAccounts()));
  ipcMain.handle('accounting:summary', safe((_e, params) => accountingService.summary(params)));
  ipcMain.handle('accounting:create', safe((_e, payload) => accountingService.create(payload)));
  ipcMain.handle('accounting:reverse', safe((_e, id) => accountingService.reverse(id)));

  // ---- Leads (Phase 19 CRM) ----------------------------------------------------
  ipcMain.handle('leads:list', safe((_e, params) => leadService.list(params)));
  ipcMain.handle('leads:pipeline', safe(() => leadService.pipeline()));
  ipcMain.handle('leads:get', safe((_e, id) => leadService.get(id)));
  ipcMain.handle('leads:create', safe((_e, payload) => leadService.create(payload)));
  ipcMain.handle('leads:update', safe((_e, id, payload) => leadService.update(id, payload)));
  ipcMain.handle('leads:addNote', safe((_e, id, note) => leadService.addNote(id, note)));
  ipcMain.handle('leads:convertToCustomer', safe((_e, id) => leadService.convertToCustomer(id)));
  ipcMain.handle('leads:delete', safe((_e, id) => leadService.remove(id)));
  ipcMain.handle('leads:stages', safe(() => leadService.STAGES));
  ipcMain.handle('leads:priorities', safe(() => leadService.PRIORITIES));

  // ---- Travellers (Phase 19 CRM) -------------------------------------------------
  ipcMain.handle('travellers:list', safe((_e, params) => travellerService.list(params)));
  ipcMain.handle('travellers:get', safe((_e, id) => travellerService.get(id)));
  ipcMain.handle('travellers:listByCustomer', safe((_e, customerId) => travellerService.listByCustomer(customerId)));
  ipcMain.handle('travellers:create', safe((_e, payload) => travellerService.create(payload)));
  ipcMain.handle('travellers:update', safe((_e, id, payload) => travellerService.update(id, payload)));
  ipcMain.handle('travellers:delete', safe((_e, id) => travellerService.remove(id)));
  ipcMain.handle('travellers:relationships', safe(() => travellerService.RELATIONSHIPS));
  ipcMain.handle('travellers:bookings:list', safe((_e, bookingId) => travellerService.listForBooking(bookingId)));
  ipcMain.handle('travellers:bookings:add', safe((_e, bookingId, travellerId, notes) => travellerService.addToBooking(bookingId, travellerId, notes)));
  ipcMain.handle('travellers:bookings:remove', safe((_e, membershipId) => travellerService.removeFromBooking(membershipId)));

  // ---- Follow-ups (Phase 19 CRM) -------------------------------------------------
  ipcMain.handle('followups:list', safe((_e, params) => followUpService.list(params)));
  ipcMain.handle('followups:dueSoon', safe((_e, days) => followUpService.dueSoon(days)));
  ipcMain.handle('followups:get', safe((_e, id) => followUpService.get(id)));
  ipcMain.handle('followups:create', safe((_e, payload) => followUpService.create(payload)));
  ipcMain.handle('followups:update', safe((_e, id, payload) => followUpService.update(id, payload)));
  ipcMain.handle('followups:markStatus', safe((_e, id, status) => followUpService.markStatus(id, status)));
  ipcMain.handle('followups:delete', safe((_e, id) => followUpService.remove(id)));
  ipcMain.handle('followups:priorities', safe(() => followUpService.PRIORITIES));
  ipcMain.handle('followups:statuses', safe(() => followUpService.STATUSES));
  ipcMain.handle('followups:options', safe(() => followUpService.options()));
  ipcMain.handle('followups:log:create', safe((_e, payload) => followUpService.logContact(payload, (sessionService.current() || {}).id || null)));
  ipcMain.handle('followups:history:list', safe((_e, params) => followUpService.historyList(params)));
  ipcMain.handle('followups:history:delete', safe((_e, id) => followUpService.historyDelete(id)));

  // ---- Quotations (Phase 19 Sales) -----------------------------------------------
  // Cost price / expected profit are internal: the response filter (redaction.js) hides them, and on save a user
  // without View Profit cannot overwrite them (the service keeps the stored cost).
  const quotationActor = () => {
    let user = null;
    try { user = sessionService.current(); } catch (_) { user = null; }
    return { userId: user ? user.id : null, canSeeCost: !!(user && user.capabilities && user.capabilities.view_profit) };
  };
  ipcMain.handle('quotations:list', safe((_e, params) => quotationService.list(params)));
  ipcMain.handle('quotations:get', safe((_e, id) => quotationService.get(id)));
  ipcMain.handle('quotations:create', safe((_e, payload) => quotationService.create(payload, quotationActor())));
  ipcMain.handle('quotations:update', safe((_e, id, payload) => quotationService.update(id, payload, quotationActor())));
  ipcMain.handle('quotations:revise', safe((_e, id) => quotationService.revise(id)));
  ipcMain.handle('quotations:convertToBooking', safe((_e, id) => quotationService.convertToBooking(id)));
  ipcMain.handle('quotations:delete', safe((_e, id) => quotationService.remove(id)));
  ipcMain.handle('quotations:referenceOptions', safe((_e, params) => quotationService.referenceOptions(params)));
  ipcMain.handle('quotations:statuses', safe(() => quotationService.STATUSES));
  ipcMain.handle('quotations:meta', safe(() => quotationService.meta()));

  // ---- Packages (Phase 20 - central Package Management: Umrah/Hajj/Tour/Custom) --
  ipcMain.handle('packages:list', safe((_e, params) => packageService.list(params)));
  ipcMain.handle('packages:get', safe((_e, id) => packageService.get(id)));
  ipcMain.handle('packages:create', safe((_e, payload) => packageService.create(payload)));
  ipcMain.handle('packages:update', safe((_e, id, payload) => packageService.update(id, payload)));
  ipcMain.handle('packages:delete', safe((_e, id) => packageService.remove(id)));
  ipcMain.handle('packages:options', safe(() => packageService.options()));
  ipcMain.handle('packages:optionsByType', safe((_e, packageType) => packageService.optionsByType(packageType)));
  ipcMain.handle('packages:componentTypes', safe(() => packageService.COMPONENT_TYPES));
  ipcMain.handle('packages:packageTypes', safe(() => packageService.PACKAGE_TYPES));
  ipcMain.handle('packages:componentTypesByType', safe(() => packageService.COMPONENT_TYPES_BY_TYPE));

  // ---- Other Services (Phase 19 Operations) --------------------------------------
  ipcMain.handle('otherServices:list', safe((_e, params) => otherServiceService.list(params)));
  ipcMain.handle('otherServices:get', safe((_e, id) => otherServiceService.get(id)));
  ipcMain.handle('otherServices:create', safe((_e, payload) => otherServiceService.create(payload)));
  ipcMain.handle('otherServices:update', safe((_e, id, payload) => otherServiceService.update(id, payload)));
  ipcMain.handle('otherServices:delete', safe((_e, id) => otherServiceService.remove(id)));
  ipcMain.handle('otherServices:serviceTypes', safe(() => otherServiceService.SERVICE_TYPES));
  ipcMain.handle('otherServices:statuses', safe(() => otherServiceService.STATUSES));

  // ---- Tasks (Phase 19 Operations) -------------------------------------------------
  ipcMain.handle('tasks:list', safe((_e, params) => taskService.list(params)));
  ipcMain.handle('tasks:get', safe((_e, id) => taskService.get(id)));
  ipcMain.handle('tasks:dueSoon', safe((_e, days) => taskService.dueSoon(days)));
  ipcMain.handle('tasks:create', safe((_e, payload) => taskService.create(payload)));
  ipcMain.handle('tasks:update', safe((_e, id, payload) => taskService.update(id, payload)));
  ipcMain.handle('tasks:markStatus', safe((_e, id, status) => taskService.markStatus(id, status)));
  ipcMain.handle('tasks:delete', safe((_e, id) => taskService.remove(id)));
  ipcMain.handle('tasks:priorities', safe(() => taskService.PRIORITIES));
  ipcMain.handle('tasks:statuses', safe(() => taskService.STATUSES));

  // ---- Deadline Engine (Phase 19 Operations) ---------------------------------------
  ipcMain.handle('deadlines:list', safe((_e, params) => deadlineService.list(params)));
  ipcMain.handle('deadlines:get', safe((_e, id) => deadlineService.get(id)));
  ipcMain.handle('deadlines:dueSoon', safe((_e, days) => deadlineService.dueSoon(days)));
  ipcMain.handle('deadlines:create', safe((_e, payload) => deadlineService.create(payload)));
  ipcMain.handle('deadlines:update', safe((_e, id, payload) => deadlineService.update(id, payload)));
  ipcMain.handle('deadlines:markStatus', safe((_e, id, status) => deadlineService.markStatus(id, status)));
  ipcMain.handle('deadlines:delete', safe((_e, id) => deadlineService.remove(id)));
  ipcMain.handle('deadlines:types', safe(() => deadlineService.DEADLINE_TYPES));
  ipcMain.handle('deadlines:statuses', safe(() => deadlineService.STATUSES));

  // ---- Upcoming Travel (Phase 19 Operations) ---------------------------------------
  ipcMain.handle('bookings:upcomingTravel', safe((_e, params) => bookingService.upcomingTravel(params)));

  // ---- Travel Calendar (Phase 19 Operations) ---------------------------------------
  ipcMain.handle('calendar:list', safe((_e, params) => calendarService.list(params)));
  ipcMain.handle('calendar:eventTypes', safe(() => calendarService.EVENT_TYPES));
  // ---- Exchange rates, Agents, Commissions, Financial statements (Phase 21) ----
  const exchangeRateService = require('../services/exchangeRateService');
  const agentService = require('../services/agentService');
  const commissionService = require('../services/commissionService');
  const financialStatementsService = require('../services/financialStatementsService');
  const actingId = () => (sessionService.current() || {}).id || null;

  ipcMain.handle('exchangeRates:list', safe((_e, params) => exchangeRateService.list(params)));
  ipcMain.handle('exchangeRates:listCurrent', safe((_e, asOf) => exchangeRateService.listCurrent(asOf)));
  ipcMain.handle('exchangeRates:getRate', safe((_e, from, to, date) => exchangeRateService.getRate(from, to, date)));
  ipcMain.handle('exchangeRates:baseCurrency', safe(() => exchangeRateService.getBaseCurrency()));
  ipcMain.handle('exchangeRates:create', safe((_e, payload) => exchangeRateService.create({ ...payload, created_by: actingId() })));
  ipcMain.handle('exchangeRates:delete', safe((_e, id) => exchangeRateService.remove(id, actingId())));

  ipcMain.handle('agents:list', safe((_e, params) => agentService.list(params)));
  ipcMain.handle('agents:options', safe((_e, opts) => agentService.options(opts)));
  ipcMain.handle('agents:get', safe((_e, id) => agentService.get(id)));
  ipcMain.handle('agents:create', safe((_e, payload) => agentService.create(payload)));
  ipcMain.handle('agents:update', safe((_e, id, payload) => agentService.update(id, payload)));
  ipcMain.handle('agents:delete', safe((_e, id) => agentService.remove(id)));

  ipcMain.handle('commissions:list', safe((_e, params) => commissionService.list(params)));
  ipcMain.handle('commissions:get', safe((_e, id) => commissionService.get(id)));
  ipcMain.handle('commissions:summary', safe((_e, params) => commissionService.summary(params)));
  ipcMain.handle('commissions:create', safe((_e, payload) => commissionService.create({ ...payload, created_by: actingId() })));
  ipcMain.handle('commissions:update', safe((_e, id, payload) => commissionService.update(id, payload)));
  ipcMain.handle('commissions:approve', safe((_e, id) => commissionService.approve(id)));
  ipcMain.handle('commissions:pay', safe((_e, id, payload) => commissionService.pay(id, payload)));
  ipcMain.handle('commissions:reversePayment', safe((_e, id) => commissionService.reversePayment(id)));
  ipcMain.handle('commissions:cancel', safe((_e, id) => commissionService.cancel(id)));

  const periodLockService = require('../services/periodLockService');
  ipcMain.handle('periodLock:status', safe(() => periodLockService.status()));
  ipcMain.handle('periodLock:preview', safe((_e, closeDate) => {
    const bs = financialStatementsService.balanceSheet({ asOf: closeDate });
    return { close_date: closeDate, base_currency: bs.base_currency, profit_to_carry_forward: bs.profit_to_date, balanced: bs.balanced };
  }));
  ipcMain.handle('periodLock:setManualLock', safe((_e, date) => periodLockService.setManualLock(date, actingId())));
  ipcMain.handle('periodLock:closeYear', safe((_e, payload) => periodLockService.closeYear({ ...payload, userId: actingId() })));
  ipcMain.handle('periodLock:reopenLastClose', safe(() => periodLockService.reopenLastClose(actingId())));

  ipcMain.handle('financialStatements:accounts', safe(() => financialStatementsService.listAccounts()));
  ipcMain.handle('financialStatements:generalLedger', safe((_e, params) => financialStatementsService.generalLedger(params)));
  ipcMain.handle('financialStatements:trialBalance', safe((_e, params) => financialStatementsService.trialBalance(params)));
  ipcMain.handle('financialStatements:balanceSheet', safe((_e, params) => financialStatementsService.balanceSheet(params)));
  ipcMain.handle('financialStatements:reconcile', safe(() => financialStatementsService.reconcileCashAndBank()));
  ipcMain.handle('financialStatements:exportPdf', safe(async (_e, reportData) => exportService.exportPdf(reportData)));
  ipcMain.handle('financialStatements:exportCsv', safe(async (_e, reportData) => exportService.exportCsv(reportData)));
  ipcMain.handle('financialStatements:preview', safe((_e, reportData) => exportService.buildReportHtml(reportData)));
  ipcMain.handle('financialStatements:print', safe(async (_e, reportData) => exportService.printReport(reportData)));
}

module.exports = { registerIpcHandlers };
