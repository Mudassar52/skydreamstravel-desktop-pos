const { contextBridge, ipcRenderer } = require('electron');

/**
 * Everything the renderer (React app) is allowed to call goes here,
 * namespaced by module. Never expose ipcRenderer directly - keep the
 * surface explicit so the renderer cannot invoke arbitrary channels.
 */
contextBridge.exposeInMainWorld('api', {
  exchangeRates: {
    list: (params) => ipcRenderer.invoke('exchangeRates:list', params),
    listCurrent: (asOf) => ipcRenderer.invoke('exchangeRates:listCurrent', asOf),
    getRate: (from, to, date) => ipcRenderer.invoke('exchangeRates:getRate', from, to, date),
    baseCurrency: () => ipcRenderer.invoke('exchangeRates:baseCurrency'),
    create: (payload) => ipcRenderer.invoke('exchangeRates:create', payload),
    delete: (id) => ipcRenderer.invoke('exchangeRates:delete', id)
  },
  agents: {
    list: (params) => ipcRenderer.invoke('agents:list', params),
    options: (opts) => ipcRenderer.invoke('agents:options', opts),
    get: (id) => ipcRenderer.invoke('agents:get', id),
    create: (payload) => ipcRenderer.invoke('agents:create', payload),
    update: (id, payload) => ipcRenderer.invoke('agents:update', id, payload),
    delete: (id) => ipcRenderer.invoke('agents:delete', id)
  },
  commissions: {
    list: (params) => ipcRenderer.invoke('commissions:list', params),
    get: (id) => ipcRenderer.invoke('commissions:get', id),
    summary: (params) => ipcRenderer.invoke('commissions:summary', params),
    create: (payload) => ipcRenderer.invoke('commissions:create', payload),
    update: (id, payload) => ipcRenderer.invoke('commissions:update', id, payload),
    approve: (id) => ipcRenderer.invoke('commissions:approve', id),
    pay: (id, payload) => ipcRenderer.invoke('commissions:pay', id, payload),
    reversePayment: (id) => ipcRenderer.invoke('commissions:reversePayment', id),
    cancel: (id) => ipcRenderer.invoke('commissions:cancel', id)
  },
  periodLock: {
    status: () => ipcRenderer.invoke('periodLock:status'),
    preview: (closeDate) => ipcRenderer.invoke('periodLock:preview', closeDate),
    setManualLock: (date) => ipcRenderer.invoke('periodLock:setManualLock', date),
    closeYear: (payload) => ipcRenderer.invoke('periodLock:closeYear', payload),
    reopenLastClose: () => ipcRenderer.invoke('periodLock:reopenLastClose')
  },
  financialStatements: {
    accounts: () => ipcRenderer.invoke('financialStatements:accounts'),
    generalLedger: (params) => ipcRenderer.invoke('financialStatements:generalLedger', params),
    trialBalance: (params) => ipcRenderer.invoke('financialStatements:trialBalance', params),
    balanceSheet: (params) => ipcRenderer.invoke('financialStatements:balanceSheet', params),
    reconcile: () => ipcRenderer.invoke('financialStatements:reconcile'),
    exportPdf: (reportData) => ipcRenderer.invoke('financialStatements:exportPdf', reportData),
    exportCsv: (reportData) => ipcRenderer.invoke('financialStatements:exportCsv', reportData),
    preview: (reportData) => ipcRenderer.invoke('financialStatements:preview', reportData),
    print: (reportData) => ipcRenderer.invoke('financialStatements:print', reportData)
  },
  dashboard: {
    getStats: (range) => ipcRenderer.invoke('dashboard:getStats', range),
    getMonthlyFinancials: () => ipcRenderer.invoke('dashboard:getMonthlyFinancials'),
    getActionRequired: () => ipcRenderer.invoke('dashboard:getActionRequired'),
    getCharts: (range) => ipcRenderer.invoke('dashboard:getCharts', range),
    getUpcomingPanels: () => ipcRenderer.invoke('dashboard:getUpcomingPanels'),
    getOperationsPanels: () => ipcRenderer.invoke('dashboard:getOperationsPanels'),
    getCalendarEvents: (year, month) => ipcRenderer.invoke('dashboard:getCalendarEvents', year, month)
  },
  search: {
    query: (query) => ipcRenderer.invoke('search:query', query)
  },
  notifications: {
    list: (params) => ipcRenderer.invoke('notifications:list', params),
    unreadCount: () => ipcRenderer.invoke('notifications:unreadCount'),
    markRead: (id) => ipcRenderer.invoke('notifications:markRead', id),
    markAllRead: () => ipcRenderer.invoke('notifications:markAllRead'),
    generate: () => ipcRenderer.invoke('notifications:generate')
  },
  savedFilters: {
    list: (module) => ipcRenderer.invoke('savedFilters:list', module),
    create: (payload) => ipcRenderer.invoke('savedFilters:create', payload),
    delete: (id) => ipcRenderer.invoke('savedFilters:delete', id)
  },
  auth: {
    login: (username, password) => ipcRenderer.invoke('auth:login', username, password),
    logout: () => ipcRenderer.invoke('auth:logout')
  },
  users: {
    list: () => ipcRenderer.invoke('users:list'),
    create: (payload) => ipcRenderer.invoke('users:create', payload),
    update: (id, payload) => ipcRenderer.invoke('users:update', id, payload),
    resetPassword: (id, newPassword) => ipcRenderer.invoke('users:resetPassword', id, newPassword)
  },
  roles: {
    list: () => ipcRenderer.invoke('roles:list')
  },
  permissions: {
    getMatrix: () => ipcRenderer.invoke('permissions:getMatrix'),
    update: (payload) => ipcRenderer.invoke('permissions:update', payload)
  },
  capabilities: {
    getMatrix: () => ipcRenderer.invoke('capabilities:getMatrix'),
    update: (payload) => ipcRenderer.invoke('capabilities:update', payload)
  },
  customReports: {
    meta: () => ipcRenderer.invoke('customReports:meta'),
    dateFields: (reportType) => ipcRenderer.invoke('customReports:dateFields', reportType),
    sections: (reportType) => ipcRenderer.invoke('customReports:sections', reportType),
    run: (spec) => ipcRenderer.invoke('customReports:run', spec),
    exportPdf: (reportData) => ipcRenderer.invoke('customReports:exportPdf', reportData),
    print: (reportData) => ipcRenderer.invoke('customReports:print', reportData),
    exportCsv: (reportData) => ipcRenderer.invoke('customReports:exportCsv', reportData)
  },
  reportExport: {
    exportExcel: (sheets, suggestedName) => ipcRenderer.invoke('reportExport:exportExcel', sheets, suggestedName),
    exportPdf: (reportData) => ipcRenderer.invoke('reportExport:exportPdf', reportData),
    print: (reportData) => ipcRenderer.invoke('reportExport:print', reportData)
  },
  reportHistory: {
    record: (payload) => ipcRenderer.invoke('reportHistory:record', payload),
    list: (params) => ipcRenderer.invoke('reportHistory:list', params),
    get: (id) => ipcRenderer.invoke('reportHistory:get', id),
    regenerate: (id) => ipcRenderer.invoke('reportHistory:regenerate', id),
    remove: (id) => ipcRenderer.invoke('reportHistory:remove', id)
  },
  reportTemplates: {
    create: (payload) => ipcRenderer.invoke('reportTemplates:create', payload),
    list: (reportType) => ipcRenderer.invoke('reportTemplates:list', reportType),
    get: (id) => ipcRenderer.invoke('reportTemplates:get', id),
    remove: (id) => ipcRenderer.invoke('reportTemplates:remove', id)
  },
  bookingDossier: {
    get: (id) => ipcRenderer.invoke('bookingDossier:get', id)
  },
  vouchers: {
    available: (bookingId) => ipcRenderer.invoke('vouchers:available', bookingId),
    hotelPreview: (bookingId, hotelId) => ipcRenderer.invoke('vouchers:hotel:preview', bookingId, hotelId),
    hotelPrint: (bookingId, hotelId) => ipcRenderer.invoke('vouchers:hotel:print', bookingId, hotelId),
    hotelPdf: (bookingId, hotelId) => ipcRenderer.invoke('vouchers:hotel:pdf', bookingId, hotelId),
    transportPreview: (bookingId, transportId) => ipcRenderer.invoke('vouchers:transport:preview', bookingId, transportId),
    transportPrint: (bookingId, transportId) => ipcRenderer.invoke('vouchers:transport:print', bookingId, transportId),
    transportPdf: (bookingId, transportId) => ipcRenderer.invoke('vouchers:transport:pdf', bookingId, transportId)
  },
  supplier360: {
    dossier: (id) => ipcRenderer.invoke('supplier360:dossier', id),
    services: (id, opts) => ipcRenderer.invoke('supplier360:services', id, opts),
    bookings: (id) => ipcRenderer.invoke('supplier360:bookings', id),
    invoices: (id) => ipcRenderer.invoke('supplier360:invoices', id),
    payments: (id) => ipcRenderer.invoke('supplier360:payments', id),
    timeline: (id, opts) => ipcRenderer.invoke('supplier360:timeline', id, opts)
  },
  package360: {
    dossier: (id) => ipcRenderer.invoke('package360:dossier', id)
  },
  customer360: {
    dossier: (id, opts) => ipcRenderer.invoke('customer360:dossier', id, opts),
    bookings: (id, opts) => ipcRenderer.invoke('customer360:bookings', id, opts),
    timeline: (id, opts) => ipcRenderer.invoke('customer360:timeline', id, opts)
  },
  customers: {
    list: (params) => ipcRenderer.invoke('customers:list', params),
    get: (id) => ipcRenderer.invoke('customers:get', id),
    create: (payload) => ipcRenderer.invoke('customers:create', payload),
    update: (id, payload) => ipcRenderer.invoke('customers:update', id, payload),
    delete: (id) => ipcRenderer.invoke('customers:delete', id)
  },
  umrah: {
    packages: {
      list: () => ipcRenderer.invoke('umrah:packages:list'),
      get: (id) => ipcRenderer.invoke('umrah:packages:get', id),
      create: (payload) => ipcRenderer.invoke('umrah:packages:create', payload),
      update: (id, payload) => ipcRenderer.invoke('umrah:packages:update', id, payload),
      delete: (id) => ipcRenderer.invoke('umrah:packages:delete', id)
    },
    groups: {
      list: () => ipcRenderer.invoke('umrah:groups:list'),
      get: (id) => ipcRenderer.invoke('umrah:groups:get', id),
      create: (payload) => ipcRenderer.invoke('umrah:groups:create', payload),
      update: (id, payload) => ipcRenderer.invoke('umrah:groups:update', id, payload),
      delete: (id) => ipcRenderer.invoke('umrah:groups:delete', id),
      passengers: {
        list: (groupId) => ipcRenderer.invoke('umrah:groups:passengers:list', groupId),
        add: (groupId, customerId, notes) => ipcRenderer.invoke('umrah:groups:passengers:add', groupId, customerId, notes),
        remove: (membershipId, groupId) => ipcRenderer.invoke('umrah:groups:passengers:remove', membershipId, groupId)
      }
    }
  },
  hajj: {
    packages: {
      list: () => ipcRenderer.invoke('hajj:packages:list'),
      get: (id) => ipcRenderer.invoke('hajj:packages:get', id),
      create: (payload) => ipcRenderer.invoke('hajj:packages:create', payload),
      update: (id, payload) => ipcRenderer.invoke('hajj:packages:update', id, payload),
      delete: (id) => ipcRenderer.invoke('hajj:packages:delete', id)
    },
    groups: {
      list: () => ipcRenderer.invoke('hajj:groups:list'),
      get: (id) => ipcRenderer.invoke('hajj:groups:get', id),
      create: (payload) => ipcRenderer.invoke('hajj:groups:create', payload),
      update: (id, payload) => ipcRenderer.invoke('hajj:groups:update', id, payload),
      delete: (id) => ipcRenderer.invoke('hajj:groups:delete', id),
      pilgrims: {
        list: (groupId) => ipcRenderer.invoke('hajj:groups:pilgrims:list', groupId),
        add: (groupId, customerId, notes) => ipcRenderer.invoke('hajj:groups:pilgrims:add', groupId, customerId, notes),
        remove: (membershipId, groupId) => ipcRenderer.invoke('hajj:groups:pilgrims:remove', membershipId, groupId)
      }
    }
  },
  tours: {
    list: () => ipcRenderer.invoke('tours:list'),
    get: (id) => ipcRenderer.invoke('tours:get', id),
    create: (payload) => ipcRenderer.invoke('tours:create', payload),
    update: (id, payload) => ipcRenderer.invoke('tours:update', id, payload),
    delete: (id) => ipcRenderer.invoke('tours:delete', id),
    passengers: {
      list: (tourId) => ipcRenderer.invoke('tours:passengers:list', tourId),
      add: (tourId, customerId, notes) => ipcRenderer.invoke('tours:passengers:add', tourId, customerId, notes),
      remove: (membershipId, tourId) => ipcRenderer.invoke('tours:passengers:remove', membershipId, tourId)
    }
  },
  bookings: {
    list: (params) => ipcRenderer.invoke('bookings:list', params),
    get: (id) => ipcRenderer.invoke('bookings:get', id),
    listByCustomer: (customerId) => ipcRenderer.invoke('bookings:listByCustomer', customerId),
    create: (payload) => ipcRenderer.invoke('bookings:create', payload),
    update: (id, payload) => ipcRenderer.invoke('bookings:update', id, payload),
    delete: (id) => ipcRenderer.invoke('bookings:delete', id),
    referenceOptions: (type) => ipcRenderer.invoke('bookings:referenceOptions', type),
    packageOptions: (packageType) => ipcRenderer.invoke('bookings:packageOptions', packageType),
    passengers: {
      list: (bookingId) => ipcRenderer.invoke('bookings:passengers:list', bookingId),
      add: (bookingId, customerId, notes) => ipcRenderer.invoke('bookings:passengers:add', bookingId, customerId, notes),
      remove: (membershipId, bookingId) => ipcRenderer.invoke('bookings:passengers:remove', membershipId, bookingId)
    },
    options: () => ipcRenderer.invoke('bookings:options'),
    upcomingTravel: (params) => ipcRenderer.invoke('bookings:upcomingTravel', params)
  },
  flights: {
    list: (params) => ipcRenderer.invoke('flights:list', params),
    get: (id) => ipcRenderer.invoke('flights:get', id),
    create: (payload) => ipcRenderer.invoke('flights:create', payload),
    update: (id, payload) => ipcRenderer.invoke('flights:update', id, payload),
    delete: (id) => ipcRenderer.invoke('flights:delete', id),
    passengers: {
      list: (flightId) => ipcRenderer.invoke('flights:passengers:list', flightId),
      add: (flightId, customerId) => ipcRenderer.invoke('flights:passengers:add', flightId, customerId),
      remove: (membershipId) => ipcRenderer.invoke('flights:passengers:remove', membershipId)
    },
    travellers: {
      list: (flightId) => ipcRenderer.invoke('flights:travellers:list', flightId),
      add: (flightId, travellerId) => ipcRenderer.invoke('flights:travellers:add', flightId, travellerId),
      addAll: (flightId) => ipcRenderer.invoke('flights:travellers:addAll', flightId),
      remove: (membershipId) => ipcRenderer.invoke('flights:travellers:remove', membershipId)
    },
    listByBooking: (bookingId) => ipcRenderer.invoke('flights:listByBooking', bookingId)
  },
  hotels: {
    list: (params) => ipcRenderer.invoke('hotels:list', params),
    get: (id) => ipcRenderer.invoke('hotels:get', id),
    create: (payload) => ipcRenderer.invoke('hotels:create', payload),
    update: (id, payload) => ipcRenderer.invoke('hotels:update', id, payload),
    delete: (id) => ipcRenderer.invoke('hotels:delete', id),
    guests: {
      list: (hotelId) => ipcRenderer.invoke('hotels:guests:list', hotelId),
      update: (hotelId, guests) => ipcRenderer.invoke('hotels:guests:update', hotelId, guests)
    },
    listByBooking: (bookingId) => ipcRenderer.invoke('hotels:listByBooking', bookingId)
  },
  visa: {
    list: (params) => ipcRenderer.invoke('visa:list', params),
    get: (id) => ipcRenderer.invoke('visa:get', id),
    create: (payload) => ipcRenderer.invoke('visa:create', payload),
    update: (id, payload) => ipcRenderer.invoke('visa:update', id, payload),
    delete: (id) => ipcRenderer.invoke('visa:delete', id),
    expiringSoon: (days) => ipcRenderer.invoke('visa:expiringSoon', days),
    createForBooking: (bookingId, options) => ipcRenderer.invoke('visa:createForBooking', bookingId, options),
    listByBooking: (bookingId) => ipcRenderer.invoke('visa:listByBooking', bookingId)
  },
  transportation: {
    list: (params) => ipcRenderer.invoke('transportation:list', params),
    get: (id) => ipcRenderer.invoke('transportation:get', id),
    create: (payload) => ipcRenderer.invoke('transportation:create', payload),
    update: (id, payload) => ipcRenderer.invoke('transportation:update', id, payload),
    delete: (id) => ipcRenderer.invoke('transportation:delete', id),
    listByBooking: (bookingId) => ipcRenderer.invoke('transportation:listByBooking', bookingId)
  },
  invoiceTemplates: {
    list: () => ipcRenderer.invoke('invoiceTemplates:list'),
    get: (id) => ipcRenderer.invoke('invoiceTemplates:get', id),
    create: (payload) => ipcRenderer.invoke('invoiceTemplates:create', payload),
    update: (id, payload) => ipcRenderer.invoke('invoiceTemplates:update', id, payload),
    delete: (id) => ipcRenderer.invoke('invoiceTemplates:delete', id),
    setDefault: (id) => ipcRenderer.invoke('invoiceTemplates:setDefault', id),
    tokens: () => ipcRenderer.invoke('invoiceTemplates:tokens')
  },
  invoices: {
    list: (params) => ipcRenderer.invoke('invoices:list', params),
    get: (id) => ipcRenderer.invoke('invoices:get', id),
    listByCustomer: (customerId) => ipcRenderer.invoke('invoices:listByCustomer', customerId),
    listByBooking: (bookingId) => ipcRenderer.invoke('invoices:listByBooking', bookingId),
    create: (payload) => ipcRenderer.invoke('invoices:create', payload),
    update: (id, payload) => ipcRenderer.invoke('invoices:update', id, payload),
    cancel: (id) => ipcRenderer.invoke('invoices:cancel', id),
    delete: (id) => ipcRenderer.invoke('invoices:delete', id),
    duplicate: (id) => ipcRenderer.invoke('invoices:duplicate', id),
    createFromBooking: (bookingId) => ipcRenderer.invoke('invoices:createFromBooking', bookingId),
    generatePdf: (id) => ipcRenderer.invoke('invoices:generatePdf', id),
    preview: (id) => ipcRenderer.invoke('invoices:preview', id),
    print: (id) => ipcRenderer.invoke('invoices:print', id)
  },
  payments: {
    list: (params) => ipcRenderer.invoke('payments:list', params),
    get: (id) => ipcRenderer.invoke('payments:get', id),
    create: (payload) => ipcRenderer.invoke('payments:create', payload),
    void: (id) => ipcRenderer.invoke('payments:void', id),
    listByBooking: (bookingId) => ipcRenderer.invoke('payments:listByBooking', bookingId)
  },
  ledger: {
    list: (customerId) => ipcRenderer.invoke('ledger:list', customerId),
    getBalance: (customerId) => ipcRenderer.invoke('ledger:getBalance', customerId),
    filteredView: (customerId, opts) => ipcRenderer.invoke('ledger:filteredView', customerId, opts),
    transactionTypes: (customerId) => ipcRenderer.invoke('ledger:transactionTypes', customerId),
    exportPdf: (reportData) => ipcRenderer.invoke('ledger:exportPdf', reportData),
    exportCsv: (reportData) => ipcRenderer.invoke('ledger:exportCsv', reportData),
    print: (reportData) => ipcRenderer.invoke('ledger:print', reportData)
  },
  advances: {
    available: (customerId) => ipcRenderer.invoke('advances:available', customerId),
    listAll: (params) => ipcRenderer.invoke('advances:listAll', params),
    applicationsForInvoice: (invoiceId) => ipcRenderer.invoke('advances:applicationsForInvoice', invoiceId),
    applyToInvoice: (payload) => ipcRenderer.invoke('advances:applyToInvoice', payload),
    reverseApplication: (applicationId) => ipcRenderer.invoke('advances:reverseApplication', applicationId),
    summary: (customerId) => ipcRenderer.invoke('advances:summary', customerId)
  },
  expenses: {
    categories: {
      list: () => ipcRenderer.invoke('expenses:categories:list'),
      create: (name) => ipcRenderer.invoke('expenses:categories:create', name),
      delete: (id) => ipcRenderer.invoke('expenses:categories:delete', id)
    },
    list: (params) => ipcRenderer.invoke('expenses:list', params),
    get: (id) => ipcRenderer.invoke('expenses:get', id),
    create: (payload) => ipcRenderer.invoke('expenses:create', payload),
    update: (id, payload) => ipcRenderer.invoke('expenses:update', id, payload),
    delete: (id) => ipcRenderer.invoke('expenses:delete', id)
  },
  profit: {
    getSummary: () => ipcRenderer.invoke('profit:getSummary'),
    getMonthly: (months) => ipcRenderer.invoke('profit:getMonthly', months),
    getByBookingType: () => ipcRenderer.invoke('profit:getByBookingType'),
    getByCustomer: (customerId) => ipcRenderer.invoke('profit:getByCustomer', customerId),
    getByBooking: (bookingId) => ipcRenderer.invoke('profit:getByBooking', bookingId)
  },
  documents: {
    list: (params) => ipcRenderer.invoke('documents:list', params),
    get: (id) => ipcRenderer.invoke('documents:get', id),
    upload: (payload) => ipcRenderer.invoke('documents:upload', payload),
    open: (id) => ipcRenderer.invoke('documents:open', id),
    downloadAs: (id) => ipcRenderer.invoke('documents:downloadAs', id),
    rename: (id, newName) => ipcRenderer.invoke('documents:rename', id, newName),
    delete: (id) => ipcRenderer.invoke('documents:delete', id),
    types: () => ipcRenderer.invoke('documents:types')
  },
  reports: {
    listTypes: () => ipcRenderer.invoke('reports:listTypes'),
    run: (key, filters) => ipcRenderer.invoke('reports:run', key, filters),
    exportCsv: (reportData) => ipcRenderer.invoke('reports:exportCsv', reportData),
    exportPdf: (reportData) => ipcRenderer.invoke('reports:exportPdf', reportData),
    print: (reportData) => ipcRenderer.invoke('reports:print', reportData)
  },
  settings: {
    getAll: () => ipcRenderer.invoke('settings:getAll'),
    setMany: (payload) => ipcRenderer.invoke('settings:setMany', payload),
    uploadImage: (fieldKey) => ipcRenderer.invoke('settings:uploadImage', fieldKey),
    removeImage: (fieldKey) => ipcRenderer.invoke('settings:removeImage', fieldKey)
  },
  backup: {
    create: () => ipcRenderer.invoke('backup:create'),
    restore: () => ipcRenderer.invoke('backup:restore'),
    relaunch: () => ipcRenderer.invoke('backup:relaunch'),
    chooseFolder: () => ipcRenderer.invoke('backup:chooseFolder'),
    getConfig: () => ipcRenderer.invoke('backup:getConfig'),
    setAutoEnabled: (enabled) => ipcRenderer.invoke('backup:setAutoEnabled', enabled),
    getInfo: () => ipcRenderer.invoke('backup:getInfo')
  },
  auditLogs: {
    list: (params) => ipcRenderer.invoke('auditLogs:list', params),
    actions: () => ipcRenderer.invoke('auditLogs:actions'),
    recordTypes: () => ipcRenderer.invoke('auditLogs:recordTypes')
  },
  suppliers: {
    list: (params) => ipcRenderer.invoke('suppliers:list', params),
    get: (id) => ipcRenderer.invoke('suppliers:get', id),
    create: (payload) => ipcRenderer.invoke('suppliers:create', payload),
    update: (id, payload) => ipcRenderer.invoke('suppliers:update', id, payload),
    delete: (id) => ipcRenderer.invoke('suppliers:delete', id),
    options: () => ipcRenderer.invoke('suppliers:options'),
    serviceTypes: () => ipcRenderer.invoke('suppliers:serviceTypes')
  },
  supplierLedger: {
    list: (supplierId) => ipcRenderer.invoke('supplierLedger:list', supplierId),
    getBalance: (supplierId) => ipcRenderer.invoke('supplierLedger:getBalance', supplierId),
    filteredView: (supplierId, opts) => ipcRenderer.invoke('supplierLedger:filteredView', supplierId, opts),
    transactionTypes: (supplierId) => ipcRenderer.invoke('supplierLedger:transactionTypes', supplierId),
    exportPdf: (reportData) => ipcRenderer.invoke('supplierLedger:exportPdf', reportData),
    exportCsv: (reportData) => ipcRenderer.invoke('supplierLedger:exportCsv', reportData),
    print: (reportData) => ipcRenderer.invoke('supplierLedger:print', reportData)
  },
  supplierAdvances: {
    available: (supplierId) => ipcRenderer.invoke('supplierAdvances:available', supplierId),
    listAll: (params) => ipcRenderer.invoke('supplierAdvances:listAll', params),
    applicationsForInvoice: (invoiceId) => ipcRenderer.invoke('supplierAdvances:applicationsForInvoice', invoiceId),
    applyToInvoice: (payload) => ipcRenderer.invoke('supplierAdvances:applyToInvoice', payload),
    reverseApplication: (applicationId) => ipcRenderer.invoke('supplierAdvances:reverseApplication', applicationId),
    summary: (supplierId) => ipcRenderer.invoke('supplierAdvances:summary', supplierId)
  },
  supplierInvoices: {
    list: (params) => ipcRenderer.invoke('supplierInvoices:list', params),
    get: (id) => ipcRenderer.invoke('supplierInvoices:get', id),
    listByBooking: (bookingId) => ipcRenderer.invoke('supplierInvoices:listByBooking', bookingId),
    create: (payload) => ipcRenderer.invoke('supplierInvoices:create', payload),
    delete: (id) => ipcRenderer.invoke('supplierInvoices:delete', id)
  },
  supplierPayments: {
    list: (params) => ipcRenderer.invoke('supplierPayments:list', params),
    create: (payload) => ipcRenderer.invoke('supplierPayments:create', payload),
    void: (id) => ipcRenderer.invoke('supplierPayments:void', id),
    methods: () => ipcRenderer.invoke('supplierPayments:methods')
  },
  supplierReports: {
    listTypes: () => ipcRenderer.invoke('supplierReports:listTypes'),
    run: (key, filters) => ipcRenderer.invoke('supplierReports:run', key, filters),
    exportCsv: (reportData) => ipcRenderer.invoke('supplierReports:exportCsv', reportData),
    exportPdf: (reportData) => ipcRenderer.invoke('supplierReports:exportPdf', reportData),
    print: (reportData) => ipcRenderer.invoke('supplierReports:print', reportData)
  },
  bankAccounts: {
    list: (opts) => ipcRenderer.invoke('bankAccounts:list', opts)
  },
  cashAccounts: {
    list: (opts) => ipcRenderer.invoke('cashAccounts:list', opts)
  },
  accounts: {
    get: (type, id) => ipcRenderer.invoke('accounts:get', type, id),
    create: (type, payload) => ipcRenderer.invoke('accounts:create', type, payload),
    update: (type, id, payload) => ipcRenderer.invoke('accounts:update', type, id, payload),
    delete: (type, id) => ipcRenderer.invoke('accounts:delete', type, id),
    deposit: (payload) => ipcRenderer.invoke('accounts:deposit', payload),
    withdraw: (payload) => ipcRenderer.invoke('accounts:withdraw', payload),
    transfer: (payload) => ipcRenderer.invoke('accounts:transfer', payload)
  },
  refunds: {
    list: (params) => ipcRenderer.invoke('refunds:list', params),
    create: (payload) => ipcRenderer.invoke('refunds:create', payload),
    delete: (id) => ipcRenderer.invoke('refunds:delete', id)
  },
  accounting: {
    list: (params) => ipcRenderer.invoke('accounting:list', params),
    listAccounts: () => ipcRenderer.invoke('accounting:listAccounts'),
    summary: (params) => ipcRenderer.invoke('accounting:summary', params),
    create: (payload) => ipcRenderer.invoke('accounting:create', payload),
    reverse: (id) => ipcRenderer.invoke('accounting:reverse', id)
  },
  leads: {
    list: (params) => ipcRenderer.invoke('leads:list', params),
    pipeline: () => ipcRenderer.invoke('leads:pipeline'),
    get: (id) => ipcRenderer.invoke('leads:get', id),
    create: (payload) => ipcRenderer.invoke('leads:create', payload),
    update: (id, payload) => ipcRenderer.invoke('leads:update', id, payload),
    addNote: (id, note) => ipcRenderer.invoke('leads:addNote', id, note),
    convertToCustomer: (id) => ipcRenderer.invoke('leads:convertToCustomer', id),
    delete: (id) => ipcRenderer.invoke('leads:delete', id),
    stages: () => ipcRenderer.invoke('leads:stages'),
    priorities: () => ipcRenderer.invoke('leads:priorities')
  },
  travellers: {
    list: (params) => ipcRenderer.invoke('travellers:list', params),
    get: (id) => ipcRenderer.invoke('travellers:get', id),
    listByCustomer: (customerId) => ipcRenderer.invoke('travellers:listByCustomer', customerId),
    create: (payload) => ipcRenderer.invoke('travellers:create', payload),
    update: (id, payload) => ipcRenderer.invoke('travellers:update', id, payload),
    delete: (id) => ipcRenderer.invoke('travellers:delete', id),
    relationships: () => ipcRenderer.invoke('travellers:relationships'),
    bookings: {
      list: (bookingId) => ipcRenderer.invoke('travellers:bookings:list', bookingId),
      add: (bookingId, travellerId, notes) => ipcRenderer.invoke('travellers:bookings:add', bookingId, travellerId, notes),
      remove: (membershipId) => ipcRenderer.invoke('travellers:bookings:remove', membershipId)
    }
  },
  followups: {
    list: (params) => ipcRenderer.invoke('followups:list', params),
    dueSoon: (days) => ipcRenderer.invoke('followups:dueSoon', days),
    get: (id) => ipcRenderer.invoke('followups:get', id),
    create: (payload) => ipcRenderer.invoke('followups:create', payload),
    update: (id, payload) => ipcRenderer.invoke('followups:update', id, payload),
    markStatus: (id, status) => ipcRenderer.invoke('followups:markStatus', id, status),
    delete: (id) => ipcRenderer.invoke('followups:delete', id),
    priorities: () => ipcRenderer.invoke('followups:priorities'),
    statuses: () => ipcRenderer.invoke('followups:statuses'),
    options: () => ipcRenderer.invoke('followups:options'),
    logContact: (payload) => ipcRenderer.invoke('followups:log:create', payload),
    historyList: (params) => ipcRenderer.invoke('followups:history:list', params),
    historyDelete: (id) => ipcRenderer.invoke('followups:history:delete', id)
  },
  quotations: {
    list: (params) => ipcRenderer.invoke('quotations:list', params),
    get: (id) => ipcRenderer.invoke('quotations:get', id),
    create: (payload) => ipcRenderer.invoke('quotations:create', payload),
    update: (id, payload) => ipcRenderer.invoke('quotations:update', id, payload),
    revise: (id) => ipcRenderer.invoke('quotations:revise', id),
    convertToBooking: (id) => ipcRenderer.invoke('quotations:convertToBooking', id),
    delete: (id) => ipcRenderer.invoke('quotations:delete', id),
    referenceOptions: (params) => ipcRenderer.invoke('quotations:referenceOptions', params),
    statuses: () => ipcRenderer.invoke('quotations:statuses'),
    meta: () => ipcRenderer.invoke('quotations:meta')
  },
  packages: {
    list: (params) => ipcRenderer.invoke('packages:list', params),
    get: (id) => ipcRenderer.invoke('packages:get', id),
    create: (payload) => ipcRenderer.invoke('packages:create', payload),
    update: (id, payload) => ipcRenderer.invoke('packages:update', id, payload),
    delete: (id) => ipcRenderer.invoke('packages:delete', id),
    options: () => ipcRenderer.invoke('packages:options'),
    optionsByType: (packageType) => ipcRenderer.invoke('packages:optionsByType', packageType),
    componentTypes: () => ipcRenderer.invoke('packages:componentTypes'),
    packageTypes: () => ipcRenderer.invoke('packages:packageTypes'),
    componentTypesByType: () => ipcRenderer.invoke('packages:componentTypesByType')
  },
  otherServices: {
    list: (params) => ipcRenderer.invoke('otherServices:list', params),
    get: (id) => ipcRenderer.invoke('otherServices:get', id),
    create: (payload) => ipcRenderer.invoke('otherServices:create', payload),
    update: (id, payload) => ipcRenderer.invoke('otherServices:update', id, payload),
    delete: (id) => ipcRenderer.invoke('otherServices:delete', id),
    serviceTypes: () => ipcRenderer.invoke('otherServices:serviceTypes'),
    statuses: () => ipcRenderer.invoke('otherServices:statuses')
  },
  tasks: {
    list: (params) => ipcRenderer.invoke('tasks:list', params),
    get: (id) => ipcRenderer.invoke('tasks:get', id),
    dueSoon: (days) => ipcRenderer.invoke('tasks:dueSoon', days),
    create: (payload) => ipcRenderer.invoke('tasks:create', payload),
    update: (id, payload) => ipcRenderer.invoke('tasks:update', id, payload),
    markStatus: (id, status) => ipcRenderer.invoke('tasks:markStatus', id, status),
    delete: (id) => ipcRenderer.invoke('tasks:delete', id),
    priorities: () => ipcRenderer.invoke('tasks:priorities'),
    statuses: () => ipcRenderer.invoke('tasks:statuses')
  },
  deadlines: {
    list: (params) => ipcRenderer.invoke('deadlines:list', params),
    get: (id) => ipcRenderer.invoke('deadlines:get', id),
    dueSoon: (days) => ipcRenderer.invoke('deadlines:dueSoon', days),
    create: (payload) => ipcRenderer.invoke('deadlines:create', payload),
    update: (id, payload) => ipcRenderer.invoke('deadlines:update', id, payload),
    markStatus: (id, status) => ipcRenderer.invoke('deadlines:markStatus', id, status),
    delete: (id) => ipcRenderer.invoke('deadlines:delete', id),
    types: () => ipcRenderer.invoke('deadlines:types'),
    statuses: () => ipcRenderer.invoke('deadlines:statuses')
  },
  calendar: {
    list: (params) => ipcRenderer.invoke('calendar:list', params),
    eventTypes: () => ipcRenderer.invoke('calendar:eventTypes')
  }
});
