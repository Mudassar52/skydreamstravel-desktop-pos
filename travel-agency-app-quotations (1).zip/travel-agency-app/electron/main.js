const { app, BrowserWindow } = require('electron');
const path = require('path');
const { initDatabase } = require('../src/database/db');
const { registerIpcHandlers } = require('./ipc/handlers');
const authService = require('./services/authService');
const invoiceTemplateService = require('./services/invoiceTemplateService');
const documentService = require('./services/documentService');
const backupService = require('./services/backupService');

let mainWindow = null;
const isDev = process.env.NODE_ENV === 'development';

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1180,
    minHeight: 720,
    backgroundColor: '#F4F7FB',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  initDatabase(app.getPath('userData'));
  documentService.initStorage(app.getPath('userData'));
  authService.ensureDefaults();
  invoiceTemplateService.ensureDefaultTemplate();
  registerIpcHandlers();
  createWindow();

  // Fire-and-forget: scan for overdue payments, deadlines, follow-ups etc.
  // and create notifications for anything new (Section 55). Never blocks
  // startup, and generate() is idempotent so this is safe to run every launch.
  try {
    require('./services/notificationService').generate();
  } catch (err) {
    console.error('Notification generation failed:', err);
  }

  // Fire-and-forget: don't let a backup problem block app startup.
  backupService.runAutomaticBackupIfDue().catch((err) => console.error('Automatic backup failed:', err));

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
