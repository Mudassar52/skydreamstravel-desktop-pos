COMPANY LOGO - yahan daalo (src/assets/)
========================================
      logo-icon.png   <- har jagah dikhta hai (sidebar, header, login)
      logo.png        <- sirf sidebar collapse hone par dikhta hai

jpg / jpeg / webp / svg bhi chalte hain. Files rakhne ke baad app restart karo.
Agar sirf ek file ho to wahi dono jagah use ho jati hai. Koi na ho to plane icon dikhta hai.
