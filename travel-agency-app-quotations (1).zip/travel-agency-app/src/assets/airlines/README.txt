Airline logos yahan daalo (PNG / SVG / JPG / WEBP).
File ka naam airline ke naam jaisa lowercase me rakho, spaces ki jagah "-":
  pia.png, emirates.png, saudi-airlines.png, qatar-airways.png, airblue.png
Match na mile to dashboard me plane icon dikhega.

NOTE: is folder ki maujooda PNG files sirf placeholder badges hain (airline ka 2-letter code).
Asli logo ki PNG isi naam se paste karke replace kar do.
