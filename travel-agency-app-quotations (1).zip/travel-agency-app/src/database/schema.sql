-- =========================================================================
-- Travel Agency Manager - Core Database Schema (Phase 2)
-- SQLite. Foreign keys enforced. Extend via numbered migration files,
-- never by editing this file after release (see migrations/ folder).
-- =========================================================================

PRAGMA foreign_keys = ON;

-- ---------- Users, Roles, Permissions (Phase 3) --------------------------
CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,              -- Admin, Manager, Staff
  description TEXT
);

CREATE TABLE IF NOT EXISTS permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  module TEXT NOT NULL,                   -- customers, bookings, invoices, ...
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  can_view INTEGER NOT NULL DEFAULT 0,
  can_create INTEGER NOT NULL DEFAULT 0,
  can_edit INTEGER NOT NULL DEFAULT 0,
  can_delete INTEGER NOT NULL DEFAULT 0,
  UNIQUE(module, role_id)
);

-- ---------- Role Capabilities (ERP upgrade, Phase 9) -----------------------
-- Global, cross-module capabilities distinct from the per-module CRUD matrix
-- above (master prompt section 48: "View Profit", "View Supplier Costs",
-- "Export Reports" - financial-sensitivity flags that apply everywhere
-- profit/cost figures or export buttons appear, not to one module).
CREATE TABLE IF NOT EXISTS role_capabilities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  capability TEXT NOT NULL,
  granted INTEGER NOT NULL DEFAULT 0,
  UNIQUE(role_id, capability)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role_id INTEGER REFERENCES roles(id),
  phone TEXT,
  email TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Customers (Phase 4) -------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  father_husband_name TEXT,
  cnic TEXT,
  passport_number TEXT,
  passport_issue_date TEXT,
  passport_expiry_date TEXT,
  date_of_birth TEXT,
  gender TEXT,
  nationality TEXT,
  phone TEXT,
  whatsapp TEXT,
  email TEXT,
  address TEXT,
  emergency_contact TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  profile_picture_path TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(full_name);
CREATE INDEX IF NOT EXISTS idx_customers_cnic ON customers(cnic);
CREATE INDEX IF NOT EXISTS idx_customers_passport ON customers(passport_number);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

-- ---------- Packages: Umrah / Hajj / Tours (Phase 5) ----------------------
CREATE TABLE IF NOT EXISTS umrah_packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  package_type TEXT,
  departure_date TEXT,
  return_date TEXT,
  number_of_days INTEGER,
  visa_included INTEGER DEFAULT 0,
  flight_included INTEGER DEFAULT 0,
  hotel_included INTEGER DEFAULT 0,
  transport_included INTEGER DEFAULT 0,
  food_included INTEGER DEFAULT 0,
  ziyarat_included INTEGER DEFAULT 0,
  makkah_hotel TEXT,
  madinah_hotel TEXT,
  makkah_nights INTEGER,
  madinah_nights INTEGER,
  transport_details TEXT,
  package_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS umrah_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_name TEXT NOT NULL,
  package_id INTEGER REFERENCES umrah_packages(id),
  departure_date TEXT,
  return_date TEXT,
  total_passengers INTEGER DEFAULT 0,
  flight_id INTEGER,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Added alongside Phase 5 (group passenger lists were listed in the spec
-- but the group tables above only stored a headcount).
CREATE TABLE IF NOT EXISTS umrah_group_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES umrah_groups(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hajj_packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  departure_date TEXT,
  return_date TEXT,
  makkah_hotel TEXT,
  madinah_hotel TEXT,
  package_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hajj_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_name TEXT NOT NULL,
  package_id INTEGER REFERENCES hajj_packages(id),
  departure_date TEXT,
  return_date TEXT,
  total_pilgrims INTEGER DEFAULT 0,
  total_seats INTEGER DEFAULT 0,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hajj_group_pilgrims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES hajj_groups(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tours (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_name TEXT NOT NULL,
  destination TEXT,
  country TEXT,
  city TEXT,
  start_date TEXT,
  end_date TEXT,
  duration TEXT,
  total_seats INTEGER DEFAULT 0,
  available_seats INTEGER DEFAULT 0,
  package_price REAL DEFAULT 0,
  hotel TEXT,
  transport TEXT,
  meals TEXT,
  activities TEXT,
  guide TEXT,
  description TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tour_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tour_id INTEGER NOT NULL REFERENCES tours(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT
);

-- ---------- Bookings (Phase 6) --------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_code TEXT NOT NULL UNIQUE,
  booking_date TEXT NOT NULL DEFAULT (datetime('now')),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_type TEXT NOT NULL,          -- Umrah, Hajj, Tour, Flight, Hotel, Visa, Custom
  reference_id INTEGER,                -- id in the relevant package/group table
  departure_date TEXT,
  return_date TEXT,
  number_of_passengers INTEGER DEFAULT 1,
  total_price REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Inquiry', -- Inquiry, Pending, Confirmed, Cancelled, Completed
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bookings_customer ON bookings(customer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_type ON bookings(booking_type);

CREATE TABLE IF NOT EXISTS booking_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  notes TEXT
);

-- ---------- Flights / Hotels / Visa / Transportation (Phase 7) -----------
CREATE TABLE IF NOT EXISTS flights (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  airline TEXT,
  flight_number TEXT,
  pnr TEXT,
  departure_airport TEXT,
  arrival_airport TEXT,
  departure_date TEXT,
  departure_time TEXT,
  arrival_date TEXT,
  arrival_time TEXT,
  class TEXT,
  ticket_number TEXT,
  status TEXT DEFAULT 'Confirmed',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS flight_passengers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  flight_id INTEGER NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS hotels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  hotel_name TEXT NOT NULL,
  country TEXT,
  city TEXT,
  address TEXT,
  contact TEXT,
  check_in TEXT,
  check_out TEXT,
  room_type TEXT,
  number_of_rooms INTEGER DEFAULT 1,
  number_of_nights INTEGER DEFAULT 1,
  booking_reference TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS visa_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  country TEXT,
  visa_type TEXT,
  application_date TEXT,
  submission_date TEXT,
  approval_date TEXT,
  expiry_date TEXT,
  application_number TEXT,
  status TEXT DEFAULT 'Documents Pending',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_visa_status ON visa_applications(status);
CREATE INDEX IF NOT EXISTS idx_visa_expiry ON visa_applications(expiry_date);

CREATE TABLE IF NOT EXISTS transportation (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER REFERENCES bookings(id),
  vehicle TEXT,
  vehicle_number TEXT,
  driver TEXT,
  driver_phone TEXT,
  pickup_location TEXT,
  drop_location TEXT,
  pickup_date TEXT,
  pickup_time TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  status TEXT DEFAULT 'Scheduled',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Invoices + Template Engine (Phase 8) --------------------------
CREATE TABLE IF NOT EXISTS invoice_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  template_name TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  config_json TEXT NOT NULL,   -- serialized layout/design config; visual design lives here only
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_date TEXT NOT NULL DEFAULT (datetime('now')),
  due_date TEXT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  template_id INTEGER REFERENCES invoice_templates(id),
  subtotal REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Unpaid',  -- Unpaid, Partially Paid, Paid, Cancelled
  notes TEXT,
  terms TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);

CREATE TABLE IF NOT EXISTS invoice_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity REAL NOT NULL DEFAULT 1,
  unit_price REAL NOT NULL DEFAULT 0,
  line_total REAL NOT NULL DEFAULT 0
);

-- ---------- Payments (Phase 9) --------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_id INTEGER REFERENCES invoices(id),
  payment_date TEXT NOT NULL DEFAULT (datetime('now')),
  amount REAL NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'Cash', -- Cash, Bank Transfer, Card, Online Transfer, Other
  payment_type TEXT NOT NULL DEFAULT 'Partial', -- Advance, Partial, Full, Refund
  reference TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments(customer_id);
-- Phase 10 (performance): advanceService's availableAdvances/listAll look up
-- STANDALONE advances (payment_type = 'Advance' AND booking_id IS NULL). A
-- plain index on payment_type was tried first and made Customer 360 ~25x
-- slower: 'Advance' is roughly a third of all payments, and the planner picked
-- that low-selectivity index over idx_payments_booking for the per-booking
-- advance subqueries. A PARTIAL index fixes both - it is only considered for
-- queries whose WHERE implies the same condition (the advance list queries),
-- and it only contains those few rows, so nothing else is affected.
DROP INDEX IF EXISTS idx_payments_type;
CREATE INDEX IF NOT EXISTS idx_payments_standalone_advance ON payments(customer_id, payment_date)
  WHERE payment_type = 'Advance' AND booking_id IS NULL;

-- ---------- Customer Advance Applications (ERP upgrade, Phase 5) ----------
-- One row per time an unapplied Advance payment is allocated to an invoice.
-- The source payment row (payments.amount) is never edited - this table is
-- the traceable ledger of how much of it has been consumed and where, so an
-- advance can be applied partially, to more than one invoice over time,
-- and can never be double counted (available = amount - SUM(applied)).
CREATE TABLE IF NOT EXISTS advance_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id INTEGER NOT NULL REFERENCES payments(id),
  invoice_id INTEGER NOT NULL REFERENCES invoices(id),
  amount REAL NOT NULL,
  applied_at TEXT NOT NULL DEFAULT (datetime('now')),
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_advance_app_payment ON advance_applications(payment_id);
CREATE INDEX IF NOT EXISTS idx_advance_app_invoice ON advance_applications(invoice_id);

-- ---------- Customer Ledger (Phase 9) -------------------------------------
CREATE TABLE IF NOT EXISTS ledger_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  description TEXT,
  invoice_id INTEGER REFERENCES invoices(id),
  payment_id INTEGER REFERENCES payments(id),
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  running_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_customer ON ledger_entries(customer_id);

-- ---------- Expenses (Phase 10) -------------------------------------------
CREATE TABLE IF NOT EXISTS expense_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_date TEXT NOT NULL DEFAULT (datetime('now')),
  category_id INTEGER REFERENCES expense_categories(id),
  description TEXT,
  amount REAL NOT NULL,
  payment_method TEXT DEFAULT 'Cash',
  related_booking_id INTEGER REFERENCES bookings(id),
  related_package_type TEXT,
  related_package_id INTEGER,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);

-- ---------- Documents (Phase 11) ------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  document_type TEXT,     -- CNIC, Passport, Visa, Ticket, Voucher, Receipt, Other
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
  notes TEXT
);

-- ---------- Settings (Phase 13) -------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

-- ---------- Audit Log (Phase 15) ------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),
  action TEXT NOT NULL,
  record_type TEXT,
  record_id INTEGER,
  description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Custom Report Builder: History + Templates (ERP upgrade, Phase 6) ----
CREATE TABLE IF NOT EXISTS report_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_name TEXT NOT NULL,
  report_type TEXT NOT NULL,
  user_id INTEGER REFERENCES users(id),
  spec TEXT NOT NULL,             -- JSON: the full report spec (selection, dateField, range, sections, filters) so it can be reopened/regenerated exactly
  date_from TEXT,
  date_to TEXT,
  generated_format TEXT,          -- 'Preview' | 'PDF' | 'CSV' | 'Print'
  related_customer_id INTEGER REFERENCES customers(id),
  related_supplier_id INTEGER REFERENCES suppliers(id),
  related_booking_id INTEGER REFERENCES bookings(id),
  file_reference TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_report_history_type ON report_history(report_type);

CREATE TABLE IF NOT EXISTS report_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  report_type TEXT NOT NULL,
  spec TEXT NOT NULL,              -- JSON: the saved selection/date-field/sections configuration (not the data itself)
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- CRM: Leads, Travellers, Follow-ups (Phase 19) -----------------
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_code TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  source TEXT,
  destination TEXT,
  travel_date TEXT,
  service_type TEXT,
  assigned_agent_id INTEGER REFERENCES users(id),
  estimated_value REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'New',   -- New, Contacted, Qualified, Quotation Sent, Negotiation, Converted, Lost
  priority TEXT NOT NULL DEFAULT 'Medium', -- Low, Medium, High
  converted_customer_id INTEGER REFERENCES customers(id),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_agent ON leads(assigned_agent_id);

CREATE TABLE IF NOT EXISTS lead_activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL,   -- Note, StatusChange, Call, Email, Conversion
  description TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_lead_activities_lead ON lead_activities(lead_id);

-- Travellers: distinct from customers so a customer/lead can travel with
-- companions who aren't themselves customer records.
CREATE TABLE IF NOT EXISTS travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER REFERENCES customers(id),  -- the "owning" customer/account
  full_name TEXT NOT NULL,
  relationship TEXT,             -- Self, Spouse, Child, Parent, Other
  date_of_birth TEXT,
  gender TEXT,
  nationality TEXT,
  passport_number TEXT,
  passport_issue_date TEXT,
  passport_expiry_date TEXT,
  visa_status TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_travellers_customer ON travellers(customer_id);
CREATE INDEX IF NOT EXISTS idx_travellers_passport ON travellers(passport_number);

CREATE TABLE IF NOT EXISTS booking_travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  traveller_id INTEGER NOT NULL REFERENCES travellers(id),
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_booking_travellers_booking ON booking_travellers(booking_id);

-- Which of a booking's travellers are on which flight (flight_passengers above stays for stand-alone customers).
CREATE TABLE IF NOT EXISTS flight_travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  flight_id INTEGER NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
  traveller_id INTEGER NOT NULL REFERENCES travellers(id),
  UNIQUE (flight_id, traveller_id)
);
CREATE INDEX IF NOT EXISTS idx_flight_travellers_flight ON flight_travellers(flight_id);

-- Guest list + room allocation for a hotel stay. traveller_id NULL + is_lead = 1 is the booking's lead customer.
CREATE TABLE IF NOT EXISTS hotel_guests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id INTEGER NOT NULL REFERENCES hotels(id) ON DELETE CASCADE,
  traveller_id INTEGER REFERENCES travellers(id),
  is_lead INTEGER NOT NULL DEFAULT 0,
  room_number TEXT
);
CREATE INDEX IF NOT EXISTS idx_hotel_guests_hotel ON hotel_guests(hotel_id);

CREATE TABLE IF NOT EXISTS follow_ups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  follow_up_date TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id),
  lead_id INTEGER REFERENCES leads(id),
  booking_id INTEGER REFERENCES bookings(id),
  assigned_user_id INTEGER REFERENCES users(id),
  priority TEXT NOT NULL DEFAULT 'Medium',
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, Completed, Overdue, Cancelled
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_followups_date ON follow_ups(follow_up_date);
CREATE INDEX IF NOT EXISTS idx_followups_status ON follow_ups(status);

-- One row per contact actually made (call / WhatsApp / visit...). Powers the Follow-up History page.
CREATE TABLE IF NOT EXISTS follow_up_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  follow_up_id INTEGER REFERENCES follow_ups(id) ON DELETE SET NULL,
  next_follow_up_id INTEGER REFERENCES follow_ups(id) ON DELETE SET NULL,
  customer_id INTEGER REFERENCES customers(id),
  lead_id INTEGER REFERENCES leads(id),
  booking_id INTEGER REFERENCES bookings(id),
  contact_name TEXT,
  contact_phone TEXT,
  reference_code TEXT,
  contact_method TEXT,
  activity TEXT,
  purpose TEXT,
  outcome TEXT,
  notes TEXT,
  next_follow_up_date TEXT,
  reminder_time TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_fulogs_customer ON follow_up_logs(customer_id);
CREATE INDEX IF NOT EXISTS idx_fulogs_lead ON follow_up_logs(lead_id);
CREATE INDEX IF NOT EXISTS idx_fulogs_created ON follow_up_logs(created_at);

-- ---------- Sales: Quotations, generic Packages (Phase 19) ----------------
CREATE TABLE IF NOT EXISTS quotations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quotation_number TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  lead_id INTEGER REFERENCES leads(id),
  destination TEXT,
  travel_date_from TEXT,
  travel_date_to TEXT,
  supplier_id INTEGER REFERENCES suppliers(id),
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  markup REAL DEFAULT 0,
  discount REAL DEFAULT 0,
  tax REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Draft', -- Draft, Sent, Accepted, Rejected, Expired, Converted
  notes TEXT,
  terms TEXT,
  converted_booking_id INTEGER REFERENCES bookings(id),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_quotations_customer ON quotations(customer_id);
CREATE INDEX IF NOT EXISTS idx_quotations_status ON quotations(status);

-- Service rows of a quotation (flight / hotel / visa / transport / package / other).
-- cost_price is INTERNAL (per unit) and only returned to roles with View Profit.
-- details holds optional Umrah fields as JSON (makkah_hotel, madinah_hotel, room_type, hotel_nights,
-- visa_details, transport_type, ziyarat).
CREATE TABLE IF NOT EXISTS quotation_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quotation_id INTEGER NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  category TEXT NOT NULL DEFAULT 'Other',
  name TEXT NOT NULL,
  description TEXT,
  service_date TEXT,
  quantity REAL NOT NULL DEFAULT 1,
  unit TEXT,
  unit_price REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0,
  line_total REAL NOT NULL DEFAULT 0,
  cost_price REAL NOT NULL DEFAULT 0,
  details TEXT
);
CREATE INDEX IF NOT EXISTS idx_quotation_items_quotation ON quotation_items(quotation_id);

CREATE TABLE IF NOT EXISTS quotation_travellers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quotation_id INTEGER NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
  traveller_id INTEGER NOT NULL REFERENCES travellers(id)
);

-- Generic sellable packages (distinct from the Umrah/Hajj/Tour package
-- tables, which stay as-is): flexible multi-component packages that can be
-- inserted into a quotation/booking.
CREATE TABLE IF NOT EXISTS packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_name TEXT NOT NULL,
  destination TEXT,
  duration TEXT,
  description TEXT,
  supplier_cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  markup REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS package_components (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_id INTEGER NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
  component_type TEXT NOT NULL, -- Flight, Hotel, Transport, Visa, Ziyarat, Meals, Insurance, Other
  description TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_package_components_package ON package_components(package_id);

-- ---------- Suppliers + Ledger (Phase 19) ----------------------------------
CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  company TEXT,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  service_type TEXT,  -- Airline, Hotel, Transport, Visa Agent, Tour Operator, Other
  currency TEXT DEFAULT 'PKR',
  payment_terms TEXT,
  opening_balance REAL DEFAULT 0,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_suppliers_name ON suppliers(name);
CREATE INDEX IF NOT EXISTS idx_suppliers_type ON suppliers(service_type);

CREATE TABLE IF NOT EXISTS supplier_invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_number TEXT NOT NULL,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_date TEXT NOT NULL DEFAULT (datetime('now')),
  due_date TEXT,
  currency TEXT DEFAULT 'PKR',
  amount REAL NOT NULL DEFAULT 0,
  tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  remaining_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Unpaid', -- Unpaid, Partially Paid, Paid, Overdue
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_supplier_invoices_supplier ON supplier_invoices(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_invoices_status ON supplier_invoices(status);
CREATE INDEX IF NOT EXISTS idx_supplier_invoices_booking ON supplier_invoices(booking_id);

CREATE TABLE IF NOT EXISTS supplier_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  booking_id INTEGER REFERENCES bookings(id),
  supplier_invoice_id INTEGER REFERENCES supplier_invoices(id),
  payment_date TEXT NOT NULL DEFAULT (datetime('now')),
  amount REAL NOT NULL,
  currency TEXT DEFAULT 'PKR',
  payment_method TEXT NOT NULL DEFAULT 'Bank Transfer',
  account_type TEXT,        -- Bank, Cash
  account_id INTEGER,       -- references bank_accounts.id or cash_accounts.id depending on account_type
  reference TEXT,
  notes TEXT,
  staff_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_invoice ON supplier_payments(supplier_invoice_id);
-- Phase 10 (performance): bookingDossierService.supplierCosts and
-- supplier360Service.bookings both filter supplier_payments by booking_id.
CREATE INDEX IF NOT EXISTS idx_supplier_payments_booking ON supplier_payments(booking_id);

-- ---------- Supplier Advance Applications (ERP upgrade, Phase 5) ---------
-- Mirrors advance_applications for the supplier side: how much of an
-- unapplied supplier advance (a supplier_payment with no supplier_invoice_id)
-- has been allocated against a real supplier invoice.
CREATE TABLE IF NOT EXISTS supplier_advance_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_payment_id INTEGER NOT NULL REFERENCES supplier_payments(id),
  supplier_invoice_id INTEGER NOT NULL REFERENCES supplier_invoices(id),
  amount REAL NOT NULL,
  applied_at TEXT NOT NULL DEFAULT (datetime('now')),
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_supplier_advance_app_payment ON supplier_advance_applications(supplier_payment_id);
CREATE INDEX IF NOT EXISTS idx_supplier_advance_app_invoice ON supplier_advance_applications(supplier_invoice_id);

-- Supplier ledger works the same way as customer ledger_entries: one row
-- per financial event, running_balance computed server-side.
CREATE TABLE IF NOT EXISTS supplier_ledger_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  description TEXT,
  supplier_invoice_id INTEGER REFERENCES supplier_invoices(id),
  supplier_payment_id INTEGER REFERENCES supplier_payments(id),
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  running_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_supplier_ledger_supplier ON supplier_ledger_entries(supplier_id);

-- ---------- Operations: Other Services, Tasks, Deadlines (Phase 19) -------
CREATE TABLE IF NOT EXISTS other_services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_type TEXT NOT NULL, -- Ziyarat, Meals, Insurance, Tours, Excursions, Guide, Tickets, Miscellaneous
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  traveller_id INTEGER REFERENCES travellers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  description TEXT,
  service_date TEXT,
  cost REAL DEFAULT 0,
  selling_price REAL DEFAULT 0,
  currency TEXT DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'Pending',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_other_services_booking ON other_services(booking_id);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  assigned_user_id INTEGER REFERENCES users(id),
  priority TEXT NOT NULL DEFAULT 'Medium',
  due_date TEXT,
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, In Progress, Completed, Overdue, Cancelled
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_user_id);

-- Deadline engine: one row per deadline instance, any booking/traveller-
-- related deadline type. Reminder thresholds are computed at query time
-- from due_date, not stored.
CREATE TABLE IF NOT EXISTS deadlines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  deadline_type TEXT NOT NULL, -- Reservation, Ticketing, Payment, Cancellation, HotelCancellation, Visa, Confirmation
  title TEXT,
  due_date TEXT NOT NULL,
  booking_id INTEGER REFERENCES bookings(id),
  traveller_id INTEGER REFERENCES travellers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, Completed, Overdue, Cancelled
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_deadlines_due ON deadlines(due_date);
CREATE INDEX IF NOT EXISTS idx_deadlines_booking ON deadlines(booking_id);
CREATE INDEX IF NOT EXISTS idx_deadlines_status ON deadlines(status);

-- ---------- Finance: Bank/Cash accounts, Refunds, Accounting (Phase 19) ---
CREATE TABLE IF NOT EXISTS bank_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_name TEXT NOT NULL,
  bank_name TEXT,
  account_number TEXT,
  currency TEXT DEFAULT 'PKR',
  opening_balance REAL DEFAULT 0,
  current_balance REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cash_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_name TEXT NOT NULL,
  currency TEXT DEFAULT 'PKR',
  opening_balance REAL DEFAULT 0,
  current_balance REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Unified transaction log for both bank and cash accounts, so a statement
-- for either account type is one query away.
CREATE TABLE IF NOT EXISTS account_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_type TEXT NOT NULL,  -- Bank, Cash
  account_id INTEGER NOT NULL, -- bank_accounts.id or cash_accounts.id
  transaction_date TEXT NOT NULL DEFAULT (datetime('now')),
  transaction_type TEXT NOT NULL, -- Deposit, Withdrawal, CustomerPayment, SupplierPayment, Expense, Transfer, Refund
  amount REAL NOT NULL,
  direction TEXT NOT NULL,     -- In, Out
  reference_type TEXT,         -- payments, supplier_payments, expenses, refunds, manual
  reference_id INTEGER,
  description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_account_txn_account ON account_transactions(account_type, account_id);
CREATE INDEX IF NOT EXISTS idx_account_txn_date ON account_transactions(transaction_date);

CREATE TABLE IF NOT EXISTS refunds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  booking_id INTEGER REFERENCES bookings(id),
  invoice_id INTEGER REFERENCES invoices(id),
  payment_id INTEGER REFERENCES payments(id),
  refund_amount REAL NOT NULL,
  refund_date TEXT NOT NULL DEFAULT (datetime('now')),
  reason TEXT,
  payment_method TEXT DEFAULT 'Bank Transfer',
  account_type TEXT,
  account_id INTEGER,
  notes TEXT,
  staff_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_refunds_customer ON refunds(customer_id);

-- Generic double-entry-style accounting log covering every module, so
-- reports can be built off one table instead of reconstructing history
-- from payments/expenses/invoices separately.
CREATE TABLE IF NOT EXISTS accounting_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_date TEXT NOT NULL DEFAULT (datetime('now')),
  account TEXT NOT NULL,      -- e.g. 'Cash', 'Bank - HBL', 'Customer Receivable', 'Supplier Payable', 'Revenue', 'Expense'
  debit REAL NOT NULL DEFAULT 0,
  credit REAL NOT NULL DEFAULT 0,
  reference TEXT,
  booking_id INTEGER REFERENCES bookings(id),
  customer_id INTEGER REFERENCES customers(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  payment_id INTEGER REFERENCES payments(id),
  expense_id INTEGER REFERENCES expenses(id),
  is_reversal INTEGER NOT NULL DEFAULT 0,
  reversed_entry_id INTEGER REFERENCES accounting_entries(id),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_accounting_date ON accounting_entries(entry_date);
CREATE INDEX IF NOT EXISTS idx_accounting_booking ON accounting_entries(booking_id);

-- ---------- Notifications + Saved Filters (Phase 19) -----------------------
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  notif_type TEXT NOT NULL,   -- PaymentOverdue, SupplierPaymentPending, VisaDeadline, PassportExpiry, FlightDeadline, HotelDeadline, FollowUpDue, TaskOverdue, MissingDocument, BookingConfirmationPending
  title TEXT NOT NULL,
  message TEXT,
  record_type TEXT,           -- table name of the linked record
  record_id INTEGER,
  user_id INTEGER REFERENCES users(id), -- NULL = visible to all
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at);

CREATE TABLE IF NOT EXISTS saved_filters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  module TEXT NOT NULL,       -- which screen this filter applies to (bookings, invoices, ...)
  filter_json TEXT NOT NULL,  -- serialized filter configuration
  user_id INTEGER REFERENCES users(id), -- NULL = shared/global filter
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_saved_filters_module ON saved_filters(module);

-- ---------- Performance indexes (Phase 16) --------------------------------
-- Foreign-key/join columns that were queried frequently by Phases 6-15 but
-- had no index, which matters once a real agency has thousands of rows
-- (Section 38: 5,000+ bookings, 10,000+ invoices). Additive - safe to run
-- against a database created by any earlier phase.
CREATE INDEX IF NOT EXISTS idx_flights_booking ON flights(booking_id);
CREATE INDEX IF NOT EXISTS idx_flight_passengers_flight ON flight_passengers(flight_id);
CREATE INDEX IF NOT EXISTS idx_hotels_booking ON hotels(booking_id);
CREATE INDEX IF NOT EXISTS idx_visa_customer ON visa_applications(customer_id);
CREATE INDEX IF NOT EXISTS idx_visa_booking ON visa_applications(booking_id);
CREATE INDEX IF NOT EXISTS idx_transportation_booking ON transportation(booking_id);
CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_invoices_booking ON invoices(booking_id);
CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(invoice_date);
CREATE INDEX IF NOT EXISTS idx_payments_invoice ON payments(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_booking ON payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_ledger_invoice ON ledger_entries(invoice_id);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category_id);
CREATE INDEX IF NOT EXISTS idx_expenses_booking ON expenses(related_booking_id);
CREATE INDEX IF NOT EXISTS idx_documents_customer ON documents(customer_id);
CREATE INDEX IF NOT EXISTS idx_documents_booking ON documents(booking_id);
CREATE INDEX IF NOT EXISTS idx_umrah_groups_package ON umrah_groups(package_id);
CREATE INDEX IF NOT EXISTS idx_umrah_group_passengers_group ON umrah_group_passengers(group_id);
CREATE INDEX IF NOT EXISTS idx_hajj_groups_package ON hajj_groups(package_id);
CREATE INDEX IF NOT EXISTS idx_hajj_group_pilgrims_group ON hajj_group_pilgrims(group_id);
CREATE INDEX IF NOT EXISTS idx_tour_passengers_tour ON tour_passengers(tour_id);
CREATE INDEX IF NOT EXISTS idx_booking_passengers_booking ON booking_passengers(booking_id);

-- ---------- Performance indexes (ERP upgrade, Phase 10) -------------------
-- (The supplier_id indexes on flights/hotels/visa_applications/transportation/
-- other_services live in db.js's ensurePostMigrationIndexes(), NOT here:
-- supplier_id on those tables is added by addMissingColumns(), which runs
-- AFTER this file, so an index on it can't be created from schema.sql.)
-- hotels.check_in/check_out are filtered directly (not wrapped in strftime)
-- by dashboardService.getCalendarEvents and the Travel Operations report.
CREATE INDEX IF NOT EXISTS idx_hotels_checkin ON hotels(check_in);
CREATE INDEX IF NOT EXISTS idx_hotels_checkout ON hotels(check_out);
CREATE INDEX IF NOT EXISTS idx_bookings_departure ON bookings(departure_date);
CREATE INDEX IF NOT EXISTS idx_bookings_return ON bookings(return_date);
CREATE INDEX IF NOT EXISTS idx_supplier_invoices_date ON supplier_invoices(invoice_date);
-- Supports the duplicate-invoice-number check. Deliberately NOT unique: an existing
-- database may already contain duplicates, and a UNIQUE index would stop the app starting.
CREATE INDEX IF NOT EXISTS idx_supplier_invoices_number ON supplier_invoices(supplier_id, invoice_number);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_record_type ON audit_logs(record_type);


-- ---------- Exchange rates (Phase 21) --------------------------------------
-- Admin-entered rates only - nothing is hard-coded or fetched. A row says:
-- 1 unit of from_currency = `rate` units of to_currency, from effective_date
-- onward (until a newer row for the same pair replaces it). Rows are never
-- edited, only added or deleted, so past conversions stay explainable.
CREATE TABLE IF NOT EXISTS exchange_rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_currency TEXT NOT NULL,
  to_currency TEXT NOT NULL,
  rate REAL NOT NULL CHECK (rate > 0),
  effective_date TEXT NOT NULL,
  notes TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_exchange_rates_pair ON exchange_rates(from_currency, to_currency, effective_date);

-- ---------- Agents & Commissions (Phase 21) --------------------------------
CREATE TABLE IF NOT EXISTS agents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_code TEXT NOT NULL UNIQUE,            -- AG-0001
  name TEXT NOT NULL,
  company TEXT,
  phone TEXT,
  email TEXT,
  city TEXT,
  address TEXT,
  commission_type TEXT NOT NULL DEFAULT 'Percentage',  -- Percentage, Fixed
  commission_value REAL NOT NULL DEFAULT 0,             -- % of booking total, or a fixed amount per booking
  status TEXT NOT NULL DEFAULT 'Active',                -- Active, Inactive
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_agents_name ON agents(name);

-- One commission per (agent, booking). base_amount/rate are FROZEN at the
-- moment the commission is created so editing the agent's default rate later
-- never silently changes commissions that were already promised.
CREATE TABLE IF NOT EXISTS commissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id INTEGER NOT NULL REFERENCES agents(id),
  booking_id INTEGER NOT NULL REFERENCES bookings(id),
  base_amount REAL NOT NULL DEFAULT 0,
  commission_type TEXT NOT NULL DEFAULT 'Percentage',
  commission_value REAL NOT NULL DEFAULT 0,
  commission_amount REAL NOT NULL DEFAULT 0,
  currency TEXT,
  status TEXT NOT NULL DEFAULT 'Pending',     -- Pending, Approved, Paid, Cancelled
  approved_date TEXT,
  paid_date TEXT,
  payment_method TEXT,
  account_type TEXT,
  account_id INTEGER,
  expense_id INTEGER REFERENCES expenses(id),
  notes TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_commissions_agent ON commissions(agent_id);
CREATE INDEX IF NOT EXISTS idx_commissions_booking ON commissions(booking_id);
CREATE INDEX IF NOT EXISTS idx_commissions_status ON commissions(status);

-- ---------- Period lock & year-end close (Phase 21c) -----------------------
-- A close date means: everything up to and including that date is final. Records dated on or before it can no longer
-- be added, changed, voided or deleted, and the General Ledger gets a closing entry on that date that moves the year's
-- revenue/expenses into Retained Earnings. Closes can only be undone newest-first.
CREATE TABLE IF NOT EXISTS year_end_closes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  close_date TEXT NOT NULL UNIQUE,
  notes TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
