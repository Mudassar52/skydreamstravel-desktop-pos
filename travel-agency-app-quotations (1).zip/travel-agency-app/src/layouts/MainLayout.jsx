import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from '../components/Sidebar.jsx';
import Header from '../components/Header.jsx';
import { NAV_ITEMS, flattenNavItems } from '../utils/navConfig';

const FLAT_NAV_ITEMS = flattenNavItems(NAV_ITEMS);

export default function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const current = FLAT_NAV_ITEMS.find((item) =>
    item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path)
  );

  return (
    <div className="app-shell">
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((c) => !c)} />
      <div className="main-column">
        <Header title={current ? current.label : 'Travel Agency Manager'} />
        <div className="content-area">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
