import { createContext, useContext, useState, useCallback, useMemo } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const login = useCallback(async (username, password) => {
    setLoading(true);
    setError(null);
    try {
      const result = await window.api.auth.login(username, password);
      if (!result.ok) {
        setError(result.error);
        return false;
      }
      setUser(result.data);
      return true;
    } catch (err) {
      setError('Could not reach the application backend.');
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Tell the main process too, so its own session (used for server-side permission checks) ends with the screen's.
  const logout = useCallback(() => { try { window.api.auth.logout(); } catch (_) { /* nothing to clear */ } setUser(null); }, []);

  // can('customers', 'edit') -> true/false. Admin-created permission rows
  // drive this; an unknown module defaults to no access (fail closed).
  const can = useCallback(
    (module, action = 'view') => {
      if (!user) return false;
      const grant = user.permissions?.[module];
      return !!grant?.[action];
    },
    [user]
  );

  // hasCapability('view_profit') -> true/false. Global, cross-module flags
  // (View Profit / View Supplier Costs / Export Reports) distinct from the
  // per-module `can()` above - an unknown capability defaults to no access
  // (fail closed), same philosophy as `can`.
  const hasCapability = useCallback(
    (capability) => {
      if (!user) return false;
      return !!user.capabilities?.[capability];
    },
    [user]
  );

  const value = useMemo(() => ({ user, login, logout, can, hasCapability, error, loading, setError }), [user, login, logout, can, hasCapability, error, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
