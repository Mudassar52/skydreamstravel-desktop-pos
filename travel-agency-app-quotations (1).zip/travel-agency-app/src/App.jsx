import { Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout.jsx';
import Dashboard from './pages/Dashboard.jsx';
import StaffUsers from './pages/StaffUsers.jsx';
import Customers from './pages/Customers.jsx';
import CustomerDossier from './pages/CustomerDossier.jsx';
import SupplierDossier from './pages/SupplierDossier.jsx';
import PackageDossier from './pages/PackageDossier.jsx';
import BookingDossier from './pages/BookingDossier.jsx';
import ReportBuilder from './pages/ReportBuilder.jsx';
import ReportHistory from './pages/ReportHistory.jsx';
import ReportTemplates from './pages/ReportTemplates.jsx';
import CustomerAdvances from './pages/CustomerAdvances.jsx';
import SupplierAdvances from './pages/SupplierAdvances.jsx';
import Leads from './pages/Leads.jsx';
import Travellers from './pages/Travellers.jsx';
import FollowUps from './pages/FollowUps.jsx';
import FollowUpHistory from './pages/FollowUpHistory.jsx';
import Quotations from './pages/Quotations.jsx';
import Packages from './pages/Packages.jsx';
import OtherServices from './pages/OtherServices.jsx';
import Tasks from './pages/Tasks.jsx';
import Deadlines from './pages/Deadlines.jsx';
import UpcomingTravel from './pages/UpcomingTravel.jsx';
import TravelCalendar from './pages/TravelCalendar.jsx';
import BankAccounts from './pages/BankAccounts.jsx';
import CashAccounts from './pages/CashAccounts.jsx';
import Refunds from './pages/Refunds.jsx';
import Accounting from './pages/Accounting.jsx';
import Notifications from './pages/Notifications.jsx';
import Umrah from './pages/Umrah.jsx';
import Hajj from './pages/Hajj.jsx';
import Tours from './pages/Tours.jsx';
import Bookings from './pages/Bookings.jsx';
import Flights from './pages/Flights.jsx';
import Hotels from './pages/Hotels.jsx';
import Visa from './pages/Visa.jsx';
import Transportation from './pages/Transportation.jsx';
import Invoices from './pages/Invoices.jsx';
import InvoiceTemplates from './pages/InvoiceTemplates.jsx';
import Payments from './pages/Payments.jsx';
import Ledger from './pages/Ledger.jsx';
import Expenses from './pages/Expenses.jsx';
import Documents from './pages/Documents.jsx';
import Reports from './pages/Reports.jsx';
import SettingsPage from './pages/Settings.jsx';
import Backup from './pages/Backup.jsx';
import Suppliers from './pages/Suppliers.jsx';
import SupplierLedger from './pages/SupplierLedger.jsx';
import SupplierInvoices from './pages/SupplierInvoices.jsx';
import SupplierPayments from './pages/SupplierPayments.jsx';
import SupplierReports from './pages/SupplierReports.jsx';
import AuditLogs from './pages/AuditLogs.jsx';
import ExchangeRates from './pages/ExchangeRates.jsx';
import PeriodClose from './pages/PeriodClose.jsx';
import Agents from './pages/Agents.jsx';
import Commissions from './pages/Commissions.jsx';
import { GeneralLedgerPage, TrialBalancePage, BalanceSheetPage } from './pages/FinancialStatements.jsx';
import ComingSoon from './pages/ComingSoon.jsx';
import Login from './pages/Login.jsx';
import { NAV_ITEMS, flattenNavItems } from './utils/navConfig';
import { useAuth } from './context/AuthContext.jsx';

const FLAT_NAV_ITEMS = flattenNavItems(NAV_ITEMS);

const IMPLEMENTED_PAGES = {
  '/staff': StaffUsers,
  '/customers': Customers,
  '/leads': Leads,
  '/travellers': Travellers,
  '/followups': FollowUps,
  '/followup-history': FollowUpHistory,
  '/quotations': Quotations,
  '/packages': Packages,
  '/other-services': OtherServices,
  '/tasks': Tasks,
  '/deadlines': Deadlines,
  '/upcoming-travel': UpcomingTravel,
  '/travel-calendar': TravelCalendar,
  '/bank-accounts': BankAccounts,
  '/cash-accounts': CashAccounts,
  '/refunds': Refunds,
  '/accounting': Accounting,
  '/notifications': Notifications,
  '/umrah': Umrah,
  '/hajj': Hajj,
  '/tours': Tours,
  '/bookings': Bookings,
  '/flights': Flights,
  '/hotels': Hotels,
  '/visa': Visa,
  '/transportation': Transportation,
  '/invoices': Invoices,
  '/invoice-templates': InvoiceTemplates,
  '/payments': Payments,
  '/ledger': Ledger,
  '/expenses': Expenses,
  '/documents': Documents,
  '/reports': Reports,
  '/custom-reports': ReportBuilder,
  '/report-history': ReportHistory,
  '/report-templates': ReportTemplates,
  '/customer-advances': CustomerAdvances,
  '/supplier-advances': SupplierAdvances,
  '/settings': SettingsPage,
  '/backup': Backup,
  '/suppliers': Suppliers,
  '/supplier-ledger': SupplierLedger,
  '/supplier-invoices': SupplierInvoices,
  '/supplier-payments': SupplierPayments,
  '/supplier-reports': SupplierReports,
  '/audit-logs': AuditLogs,
  '/exchange-rates': ExchangeRates,
  '/period-close': PeriodClose,
  '/agents': Agents,
  '/commissions': Commissions,
  '/general-ledger': GeneralLedgerPage,
  '/trial-balance': TrialBalancePage,
  '/balance-sheet': BalanceSheetPage
};

function AccessDenied() {
  return (
    <div className="card" style={{ padding: 40, textAlign: 'center' }}>
      <h3>Access denied</h3>
      <p style={{ color: 'var(--color-text-muted)', fontSize: 13 }}>
        Your role doesn't have permission to view this module.
      </p>
    </div>
  );
}

export default function App() {
  const { user, can } = useAuth();

  if (!user) return <Login />;

  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Dashboard />} />
        {Array.from(new Map(FLAT_NAV_ITEMS.filter((item) => item.path !== '/').map((item) => [item.path, item])).values()).map((item) => {
          const Implemented = IMPLEMENTED_PAGES[item.path];
          const allowed = can(item.module, 'view');
          let element;
          if (!allowed) element = <AccessDenied />;
          else if (Implemented) element = <Implemented />;
          else element = <ComingSoon label={item.label} phase={item.phase} />;
          return <Route key={item.path} path={item.path} element={element} />;
        })}
        {/* Detail routes (not sidebar items). Same permission as their parent module. */}
        <Route path="/customers/:customerId/360" element={can('customers', 'view') ? <CustomerDossier /> : <AccessDenied />} />
        <Route path="/suppliers/:supplierId/360" element={can('suppliers', 'view') ? <SupplierDossier /> : <AccessDenied />} />
        <Route path="/packages/:packageId/360" element={can('packages', 'view') ? <PackageDossier /> : <AccessDenied />} />
        <Route path="/bookings/:bookingId/360" element={can('bookings', 'view') ? <BookingDossier /> : <AccessDenied />} />
      </Route>
    </Routes>
  );
}
