import { useCallback, useEffect, useRef, useState } from 'react';

// Loads a paginated IPC list one page at a time with a "load more" action,
// and keeps the server's `total` so the UI can say "showing X of Y" instead
// of quietly showing only the first page. A failed load is surfaced as an
// `error` string - never disguised as an empty list.
//
//   fetchPage({ page, pageSize }) -> { ok, data: { rows, total } } | { ok:false, error }
export function usePagedList(fetchPage, deps = [], pageSize = 25) {
  const [rows, setRows] = useState(null);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState('');
  const [loadingMore, setLoadingMore] = useState(false);
  const pageRef = useRef(1);
  const latest = useRef(0);
  const fetchRef = useRef(fetchPage);
  fetchRef.current = fetchPage; // always call the latest closure without re-triggering the load effect

  const reload = useCallback(async () => {
    const mine = ++latest.current;
    setError('');
    setRows(null);
    pageRef.current = 1;
    const res = await fetchRef.current({ page: 1, pageSize });
    if (mine !== latest.current) return; // superseded by a newer load (filters/ids changed)
    if (!res.ok) { setError(res.error); setRows([]); setTotal(0); return; }
    setRows(res.data.rows);
    setTotal(res.data.total);
  }, [pageSize]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { reload(); }, [reload, ...deps]);

  const loadMore = useCallback(async () => {
    setLoadingMore(true);
    const mine = latest.current;
    const next = pageRef.current + 1;
    const res = await fetchRef.current({ page: next, pageSize });
    setLoadingMore(false);
    if (mine !== latest.current) return; // the list was reloaded meanwhile - drop this stale page
    if (!res.ok) { setError(res.error); return; }
    pageRef.current = next;
    setRows((prev) => [...(prev || []), ...res.data.rows]);
    setTotal(res.data.total);
  }, [pageSize]);

  return { rows, total, error, loadingMore, loadMore, reload };
}
