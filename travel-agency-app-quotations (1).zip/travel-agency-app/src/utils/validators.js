// Lightweight, dependency-free validators shared across the renderer.
// Kept intentionally lenient on format (agency serves multiple nationalities)
// but strict on the things that would corrupt data or break lookups.

export function isRequired(value) {
  return value !== undefined && value !== null && String(value).trim().length > 0;
}

export function isValidEmail(value) {
  if (!value) return true; // optional field
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function isValidPhone(value) {
  if (!value) return true; // optional field
  return /^[+\d][\d\s-]{6,18}$/.test(value.trim());
}

export function isValidDateRange(startDate, endDate) {
  if (!startDate || !endDate) return true;
  return new Date(endDate) >= new Date(startDate);
}

/**
 * Validates the customer form. Returns { valid, errors } where errors is a
 * map of field -> message, ready to show inline under each input.
 */
export function validateCustomer(form) {
  const errors = {};

  if (!isRequired(form.full_name)) errors.full_name = 'Full name is required.';
  if (!isValidEmail(form.email)) errors.email = 'Enter a valid email address.';
  if (!isValidPhone(form.phone)) errors.phone = 'Enter a valid phone number.';
  if (!isValidPhone(form.whatsapp)) errors.whatsapp = 'Enter a valid WhatsApp number.';
  if (!isValidDateRange(form.passport_issue_date, form.passport_expiry_date)) {
    errors.passport_expiry_date = 'Expiry date must be after the issue date.';
  }

  return { valid: Object.keys(errors).length === 0, errors };
}
