// Small display helpers shared by the dashboard's "Upcoming Flights" and
// "Upcoming Umrah" panels.

// Airline logos: drop PNG/SVG/JPG/WEBP files into src/assets/airlines/ named
// after the airline (e.g. pia.png, emirates.png, saudi-airlines.png). Any
// airline without a matching file simply falls back to a plane icon.
const logoFiles = import.meta.glob('../assets/airlines/*.{png,jpg,jpeg,webp,svg}', { eager: true, import: 'default' });

const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

const LOGOS = Object.entries(logoFiles).map(([path, url]) => ({
  key: slug(path.split('/').pop().replace(/\.[^.]+$/, '')),
  url
}));

export function airlineLogo(name) {
  const s = slug(name);
  if (!s) return null;
  const exact = LOGOS.find((l) => l.key === s);
  if (exact) return exact.url;
  const loose = LOGOS.find((l) => l.key.length >= 3 && (s.includes(l.key) || l.key.includes(s)));
  return loose ? loose.url : null;
}

// "Lahore (LHE)" -> { code: 'LHE', name: 'Lahore' }; "LHE" -> { code: 'LHE', name: '' };
// "Allama Iqbal Intl" -> { code: 'ALL', name: 'Allama Iqbal Intl' }
export function parseAirport(raw) {
  const text = String(raw || '').trim();
  if (!text) return { code: '—', name: '' };
  const paren = text.match(/\(([A-Za-z]{3,4})\)/);
  if (paren) return { code: paren[1].toUpperCase(), name: text.replace(paren[0], '').replace(/[-–,]\s*$/, '').trim() };
  const dash = text.match(/^([A-Za-z]{3})\s*[-–:]\s*(.+)$/);
  if (dash) return { code: dash[1].toUpperCase(), name: dash[2].trim() };
  if (/^[A-Za-z]{3,4}$/.test(text)) return { code: text.toUpperCase(), name: '' };
  return { code: text.slice(0, 3).toUpperCase(), name: text };
}

export function parseDay(value) {
  if (!value) return null;
  const [y, m, d] = String(value).slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}

export function daysUntil(value) {
  const day = parseDay(value);
  if (!day) return null;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((day - today) / 86400000);
}

export function countdownLabel(value) {
  const n = daysUntil(value);
  if (n === null) return '';
  if (n < 0) return n === -1 ? 'Yesterday' : `${-n} days ago`;
  if (n === 0) return 'Today';
  if (n === 1) return 'Tomorrow';
  return `in ${n} days`;
}

export function fmtDate(value, withYear = true) {
  const day = parseDay(value);
  if (!day) return '—';
  return day.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', ...(withYear ? { year: 'numeric' } : {}) });
}

export function daysBetween(a, b) {
  const da = parseDay(a);
  const db = parseDay(b);
  if (!da || !db) return null;
  return Math.round((db - da) / 86400000);
}
