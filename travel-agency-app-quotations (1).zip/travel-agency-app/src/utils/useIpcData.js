import { useCallback, useEffect, useRef, useState } from 'react';

// Loads one IPC call and keeps its three honest states apart: loading,
// loaded, FAILED. A failed call is reported as `error` (with `retry`) rather
// than being turned into an empty list, which would look like "no records"
// and hide a real problem (master prompt section 55: loading / error / retry,
// never fail silently).
//
//   fetcher() -> the usual { ok, data } | { ok:false, error } envelope
export function useIpcData(fetcher, deps = []) {
  const [state, setState] = useState({ data: null, error: '', loading: true });
  const fetchRef = useRef(fetcher);
  fetchRef.current = fetcher; // latest closure, without re-triggering the effect
  const latest = useRef(0);

  const run = useCallback(async () => {
    const mine = ++latest.current;
    setState((s) => ({ ...s, loading: true, error: '' }));
    const res = await fetchRef.current();
    // If the inputs changed again while this call was in flight (e.g. the user
    // flipped through months quickly), a slower, older response must not
    // overwrite the newer one.
    if (mine !== latest.current) return;
    setState(res.ok ? { data: res.data, error: '', loading: false } : { data: null, error: res.error || 'Something went wrong.', loading: false });
  }, []);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { run(); }, [run, ...deps]);

  return { ...state, retry: run };
}
