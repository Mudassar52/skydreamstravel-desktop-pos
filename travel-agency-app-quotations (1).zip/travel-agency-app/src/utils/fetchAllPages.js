// Pulls EVERY page of a paginated IPC list call. Used where completeness
// matters more than speed - chiefly exports - so a customer with, say, 700
// payments gets all 700 in their PDF/Excel instead of the first page-size
// worth silently (master prompt section 55: "do not silently fail").
//
//   fetchPage({ page, pageSize }) -> the usual { ok, data | error } envelope
//   pick(data)                    -> the array of rows inside data (default data.rows)
export async function fetchAllPages(fetchPage, { pageSize = 500, pick = (d) => d.rows } = {}) {
  const all = [];
  for (let page = 1; ; page++) {
    const res = await fetchPage({ page, pageSize });
    if (!res.ok) return { ok: false, error: res.error };
    const rows = pick(res.data) || [];
    all.push(...rows);
    // Stop when we have everything the server says exists, or a short/empty page
    // (guards against an infinite loop if a total were ever inaccurate).
    if (rows.length < pageSize || all.length >= res.data.total) break;
  }
  return { ok: true, data: all };
}
