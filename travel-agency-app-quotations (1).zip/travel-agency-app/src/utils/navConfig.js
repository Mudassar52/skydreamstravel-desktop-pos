import {
  LayoutDashboard,
  Users,
  UserSquare2,
  BellRing,
  CalendarCheck,
  FileText,
  Package,
  Plane,
  Hotel,
  FileCheck2,
  Car,
  Sparkles,
  ListChecks,
  Clock,
  CalendarClock,
  CalendarDays,
  Receipt,
  CreditCard,
  Landmark,
  Wallet,
  Undo2,
  BookOpen,
  Truck,
  BookUser,
  BarChart3,
  Files,
  UserCog,
  Bell,
  ShieldCheck,
  Settings,
  DatabaseBackup,
  Target,
  Compass,
  Globe2,
  Percent,
  ClipboardList,
  History
} from 'lucide-react';

// phase: the phase (from the project plan) that implements this screen.
// `module` matches the permission keys seeded in electron/services/permissionModules.js
// `implemented: true` means the screen is real; otherwise it renders ComingSoon.
// `navState` (optional): router state passed to the link, so several sidebar
// entries can deep-link into one flexible page already preset to a type/filter
// (e.g. "Customer Reports" opens the Custom Report Builder with that report
// type selected) instead of duplicating a near-identical page per entry.
//
// Structure: flat items render as single sidebar links. Items with a
// `children` array render as a collapsible dropdown group (Sidebar.jsx).
// A group itself carries no route/module - only its children do.
//
// Grouped per the ERP upgrade's sidebar spec (Dashboard / CRM / Sales &
// Bookings / Travel Operations / Finance / Reports / Documents / Partners /
// Administration). Every item that existed before this reorganization is
// still here (Core Rule: never remove existing functionality) - some are
// relabeled to match the spec's wording (e.g. "Leads" -> "Inquiries",
// "Ledger" -> "Customer Ledger") or moved into a different group, but the
// same `path`/`module` so nothing breaks.
export const NAV_ITEMS = [
  { label: 'Dashboard', path: '/', icon: LayoutDashboard, color: '#E0485A', phase: 1, module: 'dashboard', implemented: true },

  {
    label: 'CRM',
    icon: Users,
    group: 'crm', color: '#8B5CF6',
    children: [
      { label: 'Customers', path: '/customers', icon: Users, phase: 4, module: 'customers', implemented: true },
      { label: 'Inquiries', path: '/leads', icon: Target, phase: 19, module: 'leads', implemented: true },
      { label: 'Follow-ups', path: '/followups', icon: BellRing, phase: 19, module: 'followups', implemented: true },
      { label: 'Follow-up History', path: '/followup-history', icon: History, phase: 19, module: 'followups', implemented: true },
      { label: 'Quotations', path: '/quotations', icon: FileText, phase: 19, module: 'quotations', implemented: true }
    ]
  },

  {
    label: 'Sales / Bookings',
    icon: Receipt,
    group: 'sales', color: '#F59E0B',
    children: [
      { label: 'Bookings', path: '/bookings', icon: CalendarCheck, phase: 6, module: 'bookings', implemented: true },
      { label: 'Travellers', path: '/travellers', icon: UserSquare2, phase: 19, module: 'travellers', implemented: true },
      { label: 'Packages', path: '/packages', icon: Package, phase: 19, module: 'packages', implemented: true },
      { label: 'Invoices', path: '/invoices', icon: Receipt, phase: 8, module: 'invoices', implemented: true }
    ]
  },

  {
    label: 'Travel Operations',
    icon: Compass,
    group: 'operations', color: '#0EA5E9',
    children: [
      { label: 'Flights', path: '/flights', icon: Plane, phase: 7, module: 'flights', implemented: true },
      { label: 'Hotels', path: '/hotels', icon: Hotel, phase: 7, module: 'hotels', implemented: true },
      { label: 'Visa', path: '/visa', icon: FileCheck2, phase: 7, module: 'visa', implemented: true },
      { label: 'Transport', path: '/transportation', icon: Car, phase: 7, module: 'transportation', implemented: true },
      { label: 'Ziyarat & Other Services', path: '/other-services', icon: Sparkles, phase: 19, module: 'other_services', implemented: true },
      { label: 'Umrah', path: '/umrah', icon: Landmark, phase: 5, module: 'umrah', implemented: true },
      { label: 'Hajj', path: '/hajj', icon: Compass, phase: 5, module: 'hajj', implemented: true },
      { label: 'Tours', path: '/tours', icon: Globe2, phase: 5, module: 'tours', implemented: true },
      { label: 'Tasks', path: '/tasks', icon: ListChecks, phase: 19, module: 'tasks', implemented: true },
      { label: 'Deadlines', path: '/deadlines', icon: Clock, phase: 19, module: 'deadlines', implemented: true },
      { label: 'Upcoming Travel', path: '/upcoming-travel', icon: CalendarClock, phase: 19, module: 'upcoming_travel', implemented: true },
      { label: 'Travel Calendar', path: '/travel-calendar', icon: CalendarDays, phase: 19, module: 'travel_calendar', implemented: true }
    ]
  },

  {
    label: 'Finance',
    icon: Landmark,
    group: 'finance', color: '#10B981',
    children: [
      { label: 'Customer Payments', path: '/payments', icon: CreditCard, phase: 9, module: 'payments', implemented: true },
      { label: 'Customer Advances', path: '/customer-advances', icon: Wallet, phase: 50, module: 'payments', implemented: true },
      { label: 'Customer Ledger', path: '/ledger', icon: BookOpen, phase: 9, module: 'ledger', implemented: true },
      { label: 'Expenses', path: '/expenses', icon: Wallet, phase: 10, module: 'expenses', implemented: true },
      { label: 'Refunds', path: '/refunds', icon: Undo2, phase: 19, module: 'refunds', implemented: true },
      { label: 'Cash', path: '/cash-accounts', icon: Wallet, phase: 19, module: 'cash_accounts', implemented: true },
      { label: 'Bank', path: '/bank-accounts', icon: Landmark, phase: 19, module: 'bank_accounts', implemented: true },
      { label: 'Profit & Loss', path: '/accounting', icon: BookOpen, phase: 19, module: 'accounting', implemented: true },
      { label: 'General Ledger', path: '/general-ledger', icon: BookOpen, phase: 21, module: 'financial_statements', implemented: true },
      { label: 'Trial Balance', path: '/trial-balance', icon: BookOpen, phase: 21, module: 'financial_statements', implemented: true },
      { label: 'Balance Sheet', path: '/balance-sheet', icon: BookOpen, phase: 21, module: 'financial_statements', implemented: true },
      { label: 'Period Close', path: '/period-close', icon: BookOpen, phase: 21, module: 'financial_statements', implemented: true },
      { label: 'Exchange Rates', path: '/exchange-rates', icon: Percent, phase: 21, module: 'exchange_rates', implemented: true }
    ]
  },

  {
    label: 'Reports',
    icon: BarChart3,
    group: 'reports', color: '#6366F1',
    children: [
      { label: 'Custom Report Builder', path: '/custom-reports', icon: BarChart3, phase: 27, module: 'reports', implemented: true },
      { label: 'Report History', path: '/report-history', icon: BarChart3, phase: 42, module: 'reports', implemented: true },
      { label: 'Report Templates', path: '/report-templates', icon: ClipboardList, phase: 50, module: 'reports', implemented: true },
      { label: 'All Reports (legacy)', path: '/reports', icon: BarChart3, phase: 12, module: 'reports', implemented: true }
    ]
  },

  {
    label: 'Documents',
    icon: Files,
    group: 'documents', color: '#F97316',
    children: [
      { label: 'Documents', path: '/documents', icon: Files, phase: 11, module: 'documents', implemented: true }
    ]
  },

  {
    label: 'Suppliers',
    icon: Truck,
    group: 'suppliers', color: '#14B8A6',
    children: [
      { label: 'Suppliers', path: '/suppliers', icon: Truck, phase: 19, module: 'suppliers', implemented: true },
      { label: 'Supplier Invoices', path: '/supplier-invoices', icon: FileText, phase: 19, module: 'supplier_invoices', implemented: true },
      { label: 'Supplier Payments', path: '/supplier-payments', icon: CreditCard, phase: 19, module: 'supplier_payments', implemented: true },
      { label: 'Supplier Advances', path: '/supplier-advances', icon: Wallet, phase: 50, module: 'supplier_payments', implemented: true },
      { label: 'Supplier Ledger', path: '/supplier-ledger', icon: BookUser, phase: 19, module: 'supplier_ledger', implemented: true },
      { label: 'Supplier Reports', path: '/supplier-reports', icon: BarChart3, phase: 19, module: 'supplier_reports', implemented: true }
    ]
  },

  {
    label: 'Administration',
    icon: UserCog,
    group: 'admin', color: '#64748B',
    children: [
      { label: 'Users & Permissions', path: '/staff', icon: UserCog, phase: 3, module: 'staff', implemented: true },
      { label: 'Audit Logs', path: '/audit-logs', icon: ShieldCheck, phase: 19, module: 'audit_logs', implemented: true },
      { label: 'Invoice Templates', path: '/invoice-templates', icon: FileText, phase: 8, module: 'invoice_templates', implemented: true },
      { label: 'Notifications', path: '/notifications', icon: Bell, phase: 19, module: 'notifications', implemented: true },
      { label: 'Settings', path: '/settings', icon: Settings, phase: 13, module: 'settings', implemented: true },
      { label: 'Backup / Restore', path: '/backup', icon: DatabaseBackup, phase: 14, module: 'backup', implemented: true }
    ]
  }
];

// Flattened list of every leaf nav item (used by App.jsx for routing and
// by AuthContext for permission filtering) regardless of group nesting.
// Several entries intentionally share the same `path` (deep-links into a
// flexible page with different `navState`) - callers that index by path
// should dedupe, which App.jsx's route generation already does.
export function flattenNavItems(items = NAV_ITEMS) {
  const out = [];
  for (const item of items) {
    if (item.children) {
      out.push(...flattenNavItems(item.children));
    } else {
      out.push(item);
    }
  }
  return out;
}
