import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, ArrowRightLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const today = () => new Date().toISOString().slice(0, 10);
const fmt = (n) => Number(n).toLocaleString('en-US', { maximumFractionDigits: 8 });

export default function ExchangeRates() {
  const { can } = useAuth();
  const [base, setBase] = useState('PKR');
  const [current, setCurrent] = useState([]);
  const [history, setHistory] = useState([]);
  const pg = usePagination(history, 25);
  const [formOpen, setFormOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [calc, setCalc] = useState({ amount: '100', from: '', to: '' });
  const [calcResult, setCalcResult] = useState('');

  const load = useCallback(async () => {
    const [b, c, h] = await Promise.all([window.api.exchangeRates.baseCurrency(), window.api.exchangeRates.listCurrent(), window.api.exchangeRates.list({})]);
    if (b.ok) setBase(b.data);
    if (c.ok) setCurrent(c.data); else setError(c.error);
    if (h.ok) setHistory(h.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  function flash(m) { setNotice(m); setTimeout(() => setNotice(''), 3000); }

  async function remove() {
    const res = await window.api.exchangeRates.delete(deleteTarget.id);
    setDeleteTarget(null);
    if (!res.ok) setError(res.error); else { flash('Rate deleted.'); load(); }
  }

  async function runCalc() {
    setCalcResult('');
    const from = calc.from.trim().toUpperCase(); const to = (calc.to.trim() || base).toUpperCase();
    const res = await window.api.exchangeRates.getRate(from, to, today());
    if (!res.ok) return setCalcResult(res.error);
    if (!res.data) return setCalcResult(`No rate on file to convert ${from} to ${to}.`);
    setCalcResult(`${fmt(calc.amount)} ${from} = ${fmt(Number(calc.amount) * res.data.rate)} ${to}  (rate ${fmt(res.data.rate)}, ${res.data.source})`);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Exchange Rates</h1>
          <p>Base currency: <strong>{base}</strong> (change it under Settings › Default Currency). Rates are entered by you - nothing is fetched or assumed.</p>
        </div>
        {can('exchange_rates', 'create') && <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Add Rate</button>}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0, marginBottom: 16 }}>
        <div style={{ padding: '12px 16px', fontWeight: 600, fontSize: 13 }}>Rates in force today</div>
        <table className="data-table">
          <thead><tr><th>Pair</th><th>Rate</th><th>Effective from</th><th>Notes</th></tr></thead>
          <tbody>
            {current.map((r) => (
              <tr key={r.id}><td><strong>1 {r.from_currency}</strong> = {r.to_currency}</td><td>{fmt(r.rate)}</td><td>{r.effective_date}</td><td>{r.notes || ''}</td></tr>
            ))}
            {current.length === 0 && <tr><td colSpan={4} className="empty-row">No exchange rates yet. Until you add one, amounts in different currencies are shown separately and never converted.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ padding: 16, marginBottom: 16 }}>
        <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8 }}><ArrowRightLeft size={14} style={{ verticalAlign: -2 }} /> Quick converter (uses today's rate)</div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <input className="field-input" style={{ width: 120 }} type="number" value={calc.amount} onChange={(e) => setCalc({ ...calc, amount: e.target.value })} />
          <input className="field-input" style={{ width: 80 }} placeholder="USD" maxLength={3} value={calc.from} onChange={(e) => setCalc({ ...calc, from: e.target.value })} />
          <span>to</span>
          <input className="field-input" style={{ width: 80 }} placeholder={base} maxLength={3} value={calc.to} onChange={(e) => setCalc({ ...calc, to: e.target.value })} />
          <button className="btn btn-secondary" onClick={runCalc} disabled={calc.from.length !== 3}>Convert</button>
          {calcResult && <span style={{ fontSize: 13 }}>{calcResult}</span>}
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: '12px 16px', fontWeight: 600, fontSize: 13 }}>Full history</div>
        <table className="data-table">
          <thead><tr><th>Pair</th><th>Rate</th><th>Effective from</th><th>Entered by</th><th>Notes</th><th></th></tr></thead>
          <tbody>
            {pg.pageRows.map((r) => (
              <tr key={r.id}>
                <td>{r.from_currency} → {r.to_currency}</td><td>{fmt(r.rate)}</td><td>{r.effective_date}</td><td>{r.created_by_name || '—'}</td><td>{r.notes || ''}</td>
                <td className="row-actions">{can('exchange_rates', 'delete') && <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(r)}><Trash2 size={14} /></button>}</td>
              </tr>
            ))}
            {history.length === 0 && <tr><td colSpan={6} className="empty-row">Nothing recorded.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="rates" />
      </div>

      {formOpen && <RateForm base={base} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); flash('Rate saved.'); load(); }} />}
      {deleteTarget && (
        <Modal title="Delete rate?" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13 }}>Remove 1 {deleteTarget.from_currency} = {fmt(deleteTarget.rate)} {deleteTarget.to_currency} (from {deleteTarget.effective_date})? Statements and totals that used it will be recalculated.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={remove}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function RateForm({ base, onClose, onSaved }) {
  const [form, setForm] = useState({ from_currency: '', to_currency: base, rate: '', effective_date: today(), notes: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = await window.api.exchangeRates.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }
  return (
    <Modal title="Add Exchange Rate" onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error">{error}</div>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="From currency (1 unit of)"><input className="field-input" maxLength={3} placeholder="USD" value={form.from_currency} onChange={(e) => set('from_currency', e.target.value.toUpperCase())} /></Field>
          <Field label="To currency"><input className="field-input" maxLength={3} value={form.to_currency} onChange={(e) => set('to_currency', e.target.value.toUpperCase())} /></Field>
          <Field label={`Rate (1 ${form.from_currency || '…'} = ? ${form.to_currency || '…'})`}><input className="field-input" type="number" step="any" value={form.rate} onChange={(e) => set('rate', e.target.value)} /></Field>
          <Field label="Effective from"><input className="field-input" type="date" value={form.effective_date} onChange={(e) => set('effective_date', e.target.value)} /></Field>
          <Field label="Notes" full><input className="field-input" value={form.notes} onChange={(e) => set('notes', e.target.value)} placeholder="e.g. Bank rate on the day" /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Rate'}</button>
        </div>
      </form>
    </Modal>
  );
}
