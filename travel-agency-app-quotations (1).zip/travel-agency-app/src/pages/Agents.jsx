import { useEffect, useState, useCallback } from 'react';
import { Plus, Search, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const num = (n) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
const EMPTY = { name: '', company: '', phone: '', email: '', city: '', address: '', commission_type: 'Percentage', commission_value: '', status: 'Active', notes: '' };

export default function Agents() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [formId, setFormId] = useState(undefined); // undefined closed, null new, number edit
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.agents.list({ search, status, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); setError(''); } else setError(res.error);
  }, [search, status, page]);
  useEffect(() => { load(); }, [load]);
  function flash(m) { setNotice(m); setTimeout(() => setNotice(''), 3000); }

  async function remove() {
    const res = await window.api.agents.delete(deleteTarget.id);
    setDeleteTarget(null);
    if (!res.ok) setError(res.error); else { flash('Agent deleted.'); load(); }
  }
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div>
      <div className="page-header">
        <div><h1>Agents</h1><p>{total.toLocaleString()} agent{total === 1 ? '' : 's'}</p></div>
        {can('agents', 'create') && <button className="btn btn-primary" onClick={() => setFormId(null)}><Plus size={15} /> Add Agent</button>}
      </div>
      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', gap: 8 }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={14} style={{ position: 'absolute', left: 10, top: 11, color: 'var(--color-text-muted)' }} />
          <input className="field-input" style={{ paddingLeft: 30 }} placeholder="Search name, code, company, phone…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        </div>
        <select className="field-input" style={{ width: 140 }} value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option>All</option><option>Active</option><option>Inactive</option>
        </select>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead><tr><th>Code</th><th>Agent</th><th>Phone</th><th>Default commission</th><th>Bookings</th><th>Commission due</th><th>Paid</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {rows.map((a) => (
              <tr key={a.id}>
                <td>{a.agent_code}</td>
                <td><strong>{a.name}</strong>{a.company && <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{a.company}</div>}</td>
                <td>{a.phone || '—'}</td>
                <td>{a.commission_type === 'Percentage' ? `${num(a.commission_value)}%` : `${num(a.commission_value)} flat`}</td>
                <td>{a.booking_count}</td>
                <td>{num(a.commission_due)}</td>
                <td>{num(a.commission_paid)}</td>
                <td><span className={`status-pill ${a.status === 'Active' ? 'on' : 'off'}`}>{a.status}</span></td>
                <td className="row-actions">
                  {can('agents', 'edit') && <button className="icon-btn" title="Edit" onClick={() => setFormId(a.id)}><Pencil size={14} /></button>}
                  {can('agents', 'delete') && <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(a)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="empty-row">No agents yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {pages}</span>
          <button className="icon-btn" disabled={page <= 1} onClick={() => setPage(page - 1)}><ChevronLeft size={15} /></button>
          <button className="icon-btn" disabled={page >= pages} onClick={() => setPage(page + 1)}><ChevronRight size={15} /></button>
        </div>
      </div>

      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 10 }}>
        Commission amounts are in each booking's own currency. Changing an agent's default rate only affects commissions created afterwards.
      </p>

      {formId !== undefined && <AgentForm id={formId} onClose={() => setFormId(undefined)} onSaved={(m) => { setFormId(undefined); flash(m); load(); }} />}
      {deleteTarget && (
        <Modal title="Delete agent?" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13 }}>Delete {deleteTarget.agent_code} - {deleteTarget.name}? An agent with bookings or commissions cannot be deleted; mark them Inactive instead.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={remove}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function AgentForm({ id, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  useEffect(() => {
    if (id) window.api.agents.get(id).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); else setError(res.error); });
  }, [id]);
  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = id ? await window.api.agents.update(id, form) : await window.api.agents.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(id ? 'Agent updated.' : `Agent ${res.data.agentCode} created.`);
  }
  return (
    <Modal title={id ? 'Edit Agent' : 'Add Agent'} onClose={onClose} width={560}>
      <form onSubmit={submit}>
        {error && <div className="login-error">{error}</div>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="Name *"><input className="field-input" value={form.name} onChange={(e) => set('name', e.target.value)} /></Field>
          <Field label="Company"><input className="field-input" value={form.company || ''} onChange={(e) => set('company', e.target.value)} /></Field>
          <Field label="Phone"><input className="field-input" value={form.phone || ''} onChange={(e) => set('phone', e.target.value)} /></Field>
          <Field label="Email"><input className="field-input" value={form.email || ''} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="City"><input className="field-input" value={form.city || ''} onChange={(e) => set('city', e.target.value)} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}><option>Active</option><option>Inactive</option></select>
          </Field>
          <Field label="Commission type">
            <select className="field-input" value={form.commission_type} onChange={(e) => set('commission_type', e.target.value)}>
              <option value="Percentage">Percentage of booking total</option><option value="Fixed">Fixed amount per booking</option>
            </select>
          </Field>
          <Field label={form.commission_type === 'Percentage' ? 'Rate (%)' : 'Amount per booking'}>
            <input className="field-input" type="number" step="any" min="0" value={form.commission_value} onChange={(e) => set('commission_value', e.target.value)} />
          </Field>
          <Field label="Address" full><input className="field-input" value={form.address || ''} onChange={(e) => set('address', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}
