import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BookOpen, Download, Search, ChevronUp, ChevronDown, RefreshCw, FileDown, Printer, FileSpreadsheet, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchAllPages } from '../utils/fetchAllPages.js';
import { usePagedList } from '../utils/usePagedList.js';
import './customers.css';
import { useIpcData } from '../utils/useIpcData.js';
import ErrorRetry from '../components/ErrorRetry.jsx';

// Customer 360 travel dossier (master prompt sections 4-7, 15, 17-20).
// Every figure on this page comes from window.api.customer360.* (SQL over the
// real transaction tables) or the existing payments / ledger / travellers /
// documents APIs. Nothing is hard-coded; empty data shows an empty state.

const TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'bookings', label: 'Bookings' },
  { key: 'payments', label: 'Payments' },
  { key: 'ledger', label: 'Ledger' },
  { key: 'travellers', label: 'Travellers' },
  { key: 'documents', label: 'Documents' },
  { key: 'timeline', label: 'Timeline' }
];

const BOOKING_TYPES = ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transportation', 'Custom'];
const BOOKING_STATUSES = ['Inquiry', 'Pending', 'Confirmed', 'Completed', 'Cancelled'];

function makeMoney(currency) {
  return (n) => {
    const v = Number(n || 0);
    try {
      return new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v);
    } catch (_) {
      return `${currency} ${v.toLocaleString()}`;
    }
  };
}

const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function CustomerDossier() {
  const { hasCapability, can } = useAuth();
  const { customerId } = useParams();
  const id = Number(customerId);
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');
  const [dossier, setDossier] = useState(null);
  const [currency, setCurrency] = useState('PKR');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [exportBusy, setExportBusy] = useState(false);
  const [exportError, setExportError] = useState('');

  const loadDossier = useCallback(async () => {
    setLoading(true);
    setError('');
    const [res, settings] = await Promise.all([window.api.customer360.dossier(id), window.api.settings.getAll()]);
    setLoading(false);
    if (!res.ok) return setError(res.error);
    setDossier(res.data);
    if (settings.ok && settings.data.default_currency) setCurrency(settings.data.default_currency);
  }, [id]);

  useEffect(() => { loadDossier(); }, [loadDossier]);

  const money = useMemo(() => makeMoney(currency), [currency]);

  if (loading && !dossier) return <div className="card" style={{ padding: 30 }}>Loading customer dossier…</div>;
  if (error) {
    return (
      <div className="card" style={{ padding: 30 }}>
        <p className="login-error">{error}</p>
        <button className="btn btn-secondary" onClick={loadDossier}><RefreshCw size={14} /> Retry</button>
      </div>
    );
  }
  const { header, summary } = dossier;

  async function exportDossier(format) {
    setExportBusy(true); setExportError('');
    // Every part is fetched IN FULL (all pages) and the export is abandoned
    // with a clear message if any part fails - never a PDF/Excel that quietly
    // omits a section or stops at the first 500 rows.
    const parts = { Bookings: null, Payments: null, Ledger: null, Travellers: null, Documents: null, Timeline: null };
    [parts.Bookings, parts.Payments, parts.Ledger, parts.Travellers, parts.Documents, parts.Timeline] = await Promise.all([
      window.api.customer360.bookings(id, { pageSize: 0 }),
      fetchAllPages((p) => window.api.payments.list({ customerId: id, ...p })),
      // A role without Ledger access exports the dossier without that section instead of failing the whole export.
      can('ledger', 'view') ? window.api.ledger.filteredView(id, {}) : Promise.resolve({ ok: true, data: { entries: [], totalDebit: 0, totalCredit: 0 } }),
      window.api.travellers.listByCustomer(id),
      fetchAllPages((p) => window.api.documents.list({ customerId: id, ...p })),
      fetchAllPages((p) => window.api.customer360.timeline(id, p), { pick: (d) => d.items })
    ]);
    setExportBusy(false);
    const failed = Object.entries(parts).find(([, r]) => !r.ok);
    if (failed) { setExportError(`Export cancelled - could not load ${failed[0]}: ${failed[1].error}`); return; }
    const [bk, pay, ledg, trav, docs, tl] = [parts.Bookings, parts.Payments, parts.Ledger, parts.Travellers, parts.Documents, parts.Timeline];
    const sections = [
      { title: 'Customer Info', columns: Object.keys(header).filter((k) => k !== 'customer').map((k) => ({ key: k, label: k })), rows: [header] },
      { title: 'Bookings', columns: [{ key: 'booking_code', label: 'Booking #' }, { key: 'booking_date', label: 'Date' }, { key: 'selling', label: 'Selling', money: true }, { key: 'paid', label: 'Paid', money: true }, { key: 'outstanding', label: 'Outstanding', money: true }, { key: 'status', label: 'Status' }], rows: bk.ok ? bk.data.items : [] },
      { title: 'Payments', columns: [{ key: 'payment_date', label: 'Date' }, { key: 'payment_method', label: 'Method' }, { key: 'payment_type', label: 'Type' }, { key: 'amount', label: 'Amount', money: true }], rows: pay.data },
      { title: 'Ledger', columns: [{ key: 'entry_date', label: 'Date' }, { key: 'description', label: 'Description' }, { key: 'debit', label: 'Debit', money: true }, { key: 'credit', label: 'Credit', money: true }, { key: 'running_balance', label: 'Balance', money: true }], rows: ledg.ok ? ledg.data.entries : [], totals: ledg.ok ? { debit: ledg.data.totalDebit, credit: ledg.data.totalCredit } : null },
      { title: 'Travellers', columns: [{ key: 'full_name', label: 'Name' }, { key: 'relationship', label: 'Relationship' }, { key: 'passport_number', label: 'Passport' }], rows: trav.ok ? trav.data : [] },
      { title: 'Documents', columns: [{ key: 'file_name', label: 'File' }, { key: 'document_type', label: 'Type' }, { key: 'uploaded_at', label: 'Uploaded' }], rows: docs.data },
      { title: 'Timeline', columns: [{ key: 'at', label: 'Date' }, { key: 'event', label: 'Event' }, { key: 'reference', label: 'Reference' } ], rows: tl.data }
    ];
    const reportData = { title: `Customer Dossier - ${header.full_name}`, dateRangeLabel: 'All dates', filtersSummary: hasCapability('view_profit') && summary.profitability.gross_profit !== null ? `Profit (gross): ${money(summary.profitability.gross_profit)}` : '', sections };
    let res;
    if (format === 'pdf') res = await window.api.reportExport.exportPdf(reportData);
    else if (format === 'print') res = await window.api.reportExport.print(reportData);
    else res = await window.api.reportExport.exportExcel(sections.map((s) => ({ name: s.title, columns: s.columns, rows: s.rows, totals: s.totals })), `Customer-Dossier-${header.full_name}.xlsx`);
    if (!res.ok) setExportError(res.error);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="link-cell" onClick={() => navigate('/customers')} style={{ marginBottom: 6, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <ArrowLeft size={13} /> Back to Customers
          </button>
          <h1>{header.full_name}</h1>
          <p>
            {header.customer_code} · {header.customer_type} ·{' '}
            <span className={`status-pill ${header.status === 'Active' ? 'on' : 'off'}`}>{header.status}</span>
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {hasCapability('export_reports') && (
            <>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('pdf')}><FileDown size={14} /> PDF</button>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('excel')}><FileSpreadsheet size={14} /> Excel</button>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('print')}><Printer size={14} /> Print</button>
            </>
          )}
          {can('ledger', 'view') && (
            <button className="btn btn-secondary" onClick={() => navigate('/ledger', { state: { customerId: id, customerLabel: header.full_name } })}>
              <BookOpen size={14} /> Full Ledger
            </button>
          )}
        </div>
      </div>

      {exportError && <div className="login-error" style={{ marginBottom: 12 }}>{exportError}</div>}

      <div className="tabs" style={{ marginBottom: 16 }}>
        {TABS.filter((t) => t.key !== 'ledger' || can('ledger', 'view')).map((t) => (
          <button key={t.key} className={tab === t.key ? 'tab active' : 'tab'} onClick={() => setTab(t.key)}>{t.label}</button>
        ))}
      </div>

      {tab === 'overview' && <Overview header={header} summary={summary} money={money} canViewProfit={hasCapability('view_profit')} />}
      {tab === 'bookings' && <BookingsTab id={id} currencies={dossier.currencies} money={money} defaultCurrency={currency} />}
      {tab === 'payments' && <PaymentsTab id={id} money={money} />}
      {tab === 'ledger' && <LedgerTab id={id} money={money} />}
      {tab === 'travellers' && <TravellersTab id={id} />}
      {tab === 'documents' && <DocumentsTab id={id} />}
      {tab === 'timeline' && <TimelineTab id={id} />}
    </div>
  );
}

// ------------------------------------------------------------------ Overview
function Overview({ header, summary, money, canViewProfit }) {
  const s = summary;
  const cards = [
    ['Total Bookings', s.bookings.total],
    ['Active Bookings', s.bookings.active],
    ['Completed Bookings', s.bookings.completed],
    ['Cancelled Bookings', s.bookings.cancelled],
    ['Total Invoices', s.invoices.count],
    ['Total Billed', money(s.invoices.total_billed)],
    ['Total Paid', money(s.payments.total_paid)],
    ['Advance Received', money(s.advance.received)],
    ['Advance Used', money(s.advance.used)],
    ['Remaining Advance', money(s.advance.remaining)],
    ['Outstanding Balance', money(s.outstanding_balance), s.outstanding_balance > 0 ? 'var(--color-danger)' : undefined],
    ['Total Refunds', money(s.payments.total_refunds)],
    ...(canViewProfit ? [
      ['Total Service Cost', money(s.profitability.total_cost)],
      ['Gross Profit', money(s.profitability.gross_profit), s.profitability.gross_profit < 0 ? 'var(--color-danger)' : 'var(--color-success)']
    ] : []),
    ['Last Payment', day(s.payments.last_payment_date)],
    ['Last Travel', day(s.travel.last_travel_date)],
    ['Next Travel', day(s.travel.next_travel_date)]
  ];
  const cb = s.profitability.cost_breakdown || {}; // null when the role lacks View Profit (blanked by the main process)
  const currencyBlock = s.mixed_currency ? (
    <div className="card" style={{ padding: '14px 18px', marginBottom: 16, borderLeft: '3px solid var(--color-warning, #C9A227)' }}>
      <strong style={{ fontSize: 13 }}>This customer has bookings in {s.currencies.length} currencies ({s.currencies.map((c) => c.currency).join(', ')}).</strong>
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', margin: '4px 0 10px' }}>
        Figures are recorded in each booking's own currency, so the combined totals elsewhere on this page add different currencies together.
        Use this per-currency breakdown for accurate amounts.
        {s.converted && s.converted.complete && ` The converted row below uses the exchange rates on file (${s.converted.rates.map((r) => `${r.currency} → ${s.converted.currency} @ ${Number(r.rate).toLocaleString('en-US', { maximumFractionDigits: 6 })}`).join(', ')}).`}
      </p>
      {s.converted && !s.converted.complete && (
        <p style={{ fontSize: 12, color: 'var(--color-danger, #B42318)', margin: '0 0 10px' }}>
          No exchange rate is on file for {s.converted.missing.join(', ')} to {s.converted.currency}, so a converted total cannot be shown. Add one under Finance › Exchange Rates.
        </p>
      )}
      <table className="data-table">
        <thead><tr><th>Currency</th><th>Bookings</th><th style={{ textAlign: 'right' }}>Selling</th><th style={{ textAlign: 'right' }}>Paid (net)</th><th style={{ textAlign: 'right' }}>Outstanding</th></tr></thead>
        <tbody>
          {s.currencies.map((c) => {
            const fmt = makeMoney(c.currency);
            return <tr key={c.currency}><td><strong>{c.currency}</strong></td><td>{c.bookings}</td><td style={{ textAlign: 'right' }}>{fmt(c.selling)}</td><td style={{ textAlign: 'right' }}>{fmt(c.paid)}</td><td style={{ textAlign: 'right' }}>{fmt(c.outstanding)}</td></tr>;
          })}
          {s.converted && s.converted.complete && (() => {
            const fmt = makeMoney(s.converted.currency);
            return (
              <tr style={{ fontWeight: 700, borderTop: '2px solid var(--color-border, #D0D5DD)' }}>
                <td>Total in {s.converted.currency}</td><td></td>
                <td style={{ textAlign: 'right' }}>{fmt(s.converted.selling)}</td>
                <td style={{ textAlign: 'right' }}>{fmt(s.converted.paid)}</td>
                <td style={{ textAlign: 'right' }}>{fmt(s.converted.outstanding)}</td>
              </tr>
            );
          })()}
        </tbody>
      </table>
    </div>
  ) : null;
  const costRows = [
    ['Flight', cb.flight], ['Visa', cb.visa], ['Hotel', cb.hotel], ['Transport', cb.transport],
    ['Ziyarat', cb.ziyarat], ['Other services', cb.other], ['Supplier invoices (actual)', cb.supplier_invoices]
  ];

  return (
    <>
      {currencyBlock}
      <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 12 }}>Customer Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13 }}>
          <Info label="Phone" value={header.phone} />
          <Info label="WhatsApp" value={header.whatsapp} />
          <Info label="Email" value={header.email} />
          <Info label="Address" value={header.address} />
          <Info label="CNIC" value={header.cnic} />
          <Info label="Passport" value={header.passport_number ? `${header.passport_number}${header.passport_expiry_date ? ` (exp ${header.passport_expiry_date})` : ''}` : null} />
          <Info label="Nationality" value={header.nationality} />
          <Info label="Registered" value={day(header.registration_date)} />
          <Info label="Assigned Staff" value={header.assigned_staff} />
          <Info label="Notes" value={header.notes} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 12, marginBottom: 16 }}>
        {cards.map(([label, value, color]) => (
          <div key={label} className="card" style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: color || 'inherit', marginTop: 2 }}>{value}</div>
          </div>
        ))}
      </div>

      {canViewProfit ? (
        <div className="card" style={{ padding: '18px 22px' }}>
          <h3 style={{ fontSize: 13.5, marginBottom: 4 }}>Profitability</h3>
          <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 12 }}>
            Revenue is billed on non-cancelled invoices. A booking that has supplier invoices uses those actual costs; otherwise its estimated service costs are used — never both.
          </p>
          <table className="data-table">
            <tbody>
              <tr><td>Revenue (billed)</td><td style={{ textAlign: 'right', fontWeight: 600 }}>{money(s.profitability.revenue)}</td></tr>
              {costRows.map(([label, v]) => (
                <tr key={label}><td style={{ paddingLeft: 24 }}>{label} cost</td><td style={{ textAlign: 'right' }}>{money(v)}</td></tr>
              ))}
              <tr><td><strong>Total cost</strong></td><td style={{ textAlign: 'right', fontWeight: 600 }}>{money(s.profitability.total_cost)}</td></tr>
              <tr><td><strong>Gross profit</strong></td><td style={{ textAlign: 'right', fontWeight: 700 }}>{money(s.profitability.gross_profit)}</td></tr>
              <tr><td>Profit margin</td><td style={{ textAlign: 'right' }}>{s.profitability.margin_percent === null ? '—' : `${s.profitability.margin_percent}%`}</td></tr>
            </tbody>
          </table>
        </div>
      ) : (
        <div className="card" style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 10, color: 'var(--color-text-muted)' }}>
          <Lock size={14} /> Profitability is restricted for your role.
        </div>
      )}
    </>
  );
}

function Info({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
      <div>{value || '—'}</div>
    </div>
  );
}

// ------------------------------------------------------------------ Bookings
const COLUMNS = [
  ['booking_code', 'Booking #'], ['booking_date', 'Date'], ['booking_type', 'Type'], ['package_name', 'Package'],
  ['departure_date', 'Departure'], ['return_date', 'Return'], ['selling', 'Selling'], ['paid', 'Paid'],
  ['advance', 'Advance', false], ['outstanding', 'Outstanding'], ['cost', 'Cost'], ['profit', 'Profit'], ['status', 'Status']
];

function BookingsTab({ id, currencies, money, defaultCurrency }) {
  const empty = { search: '', bookingType: 'All', status: 'All', paymentStatus: 'All', currency: 'All', dateFrom: '', dateTo: '', minAmount: '', maxAmount: '' };
  const [filters, setFilters] = useState(empty);
  const [applied, setApplied] = useState(empty);
  const [sort, setSort] = useState({ by: 'booking_date', dir: 'desc' });
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setError('');
    const res = await window.api.customer360.bookings(id, { ...applied, sortBy: sort.by, sortDir: sort.dir, page, pageSize });
    if (!res.ok) return setError(res.error);
    setData(res.data);
  }, [id, applied, sort, page]);
  useEffect(() => { load(); }, [load]);

  const set = (k, v) => setFilters((f) => ({ ...f, [k]: v }));
  const apply = () => { setPage(1); setApplied(filters); };
  const reset = () => { setFilters(empty); setApplied(empty); setPage(1); };
  const toggleSort = (col) => { setPage(1); setSort((s) => (s.by === col ? { by: col, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { by: col, dir: 'asc' })); };

  async function exportCsv() {
    const res = await window.api.customer360.bookings(id, { ...applied, sortBy: sort.by, sortDir: sort.dir, pageSize: 0 });
    if (!res.ok) return setError(res.error);
    const head = ['Booking #', 'Date', 'Type', 'Package', 'Departure', 'Return', 'Currency', 'Selling', 'Paid', 'Advance', 'Outstanding', 'Cost', 'Profit', 'Payment Status', 'Status'];
    const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = [head.map(q).join(',')].concat(res.data.items.map((r) => [
      r.booking_code, day(r.booking_date), r.booking_type, r.package_name, day(r.departure_date), day(r.return_date), r.currency,
      r.selling, r.paid, r.advance, r.outstanding, r.cost, r.profit, r.payment_status, r.status
    ].map(q).join(',')));
    const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `customer-${id}-bookings.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  const sel = { className: 'field-input', style: { minWidth: 120 } };

  return (
    <div>
      <div className="card" style={{ padding: '14px 18px', marginBottom: 14 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'flex-end' }}>
          <div style={{ position: 'relative' }}>
            <Search size={13} style={{ position: 'absolute', left: 9, top: 11, color: 'var(--color-text-faint)' }} />
            <input className="field-input" style={{ paddingLeft: 28, width: 190 }} placeholder="Search booking / package" value={filters.search}
              onChange={(e) => set('search', e.target.value)} onKeyDown={(e) => e.key === 'Enter' && apply()} />
          </div>
          <select {...sel} value={filters.bookingType} onChange={(e) => set('bookingType', e.target.value)}>
            <option value="All">All types</option>{BOOKING_TYPES.map((t) => <option key={t}>{t}</option>)}
          </select>
          <select {...sel} value={filters.status} onChange={(e) => set('status', e.target.value)}>
            <option value="All">All statuses</option>{BOOKING_STATUSES.map((t) => <option key={t}>{t}</option>)}
          </select>
          <select {...sel} value={filters.paymentStatus} onChange={(e) => set('paymentStatus', e.target.value)}>
            <option value="All">All payment</option><option>Paid</option><option>Partial</option><option>Unpaid</option>
          </select>
          <select {...sel} value={filters.currency} onChange={(e) => set('currency', e.target.value)}>
            <option value="All">All currencies</option>{currencies.map((c) => <option key={c}>{c}</option>)}
          </select>
          <input className="field-input" type="date" title="Booked from" value={filters.dateFrom} onChange={(e) => set('dateFrom', e.target.value)} />
          <input className="field-input" type="date" title="Booked to" value={filters.dateTo} onChange={(e) => set('dateTo', e.target.value)} />
          <input className="field-input" type="number" style={{ width: 110 }} placeholder="Min amount" value={filters.minAmount} onChange={(e) => set('minAmount', e.target.value)} />
          <input className="field-input" type="number" style={{ width: 110 }} placeholder="Max amount" value={filters.maxAmount} onChange={(e) => set('maxAmount', e.target.value)} />
          <button className="btn btn-primary btn-sm" onClick={apply}>Apply</button>
          <button className="btn btn-secondary btn-sm" onClick={reset}>Reset</button>
          <button className="btn btn-secondary btn-sm" onClick={exportCsv} disabled={!data || data.total === 0}><Download size={13} /> Export CSV</button>
        </div>
      </div>

      {error && <div className="login-error">{error} <button className="link-cell" onClick={load}>Retry</button></div>}

      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              {COLUMNS.map(([key, label, sortable = true]) => (
                <th key={key} onClick={sortable ? () => toggleSort(key) : undefined} style={{ cursor: sortable ? 'pointer' : 'default', whiteSpace: 'nowrap' }}>
                  {label}{sort.by === key && (sort.dir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {!data && <tr><td colSpan={COLUMNS.length} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.items.length === 0 && <tr><td colSpan={COLUMNS.length} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No bookings found</td></tr>}
            {data && data.items.map((r) => (
              <tr key={r.id}>
                <td><strong>{r.booking_code}</strong></td>
                <td>{day(r.booking_date)}</td>
                <td>{r.booking_type}</td>
                <td>{r.package_name || '—'}</td>
                <td>{day(r.departure_date)}</td>
                <td>{day(r.return_date)}</td>
                <td>{makeMoney(r.currency)(r.selling)}</td>
                <td>{makeMoney(r.currency)(r.paid)}</td>
                <td>{r.advance > 0 ? makeMoney(r.currency)(r.advance) : '—'}</td>
                <td style={{ color: r.outstanding > 0 ? 'var(--color-danger)' : 'inherit' }}>{makeMoney(r.currency)(r.outstanding)}</td>
                <td title={r.cost_source === 'actual' ? 'Actual supplier invoices' : 'Estimated from services'}>
                  {r.cost === null ? '—' : makeMoney(r.currency)(r.cost)}{r.cost_source === 'estimated' && r.cost > 0 ? ' *' : ''}
                </td>
                <td style={{ color: r.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)', fontWeight: 600 }}>{r.profit === null ? '—' : makeMoney(r.currency)(r.profit)}</td>
                <td>{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 8 }}>* estimated cost from booking services (no supplier invoice recorded yet). Amounts shown in each booking's own currency ({defaultCurrency} default).</p>

      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages} · {data.total} bookings</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ Payments
function LoadMoreFooter({ shown, total, loadingMore, onMore }) {
  if (shown >= total) return null;
  return (
    <div style={{ padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5, borderTop: '1px solid var(--color-border)' }}>
      <span>Showing {shown} of {total}</span>
      <button className="btn btn-secondary btn-sm" disabled={loadingMore} onClick={onMore}>{loadingMore ? 'Loading…' : 'Load more'}</button>
    </div>
  );
}

function PaymentsTab({ id, money }) {
  const { rows, total, error, loadingMore, loadMore, reload } = usePagedList((p) => window.api.payments.list({ customerId: id, ...p }), [id], 50);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      {error && <div className="login-error" style={{ margin: 12 }}>{error} <button className="link-cell" onClick={reload}>Retry</button></div>}
      <table className="data-table">
        <thead><tr><th>Date</th><th>Payment #</th><th>Invoice</th><th>Booking</th><th>Method</th><th>Type</th><th>Amount</th><th>Reference</th><th>Notes</th></tr></thead>
        <tbody>
          {!rows && <tr><td colSpan={9} style={{ padding: 24 }}>Loading…</td></tr>}
          {rows && rows.length === 0 && <tr><td colSpan={9} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No payments found</td></tr>}
          {rows && rows.map((p) => (
            <tr key={p.id}>
              <td>{day(p.payment_date)}</td><td>PAY-{String(p.id).padStart(5, '0')}</td><td>{p.invoice_number || '—'}</td><td>{p.booking_code || '—'}</td>
              <td>{p.payment_method}</td><td>{p.payment_type}</td>
              <td style={{ fontWeight: 600, color: p.payment_type === 'Refund' ? 'var(--color-danger)' : 'inherit' }}>{p.payment_type === 'Refund' ? '−' : ''}{money(p.amount)}</td>
              <td>{p.reference || '—'}</td><td>{p.notes || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows && <LoadMoreFooter shown={rows.length} total={total} loadingMore={loadingMore} onMore={loadMore} />}
    </div>
  );
}

// -------------------------------------------------------------------- Ledger
function LedgerTab({ id, money }) {
  const { data: ledger, error, retry } = useIpcData(async () => {
    const [e, bal] = await Promise.all([window.api.ledger.list(id), window.api.ledger.getBalance(id)]);
    if (!e.ok) return e;
    if (!bal.ok) return bal;
    return { ok: true, data: { entries: e.data, balance: bal.data } };
  }, [id]);
  const entries = ledger ? ledger.entries : null;
  const balance = ledger ? ledger.balance : 0;
  const totals = (entries || []).reduce((a, e) => ({ debit: a.debit + e.debit, credit: a.credit + e.credit }), { debit: 0, credit: 0 });
  return (
    <div>
      <ErrorRetry error={error} onRetry={retry} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 14 }}>
        {[['Total Debit', money(totals.debit)], ['Total Credit', money(totals.credit)], ['Closing Balance', money(balance)]].map(([l, v]) => (
          <div key={l} className="card" style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{l}</div>
            <div style={{ fontSize: 17, fontWeight: 700 }}>{v}</div>
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Date</th><th>Description</th><th>Invoice</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
          <tbody>
            {!entries && !error && <tr><td colSpan={6} style={{ padding: 24 }}>Loading…</td></tr>}
            {entries && entries.length === 0 && <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No ledger entries yet</td></tr>}
            {entries && entries.map((e) => (
              <tr key={e.id}>
                <td>{day(e.entry_date)}</td><td>{e.description}</td><td>{e.invoice_number || '—'}</td>
                <td>{e.debit > 0 ? money(e.debit) : '—'}</td><td>{e.credit > 0 ? money(e.credit) : '—'}</td>
                <td style={{ fontWeight: 600 }}>{money(e.running_balance)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- Travellers
function TravellersTab({ id }) {
  const { data: rows, error, retry } = useIpcData(() => window.api.travellers.listByCustomer(id), [id]);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      <ErrorRetry error={error} onRetry={retry} />
      <table className="data-table">
        <thead><tr><th>Name</th><th>Relationship</th><th>Gender</th><th>DOB</th><th>Nationality</th><th>Passport</th><th>Passport Expiry</th><th>Visa Status</th></tr></thead>
        <tbody>
          {!rows && !error && <tr><td colSpan={8} style={{ padding: 24 }}>Loading…</td></tr>}
          {rows && rows.length === 0 && <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No travellers found</td></tr>}
          {rows && rows.map((t) => (
            <tr key={t.id}>
              <td><strong>{t.full_name}</strong></td><td>{t.relationship || '—'}</td><td>{t.gender || '—'}</td><td>{day(t.date_of_birth)}</td>
              <td>{t.nationality || '—'}</td><td>{t.passport_number || '—'}</td><td>{day(t.passport_expiry_date)}</td><td>{t.visa_status || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ----------------------------------------------------------------- Documents
function DocumentsTab({ id }) {
  const { rows, total, error: loadError, loadingMore, loadMore, reload } = usePagedList((p) => window.api.documents.list({ customerId: id, ...p }), [id], 50);
  const [error, setError] = useState('');
  async function open(docId) { const r = await window.api.documents.open(docId); if (!r.ok) setError(r.error); }
  async function download(docId) { const r = await window.api.documents.downloadAs(docId); if (!r.ok) setError(r.error); }
  return (
    <div>
      {(error || loadError) && <div className="login-error">{error || loadError} {loadError && <button className="link-cell" onClick={reload}>Retry</button>}</div>}
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Document</th><th>Type</th><th>Uploaded</th><th>Booking</th><th>Notes</th><th></th></tr></thead>
          <tbody>
            {!rows && <tr><td colSpan={6} style={{ padding: 24 }}>Loading…</td></tr>}
            {rows && rows.length === 0 && <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No documents uploaded</td></tr>}
            {rows && rows.map((d) => (
              <tr key={d.id}>
                <td>{d.file_name}</td><td>{d.document_type || '—'}</td><td>{day(d.uploaded_at)}</td><td>{d.booking_code || '—'}</td><td>{d.notes || '—'}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="btn btn-secondary btn-sm" onClick={() => open(d.id)}>Preview</button>{' '}
                  <button className="btn btn-secondary btn-sm" onClick={() => download(d.id)}>Download</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows && <LoadMoreFooter shown={rows.length} total={total} loadingMore={loadingMore} onMore={loadMore} />}
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 8 }}>Upload and delete are managed from the Documents module (with its permissions).</p>
    </div>
  );
}

// ------------------------------------------------------------------ Timeline
function TimelineTab({ id }) {
  const [page, setPage] = useState(1);
  const pageSize = 25;
  const { data, error, retry } = useIpcData(() => window.api.customer360.timeline(id, { page, pageSize }), [id, page]);
  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  return (
    <div>
      <ErrorRetry error={error} onRetry={retry} />
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Date / Time</th><th>Event</th><th>Reference</th><th>Staff</th><th>Notes</th></tr></thead>
          <tbody>
            {!data && !error && <tr><td colSpan={5} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.items.length === 0 && <tr><td colSpan={5} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No activity yet</td></tr>}
            {data && data.items.map((e, i) => (
              <tr key={`${e.at}-${i}`}>
                <td style={{ whiteSpace: 'nowrap' }}>{String(e.at).slice(0, 16).replace('T', ' ')}</td>
                <td><strong>{e.event}</strong></td><td>{e.reference || '—'}</td><td>{e.staff || '—'}</td><td>{e.notes || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
