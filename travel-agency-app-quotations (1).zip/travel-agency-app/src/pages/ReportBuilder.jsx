import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { FileDown, Printer, FileSpreadsheet, Save, X, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import SupplierSearchSelect from '../components/SupplierSearchSelect.jsx';
import DateRangeFilter from '../components/DateRangeFilter.jsx';
import Pagination, { usePagination } from '../components/Pagination.jsx';
import './customers.css';

// Custom Report Builder (master prompt sections 27-33, 37-38, 43). Every
// number comes from window.api.customReports.run(spec), which composes real
// data through the same 360/ledger services the rest of the app uses - the
// builder only decides what to include and how to filter it.

// How many records a multi-record preview fetches up front (the screen reveals them 25 at a time).
const PREVIEW_FETCH_LIMIT = 100;

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const day = (s) => (s ? String(s).slice(0, 10) : '—');

const SECTION_LABELS = {
  customer_info: 'Customer Info', supplier_info: 'Supplier Info', booking_info: 'Booking Info', customer: 'Customer',
  bookings: 'Bookings', travellers: 'Travellers', package: 'Package', flights: 'Flights', hotels: 'Hotels', visa: 'Visa',
  transport: 'Transport', ziyarat: 'Ziyarat', suppliers: 'Suppliers', services: 'Services', invoices: 'Invoices',
  payments: 'Payments', advances: 'Advances', outstanding: 'Outstanding', payable: 'Payable', supplier_costs: 'Supplier Costs',
  profit: 'Profit', documents: 'Documents', timeline: 'Timeline', ledger: 'Ledger', notes: 'Notes'
};

// Column sets reused across customer/supplier/booking report sections.
const TABLE_SECTIONS = {
  bookings: [['booking_code', 'Booking #'], ['booking_date', 'Date', day], ['booking_type', 'Type'], ['selling', 'Selling', money], ['paid', 'Paid', money], ['outstanding', 'Outstanding', money], ['cost', 'Cost', money], ['profit', 'Profit', money], ['status', 'Status']],
  travellers: [['full_name', 'Name'], ['relationship', 'Relationship'], ['passport_number', 'Passport'], ['nationality', 'Nationality']],
  flights: [['airline', 'Airline'], ['flight_number', 'Flight #'], ['departure_date', 'Departure', day], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money], ['supplier_name', 'Supplier']],
  hotels: [['hotel_name', 'Hotel'], ['check_in', 'Check-in', day], ['check_out', 'Check-out', day], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money], ['supplier_name', 'Supplier']],
  visa: [['country', 'Country'], ['visa_type', 'Type'], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money], ['status', 'Status']],
  transport: [['transport_type', 'Type'], ['pickup_location', 'Pickup'], ['drop_location', 'Drop'], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money]],
  ziyarat: [['service_type', 'Service'], ['description', 'Description'], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money]],
  suppliers: [['name', 'Supplier'], ['supplier_code', 'Code'], ['service_type', 'Service Type'], ['service_count', 'Services']],
  services: [['service_type', 'Type'], ['service_date', 'Date', day], ['booking_code', 'Booking'], ['customer_name', 'Customer'], ['cost', 'Cost', money], ['selling_price', 'Selling', money], ['profit', 'Profit', money]],
  invoices: [['invoice_number', 'Invoice #'], ['invoice_date', 'Date', day], ['total', 'Total', money], ['paid_amount', 'Paid', money], ['remaining_amount', 'Remaining', money], ['status', 'Status']],
  payments: [['payment_date', 'Date', day], ['payment_method', 'Method'], ['payment_type', 'Type'], ['amount', 'Amount', money], ['reference', 'Reference']],
  documents: [['file_name', 'File'], ['document_type', 'Type'], ['uploaded_at', 'Uploaded', day]],
  timeline: [['at', 'Date/Time'], ['event', 'Event'], ['reference', 'Reference'], ['notes', 'Notes']]
};
const INFO_SECTIONS = ['customer_info', 'supplier_info', 'booking_info', 'customer', 'package', 'notes', 'advances', 'outstanding', 'payable', 'profit'];

const FLAT_COLUMNS = {
  service: [['service_type', 'Service Type'], ['count', 'Count'], ['purchase', 'Purchase', money], ['sales', 'Sales', money], ['profit', 'Profit', money]],
  financial: [['line', 'Line Item'], ['amount', 'Amount', money]],
  profitability: [['booking_code', 'Booking #'], ['customer_name', 'Customer'], ['booking_date', 'Date', day], ['selling', 'Selling', money], ['cost', 'Cost', money], ['profit', 'Profit', money], ['margin_percent', 'Margin %']],
  payment: [['payment_date', 'Date', day], ['customer_name', 'Customer'], ['booking_code', 'Booking'], ['invoice_number', 'Invoice'], ['payment_method', 'Method'], ['payment_type', 'Type'], ['amount', 'Amount', money], ['reference', 'Reference']]
};
const LEDGER_COLUMNS = [['entry_date', 'Date', day], ['txn_type', 'Type'], ['invoice_number', 'Reference'], ['description', 'Description'], ['debit', 'Debit', money], ['credit', 'Credit', money], ['running_balance', 'Balance', money]];

export default function ReportBuilder() {
  const [meta, setMeta] = useState(null);
  const { hasCapability } = useAuth();
  const location = useLocation();
  const [reportType, setReportType] = useState(location.state?.presetType || 'customer');
  const [dateFields, setDateFields] = useState([]);
  const [sectionsAvailable, setSectionsAvailable] = useState([]);
  const [sections, setSections] = useState([]);
  const [entityType, setEntityType] = useState('customer');
  const [selectionMode, setSelectionMode] = useState('all');
  const [picked, setPicked] = useState([]); // [{id,label}]
  const [serviceTypes, setServiceTypes] = useState([]);
  const [opsType, setOpsType] = useState('');
  const [paymentType, setPaymentType] = useState('All');
  const [status, setStatus] = useState('All');
  const [bookingServiceType, setBookingServiceType] = useState('All');
  const [range, setRange] = useState({ preset: '', from: '', to: '', dateField: '' });
  const [templates, setTemplates] = useState([]);
  const [templateId, setTemplateId] = useState('');
  const [result, setResult] = useState(null);
  const [orientation, setOrientation] = useState('landscape');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const resultRef = useRef(null);

  useEffect(() => {
    window.api.customReports.meta().then((r) => { if (r.ok) { setMeta(r.data); setOpsType(r.data.opsTypes[0]); setServiceTypes(r.data.serviceTypes.slice(0, 5)); } });
  }, []);

  // A sidebar entry like "Booking Reports" links to this same route with a
  // different navState - since React Router doesn't remount the page for a
  // same-path navigation, re-apply the preset type whenever it changes.
  useEffect(() => {
    if (location.state?.presetType && (hasCapability('view_profit') || !['financial', 'profitability'].includes(location.state.presetType))) {
      setReportType(location.state.presetType);
    }
  }, [location.state]);

  // Reopened from Report History (ReportHistory.jsx stashes the stored spec here).
  useEffect(() => {
    const raw = sessionStorage.getItem('reopenReportSpec');
    if (!raw) return;
    sessionStorage.removeItem('reopenReportSpec');
    try {
      const s = JSON.parse(raw);
      if (s.reportType && (hasCapability('view_profit') || !['financial', 'profitability'].includes(s.reportType))) setReportType(s.reportType);
      if (s.sections) setSections(s.sections);
      if (s.selection) setSelectionMode(s.selection.mode);
      if (s.serviceTypes) setServiceTypes(s.serviceTypes);
      if (s.opsType) setOpsType(s.opsType);
      if (s.paymentType) setPaymentType(s.paymentType);
      if (s.entityType) setEntityType(s.entityType);
      if (s.dateFrom || s.dateTo) setRange((v) => ({ ...v, preset: 'custom', from: s.dateFrom || '', to: s.dateTo || '', dateField: s.dateField || v.dateField }));
    } catch (_) { /* ignore malformed stash */ }
  }, []);

  useEffect(() => {
    window.api.customReports.dateFields(reportType).then((r) => { if (r.ok) { setDateFields(r.data); setRange((v) => ({ ...v, dateField: r.data[0]?.value || '' })); } });
    window.api.customReports.sections(reportType).then((r) => {
      if (r.ok) {
        const allowed = r.data.filter((s) => (s !== 'profit' || hasCapability('view_profit')) && (s !== 'supplier_costs' || hasCapability('view_supplier_costs')));
        setSectionsAvailable(allowed); setSections(allowed);
      }
    });
    window.api.reportTemplates.list(reportType).then((r) => { if (r.ok) setTemplates(r.data); });
    setResult(null); setPicked([]); setSelectionMode('all'); setTemplateId('');
  }, [reportType]);

  const toggleSection = (s) => setSections((arr) => (arr.includes(s) ? arr.filter((x) => x !== s) : [...arr, s]));
  const removePick = (id) => setPicked((arr) => arr.filter((p) => p.id !== id));
  const addPick = (id, label) => { if (!picked.some((p) => p.id === id)) setPicked((arr) => [...arr, { id, label }]); };

  function buildSpec() {
    const spec = { reportType, dateField: range.dateField, dateFrom: range.from, dateTo: range.to };
    if (['customer', 'booking'].includes(reportType)) spec.selection = { mode: selectionMode, ids: picked.map((p) => p.id) };
    if (reportType === 'supplier') spec.selection = { mode: selectionMode, ids: picked.map((p) => p.id) };
    if (reportType === 'ledger') { spec.entityType = entityType; spec.selection = { mode: selectionMode, ids: picked.map((p) => p.id) }; }
    if (['customer', 'supplier', 'booking'].includes(reportType)) {
      // Safety net: a reopened report-history/template spec could carry a
      // restricted section even if the current role can't see it in the
      // checklist above - never send it to the backend, so preview and
      // export both honour the current user's access, not whoever saved it.
      spec.sections = sections.filter((s) => (s !== 'profit' || hasCapability('view_profit')) && (s !== 'supplier_costs' || hasCapability('view_supplier_costs')));
    }
    if (reportType === 'service') spec.serviceTypes = serviceTypes;
    if (reportType === 'travel_ops') spec.opsType = opsType;
    if (reportType === 'payment') { spec.paymentType = paymentType; if (picked[0]) spec.customerId = picked[0].id; }
    if (reportType === 'booking') { spec.serviceType = bookingServiceType; spec.status = status; if (picked.length === 1) spec.customerId = picked[0].id; }
    return spec;
  }

  async function preview() {
    setBusy(true); setError('');
    // Multi-record reports are previewed one bounded page at a time (the screen can't
    // show 30,000 customer cards anyway); exports below always re-run WITHOUT the limit.
    const limited = ['customer', 'supplier', 'booking'].includes(reportType) ? { previewLimit: PREVIEW_FETCH_LIMIT } : {};
    const res = await window.api.customReports.run({ ...buildSpec(), ...limited });
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setResult(res.data);
    // A preview is a generated report too: save it to Report History (same as PDF / Excel / Print) so it can be reopened later.
    try { await logHistory('Preview'); } catch (_) { /* history is a convenience - never block the preview */ }
    // The result is rendered below the filter form; bring it into view so Preview never looks like it did nothing.
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }

  function reportPayload(res = result) {
    const spec = buildSpec();
    const title = meta.types.find((t) => t.key === reportType)?.label || 'Report';
    const dateRangeLabel = range.from && range.to ? `${range.from} to ${range.to}` : 'All dates';
    const filtersSummary = ['customer', 'supplier', 'booking', 'ledger'].includes(reportType)
      ? `${selectionMode === 'all' ? 'All records' : `${picked.length} selected`} - sections: ${sections.map((s) => SECTION_LABELS[s] || s).join(', ')}`
      : '';

    let reportSections = [];
    if (['customer', 'supplier'].includes(reportType)) {
      reportSections = res.records.flatMap((rec) => {
        const name = rec.customer?.full_name || rec.supplier?.name;
        return Object.entries(rec.sections).map(([key, data]) => sectionToTable(key, data, `${name} - ${SECTION_LABELS[key] || key}`));
      });
    } else if (reportType === 'booking') {
      reportSections = res.records.flatMap((rec) => Object.entries(rec.sections).map(([key, data]) => sectionToTable(key, data, `${rec.booking.booking_code} - ${SECTION_LABELS[key] || key}`)));
    } else if (reportType === 'ledger') {
      reportSections = res.records.map((rec) => ({
        title: `${rec.name} - Ledger`, columns: LEDGER_COLUMNS.map(([k, l, f]) => ({ key: k, label: l, money: !!f && f === money })),
        rows: rec.view.entries, totals: { debit: rec.view.totalDebit, credit: rec.view.totalCredit }
      }));
    } else {
      const cols = FLAT_COLUMNS[reportType] || [];
      reportSections = [{ title, columns: cols.map(([k, l, f]) => ({ key: k, label: l, money: f === money })), rows: res.rows || [], totals: res.grandTotals }];
    }
    return { title, dateRangeLabel, filtersSummary: [filtersSummary, res.currencyNotice].filter(Boolean).join('  |  '), sections: reportSections, grandTotals: res.grandTotals, orientation };
  }

  function sectionToTable(key, data, title) {
    if (TABLE_SECTIONS[key]) {
      const cols = TABLE_SECTIONS[key];
      return { title, columns: cols.map(([k, l, f]) => ({ key: k, label: l, money: f === money })), rows: Array.isArray(data) ? data : [] };
    }
    // info-style sections become a single-row key/value table
    const obj = data && typeof data === 'object' ? data : { value: data };
    return { title, columns: Object.keys(obj).map((k) => ({ key: k, label: k })), rows: [obj] };
  }

  // Builds the Excel workbook shape: unlike the PDF (one set of tables per
  // record), Excel gets ONE SHEET PER SECTION aggregated across every
  // selected record - e.g. a single "Bookings" sheet listing every booking
  // from every selected customer, with a leading column saying whose it is -
  // because that is what's actually useful to filter/pivot in a spreadsheet
  // (master prompt section 36's example: Summary, Customers, Bookings,
  // Services, Payments, Supplier Costs, Ledger, Profit - only the relevant
  // sheets for what was actually selected).
  function excelPayload(res = result) {
    const title = meta.types.find((t) => t.key === reportType)?.label || 'Report';

    if (['customer', 'supplier', 'booking'].includes(reportType)) {
      const idLabel = reportType === 'booking' ? 'Booking #' : reportType === 'supplier' ? 'Supplier' : 'Customer';
      const idOf = (rec) => rec.booking?.booking_code || rec.customer?.full_name || rec.supplier?.name || '—';

      const summarySheet = {
        name: 'Summary',
        columns: [{ key: 'id', label: idLabel }, ...sections.map((s) => ({ key: s, label: `${SECTION_LABELS[s] || s} Count` }))],
        rows: res.records.map((rec) => {
          const row = { id: idOf(rec) };
          for (const s of sections) {
            const d = rec.sections[s];
            row[s] = Array.isArray(d) ? d.length : (d ? 1 : 0);
          }
          return row;
        })
      };

      const sectionSheets = sections
        .filter((s) => TABLE_SECTIONS[s])
        .map((s) => {
          const cols = TABLE_SECTIONS[s];
          const rows = res.records.flatMap((rec) => (Array.isArray(rec.sections[s]) ? rec.sections[s] : []).map((r) => ({ __owner: idOf(rec), ...r })));
          return {
            name: SECTION_LABELS[s] || s,
            columns: [{ key: '__owner', label: idLabel }, ...cols.map(([k, l, f]) => ({ key: k, label: l, money: f === money }))],
            rows
          };
        })
        .filter((sheet) => sheet.rows.length > 0);

      const infoSheets = sections
        .filter((s) => INFO_SECTIONS.includes(s) && s !== 'notes')
        .map((s) => {
          const rows = res.records.map((rec) => {
            const d = rec.sections[s];
            const obj = d && typeof d === 'object' ? d : { value: d };
            return { __owner: idOf(rec), ...Object.fromEntries(Object.entries(obj).filter(([k]) => k !== 'components')) };
          });
          const keys = [...new Set(rows.flatMap((r) => Object.keys(r)))].filter((k) => k !== '__owner');
          return { name: SECTION_LABELS[s] || s, columns: [{ key: '__owner', label: idLabel }, ...keys.map((k) => ({ key: k, label: k }))], rows };
        })
        .filter((sheet) => sheet.rows.length > 0);

      return { sheets: [summarySheet, ...sectionSheets, ...infoSheets], suggestedName: `${title.replace(/[^\w\- ]/g, '')}.xlsx` };
    }

    if (reportType === 'ledger') {
      const summarySheet = {
        name: 'Summary',
        columns: [{ key: 'name', label: 'Account' }, { key: 'debit', label: 'Total Debit', money: true }, { key: 'credit', label: 'Total Credit', money: true }, { key: 'closing', label: 'Closing Balance', money: true }],
        rows: res.records.map((rec) => ({ name: rec.name, debit: rec.view.totalDebit, credit: rec.view.totalCredit, closing: rec.view.closingBalance }))
      };
      const ledgerSheet = {
        name: 'Ledger',
        columns: [{ key: 'account', label: 'Account' }, ...LEDGER_COLUMNS.map(([k, l, f]) => ({ key: k, label: l, money: f === money }))],
        rows: res.records.flatMap((rec) => rec.view.entries.map((e) => ({ account: rec.name, ...e })))
      };
      return { sheets: [summarySheet, ledgerSheet], suggestedName: `${title.replace(/[^\w\- ]/g, '')}.xlsx` };
    }

    // Flat types: one sheet is already the whole report.
    const cols = FLAT_COLUMNS[reportType] || (res.rows?.[0] ? Object.keys(res.rows[0]).map((k) => [k, k]) : []);
    return {
      sheets: [{ name: title.slice(0, 31), columns: cols.map(([k, l, f]) => ({ key: k, label: l, money: f === money })), rows: res.rows || [], totals: res.grandTotals }],
      suggestedName: `${title.replace(/[^\w\- ]/g, '')}.xlsx`
    };
  }

  async function logHistory(format) {
    const spec = buildSpec();
    const title = meta.types.find((t) => t.key === reportType)?.label || 'Report';
    await window.api.reportHistory.record({
      reportName: `${title} - ${new Date().toLocaleString()}`, reportType, spec,
      dateFrom: range.from || null, dateTo: range.to || null, generatedFormat: format,
      relatedCustomerId: reportType === 'customer' && picked.length === 1 ? picked[0].id : (reportType === 'payment' ? picked[0]?.id : null),
      relatedSupplierId: reportType === 'supplier' && picked.length === 1 ? picked[0].id : null,
      relatedBookingId: reportType === 'booking' && picked.length === 1 ? picked[0].id : null
    });
  }

  // The preview may be a truncated page of a much larger report. Anything that LEAVES
  // the app (PDF / Excel / Print) must carry the whole thing, never the on-screen subset.
  async function getFullResult() {
    if (!result?.truncated) return { ok: true, data: result };
    return window.api.customReports.run(buildSpec());
  }
  async function loadAll() {
    setBusy(true); setError('');
    const res = await getFullResult();
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setResult(res.data);
  }

  async function act(fn, format) { setBusy(true); setError(''); const r = await fn(); setBusy(false); if (!r.ok) return setError(r.error); await logHistory(format); }

  async function saveTemplate() {
    const name = window.prompt('Template name:');
    if (!name) return;
    const spec = buildSpec();
    spec.dateFrom = ''; spec.dateTo = ''; // templates save the configuration, not a frozen date range
    const r = await window.api.reportTemplates.create({ name, reportType, spec });
    if (!r.ok) return setError(r.error);
    const list = await window.api.reportTemplates.list(reportType);
    if (list.ok) setTemplates(list.data);
  }

  function loadTemplate(id) {
    setTemplateId(id);
    const t = templates.find((x) => String(x.id) === String(id));
    if (!t) return;
    const s = t.spec;
    if (s.sections) setSections(s.sections);
    if (s.selection) { setSelectionMode(s.selection.mode); setPicked([]); }
    if (s.serviceTypes) setServiceTypes(s.serviceTypes);
    if (s.opsType) setOpsType(s.opsType);
    if (s.paymentType) setPaymentType(s.paymentType);
    if (s.entityType) setEntityType(s.entityType);
  }

  const PickerComponent = (reportType === 'supplier' || (reportType === 'ledger' && entityType === 'supplier')) ? SupplierSearchSelect : CustomerSearchSelect;

  if (!meta) return <div className="card" style={{ padding: 30 }}>Loading report builder…</div>;

  return (
    <div>
      <div className="page-header">
        <div><h1>Custom Report Builder</h1><p>Compose a report from real data - pick what to include, filter it, then preview or export.</p></div>
      </div>

      <div className="card" style={{ padding: '18px 20px', marginBottom: 18 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, alignItems: 'flex-end', marginBottom: 14 }}>
          <Field label="Report Type">
            <select className="field-input" style={{ minWidth: 200 }} value={reportType} onChange={(e) => setReportType(e.target.value)}>
              {meta.types.filter((t) => hasCapability('view_profit') || !['financial', 'profitability'].includes(t.key)).map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
            </select>
          </Field>
          {templates.length > 0 && (
            <Field label="Load Template">
              <select className="field-input" value={templateId} onChange={(e) => loadTemplate(e.target.value)}>
                <option value="">— choose —</option>
                {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </Field>
          )}
          {dateFields.length > 0 && <DateRangeFilter value={range} onChange={setRange} dateFieldOptions={dateFields} />}
        </div>

        {reportType === 'ledger' && (
          <Field label="Ledger For" style={{ marginBottom: 12 }}>
            <select className="field-input" style={{ width: 160 }} value={entityType} onChange={(e) => { setEntityType(e.target.value); setPicked([]); }}>
              <option value="customer">Customer</option><option value="supplier">Supplier</option>
            </select>
          </Field>
        )}

        {['customer', 'supplier', 'booking', 'ledger'].includes(reportType) && (
          <div style={{ marginBottom: 14 }}>
            <label className="field-label">{reportType === 'booking' ? 'Bookings' : reportType === 'supplier' ? 'Suppliers' : 'Customers'}</label>
            <div style={{ display: 'flex', gap: 14, marginBottom: 8 }}>
              {['all', 'specific', 'multiple'].map((m) => (
                <label key={m} style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <input type="radio" checked={selectionMode === m} onChange={() => { setSelectionMode(m); setPicked([]); }} /> {m === 'all' ? 'All' : m === 'specific' ? 'Specific' : 'Multiple'}
                </label>
              ))}
            </div>
            {selectionMode !== 'all' && reportType !== 'booking' && (
              <>
                <div style={{ maxWidth: 360 }}><PickerComponent value="" valueLabel="" onChange={(id, label) => addPick(id, label)} /></div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
                  {picked.map((p) => (
                    <span key={p.id} className="chip">{p.label} <button onClick={() => removePick(p.id)}><X size={11} /></button></span>
                  ))}
                </div>
              </>
            )}
            {reportType === 'booking' && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
                <Field label="Filter by Customer (optional)"><div style={{ width: 240 }}><CustomerSearchSelect value={picked[0]?.id || ''} valueLabel={picked[0]?.label || ''} onChange={(id, label) => setPicked([{ id, label }])} /></div></Field>
                <Field label="Status"><select className="field-input" value={status} onChange={(e) => setStatus(e.target.value)}><option>All</option><option>Inquiry</option><option>Pending</option><option>Confirmed</option><option>Completed</option><option>Cancelled</option></select></Field>
                <Field label="Service Type"><select className="field-input" value={bookingServiceType} onChange={(e) => setBookingServiceType(e.target.value)}><option>All</option><option>Flight</option><option>Hotel</option><option>Visa</option><option>Transport</option><option>Ziyarat</option></select></Field>
              </div>
            )}
          </div>
        )}

        {reportType === 'service' && (
          <Field label="Service Types" style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
              {meta.serviceTypes.filter((t) => t !== 'Package' && t !== 'Other').map((t) => (
                <label key={t} style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <input type="checkbox" checked={serviceTypes.includes(t)} onChange={() => setServiceTypes((arr) => (arr.includes(t) ? arr.filter((x) => x !== t) : [...arr, t]))} /> {t}
                </label>
              ))}
            </div>
          </Field>
        )}

        {reportType === 'travel_ops' && (
          <Field label="Operation Type" style={{ marginBottom: 14 }}>
            <select className="field-input" style={{ minWidth: 220 }} value={opsType} onChange={(e) => setOpsType(e.target.value)}>
              {meta.opsTypes.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
        )}

        {reportType === 'payment' && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginBottom: 14 }}>
            <Field label="Customer (optional)"><div style={{ width: 240 }}><CustomerSearchSelect value={picked[0]?.id || ''} valueLabel={picked[0]?.label || ''} onChange={(id, label) => setPicked([{ id, label }])} /></div></Field>
            <Field label="Payment Type"><select className="field-input" value={paymentType} onChange={(e) => setPaymentType(e.target.value)}><option>All</option><option>Advance</option><option>Partial</option><option>Full</option><option>Refund</option></select></Field>
          </div>
        )}

        {sectionsAvailable.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <label className="field-label">Sections to Include</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => setSections(sectionsAvailable)}>Select All</button>
                <button className="btn btn-secondary btn-sm" onClick={() => setSections([])}>Unselect All</button>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '6px 10px', marginTop: 8 }}>
              {sectionsAvailable.map((s) => (
                <label key={s} style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <input type="checkbox" checked={sections.includes(s)} onChange={() => toggleSection(s)} /> {SECTION_LABELS[s] || s}
                </label>
              ))}
            </div>
          </div>
        )}

        {error && <div className="login-error" style={{ marginBottom: 10 }}>{error}</div>}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <button className="btn btn-primary" disabled={busy} onClick={preview}>{busy ? 'Loading…' : 'Preview'}</button>
          {result && (
            <select className="field-input" style={{ width: 130 }} value={orientation} onChange={(e) => setOrientation(e.target.value)} title="PDF/Print page orientation">
              <option value="landscape">A4 Landscape</option><option value="portrait">A4 Portrait</option>
            </select>
          )}
          <button className="btn btn-secondary" disabled={busy} onClick={saveTemplate}><Save size={14} /> Save as Template</button>
          {result && hasCapability('export_reports') && (
            <>
              <button className="btn btn-secondary" disabled={busy} onClick={() => act(async () => { const full = await getFullResult(); return full.ok ? window.api.customReports.exportPdf(reportPayload(full.data)) : full; }, 'PDF')}><FileDown size={14} /> PDF</button>
              <button className="btn btn-secondary" disabled={busy} onClick={() => act(async () => { const full = await getFullResult(); if (!full.ok) return full; const { sheets, suggestedName } = excelPayload(full.data); return window.api.reportExport.exportExcel(sheets, suggestedName); }, 'Excel')}><FileSpreadsheet size={14} /> Excel</button>
              <button className="btn btn-secondary" disabled={busy} onClick={() => act(async () => { const full = await getFullResult(); return full.ok ? window.api.customReports.print(reportPayload(full.data)) : full; }, 'Print')}><Printer size={14} /> Print</button>
            </>
          )}
          {result && !hasCapability('export_reports') && (
            <span style={{ fontSize: 11.5, color: 'var(--color-text-faint)', display: 'flex', alignItems: 'center', gap: 5 }}><Lock size={12} /> Export is restricted for your role</span>
          )}
        </div>
      </div>

      {result && (
        <div ref={resultRef} style={{ scrollMarginTop: 12 }}>
          <div className="card" style={{ padding: '10px 16px', marginBottom: 14, fontSize: 13, fontWeight: 600 }}>
            Preview — {meta.types.find((t) => t.key === reportType)?.label || 'Report'}
            {(result.records || result.rows) && <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}> · {(result.records || result.rows).length} {(result.records || result.rows).length === 1 ? 'record' : 'records'}</span>}
          </div>
          <CurrencyNotice text={result.currencyNotice} />
          <ReportPreview result={result} reportType={reportType} onLoadAll={loadAll} busy={busy} />
        </div>
      )}
    </div>
  );
}

function Field({ label, children, style }) {
  return <div style={style}><label className="field-label">{label}</label>{children}</div>;
}

// Rendering thousands of nested tables at once freezes the window (an "All
// customers" report can have a card per customer). The preview shows the
// first PAGE of records and lets the user reveal more; exports always use the
// FULL result, so nothing is lost - only the on-screen rendering is bounded.
const PREVIEW_PAGE = 25;

function ShowMore({ shown, total, onMore, onAll, truncated, onLoadAll, busy }) {
  if (shown >= total && truncated) {
    return (
      <div className="card" style={{ padding: '12px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5 }}>
        <span>Preview limited to the first {truncated.shown} of {truncated.total} records (exports include all {truncated.total}).</span>
        <button className="btn btn-secondary btn-sm" disabled={busy} onClick={onLoadAll}>{busy ? 'Loading…' : `Load all ${truncated.total} on screen`}</button>
      </div>
    );
  }
  if (shown >= total) return null;
  return (
    <div className="card" style={{ padding: '12px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5 }}>
      <span>Showing {shown} of {total} records on screen (exports include all {total}).</span>
      <button className="btn btn-secondary btn-sm" onClick={onMore}>Show {Math.min(PREVIEW_PAGE, total - shown)} more</button>
      <button className="btn btn-secondary btn-sm" onClick={onAll}>Show all</button>
    </div>
  );
}

// This app records a currency per booking but has no exchange rates and never converts, so when a
// report spans several currencies it says so (and the same sentence is printed on the PDF).
function CurrencyNotice({ text }) {
  if (!text) return null;
  return <div className="card" style={{ padding: '10px 16px', marginBottom: 14, fontSize: 12.5, borderLeft: '3px solid var(--color-warning, #C9A227)' }}>{text}</div>;
}

export function ReportPreview({ result, reportType, onLoadAll, busy }) {
  const [visible, setVisible] = useState(PREVIEW_PAGE);
  useEffect(() => { setVisible(PREVIEW_PAGE); }, [result]); // a fresh preview starts back at page one
  const flat = usePagination(result.rows || [], 50);
  useEffect(() => { flat.reset(); }, [result]);
  const more = () => setVisible((v) => v + PREVIEW_PAGE);
  const all = () => setVisible(Number.MAX_SAFE_INTEGER);
  if (['customer', 'supplier'].includes(reportType)) {
    return (
      <div>
        {result.records.length === 0 && <EmptyCard text="No matching records." />}
        {result.records.slice(0, visible).map((rec, i) => (
          <div key={i} className="card" style={{ padding: '16px 20px', marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, marginBottom: 10 }}>{rec.customer?.full_name || rec.supplier?.name}</h3>
            {Object.entries(rec.sections).map(([key, data]) => <SectionBlock key={key} title={SECTION_LABELS[key] || key} data={data} sectionKey={key} />)}
          </div>
        ))}
        <ShowMore shown={Math.min(visible, result.records.length)} total={result.records.length} onMore={more} onAll={all} truncated={result.truncated} onLoadAll={onLoadAll} busy={busy} />
        <GrandTotals totals={result.grandTotals} />
      </div>
    );
  }
  if (reportType === 'booking') {
    return (
      <div>
        {result.records.length === 0 && <EmptyCard text="No matching bookings." />}
        {result.records.slice(0, visible).map((rec, i) => (
          <div key={i} className="card" style={{ padding: '16px 20px', marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, marginBottom: 10 }}>{rec.booking.booking_code} — {rec.booking.customer?.full_name}</h3>
            {Object.entries(rec.sections).map(([key, data]) => <SectionBlock key={key} title={SECTION_LABELS[key] || key} data={data} sectionKey={key} />)}
          </div>
        ))}
        <ShowMore shown={Math.min(visible, result.records.length)} total={result.records.length} onMore={more} onAll={all} truncated={result.truncated} onLoadAll={onLoadAll} busy={busy} />
        <GrandTotals totals={result.grandTotals} />
      </div>
    );
  }
  if (reportType === 'ledger') {
    return (
      <div>
        {result.records.length === 0 && <EmptyCard text="No matching ledger activity." />}
        {result.records.slice(0, visible).map((rec) => (
          <div key={rec.id} className="card" style={{ padding: '16px 20px', marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, marginBottom: 10 }}>{rec.name} — Closing: {money(rec.view.closingBalance)}</h3>
            <SimpleTable columns={LEDGER_COLUMNS} rows={rec.view.entries} />
          </div>
        ))}
        <ShowMore shown={Math.min(visible, result.records.length)} total={result.records.length} onMore={more} onAll={all} truncated={result.truncated} onLoadAll={onLoadAll} busy={busy} />
        <GrandTotals totals={result.grandTotals} />
      </div>
    );
  }
  // flat types: service, financial, profitability, travel_ops, payment
  const cols = FLAT_COLUMNS[reportType] || (result.rows?.[0] ? Object.keys(result.rows[0]).map((k) => [k, k]) : []);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      <SimpleTable columns={cols} rows={flat.pageRows} />
      <Pagination {...flat.pagerProps} label="rows" />
      <div style={{ padding: '10px 16px' }}><GrandTotals totals={result.grandTotals} /></div>
    </div>
  );
}

// Report sections come back as: a table (array of rows), a flat info object, or an info object that also carries
// nested objects / row lists (e.g. profit -> cost_breakdown, ledger -> entries, booking_info -> customer). React cannot
// render an object as a child (it throws and blanks the whole page), so every value is turned into text or a sub-table here.
const humanize = (k) => String(k).replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
function cellText(v) {
  if (v === null || v === undefined || v === '') return '—';
  if (typeof v === 'number') return v.toLocaleString();
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  if (typeof v === 'object') return Array.isArray(v) ? `${v.length} item${v.length === 1 ? '' : 's'}` : Object.entries(v).map(([k, x]) => `${humanize(k)}: ${cellText(x)}`).join(', ');
  return String(v);
}
const isPlainObject = (v) => v && typeof v === 'object' && !Array.isArray(v);
const autoColumns = (rows) => Object.keys(rows[0] || {}).filter((k) => k !== 'id' && !k.endsWith('_id') && (rows[0][k] === null || typeof rows[0][k] !== 'object')).map((k) => [k, humanize(k)]);

const SectionBlock = memo(function SectionBlock({ title, data, sectionKey }) {
  if (TABLE_SECTIONS[sectionKey]) {
    return (
      <div style={{ marginBottom: 14 }}>
        <h4 style={{ fontSize: 12.5, color: 'var(--color-text-muted)', margin: '0 0 6px' }}>{title}</h4>
        {Array.isArray(data) && data.length > 0 ? <SimpleTable columns={TABLE_SECTIONS[sectionKey]} rows={data} /> : <p style={{ fontSize: 12, color: 'var(--color-text-faint)' }}>No records.</p>}
      </div>
    );
  }
  const obj = isPlainObject(data) ? data : { Value: data ?? '—' };
  const entries = Object.entries(obj).filter(([k]) => k !== 'components');
  const cells = [];   // simple "label: value" pairs (nested objects are flattened one level)
  const lists = [];   // row lists -> small tables underneath
  for (const [k, v] of entries) {
    if (Array.isArray(v)) lists.push([k, v]);
    else if (isPlainObject(v)) Object.entries(v).forEach(([kk, vv]) => cells.push([`${humanize(k)} · ${humanize(kk)}`, vv]));
    else cells.push([humanize(k), v]);
  }
  return (
    <div style={{ marginBottom: 14 }}>
      <h4 style={{ fontSize: 12.5, color: 'var(--color-text-muted)', margin: '0 0 6px' }}>{title}</h4>
      {cells.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '4px 16px', fontSize: 12.5 }}>
          {cells.map(([k, v]) => (
            <div key={k}><span style={{ color: 'var(--color-text-faint)' }}>{k}: </span>{cellText(v)}</div>
          ))}
        </div>
      )}
      {lists.map(([k, rows]) => (
        <div key={k} style={{ marginTop: 8 }}>
          {(lists.length > 1 || cells.length > 0) && <div style={{ fontSize: 12, color: 'var(--color-text-muted)', margin: '0 0 4px' }}>{humanize(k)}</div>}
          {rows.length > 0 && isPlainObject(rows[0]) ? <SimpleTable columns={autoColumns(rows)} rows={rows} /> : <p style={{ fontSize: 12, color: 'var(--color-text-faint)' }}>No records.</p>}
        </div>
      ))}
    </div>
  );
});

const SimpleTable = memo(function SimpleTable({ columns, rows }) {
  return (
    <table className="data-table">
      <thead><tr>{columns.map(([k, l]) => <th key={k}>{l}</th>)}</tr></thead>
      <tbody>
        {rows.length === 0 && <tr><td colSpan={columns.length} style={{ padding: 16, textAlign: 'center', color: 'var(--color-text-muted)' }}>No records.</td></tr>}
        {rows.map((row, i) => (
          <tr key={i}>{columns.map(([k, , fmt]) => <td key={k}>{fmt ? fmt(row[k]) : cellText(row[k])}</td>)}</tr>
        ))}
      </tbody>
    </table>
  );
});

function GrandTotals({ totals }) {
  if (!totals || Object.keys(totals).length === 0) return null;
  return (
    <div style={{ fontSize: 13, fontWeight: 600, padding: '8px 2px' }}>
      {Object.entries(totals).map(([k, v]) => (
        <span key={k} style={{ marginRight: 18 }}>{k.replace(/_/g, ' ')}: {typeof v === 'number' ? money(v) : v}</span>
      ))}
    </div>
  );
}

function EmptyCard({ text }) {
  return <div className="card" style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>{text}</div>;
}
