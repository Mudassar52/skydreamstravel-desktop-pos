import { useState } from 'react';
import { Plane, LogIn, AlertCircle, User, Lock, Eye, EyeOff, Loader2, ShieldCheck, Users, FileText, BarChart3 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { logoIconSrc } from '../components/brandLogo.js';
import './login.css';

const HIGHLIGHTS = [
  { icon: Users, text: 'Customers, leads and bookings in one place' },
  { icon: FileText, text: 'Invoices, payments and travel dossiers' },
  { icon: BarChart3, text: 'Live reports on sales, profit and outstanding' },
  { icon: ShieldCheck, text: 'Role-based, secure staff access' }
];

export default function Login() {
  const { login, error, loading } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    if (!username || !password) return;
    login(username, password);
  }

  return (
    <div className="login-screen">
      <aside className="login-hero">
        <div className="login-hero-inner">
          <div className="login-hero-logo">
            {logoIconSrc ? <img src={logoIconSrc} alt="Company logo" draggable={false} /> : <Plane size={40} />}
          </div>
          <h2>Welcome back</h2>
          <p>Run your whole travel agency — Umrah, Hajj, tours, flights and visas — from one dashboard.</p>
          <ul>
            {HIGHLIGHTS.map(({ icon: Icon, text }) => (
              <li key={text}><span><Icon size={16} /></span>{text}</li>
            ))}
          </ul>
        </div>
        <div className="login-hero-orb orb-a" />
        <div className="login-hero-orb orb-b" />
      </aside>

      <main className="login-panel">
        <form className="login-card" onSubmit={handleSubmit}>
          <div className="login-brand">
            {logoIconSrc ? (
              <img className="login-logo" src={logoIconSrc} alt="Company logo" draggable={false} />
            ) : (
              <>
                <div className="brand-mark"><Plane size={20} /></div>
                <div>
                  <strong>Travel Agency</strong>
                  <span>Manager</span>
                </div>
              </>
            )}
          </div>

          <h1>Sign in</h1>
          <p className="login-sub">Enter your credentials to access the agency system.</p>

          {error && (
            <div className="login-error">
              <AlertCircle size={15} />
              <span>{error}</span>
            </div>
          )}

          <label className="field-label" htmlFor="login-username">Username</label>
          <div className="login-input">
            <User size={16} />
            <input
              id="login-username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              autoComplete="username"
              autoFocus
            />
          </div>

          <label className="field-label" htmlFor="login-password" style={{ marginTop: 16 }}>Password</label>
          <div className="login-input">
            <Lock size={16} />
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              autoComplete="current-password"
            />
            <button
              type="button"
              className="login-eye"
              title={showPassword ? 'Hide password' : 'Show password'}
              onClick={() => setShowPassword((v) => !v)}
              tabIndex={-1}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          <button className="btn btn-primary login-submit" type="submit" disabled={loading || !username || !password}>
            {loading ? <Loader2 size={16} className="spin" /> : <LogIn size={16} />}
            {loading ? 'Signing in…' : 'Sign In'}
          </button>

          <p className="login-hint">First run default: <strong>admin</strong> / <strong>admin123</strong> — change this from Staff &amp; Users after signing in.</p>
        </form>
      </main>
    </div>
  );
}
