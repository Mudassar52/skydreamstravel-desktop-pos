import { useEffect, useState } from 'react';
import { Plus, Undo2, BarChart3 } from 'lucide-react';
import Pagination from '../components/Pagination.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Accounting() {
  const { can } = useAuth();
  const [view, setView] = useState('entries');
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [summary, setSummary] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.accounting.list({ page, pageSize });
    if (res.ok && res.data.rows.length === 0 && page > 1) { setPage(page - 1); return; }
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
    const sum = await window.api.accounting.summary({});
    if (sum.ok) setSummary(sum.data);
  }
  useEffect(() => { reload(); }, [page, pageSize]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function reverse(entry) {
    const res = await window.api.accounting.reverse(entry.id);
    if (!res.ok) setError(res.error); else { flash('Reversal entry posted.'); reload(); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Accounting</h1>
          <p>{total.toLocaleString()} entr{total === 1 ? 'y' : 'ies'} — connected debit/credit ledger across every module</p>
        </div>
        {can('accounting', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> New Entry</button>
        )}
      </div>

      <div className="customers-toolbar">
        <button className={`btn btn-sm ${view === 'entries' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setView('entries')}>Entries</button>
        <button className={`btn btn-sm ${view === 'summary' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setView('summary')}><BarChart3 size={13} /> Account Summary</button>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      {view === 'entries' && (
        <div className="card" style={{ padding: 0 }}>
          <table className="data-table">
            <thead>
              <tr><th>Date</th><th>Account</th><th>Reference</th><th>Debit</th><th>Credit</th><th>Linked</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map((e) => (
                <tr key={e.id} style={{ opacity: e.is_reversal ? 0.7 : 1 }}>
                  <td>{e.entry_date?.slice(0, 10)}</td>
                  <td>{e.account}{e.is_reversal ? ' (reversal)' : ''}</td>
                  <td>{e.reference || '—'}</td>
                  <td>{e.debit > 0 ? money(e.debit) : '—'}</td>
                  <td>{e.credit > 0 ? money(e.credit) : '—'}</td>
                  <td>{e.booking_code || e.customer_name || e.supplier_name || '—'}</td>
                  <td className="row-actions">
                    {!e.is_reversal && can('accounting', 'edit') && (
                      <button className="icon-btn" title="Reverse entry" onClick={() => reverse(e)}><Undo2 size={14} /></button>
                    )}
                  </td>
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No manual accounting entries yet.</td></tr>}
            </tbody>
          </table>
        <Pagination page={page} pageSize={pageSize} total={total} onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} label="entries" />
        </div>
      )}

      {view === 'summary' && summary && (
        <div className="card" style={{ padding: 0 }}>
          <table className="data-table">
            <thead><tr>{summary.columns.map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
            <tbody>
              {summary.rows.map((r, idx) => (
                <tr key={idx}>
                  {summary.columns.map((c) => (
                    <td key={c.key}>{c.money ? money(r[c.key]) : r[c.key]}</td>
                  ))}
                </tr>
              ))}
              {summary.rows.length === 0 && <tr><td colSpan={summary.columns.length} className="empty-row">No entries to summarize yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {formOpen && (
        <EntryFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }} />
      )}
    </div>
  );
}

const EMPTY = { account: '', debit: '', credit: '', reference: '' };

function EntryFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.account.trim()) return setError('Account name is required.');
    if (!(Number(form.debit) > 0) && !(Number(form.credit) > 0)) return setError('Enter either a debit or a credit amount.');
    if (Number(form.debit) > 0 && Number(form.credit) > 0) return setError('An entry can be a debit or a credit, not both.');
    setSaving(true);
    const res = await window.api.accounting.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Accounting entry posted.');
  }

  return (
    <Modal title="New Accounting Entry" onClose={onClose} width={440}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Account *" full><input className="field-input" value={form.account} onChange={(e) => set('account', e.target.value)} placeholder="e.g. Cash, Bank - HBL, Revenue" /></Field>
          <Field label="Debit"><input type="number" className="field-input" value={form.debit} onChange={(e) => set('debit', e.target.value)} /></Field>
          <Field label="Credit"><input type="number" className="field-input" value={form.credit} onChange={(e) => set('credit', e.target.value)} /></Field>
          <Field label="Reference" full><input className="field-input" value={form.reference} onChange={(e) => set('reference', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Post Entry'}</button>
        </div>
      </form>
    </Modal>
  );
}
