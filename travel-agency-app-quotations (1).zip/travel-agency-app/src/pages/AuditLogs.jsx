import { useEffect, useState } from 'react';
import { Search, ShieldCheck, ChevronLeft, ChevronRight } from 'lucide-react';

// Moved out of the Users & Permissions ("Staff & Users") page into its own
// top-level "Audit Logs" screen (matches the sidebar's standalone Audit
// Logs entry) - this used to live as a tab inside Staff & Users.
export default function AuditLogs() {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [action, setAction] = useState('');
  const [recordType, setRecordType] = useState('');
  const [actions, setActions] = useState([]);
  const [recordTypes, setRecordTypes] = useState([]);
  const PAGE_SIZE = 20;

  async function reload() {
    const [logs, a, rt] = await Promise.all([
      window.api.auditLogs.list({ search, action, recordType, page, pageSize: PAGE_SIZE }),
      window.api.auditLogs.actions(),
      window.api.auditLogs.recordTypes()
    ]);
    if (logs.ok) { setRows(logs.data.rows); setTotal(logs.data.total); }
    if (a.ok) setActions(a.data);
    if (rt.ok) setRecordTypes(rt.data);
  }
  useEffect(() => { reload(); }, [search, action, recordType, page]);
  useEffect(() => { setPage(1); }, [search, action, recordType]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Audit Logs</h1>
          <p>Every create, update and delete recorded across the system, including who did it and when.</p>
        </div>
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 280 }}>
          <Search size={14} />
          <input placeholder="Search description, action, user..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 200 }} value={action} onChange={(e) => setAction(e.target.value)}>
          <option value="">All actions</option>
          {actions.map((a) => <option key={a}>{a}</option>)}
        </select>
        <select className="field-input" style={{ width: 160 }} value={recordType} onChange={(e) => setRecordType(e.target.value)}>
          <option value="">All record types</option>
          {recordTypes.map((r) => <option key={r}>{r}</option>)}
        </select>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '14px 18px', borderBottom: '1px solid var(--color-border)' }}>
          <ShieldCheck size={16} color="var(--color-primary)" />
          <strong style={{ fontSize: 13.5 }}>Activity history</strong>
        </div>
        <table className="data-table">
          <thead><tr><th>When</th><th>User</th><th>Action</th><th>Record</th><th>Description</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td style={{ whiteSpace: 'nowrap' }}>{r.created_at}</td>
                <td>{r.user_name || 'System'}</td>
                <td><span className="role-badge">{r.action}</span></td>
                <td>{r.record_type ? `${r.record_type}${r.record_id ? ` #${r.record_id}` : ''}` : '—'}</td>
                <td>{r.description || '—'}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="empty-row">No activity recorded yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages} · {total.toLocaleString()} entries</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              className="icon-btn"
              aria-label="Previous page"
              title="Previous page"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
              style={{ opacity: page <= 1 ? 0.4 : 1, cursor: page <= 1 ? 'not-allowed' : 'pointer' }}
            >
              <ChevronLeft size={15} />
            </button>
            <button
              className="icon-btn"
              aria-label="Next page"
              title="Next page"
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
              style={{ opacity: page >= totalPages ? 0.4 : 1, cursor: page >= totalPages ? 'not-allowed' : 'pointer' }}
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
