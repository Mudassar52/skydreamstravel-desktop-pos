import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, ChevronLeft, ChevronRight, Wallet } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import SupplierSearchSelect from '../components/SupplierSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['All', 'Unpaid', 'Partially Paid', 'Paid', 'Overdue'];
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const pillClass = (status) => (status === 'Paid' ? 'on' : status === 'Overdue' ? 'off' : 'on');

export default function SupplierInvoices() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [formOpen, setFormOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [advanceTarget, setAdvanceTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.supplierInvoices.list({ status, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [status, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [status]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.supplierInvoices.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Supplier invoice deleted.'); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Supplier Invoices</h1>
          <p>{total.toLocaleString()} supplier invoice{total === 1 ? '' : 's'}</p>
        </div>
        {can('supplier_invoices', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> New Supplier Invoice</button>
        )}
      </div>

      <div className="customers-toolbar">
        <select className="field-input" style={{ width: 180 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Invoice #</th><th>Supplier</th><th>Booking</th><th>Due Date</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.invoice_number}</td>
                <td>{r.supplier_name}</td>
                <td>{r.booking_code || '—'}</td>
                <td>{r.due_date ? r.due_date.slice(0, 10) : '—'}</td>
                <td>{money(r.total)}</td>
                <td>{money(r.paid_amount)}</td>
                <td style={{ fontWeight: 600 }}>{money(r.remaining_amount)}</td>
                <td><span className={`status-pill ${pillClass(r.status)}`}>{r.status}</span></td>
                <td className="row-actions">
                  {can('supplier_payments', 'create') && r.remaining_amount > 0 && r.status !== 'Paid' && (
                    <button className="icon-btn" title="Apply Supplier Advance" onClick={() => setAdvanceTarget(r)}><Wallet size={14} /></button>
                  )}
                  {can('supplier_invoices', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(r)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="empty-row">No supplier invoices found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <SupplierInvoiceFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {advanceTarget && (
        <ApplySupplierAdvanceModal invoice={advanceTarget} onClose={() => setAdvanceTarget(null)}
          onApplied={(msg) => { setAdvanceTarget(null); flash(msg); load(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete supplier invoice" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
            Delete invoice <strong>{deleteTarget.invoice_number}</strong>? This can't be undone.
          </p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  supplier_id: '', supplier_label: '', invoice_number: '', invoice_date: '', due_date: '',
  currency: 'PKR', amount: '', tax: 0, notes: ''
};

function SupplierInvoiceFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.supplier_id) return setError('Please select a supplier.');
    if (!form.invoice_number.trim()) return setError('Invoice number is required.');
    setSaving(true);
    const res = await window.api.supplierInvoices.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Supplier invoice created.');
  }

  return (
    <Modal title="New Supplier Invoice" onClose={onClose} width={520}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Supplier *" full>
            <SupplierSearchSelect value={form.supplier_id} valueLabel={form.supplier_label} onChange={(id, label) => setForm((s) => ({ ...s, supplier_id: id, supplier_label: label }))} />
          </Field>
          <Field label="Invoice Number *"><input className="field-input" value={form.invoice_number} onChange={(e) => set('invoice_number', e.target.value)} /></Field>
          <Field label="Invoice Date"><input type="date" className="field-input" value={form.invoice_date} onChange={(e) => set('invoice_date', e.target.value)} /></Field>
          <Field label="Due Date"><input type="date" className="field-input" value={form.due_date} onChange={(e) => set('due_date', e.target.value)} /></Field>
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Amount *"><input type="number" className="field-input" value={form.amount} onChange={(e) => set('amount', e.target.value)} /></Field>
          <Field label="Tax"><input type="number" className="field-input" value={form.tax} onChange={(e) => set('tax', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Create Invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

// Supplier Advance System (master prompt section 25): shows this supplier's
// unapplied advances and lets the user allocate part or all of one to this
// supplier invoice, plus a reversal option for what's already applied.
function ApplySupplierAdvanceModal({ invoice, onClose, onApplied }) {
  const [available, setAvailable] = useState(null);
  const [applied, setApplied] = useState(null);
  const [amounts, setAmounts] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const [av, ap] = await Promise.all([
      window.api.supplierAdvances.available(invoice.supplier_id),
      window.api.supplierAdvances.applicationsForInvoice(invoice.id)
    ]);
    if (av.ok) setAvailable(av.data);
    if (ap.ok) setApplied(ap.data);
  }, [invoice.supplier_id, invoice.id]);
  useEffect(() => { load(); }, [load]);

  async function apply(paymentId) {
    const amount = Number(amounts[paymentId]);
    if (!(amount > 0)) return setError('Enter an amount greater than zero.');
    setBusy(true); setError('');
    const res = await window.api.supplierAdvances.applyToInvoice({ supplierPaymentId: paymentId, supplierInvoiceId: invoice.id, amount });
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
  }

  async function reverse(applicationId) {
    setBusy(true); setError('');
    const res = await window.api.supplierAdvances.reverseApplication(applicationId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
  }

  return (
    <Modal title={`Apply Supplier Advance — ${invoice.invoice_number}`} onClose={onClose}>
      <div style={{ padding: '4px 2px 14px' }}>
        {error && <div className="login-error" style={{ marginBottom: 10 }}>{error}</div>}
        <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 12 }}>
          Balance remaining on this invoice: {money(invoice.remaining_amount)}
        </p>

        {!available || !applied ? <p>Loading…</p> : (
          <>
            {available.rows.length === 0 && <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>No unapplied advances for this supplier.</p>}
            {available.rows.map((a) => (
              <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 12.5, flex: 1 }}>{a.payment_date?.slice(0, 10)} — {a.reference || `Advance #${a.id}`} ({money(a.available)} available)</span>
                <input className="field-input" type="number" style={{ width: 110 }} placeholder="Amount"
                  value={amounts[a.id] || ''} onChange={(e) => setAmounts((s) => ({ ...s, [a.id]: e.target.value }))} />
                <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => apply(a.id)}>Apply</button>
              </div>
            ))}
            {applied.length > 0 && (
              <>
                <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', margin: '14px 0 8px' }}>Already applied to this invoice</p>
                {applied.map((a) => (
                  <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                    <span style={{ fontSize: 12.5, flex: 1 }}>{a.applied_at?.slice(0, 10)} — {money(a.amount)} from advance #{a.supplier_payment_id}</span>
                    <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => reverse(a.id)}>Reverse</button>
                  </div>
                ))}
              </>
            )}
          </>
        )}

        <div className="modal-actions" style={{ marginTop: 16 }}>
          <button type="button" className="btn btn-secondary" onClick={() => onApplied('Advance updated.')}>Done</button>
        </div>
      </div>
    </Modal>
  );
}
