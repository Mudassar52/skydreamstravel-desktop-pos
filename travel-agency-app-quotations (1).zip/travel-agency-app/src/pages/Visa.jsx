import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, AlertTriangle, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const STATUSES = ['Documents Pending', 'Ready to Apply', 'Applied', 'Processing', 'Approved', 'Rejected', 'Expired'];
const EMPTY = {
  customer_id: '', customer_label: '', booking_id: '', country: '', visa_type: '',
  application_date: '', submission_date: '', approval_date: '', expiry_date: '',
  application_number: '', status: 'Documents Pending', notes: ''
};
const PAGE_SIZE = 15;

export default function Visa() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [bookingOptions, setBookingOptions] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [error, setError] = useState('');

  async function reload() {
    const [v, b] = await Promise.all([
      window.api.visa.list({ search, status: statusFilter, page, pageSize: PAGE_SIZE }),
      window.api.bookings.options()
    ]);
    if (v.ok) { setRows(v.data.rows); setTotal(v.data.total); }
    if (b.ok) setBookingOptions(b.data);
  }
  useEffect(() => { reload(); }, [search, statusFilter, page]);
  useEffect(() => { setPage(1); }, [search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  async function confirmDelete() {
    const res = await window.api.visa.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  const expiringCount = rows.filter((r) => r.expiringSoon).length;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Visa</h1>
          <p>{total.toLocaleString()} application{total === 1 ? '' : 's'}.{expiringCount > 0 && ` ${expiringCount} on this page expiring within 30 days.`}</p>
        </div>
        {can('visa', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Visa Application
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 280 }}>
          <Search size={15} />
          <input placeholder="Search customer, country, application #..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 180 }} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Customer</th><th>Country</th><th>Type</th><th>Expiry</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((v) => (
              <tr key={v.id}>
                <td>{v.customer_name}{v.traveller_id && v.holder_name ? <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>with {v.holder_name}'s booking</div> : null}</td>
                <td>{v.country}</td>
                <td>{v.visa_type || '—'}</td>
                <td>
                  {v.expiry_date || '—'}
                  {v.expiringSoon && (
                    <span title="Expiring within 30 days" style={{ marginLeft: 6, color: 'var(--color-warning)' }}>
                      <AlertTriangle size={13} style={{ verticalAlign: 'text-bottom' }} />
                    </span>
                  )}
                </td>
                <td><span className={`status-pill ${v.status === 'Approved' ? 'on' : 'off'}`}>{v.status}</span></td>
                <td className="row-actions">
                  {can('visa', 'edit') && <button className="icon-btn" onClick={() => { setEditingId(v.id); setFormOpen(true); }}><Pencil size={14} /></button>}
                  {can('visa', 'delete') && <button className="icon-btn" onClick={() => setDeleteTarget(v)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No visa applications yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <VisaFormModal visaId={editingId} bookingOptions={bookingOptions} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete visa application" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete the visa application for <strong>{deleteTarget.customer_name}</strong>?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function VisaFormModal({ visaId, bookingOptions, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (visaId) {
      window.api.visa.get(visaId).then((res) => {
        if (res.ok) setForm({ ...EMPTY, ...res.data, customer_label: res.data.customer_name });
      });
    }
  }, [visaId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    if (!form.country.trim()) return setError('Country is required.');
    setSaving(true);
    const res = visaId ? await window.api.visa.update(visaId, form) : await window.api.visa.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={visaId ? 'Edit Visa Application' : 'New Visa Application'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            <CustomerSearchSelect
              value={form.customer_id}
              valueLabel={form.customer_label}
              onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))}
            />
          </Field>
          <Field label="Booking (optional)" full>
            <select className="field-input" value={form.booking_id || ''} onChange={(e) => set('booking_id', e.target.value ? Number(e.target.value) : '')}>
              <option value="">— Not linked to a booking —</option>
              {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
            </select>
          </Field>
          <Field label="Country *"><input className="field-input" value={form.country} onChange={(e) => set('country', e.target.value)} /></Field>
          <Field label="Visa Type"><input className="field-input" value={form.visa_type || ''} onChange={(e) => set('visa_type', e.target.value)} /></Field>
          <Field label="Application Number"><input className="field-input" value={form.application_number || ''} onChange={(e) => set('application_number', e.target.value)} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status || ''} onChange={(e) => set('status', e.target.value)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Application Date"><input type="date" className="field-input" value={form.application_date || ''} onChange={(e) => set('application_date', e.target.value)} /></Field>
          <Field label="Submission Date"><input type="date" className="field-input" value={form.submission_date || ''} onChange={(e) => set('submission_date', e.target.value)} /></Field>
          <Field label="Approval Date"><input type="date" className="field-input" value={form.approval_date || ''} onChange={(e) => set('approval_date', e.target.value)} /></Field>
          <Field label="Expiry Date"><input type="date" className="field-input" value={form.expiry_date || ''} onChange={(e) => set('expiry_date', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Application'}</button>
        </div>
      </form>
    </Modal>
  );
}
