import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, PlayCircle } from 'lucide-react';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

// Report Templates (master prompt section 43). Templates themselves are
// created from the Custom Report Builder ("Save as Template"); this page is
// where they're reviewed, reused or removed.

const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function ReportTemplates() {
  const navigate = useNavigate();
  const [reportType, setReportType] = useState('All');
  const [templates, setTemplates] = useState(null);
  const pg = usePagination(templates || [], 25);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.reportTemplates.list(reportType === 'All' ? null : reportType);
    if (res.ok) setTemplates(res.data); else setError(res.error);
  }, [reportType]);
  useEffect(() => { load(); }, [load]);

  async function remove(id) {
    if (!window.confirm('Delete this template?')) return;
    const res = await window.api.reportTemplates.remove(id);
    if (!res.ok) return setError(res.error);
    load();
  }

  function use(t) {
    sessionStorage.setItem('reopenReportSpec', JSON.stringify({ reportType: t.report_type, ...t.spec }));
    navigate('/custom-reports');
  }

  return (
    <div>
      <div className="page-header">
        <div><h1>Report Templates</h1><p>Saved report configurations, created from the Custom Report Builder's "Save as Template".</p></div>
      </div>

      <div className="card" style={{ padding: '14px 18px', marginBottom: 16 }}>
        <select className="field-input" value={reportType} onChange={(e) => setReportType(e.target.value)}>
          <option value="All">All types</option>
          <option value="customer">Customer</option><option value="supplier">Supplier</option><option value="booking">Booking</option>
          <option value="service">Service</option><option value="financial">Financial</option><option value="profitability">Profitability</option>
          <option value="travel_ops">Travel Operations</option><option value="payment">Payment</option><option value="ledger">Ledger</option>
        </select>
      </div>

      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Name</th><th>Type</th><th>Sections</th><th>Created By</th><th>Created</th><th></th></tr></thead>
          <tbody>
            {!templates && <tr><td colSpan={6} style={{ padding: 24 }}>Loading…</td></tr>}
            {templates && templates.length === 0 && <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No templates saved yet.</td></tr>}
            {templates && pg.pageRows.map((t) => (
              <tr key={t.id}>
                <td><strong>{t.name}</strong></td>
                <td>{t.report_type}</td>
                <td>{(t.spec.sections || []).join(', ') || '—'}</td>
                <td>{t.created_by_name || '—'}</td>
                <td>{day(t.created_at)}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="icon-btn" title="Use this Template" onClick={() => use(t)}><PlayCircle size={14} /></button>
                  <button className="icon-btn" title="Delete" onClick={() => remove(t.id)}><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="templates" />
      </div>
    </div>
  );
}
