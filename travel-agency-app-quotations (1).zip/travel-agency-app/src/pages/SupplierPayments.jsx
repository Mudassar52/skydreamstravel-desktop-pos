import { useEffect, useState } from 'react';
import { Plus, Undo2 } from 'lucide-react';
import Pagination from '../components/Pagination.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import CrossCurrencyField from '../components/CrossCurrencyField.jsx';
import Field from '../components/Field.jsx';
import SupplierSearchSelect from '../components/SupplierSearchSelect.jsx';
import './customers.css';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function SupplierPayments() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [formOpen, setFormOpen] = useState(false);
  const [voidTarget, setVoidTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.supplierPayments.list({ page, pageSize });
    if (res.ok && res.data.rows.length === 0 && page > 1) { setPage(page - 1); return; }
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }
  useEffect(() => { reload(); }, [page, pageSize]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmVoid() {
    const res = await window.api.supplierPayments.void(voidTarget.id);
    if (!res.ok) setError(res.error); else { flash('Payment voided.'); reload(); }
    setVoidTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Supplier Payments</h1>
          <p>{total.toLocaleString()} recorded payment{total === 1 ? '' : 's'}</p>
        </div>
        {can('supplier_payments', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Record Payment</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Date</th><th>Supplier</th><th>Invoice</th><th>Amount</th><th>Method</th><th>Reference</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id}>
                <td>{p.payment_date?.slice(0, 10)}</td>
                <td>{p.supplier_name}</td>
                <td>{p.invoice_number || p.booking_code || '—'}</td>
                <td>{money(p.amount)}</td>
                <td>{p.payment_method}</td>
                <td>{p.reference || '—'}</td>
                <td className="row-actions">
                  {can('supplier_payments', 'delete') && (
                    <button className="icon-btn" title="Void payment" onClick={() => setVoidTarget(p)}><Undo2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No supplier payments recorded yet.</td></tr>}
          </tbody>
        </table>
        <Pagination page={page} pageSize={pageSize} total={total} onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} label="payments" />
      </div>

      {formOpen && (
        <SupplierPaymentFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }} />
      )}

      {voidTarget && (
        <Modal title="Void payment" onClose={() => setVoidTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
            Void the payment of <strong>{money(voidTarget.amount)}</strong> to <strong>{voidTarget.supplier_name}</strong>?
            This reverses its effect on the linked invoice and the supplier ledger.
          </p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setVoidTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmVoid}>Void Payment</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  supplier_id: '', supplier_label: '', supplier_invoice_id: '', amount: '',
  payment_method: 'Bank Transfer', account_type: '', account_id: '', account_amount: '', reference: '', notes: ''
};

function SupplierPaymentFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [methods, setMethods] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [cashAccounts, setCashAccounts] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.supplierPayments.methods().then((res) => res.ok && setMethods(res.data));
    window.api.bankAccounts.list().then((res) => res.ok && setBankAccounts(res.data));
    window.api.cashAccounts.list().then((res) => res.ok && setCashAccounts(res.data));
  }, []);

  useEffect(() => {
    if (!form.supplier_id) { setInvoices([]); return; }
    window.api.supplierInvoices.list({ supplierId: form.supplier_id, pageSize: 50 }).then((res) => {
      if (res.ok) setInvoices(res.data.rows.filter((i) => i.remaining_amount > 0));
    });
  }, [form.supplier_id]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.supplier_id) return setError('Please select a supplier.');
    if (!(Number(form.amount) > 0)) return setError('Amount must be greater than zero.');
    setSaving(true);
    const res = await window.api.supplierPayments.create({
      ...form,
      supplier_invoice_id: form.supplier_invoice_id || null,
      account_id: form.account_id || null,
      account_amount: form.account_amount ? Number(form.account_amount) : null
    });
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Supplier payment recorded.');
  }

  const accountOptions = form.account_type === 'Bank' ? bankAccounts : form.account_type === 'Cash' ? cashAccounts : [];
  const selectedAccount = accountOptions.find((a) => String(a.id) === String(form.account_id)) || null;
  const payInvoice = invoices.find((i) => String(i.id) === String(form.supplier_invoice_id));

  return (
    <Modal title="Record Supplier Payment" onClose={onClose} width={520}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Supplier *" full>
            <SupplierSearchSelect value={form.supplier_id} valueLabel={form.supplier_label} onChange={(id, label) => setForm((s) => ({ ...s, supplier_id: id, supplier_label: label, supplier_invoice_id: '' }))} />
          </Field>

          <Field label="Supplier Invoice (optional)" full>
            <select className="field-input" value={form.supplier_invoice_id} onChange={(e) => set('supplier_invoice_id', e.target.value)}>
              <option value="">Not linked to a specific invoice</option>
              {invoices.map((i) => <option key={i.id} value={i.id}>{i.invoice_number} — Balance {money(i.remaining_amount)}</option>)}
            </select>
          </Field>

          <Field label="Amount *"><input type="number" className="field-input" value={form.amount} onChange={(e) => set('amount', e.target.value)} /></Field>
          <Field label="Payment Method">
            <select className="field-input" value={form.payment_method} onChange={(e) => set('payment_method', e.target.value)}>
              {methods.map((m) => <option key={m}>{m}</option>)}
            </select>
          </Field>

          <Field label="Pay From (optional)">
            <select className="field-input" value={form.account_type} onChange={(e) => setForm((s) => ({ ...s, account_type: e.target.value, account_id: '' }))}>
              <option value="">Not tracked against an account</option>
              <option value="Bank" disabled={bankAccounts.length === 0}>Bank Account{bankAccounts.length === 0 ? ' (none set up yet)' : ''}</option>
              <option value="Cash" disabled={cashAccounts.length === 0}>Cash Account{cashAccounts.length === 0 ? ' (none set up yet)' : ''}</option>
            </select>
          </Field>
          {form.account_type && (
            <Field label={`${form.account_type} Account`}>
              <select className="field-input" value={form.account_id} onChange={(e) => setForm((s) => ({ ...s, account_id: e.target.value, account_amount: '' }))}>
                <option value="">— Select —</option>
                {accountOptions.map((a) => <option key={a.id} value={a.id}>{a.account_name} ({a.currency}, {money(a.current_balance)})</option>)}
              </select>
            </Field>
          )}
          <CrossCurrencyField docCurrency={payInvoice && payInvoice.currency} account={selectedAccount} label="Amount paid out" value={form.account_amount} onChange={(v) => set('account_amount', v)} />

          <Field label="Reference"><input className="field-input" value={form.reference} onChange={(e) => set('reference', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Record Payment'}</button>
        </div>
      </form>
    </Modal>
  );
}
