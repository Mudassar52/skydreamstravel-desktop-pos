import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import FollowUpFormModal from '../components/FollowUpFormModal.jsx';
import '../components/followups.css';
import './customers.css';

const PAGE_SIZE = 15;

function fmtDateTime(s) {
  if (!s) return '—';
  const d = new Date(`${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? s : d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}

export default function FollowUpHistory() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [method, setMethod] = useState('All');
  const [outcome, setOutcome] = useState('All');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [opts, setOpts] = useState({ contactMethods: [], outcomes: [] });
  const [formOpen, setFormOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.followups.options().then((r) => r.ok && setOpts(r.data)); }, []);

  const load = useCallback(async () => {
    const res = await window.api.followups.historyList({ search, method, outcome, dateFrom, dateTo, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); setError(''); } else setError(res.error);
  }, [search, method, outcome, dateFrom, dateTo, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, method, outcome, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function remove(row) {
    if (!window.confirm('Delete this history entry?')) return;
    const res = await window.api.followups.historyDelete(row.id);
    if (!res.ok) setError(res.error); else { flash('History entry deleted.'); load(); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Follow-up History</h1>
          <p>{total.toLocaleString()} recorded contact{total === 1 ? '' : 's'}</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/followups" className="btn btn-secondary">Scheduled Follow-ups</Link>
          {can('followups', 'create') && <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> New Follow-up</button>}
        </div>
      </div>

      <div className="customers-toolbar" style={{ flexWrap: 'wrap' }}>
        <div className="global-search" style={{ width: 280 }}>
          <input placeholder="Search name, phone, inquiry, notes..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 150 }} value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="All">All methods</option>
          {opts.contactMethods.map((m) => <option key={m}>{m}</option>)}
        </select>
        <select className="field-input" style={{ width: 170 }} value={outcome} onChange={(e) => setOutcome(e.target.value)}>
          <option value="All">All outcomes</option>
          {opts.outcomes.map((m) => <option key={m}>{m}</option>)}
        </select>
        <input type="date" className="field-input" style={{ width: 150 }} value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} title="From" />
        <input type="date" className="field-input" style={{ width: 150 }} value={dateTo} onChange={(e) => setDateTo(e.target.value)} title="To" />
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card fu-wide-table" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Date</th><th>Customer / Inquiry</th><th>Method</th><th>Activity</th><th>Purpose</th>
              <th>Outcome</th><th>Notes</th><th>Next Follow-up</th><th>By</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((h) => (
              <tr key={h.id}>
                <td>{fmtDateTime(h.created_at)}</td>
                <td>
                  {h.display_name || '—'}
                  {(h.reference_code || h.lead_code || h.contact_phone) && (
                    <span className="fu-cell-sub">{[h.reference_code || h.lead_code, h.contact_phone].filter(Boolean).join(' · ')}</span>
                  )}
                </td>
                <td>{h.contact_method || '—'}</td>
                <td>{h.activity || '—'}</td>
                <td>{h.purpose || '—'}</td>
                <td>{h.outcome || '—'}</td>
                <td style={{ maxWidth: 240 }}>{h.notes || '—'}</td>
                <td>{h.next_follow_up_date ? `${h.next_follow_up_date}${h.reminder_time ? ' ' + h.reminder_time : ''}` : '—'}</td>
                <td>{h.agent_name || '—'}</td>
                <td className="row-actions">
                  {can('followups', 'delete') && <button className="icon-btn" title="Delete" onClick={() => remove(h)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={10} className="empty-row">No follow-up history yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && <FollowUpFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />}
    </div>
  );
}
