import { useEffect, useState } from 'react';
import { CalendarClock } from 'lucide-react';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const PRESETS = [
  { key: 'today', label: 'Today', days: 0 },
  { key: '7', label: 'Next 7 Days', days: 7 },
  { key: '30', label: 'Next 30 Days', days: 30 },
  { key: '60', label: 'Next 60 Days', days: 60 }
];

function isoDaysFromNow(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export default function UpcomingTravel() {
  const [preset, setPreset] = useState('30');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [error, setError] = useState('');

  useEffect(() => {
    const today = isoDaysFromNow(0);
    let from = today;
    let to = today;
    if (preset === 'custom') {
      from = customFrom || today;
      to = customTo || today;
    } else {
      const p = PRESETS.find((x) => x.key === preset);
      to = isoDaysFromNow(p ? p.days : 30);
    }
    window.api.bookings.upcomingTravel({ from, to }).then((res) => {
      if (res.ok) setRows(res.data); else setError(res.error);
    });
  }, [preset, customFrom, customTo]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Upcoming Travel</h1>
          <p>{rows.length.toLocaleString()} booking{rows.length === 1 ? '' : 's'} with travel dates in range</p>
        </div>
      </div>

      <div className="customers-toolbar">
        {PRESETS.map((p) => (
          <button key={p.key} className={`btn btn-sm ${preset === p.key ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setPreset(p.key)}>{p.label}</button>
        ))}
        <button className={`btn btn-sm ${preset === 'custom' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setPreset('custom')}>Custom Range</button>
        {preset === 'custom' && (
          <>
            <input type="date" className="field-input" style={{ width: 150 }} value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} />
            <input type="date" className="field-input" style={{ width: 150 }} value={customTo} onChange={(e) => setCustomTo(e.target.value)} />
          </>
        )}
      </div>

      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Booking</th><th>Customer</th><th>Destination</th><th>Departure</th><th>Return</th><th>Flight</th><th>Hotel</th><th>Visa</th><th>Transport</th></tr>
          </thead>
          <tbody>
            {pg.pageRows.map((b) => (
              <tr key={b.id}>
                <td>{b.booking_code}</td>
                <td>{b.customer_name}</td>
                <td>{b.destination || '—'}</td>
                <td>{b.departure_date || '—'}</td>
                <td>{b.return_date || '—'}</td>
                <td>{b.flightStatus}</td>
                <td>{b.hotelStatus}</td>
                <td>{b.visaStatus}</td>
                <td>{b.transportStatus}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={9} className="empty-row"><CalendarClock size={14} style={{ marginRight: 6 }} />No upcoming travel in this range.</td></tr>
            )}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="bookings" />
      </div>
    </div>
  );
}
