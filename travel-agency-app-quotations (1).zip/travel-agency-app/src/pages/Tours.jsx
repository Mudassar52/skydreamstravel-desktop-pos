import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Users as UsersIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import MembersDrawer from '../components/MembersDrawer.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const EMPTY = {
  tour_name: '', destination: '', country: '', city: '', start_date: '', end_date: '',
  duration: '', total_seats: '', available_seats: '', package_price: '', hotel: '',
  transport: '', meals: '', activities: '', guide: '', description: '', notes: ''
};

export default function Tours() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [membersFor, setMembersFor] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.tours.list();
    if (res.ok) setRows(res.data);
  }
  useEffect(() => { reload(); }, []);

  async function confirmDelete() {
    const res = await window.api.tours.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Tours</h1>
          <p>Custom domestic and international tours — any destination, fully configurable.</p>
        </div>
        {can('tours', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Tour
          </button>
        )}
      </div>

      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Tour</th><th>Destination</th><th>Dates</th><th>Seats</th><th>Price</th><th></th></tr>
          </thead>
          <tbody>
            {pg.pageRows.map((t) => (
              <tr key={t.id}>
                <td>{t.tour_name}</td>
                <td>{[t.city, t.country].filter(Boolean).join(', ') || t.destination || '—'}</td>
                <td>{t.start_date || '—'}{t.end_date ? ` → ${t.end_date}` : ''}</td>
                <td>{t.available_seats ?? 0} / {t.total_seats ?? 0}</td>
                <td>{money(t.package_price)}</td>
                <td className="row-actions">
                  <button className="icon-btn" title="Passengers" onClick={() => setMembersFor(t.id)}><UsersIcon size={14} /></button>
                  {can('tours', 'edit') && (
                    <button className="icon-btn" onClick={() => { setEditingId(t.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('tours', 'delete') && (
                    <button className="icon-btn" onClick={() => setDeleteTarget(t)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No tours yet — create one for any destination.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="tours" />
      </div>

      {formOpen && (
        <TourFormModal tourId={editingId} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {membersFor && (
        <MembersDrawer
          title={`Passengers — ${rows.find((r) => r.id === membersFor)?.tour_name || ''}`}
          groupId={membersFor}
          api={window.api.tours.passengers}
          onClose={() => { setMembersFor(null); reload(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete tour" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.tour_name}</strong>? Its passenger list will be removed too.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function TourFormModal({ tourId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (tourId) window.api.tours.get(tourId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
  }, [tourId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.tour_name.trim()) return setError('Tour name is required.');
    setSaving(true);
    const res = tourId ? await window.api.tours.update(tourId, form) : await window.api.tours.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={tourId ? 'Edit Tour' : 'New Tour'} onClose={onClose} width={580}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Tour Name *" full><input className="field-input" value={form.tour_name} onChange={(e) => set('tour_name', e.target.value)} /></Field>
          <Field label="Destination"><input className="field-input" value={form.destination || ''} onChange={(e) => set('destination', e.target.value)} placeholder="e.g. Northern Pakistan" /></Field>
          <Field label="Country"><input className="field-input" value={form.country || ''} onChange={(e) => set('country', e.target.value)} /></Field>
          <Field label="City"><input className="field-input" value={form.city || ''} onChange={(e) => set('city', e.target.value)} /></Field>
          <Field label="Duration"><input className="field-input" value={form.duration || ''} onChange={(e) => set('duration', e.target.value)} placeholder="e.g. 5 Days / 4 Nights" /></Field>
          <Field label="Start Date"><input type="date" className="field-input" value={form.start_date || ''} onChange={(e) => set('start_date', e.target.value)} /></Field>
          <Field label="End Date"><input type="date" className="field-input" value={form.end_date || ''} onChange={(e) => set('end_date', e.target.value)} /></Field>
          <Field label="Total Seats"><input type="number" className="field-input" value={form.total_seats || ''} onChange={(e) => set('total_seats', e.target.value)} /></Field>
          <Field label="Package Price (Rs.)"><input type="number" className="field-input" value={form.package_price || ''} onChange={(e) => set('package_price', e.target.value)} /></Field>
          <Field label="Hotel"><input className="field-input" value={form.hotel || ''} onChange={(e) => set('hotel', e.target.value)} /></Field>
          <Field label="Transport"><input className="field-input" value={form.transport || ''} onChange={(e) => set('transport', e.target.value)} /></Field>
          <Field label="Meals"><input className="field-input" value={form.meals || ''} onChange={(e) => set('meals', e.target.value)} /></Field>
          <Field label="Guide"><input className="field-input" value={form.guide || ''} onChange={(e) => set('guide', e.target.value)} /></Field>
          <Field label="Activities" full><input className="field-input" value={form.activities || ''} onChange={(e) => set('activities', e.target.value)} /></Field>
          <Field label="Description" full><textarea className="field-input" rows={2} value={form.description || ''} onChange={(e) => set('description', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Tour'}</button>
        </div>
      </form>
    </Modal>
  );
}
