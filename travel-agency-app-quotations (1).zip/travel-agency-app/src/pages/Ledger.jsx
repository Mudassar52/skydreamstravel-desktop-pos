import { useCallback, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { BookOpen, FileDown, Printer, FileSpreadsheet } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

// Customer Ledger (master prompt section 17): filters, opening/closing
// balance, totals, and PDF/Excel(CSV)/Print export - all computed from
// window.api.ledger.filteredView (real ledger_entries, SQL-side filtering).

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function Ledger() {
  const { hasCapability } = useAuth();
  const location = useLocation();
  const [customerId, setCustomerId] = useState(location.state?.customerId || '');
  const [customerLabel, setCustomerLabel] = useState(location.state?.customerLabel || '');
  const empty = { dateFrom: '', dateTo: '', transactionType: 'All' };
  const [filters, setFilters] = useState(empty);
  const [applied, setApplied] = useState(empty);
  const [types, setTypes] = useState([]);
  const [view, setView] = useState(null);
  const pg = usePagination(view?.entries || [], 50);
  useEffect(() => { pg.reset(); }, [view]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!customerId) { setView(null); return; }
    const [v, t] = await Promise.all([window.api.ledger.filteredView(customerId, applied), window.api.ledger.transactionTypes(customerId)]);
    if (v.ok) setView(v.data);
    if (t.ok) setTypes(t.data);
  }, [customerId, applied]);
  useEffect(() => { load(); }, [load]);

  const set = (k, v) => setFilters((f) => ({ ...f, [k]: v }));

  function reportPayload() {
    return {
      title: `Customer Ledger - ${customerLabel}`,
      columns: [
        { key: 'entry_date', label: 'Date' }, { key: 'txn_type', label: 'Type' }, { key: 'invoice_number', label: 'Reference' },
        { key: 'description', label: 'Description' }, { key: 'debit', label: 'Debit', money: true }, { key: 'credit', label: 'Credit', money: true },
        { key: 'running_balance', label: 'Balance', money: true }
      ],
      rows: (view?.entries || []).map((e) => ({ ...e, entry_date: day(e.entry_date), invoice_number: e.invoice_number || e.payment_reference || '—' })),
      totals: { debit: view?.totalDebit, credit: view?.totalCredit, running_balance: view?.closingBalance }
    };
  }
  async function act(fn) { setBusy(true); setError(''); const r = await fn(); setBusy(false); if (!r.ok) setError(r.error); }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Customer Ledger</h1>
          <p>Running balance of what a customer owes — invoices as charges, payments as credits.</p>
        </div>
        {view && hasCapability('export_reports') && (
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.ledger.exportPdf(reportPayload()))}><FileDown size={13} /> PDF</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.reportExport.exportExcel([{ name: 'Ledger', columns: reportPayload().columns, rows: reportPayload().rows, totals: reportPayload().totals }], `Customer-Ledger-${customerLabel || 'export'}.xlsx`))}><FileSpreadsheet size={13} /> Excel</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.ledger.print(reportPayload()))}><Printer size={13} /> Print</button>
          </div>
        )}
      </div>

      <div className="card" style={{ padding: '16px 20px', marginBottom: 20 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
          <Field label="Select Customer">
            <CustomerSearchSelect value={customerId} valueLabel={customerLabel} onChange={(id, label) => { setCustomerId(id); setCustomerLabel(label); }} />
          </Field>
          <Field label="From"><input className="field-input" type="date" value={filters.dateFrom} onChange={(e) => set('dateFrom', e.target.value)} /></Field>
          <Field label="To"><input className="field-input" type="date" value={filters.dateTo} onChange={(e) => set('dateTo', e.target.value)} /></Field>
          <Field label="Type">
            <select className="field-input" value={filters.transactionType} onChange={(e) => set('transactionType', e.target.value)}>
              <option value="All">All types</option>{types.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <button className="btn btn-primary btn-sm" onClick={() => setApplied(filters)}>Apply</button>
          <button className="btn btn-secondary btn-sm" onClick={() => { setFilters(empty); setApplied(empty); }}>Reset</button>
        </div>
      </div>

      {error && <div className="login-error">{error}</div>}

      {customerId && view && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
            <Stat label="Opening Balance" value={money(view.openingBalance)} />
            <Stat label="Total Debit" value={money(view.totalDebit)} />
            <Stat label="Total Credit" value={money(view.totalCredit)} />
            <Stat label="Closing Balance" value={money(view.closingBalance)} color={view.closingBalance > 0 ? 'var(--color-danger)' : 'var(--color-success)'} />
          </div>

          <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
            <table className="data-table">
              <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Description</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
              <tbody>
                {pg.pageRows.map((e) => (
                  <tr key={e.id}>
                    <td>{day(e.entry_date)}</td>
                    <td>{e.txn_type}</td>
                    <td>{e.invoice_number || e.payment_reference || '—'}</td>
                    <td>{e.description}</td>
                    <td>{e.debit > 0 ? money(e.debit) : '—'}</td>
                    <td>{e.credit > 0 ? money(e.credit) : '—'}</td>
                    <td style={{ fontWeight: 600 }}>{money(e.running_balance)}</td>
                  </tr>
                ))}
                {view.entries.length === 0 && <tr><td colSpan={7} className="empty-row">No ledger activity matches these filters.</td></tr>}
              </tbody>
            </table>
        <Pagination {...pg.pagerProps} label="entries" />
          </div>
        </>
      )}

      {customerId && !view && <p style={{ fontSize: 13, color: 'var(--color-text-faint)' }}>Loading…</p>}
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="field-label">{label}</label>{children}</div>;
}
function Stat({ label, value, color }) {
  return (
    <div className="card" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
      <BookOpen size={16} color="var(--color-primary)" style={{ flexShrink: 0 }} />
      <div>
        <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
        <div style={{ fontSize: 16, fontWeight: 700, color: color || 'inherit' }}>{value}</div>
      </div>
    </div>
  );
}
