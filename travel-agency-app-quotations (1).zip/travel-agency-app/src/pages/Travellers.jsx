import { useEffect, useState, useCallback } from 'react';
import { UserSquare2, Plus, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 15;

export default function Travellers() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.travellers.list({ search, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.travellers.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${deleteTarget.full_name} deleted.`); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Travellers</h1>
          <p>{total.toLocaleString()} traveller{total === 1 ? '' : 's'} — companions and dependents, kept separate from customer/account records</p>
        </div>
        {can('travellers', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <UserSquare2 size={15} /> Add Traveller
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <input placeholder="Search name or passport number..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Name</th><th>Relationship</th><th>Linked Customer</th><th>Passport #</th><th>Passport Expiry</th><th>Bookings</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>{t.full_name}</td>
                <td>{t.relationship || '—'}</td>
                <td>{t.customer_name || '—'}</td>
                <td>{t.passport_number || '—'}</td>
                <td>{t.passport_expiry_date || '—'}</td>
                <td>{t.bookings_count}</td>
                <td className="row-actions">
                  {can('travellers', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(t.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('travellers', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(t)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No travellers found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <TravellerFormModal travellerId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete traveller" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.full_name}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  customer_id: '', customer_label: '', full_name: '', relationship: 'Self', date_of_birth: '',
  gender: '', nationality: '', passport_number: '', passport_issue_date: '', passport_expiry_date: '', visa_status: '', notes: ''
};

function TravellerFormModal({ travellerId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [relationships, setRelationships] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.travellers.relationships().then((res) => res.ok && setRelationships(res.data)); }, []);
  useEffect(() => {
    if (!travellerId) return;
    window.api.travellers.get(travellerId).then((res) => {
      if (res.ok) setForm({ ...EMPTY, ...res.data, customer_label: res.data.customer_name });
    });
  }, [travellerId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = travellerId ? await window.api.travellers.update(travellerId, form) : await window.api.travellers.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(travellerId ? 'Traveller updated.' : 'Traveller added.');
  }

  return (
    <Modal title={travellerId ? 'Edit Traveller' : 'Add Traveller'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Full Name *" full><input className="field-input" value={form.full_name} onChange={(e) => set('full_name', e.target.value)} /></Field>
          <Field label="Linked Customer (optional)" full>
            <CustomerSearchSelect value={form.customer_id} valueLabel={form.customer_label} onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))} />
          </Field>
          <Field label="Relationship">
            <select className="field-input" value={form.relationship || ''} onChange={(e) => set('relationship', e.target.value)}>
              {relationships.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="Date of Birth"><input type="date" className="field-input" value={form.date_of_birth || ''} onChange={(e) => set('date_of_birth', e.target.value)} /></Field>
          <Field label="Gender">
            <select className="field-input" value={form.gender || ''} onChange={(e) => set('gender', e.target.value)}>
              <option value="">—</option><option>Male</option><option>Female</option><option>Other</option>
            </select>
          </Field>
          <Field label="Nationality"><input className="field-input" value={form.nationality || ''} onChange={(e) => set('nationality', e.target.value)} /></Field>
          <Field label="Passport Number"><input className="field-input" value={form.passport_number || ''} onChange={(e) => set('passport_number', e.target.value)} /></Field>
          <Field label="Visa Status"><input className="field-input" value={form.visa_status || ''} onChange={(e) => set('visa_status', e.target.value)} /></Field>
          <Field label="Passport Issue Date"><input type="date" className="field-input" value={form.passport_issue_date || ''} onChange={(e) => set('passport_issue_date', e.target.value)} /></Field>
          <Field label="Passport Expiry Date"><input type="date" className="field-input" value={form.passport_expiry_date || ''} onChange={(e) => set('passport_expiry_date', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Traveller'}</button>
        </div>
      </form>
    </Modal>
  );
}
