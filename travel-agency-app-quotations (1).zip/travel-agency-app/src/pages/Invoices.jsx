import { useEffect, useState, useCallback } from 'react';
import { Plus, Search, Eye, Pencil, Trash2, ChevronLeft, ChevronRight, FileDown, Printer, Copy, Ban, X, Wallet, Undo2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import PreviewPane from '../components/PreviewPane.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import DateRangeFilter from '../components/DateRangeFilter.jsx';
import SavedFiltersBar from '../components/SavedFiltersBar.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['Unpaid', 'Partially Paid', 'Paid', 'Cancelled'];
const STATUS_TONE = { Unpaid: 'off', 'Partially Paid': 'off', Paid: 'on', Cancelled: 'off' };
const DATE_FIELDS = [
  { value: 'invoice_date', label: 'Invoice Date' },
  { value: 'due_date', label: 'Due Date' },
  { value: 'created_at', label: 'Created Date' }
];
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Invoices() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [dateFilter, setDateFilter] = useState({ preset: '', from: '', to: '', dateField: 'invoice_date' });
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [viewingId, setViewingId] = useState(null);
  const [fromBookingOpen, setFromBookingOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const load = useCallback(async () => {
    const res = await window.api.invoices.list({
      search, status, page, pageSize: PAGE_SIZE,
      dateField: dateFilter.dateField, dateFrom: dateFilter.from || null, dateTo: dateFilter.to || null
    });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, page, dateFilter]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status, dateFilter]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3500); }

  async function confirmDelete() {
    const res = await window.api.invoices.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${deleteTarget.invoice_number} deleted.`); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Invoices</h1>
          <p>{total.toLocaleString()} total invoice{total === 1 ? '' : 's'}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {can('invoices', 'create') && (
            <button className="btn btn-secondary" onClick={() => setFromBookingOpen(true)}>From Booking</button>
          )}
          {can('invoices', 'create') && (
            <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
              <Plus size={15} /> New Invoice
            </button>
          )}
        </div>
      </div>

      <div className="customers-toolbar" style={{ flexWrap: 'wrap', rowGap: 10 }}>
        <div className="global-search" style={{ width: 300 }}>
          <Search size={15} />
          <input placeholder="Search invoice # or customer..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 170 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <DateRangeFilter value={dateFilter} onChange={setDateFilter} dateFieldOptions={DATE_FIELDS} />
      </div>

      <div style={{ marginBottom: 14 }}>
        <SavedFiltersBar
          module="invoices"
          currentFilter={{ search, status, dateFilter }}
          onApply={(f) => { setSearch(f.search || ''); setStatus(f.status || 'All'); setDateFilter(f.dateFilter || { preset: '', from: '', to: '', dateField: 'invoice_date' }); }}
        />
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Invoice #</th><th>Customer</th><th>Date</th><th>Total</th><th>Balance Due</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((inv) => (
              <tr key={inv.id}>
                <td><button className="link-cell" onClick={() => setViewingId(inv.id)}>{inv.invoice_number}</button></td>
                <td>{inv.customer_name}</td>
                <td>{inv.invoice_date?.slice(0, 10)}</td>
                <td>{money(inv.total)}</td>
                <td>{money(inv.remaining_amount)}</td>
                <td><span className={`status-pill ${STATUS_TONE[inv.status] || 'off'}`}>{inv.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="View" onClick={() => setViewingId(inv.id)}><Eye size={14} /></button>
                  {can('invoices', 'edit') && inv.status !== 'Cancelled' && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(inv.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('invoices', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(inv)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No invoices found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <InvoiceFormModal
          invoiceId={editingId}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }}
        />
      )}

      {viewingId && (
        <InvoiceDetailDrawer
          invoiceId={viewingId}
          onClose={() => setViewingId(null)}
          onChanged={(msg) => { flash(msg); load(); }}
          onEdit={() => { setEditingId(viewingId); setViewingId(null); setFormOpen(true); }}
        />
      )}

      {fromBookingOpen && (
        <FromBookingModal
          onClose={() => setFromBookingOpen(false)}
          onCreated={(msg) => { setFromBookingOpen(false); flash(msg); load(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete invoice" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.invoice_number}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
function FromBookingModal({ onClose, onCreated }) {
  const [options, setOptions] = useState([]);
  const [bookingId, setBookingId] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.bookings.options().then((res) => { if (res.ok) setOptions(res.data); }); }, []);

  async function submit(e) {
    e.preventDefault();
    if (!bookingId) return setError('Please select a booking.');
    setSaving(true);
    const res = await window.api.invoices.createFromBooking(Number(bookingId));
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onCreated(`Invoice ${res.data.invoiceNumber} created from booking.`);
  }

  return (
    <Modal title="Create Invoice from Booking" onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <Field label="Booking">
          <select className="field-input" value={bookingId} onChange={(e) => setBookingId(e.target.value)}>
            <option value="">— Select a booking —</option>
            {options.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
          </select>
        </Field>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Creating…' : 'Create Invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------------
const EMPTY_ITEM = { description: '', quantity: 1, unit_price: '' };
const EMPTY = {
  customer_id: '', customer_label: '', booking_id: '', due_date: '', discount: 0, tax: 0,
  paid_amount: 0, notes: '', terms: '', items: [{ ...EMPTY_ITEM }]
};

function InvoiceFormModal({ invoiceId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (invoiceId) {
      window.api.invoices.get(invoiceId).then((res) => {
        if (res.ok) {
          setForm({
            ...EMPTY, ...res.data,
            customer_label: res.data.customer_name,
            items: res.data.items.length ? res.data.items : [{ ...EMPTY_ITEM }]
          });
        }
      });
    }
  }, [invoiceId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }
  function setItem(idx, f, v) {
    setForm((s) => ({ ...s, items: s.items.map((it, i) => (i === idx ? { ...it, [f]: v } : it)) }));
  }
  function addItem() { setForm((s) => ({ ...s, items: [...s.items, { ...EMPTY_ITEM }] })); }
  function removeItem(idx) { setForm((s) => ({ ...s, items: s.items.filter((_, i) => i !== idx) })); }

  const subtotal = form.items.reduce((sum, it) => sum + Number(it.quantity || 0) * Number(it.unit_price || 0), 0);
  const total = Math.max(subtotal - Number(form.discount || 0) + Number(form.tax || 0), 0);
  const remaining = total - Number(form.paid_amount || 0);

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    setSaving(true);
    const res = invoiceId ? await window.api.invoices.update(invoiceId, form) : await window.api.invoices.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(invoiceId ? 'Invoice updated.' : `Invoice ${res.data.invoiceNumber} created.`);
  }

  return (
    <Modal title={invoiceId ? 'Edit Invoice' : 'New Invoice'} onClose={onClose} width={680}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            <CustomerSearchSelect
              value={form.customer_id}
              valueLabel={form.customer_label}
              onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))}
            />
          </Field>
          <Field label="Due Date"><input type="date" className="field-input" value={form.due_date || ''} onChange={(e) => set('due_date', e.target.value)} /></Field>
          <Field label="Paid Amount (Rs.)"><input type="number" className="field-input" value={form.paid_amount} onChange={(e) => set('paid_amount', e.target.value)} /></Field>
        </div>

        <div className="form-section-title" style={{ marginTop: 18 }}>Line Items</div>
        {form.items.map((it, idx) => (
          <div key={idx} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
            <input className="field-input" style={{ flex: 3 }} placeholder="Description" value={it.description} onChange={(e) => setItem(idx, 'description', e.target.value)} />
            <input type="number" className="field-input" style={{ flex: 1 }} placeholder="Qty" value={it.quantity} onChange={(e) => setItem(idx, 'quantity', e.target.value)} />
            <input type="number" className="field-input" style={{ flex: 1.5 }} placeholder="Unit Price" value={it.unit_price} onChange={(e) => setItem(idx, 'unit_price', e.target.value)} />
            <span style={{ flex: 1.5, fontSize: 12.5, textAlign: 'right' }}>{money(Number(it.quantity || 0) * Number(it.unit_price || 0))}</span>
            {form.items.length > 1 && (
              <button type="button" className="icon-btn" onClick={() => removeItem(idx)}><X size={14} /></button>
            )}
          </div>
        ))}
        <button type="button" className="btn btn-secondary btn-sm" onClick={addItem} style={{ marginBottom: 16 }}>
          <Plus size={13} /> Add Line
        </button>

        <div className="form-grid">
          <Field label="Discount (Rs.)"><input type="number" className="field-input" value={form.discount} onChange={(e) => set('discount', e.target.value)} /></Field>
          <Field label="Tax (Rs.)"><input type="number" className="field-input" value={form.tax} onChange={(e) => set('tax', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
          <Field label="Terms & Conditions" full><textarea className="field-input" rows={2} value={form.terms || ''} onChange={(e) => set('terms', e.target.value)} /></Field>
        </div>

        <div className="totals" style={{ marginTop: 6 }}>
          <div className="row"><span>Subtotal</span><span>{money(subtotal)}</span></div>
          <div className="row"><span>Total</span><span>{money(total)}</span></div>
          <div className="row grand"><span>Balance Due</span><span>{money(remaining)}</span></div>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : invoiceId ? 'Save Changes' : 'Create Invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------------
function InvoiceDetailDrawer({ invoiceId, onClose, onChanged, onEdit }) {
  const { can } = useAuth();
  const [invoice, setInvoice] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.invoices.get(invoiceId);
    if (res.ok) setInvoice(res.data);
  }
  useEffect(() => { reload(); }, [invoiceId]);

  const [previewHtml, setPreviewHtml] = useState(null);
  async function handlePreview() {
    setBusy(true); setError('');
    const res = await window.api.invoices.preview(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setPreviewHtml(res.data);
  }

  async function handlePdf() {
    setBusy(true); setError('');
    const res = await window.api.invoices.generatePdf(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) onChanged(`Saved to ${res.data.filePath}`);
  }

  async function handlePrint() {
    setBusy(true); setError('');
    const res = await window.api.invoices.print(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
  }

  async function handleDuplicate() {
    setBusy(true); setError('');
    const res = await window.api.invoices.duplicate(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    onChanged(`Duplicated as ${res.data.invoiceNumber}.`);
    onClose();
  }

  async function handleCancel() {
    setBusy(true); setError('');
    const res = await window.api.invoices.cancel(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    onChanged('Invoice cancelled.');
    reload();
  }

  if (!invoice) return null;

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <div>
            <h2 style={{ fontSize: 17 }}>{invoice.invoice_number}</h2>
            <span className={`status-pill ${STATUS_TONE[invoice.status] || 'off'}`} style={{ marginTop: 6, display: 'inline-block' }}>{invoice.status}</span>
          </div>
        </div>
        <div className="drawer-body">
          {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 18 }}>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePreview}><Eye size={13} /> Preview</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePdf}><FileDown size={13} /> Generate PDF</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePrint}><Printer size={13} /> Print</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handleDuplicate}><Copy size={13} /> Duplicate</button>
            {can('invoices', 'edit') && invoice.status !== 'Cancelled' && (
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={onEdit}><Pencil size={13} /> Edit</button>
            )}
            {can('invoices', 'edit') && invoice.status !== 'Cancelled' && (
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handleCancel}><Ban size={13} /> Cancel Invoice</button>
            )}
          </div>

          <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 18 }}>
            <MiniStat label="Total" value={money(invoice.total)} />
            <MiniStat label="Paid" value={money(invoice.paid_amount)} />
            <MiniStat label="Balance Due" value={money(invoice.remaining_amount)} />
          </div>

          <InfoRow label="Customer" value={invoice.customer_name} />
          <InfoRow label="Booking Reference" value={invoice.booking_code} />
          <InfoRow label="Invoice Date" value={invoice.invoice_date?.slice(0, 10)} />
          <InfoRow label="Due Date" value={invoice.due_date} />

          <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Line Items</h3>
          {invoice.items.map((it) => (
            <div className="info-row" key={it.id}>
              <span>{it.description} × {it.quantity}</span>
              <span>{money(it.line_total)}</span>
            </div>
          ))}

          {invoice.status !== 'Cancelled' && (
            <ApplyAdvancePanel invoice={invoice} onApplied={() => { reload(); onChanged('Advance applied.'); }} />
          )}

          {invoice.notes && (
            <>
              <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Notes</h3>
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{invoice.notes}</p>
            </>
          )}
        </div>
      </div>
      {previewHtml && <PreviewPane title={`Invoice ${invoice.invoice_number}`} html={previewHtml} busy={busy} onClose={() => setPreviewHtml(null)} onSave={handlePdf} onPrint={handlePrint} />}
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="card" style={{ padding: '12px 14px' }}>
      <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{value}</div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="info-row">
      <span>{label}</span>
      <span>{value || '—'}</span>
    </div>
  );
}

// Customer Advance System (master prompt section 16): shows the customer's
// unapplied standalone advances and lets the user allocate part or all of
// one to this invoice, plus what has already been applied, with the option
// to reverse an application. All amounts come from window.api.advances.*.
function ApplyAdvancePanel({ invoice, onApplied }) {
  const [available, setAvailable] = useState(null);
  const [applied, setApplied] = useState(null);
  const [amounts, setAmounts] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const [av, ap] = await Promise.all([
      window.api.advances.available(invoice.customer_id),
      window.api.advances.applicationsForInvoice(invoice.id)
    ]);
    if (av.ok) setAvailable(av.data);
    if (ap.ok) setApplied(ap.data);
  }, [invoice.customer_id, invoice.id]);
  useEffect(() => { load(); }, [load]);

  async function apply(paymentId) {
    const amount = Number(amounts[paymentId]);
    if (!(amount > 0)) return setError('Enter an amount greater than zero.');
    setBusy(true); setError('');
    const res = await window.api.advances.applyToInvoice({ paymentId, invoiceId: invoice.id, amount });
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
    onApplied();
  }

  async function reverse(applicationId) {
    setBusy(true); setError('');
    const res = await window.api.advances.reverseApplication(applicationId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
    onApplied();
  }

  if (!available || !applied) return null;
  if (available.rows.length === 0 && applied.length === 0) return null;

  return (
    <div style={{ marginTop: 18 }}>
      <h3 style={{ fontSize: 13, margin: '0 0 8px', display: 'flex', alignItems: 'center', gap: 6 }}><Wallet size={14} /> Customer Advance</h3>
      {error && <div className="login-error" style={{ marginBottom: 8 }}>{error}</div>}

      {available.rows.length > 0 && invoice.remaining_amount > 0 && (
        <div className="card" style={{ padding: '10px 14px', marginBottom: 10 }}>
          <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginBottom: 8 }}>
            Available advance for this customer: {money(available.total_available)}
          </p>
          {available.rows.map((a) => (
            <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, flex: 1 }}>{a.payment_date?.slice(0, 10)} — {a.reference || `Advance #${a.id}`} ({money(a.available)} available)</span>
              <input className="field-input" type="number" style={{ width: 110 }} placeholder="Amount"
                value={amounts[a.id] || ''} onChange={(e) => setAmounts((s) => ({ ...s, [a.id]: e.target.value }))} />
              <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => apply(a.id)}>Apply</button>
            </div>
          ))}
        </div>
      )}

      {applied.length > 0 && (
        <div className="card" style={{ padding: '10px 14px' }}>
          <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginBottom: 8 }}>Applied to this invoice</p>
          {applied.map((a) => (
            <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, flex: 1 }}>{a.applied_at?.slice(0, 10)} — {money(a.amount)} from advance #{a.payment_id}</span>
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => reverse(a.id)}><Undo2 size={12} /> Reverse</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
