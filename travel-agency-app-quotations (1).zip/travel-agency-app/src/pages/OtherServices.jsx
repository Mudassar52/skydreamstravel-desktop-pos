import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import SupplierSearchSelect from '../components/SupplierSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function OtherServices() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [serviceType, setServiceType] = useState('All');
  const [types, setTypes] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.otherServices.serviceTypes().then((res) => res.ok && setTypes(res.data)); }, []);

  const load = useCallback(async () => {
    const res = await window.api.otherServices.list({ search, serviceType, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, serviceType, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, serviceType]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.otherServices.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Service deleted.'); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Other Services</h1>
          <p>{total.toLocaleString()} service{total === 1 ? '' : 's'} — Ziyarat, meals, insurance, tours, and more</p>
        </div>
        {can('other_services', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}><Plus size={15} /> Add Service</button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <input placeholder="Search description, customer, booking..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 170 }} value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
          <option value="All">All service types</option>
          {types.map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Type</th><th>Customer</th><th>Booking</th><th>Supplier</th><th>Cost</th><th>Sell</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.id}>
                <td>{s.service_type}</td>
                <td>{s.customer_name || '—'}</td>
                <td>{s.booking_code || '—'}</td>
                <td>{s.supplier_name || '—'}</td>
                <td>{money(s.cost)}</td>
                <td>{money(s.selling_price)}</td>
                <td><span className="status-pill on">{s.status}</span></td>
                <td className="row-actions">
                  {can('other_services', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(s.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('other_services', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(s)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="empty-row">No services found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <ServiceFormModal serviceId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete service" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete this {deleteTarget.service_type} service? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  service_type: 'Ziyarat', customer_id: '', customer_label: '', supplier_id: '', supplier_label: '',
  description: '', service_date: '', cost: 0, selling_price: 0, currency: 'PKR', status: 'Pending', notes: ''
};

function ServiceFormModal({ serviceId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [types, setTypes] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.otherServices.serviceTypes().then((res) => res.ok && setTypes(res.data));
    window.api.otherServices.statuses().then((res) => res.ok && setStatuses(res.data));
  }, []);
  useEffect(() => {
    if (!serviceId) return;
    window.api.otherServices.get(serviceId).then((res) => {
      if (res.ok) setForm({ ...EMPTY, ...res.data, customer_label: res.data.customer_name, supplier_label: res.data.supplier_name });
    });
  }, [serviceId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = serviceId ? await window.api.otherServices.update(serviceId, form) : await window.api.otherServices.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(serviceId ? 'Service updated.' : 'Service added.');
  }

  return (
    <Modal title={serviceId ? 'Edit Service' : 'Add Service'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Service Type *">
            <select className="field-input" value={form.service_type} onChange={(e) => set('service_type', e.target.value)}>
              {types.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              {statuses.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Customer" full>
            <CustomerSearchSelect value={form.customer_id} valueLabel={form.customer_label} onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))} />
          </Field>
          <Field label="Supplier (optional)" full>
            <SupplierSearchSelect value={form.supplier_id} valueLabel={form.supplier_label} onChange={(id, label) => setForm((s) => ({ ...s, supplier_id: id, supplier_label: label }))} />
          </Field>
          <Field label="Service Date"><input type="date" className="field-input" value={form.service_date || ''} onChange={(e) => set('service_date', e.target.value)} /></Field>
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Cost"><input type="number" className="field-input" value={form.cost} onChange={(e) => set('cost', e.target.value)} /></Field>
          <Field label="Selling Price"><input type="number" className="field-input" value={form.selling_price} onChange={(e) => set('selling_price', e.target.value)} /></Field>
          <Field label="Description" full><input className="field-input" value={form.description || ''} onChange={(e) => set('description', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Service'}</button>
        </div>
      </form>
    </Modal>
  );
}
