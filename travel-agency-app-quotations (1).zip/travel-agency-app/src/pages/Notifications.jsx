import { useEffect, useState } from 'react';
import { Bell, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const RECORD_ROUTES = {
  invoices: '/invoices', supplier_invoices: '/supplier-invoices', deadlines: '/deadlines',
  travellers: '/travellers', follow_ups: '/followups', tasks: '/tasks', bookings: '/bookings'
};

export default function Notifications() {
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [notice, setNotice] = useState('');

  async function load() {
    const res = await window.api.notifications.list({ unreadOnly, limit: 100 });
    if (res.ok) setRows(res.data);
  }
  useEffect(() => { load(); }, [unreadOnly]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function open(n) {
    if (!n.is_read) await window.api.notifications.markRead(n.id);
    const route = RECORD_ROUTES[n.record_type];
    if (route) navigate(route);
    load();
  }

  async function markAll() {
    await window.api.notifications.markAllRead();
    flash('All notifications marked as read.');
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Notifications</h1>
          <p>{rows.length.toLocaleString()} notification{rows.length === 1 ? '' : 's'}</p>
        </div>
        <button className="btn btn-secondary" onClick={markAll}><Check size={15} /> Mark All Read</button>
      </div>

      <div className="customers-toolbar">
        <select
          className="field-input"
          style={{ width: 160 }}
          value={unreadOnly ? 'unread' : 'all'}
          onChange={(e) => setUnreadOnly(e.target.value === 'unread')}
        >
          <option value="all">All</option>
          <option value="unread">Unread</option>
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}

      <div className="card" style={{ padding: 0 }}>
        {pg.pageRows.map((n) => (
          <button
            key={n.id}
            onClick={() => open(n)}
            style={{
              display: 'flex', flexDirection: 'column', gap: 3, width: '100%', textAlign: 'left',
              border: 'none', borderBottom: '1px solid var(--color-border)', background: n.is_read ? 'transparent' : 'var(--color-primary-soft, rgba(30,79,163,0.06))',
              padding: '12px 18px', cursor: 'pointer'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <strong style={{ fontSize: 13 }}>{n.title}</strong>
              <span style={{ fontSize: 11, color: 'var(--color-text-faint)' }}>{n.created_at?.slice(0, 16).replace('T', ' ')}</span>
            </div>
            {n.message && <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{n.message}</span>}
          </button>
        ))}
        {rows.length === 0 && (
          <div className="empty-row" style={{ padding: 30, textAlign: 'center' }}>
            <Bell size={16} style={{ marginRight: 6 }} />No notifications.
          </div>
        )}
        <Pagination {...pg.pagerProps} label="notifications" />
      </div>
    </div>
  );
}
