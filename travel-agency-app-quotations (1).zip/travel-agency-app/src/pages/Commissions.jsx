import { useEffect, useState, useCallback } from 'react';
import { Plus, Search, CheckCircle2, Banknote, Undo2, XCircle, Pencil, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const num = (n) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
const STATUSES = ['All', 'Pending', 'Approved', 'Paid', 'Cancelled'];
const METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];

export default function Commissions() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [summary, setSummary] = useState(null);
  const [modal, setModal] = useState(null); // { kind: 'new' | 'pay' | 'edit', row? }
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const [l, s] = await Promise.all([window.api.commissions.list({ search, status, page, pageSize: PAGE_SIZE }), window.api.commissions.summary({})]);
    if (l.ok) { setRows(l.data.rows); setTotal(l.data.total); setError(''); } else setError(l.error);
    if (s.ok) setSummary(s.data);
  }, [search, status, page]);
  useEffect(() => { load(); }, [load]);
  function flash(m) { setNotice(m); setTimeout(() => setNotice(''), 3000); }

  async function act(fn, okMsg) {
    const res = await fn();
    if (!res.ok) setError(res.error); else { setError(''); flash(okMsg); load(); }
  }
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const canEdit = can('commissions', 'edit');

  return (
    <div>
      <div className="page-header">
        <div><h1>Commissions</h1><p>{total.toLocaleString()} commission{total === 1 ? '' : 's'}</p></div>
        {can('commissions', 'create') && <button className="btn btn-primary" onClick={() => setModal({ kind: 'new' })}><Plus size={15} /> Add Commission</button>}
      </div>
      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      {summary && summary.currencies.length > 0 && (
        <div className="card" style={{ padding: '12px 16px', marginBottom: 12 }}>
          <table className="data-table">
            <thead><tr><th>Currency</th><th>Pending</th><th>Approved (to pay)</th><th>Paid</th></tr></thead>
            <tbody>
              {summary.currencies.map((c) => <tr key={c.currency}><td><strong>{c.currency}</strong></td><td>{num(c.pending)}</td><td>{num(c.approved)}</td><td>{num(c.paid)}</td></tr>)}
              {summary.converted && summary.converted.complete && (
                <tr style={{ fontWeight: 700 }}><td>Total in {summary.converted.currency}</td><td>{num(summary.converted.pending)}</td><td>{num(summary.converted.approved)}</td><td>{num(summary.converted.paid)}</td></tr>
              )}
            </tbody>
          </table>
          {summary.mixed_currency && summary.converted && !summary.converted.complete && (
            <p style={{ fontSize: 12, color: 'var(--color-danger, #B42318)', marginTop: 8 }}>
              Commissions are in more than one currency. No exchange rate is on file for {summary.converted.missing.join(', ')} to {summary.converted.currency}, so no combined total is shown. Add one under Finance › Exchange Rates.
            </p>
          )}
        </div>
      )}

      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', gap: 8 }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={14} style={{ position: 'absolute', left: 10, top: 11, color: 'var(--color-text-muted)' }} />
          <input className="field-input" style={{ paddingLeft: 30 }} placeholder="Search agent, booking, customer…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        </div>
        <select className="field-input" style={{ width: 150 }} value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead><tr><th>Agent</th><th>Booking</th><th>Customer</th><th>Booking total</th><th>Rate</th><th>Commission</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id}>
                <td>{c.agent_code} · {c.agent_name}</td>
                <td>{c.booking_code}</td>
                <td>{c.customer_name}</td>
                <td>{c.currency} {num(c.base_amount)}</td>
                <td>{c.commission_type === 'Percentage' ? `${num(c.commission_value)}%` : 'Fixed'}</td>
                <td><strong>{c.currency} {num(c.commission_amount)}</strong></td>
                <td><span className={`status-pill ${c.status === 'Paid' ? 'on' : c.status === 'Cancelled' ? 'off' : ''}`}>{c.status}</span>{c.paid_date && <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{c.paid_date}</div>}</td>
                <td className="row-actions">
                  {canEdit && c.status === 'Pending' && <button className="icon-btn" title="Edit rate" onClick={() => setModal({ kind: 'edit', row: c })}><Pencil size={14} /></button>}
                  {canEdit && c.status === 'Pending' && <button className="icon-btn" title="Approve" onClick={() => act(() => window.api.commissions.approve(c.id), 'Commission approved.')}><CheckCircle2 size={14} /></button>}
                  {canEdit && c.status === 'Approved' && <button className="icon-btn" title="Pay" onClick={() => setModal({ kind: 'pay', row: c })}><Banknote size={14} /></button>}
                  {canEdit && c.status === 'Paid' && <button className="icon-btn" title="Reverse payment" onClick={() => act(() => window.api.commissions.reversePayment(c.id), 'Payment reversed.')}><Undo2 size={14} /></button>}
                  {canEdit && (c.status === 'Pending' || c.status === 'Approved') && <button className="icon-btn" title="Cancel" onClick={() => act(() => window.api.commissions.cancel(c.id), 'Commission cancelled.')}><XCircle size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="empty-row">No commissions yet. Choose an agent on a booking and a Pending commission appears here automatically.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {pages}</span>
          <button className="icon-btn" disabled={page <= 1} onClick={() => setPage(page - 1)}><ChevronLeft size={15} /></button>
          <button className="icon-btn" disabled={page >= pages} onClick={() => setPage(page + 1)}><ChevronRight size={15} /></button>
        </div>
      </div>

      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 10 }}>
        Paying a commission records a real expense (category "Agent Commission") and moves money out of the chosen bank/cash account, so it appears in Profit, Cash/Bank statements and the General Ledger.
      </p>

      {modal && modal.kind === 'new' && <NewForm onClose={() => setModal(null)} onSaved={() => { setModal(null); flash('Commission added.'); load(); }} />}
      {modal && modal.kind === 'edit' && <EditForm row={modal.row} onClose={() => setModal(null)} onSaved={() => { setModal(null); flash('Commission updated.'); load(); }} />}
      {modal && modal.kind === 'pay' && <PayForm row={modal.row} onClose={() => setModal(null)} onSaved={() => { setModal(null); flash('Commission paid.'); load(); }} />}
    </div>
  );
}

function NewForm({ onClose, onSaved }) {
  const [agents, setAgents] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [form, setForm] = useState({ agent_id: '', booking_id: '', commission_type: '', commission_value: '' });
  const [error, setError] = useState('');
  useEffect(() => {
    window.api.agents.options().then((r) => r.ok && setAgents(r.data));
    window.api.bookings.options().then((r) => r.ok && setBookings(r.data));
  }, []);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  async function submit(e) {
    e.preventDefault();
    const res = await window.api.commissions.create({ ...form, commission_type: form.commission_type || null });
    if (!res.ok) return setError(res.error);
    onSaved();
  }
  return (
    <Modal title="Add Commission" onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error">{error}</div>}
        <div style={{ display: 'grid', gap: 12 }}>
          <Field label="Agent"><select className="field-input" value={form.agent_id} onChange={(e) => set('agent_id', e.target.value)}><option value="">Select…</option>{agents.map((a) => <option key={a.id} value={a.id}>{a.agent_code} - {a.name}</option>)}</select></Field>
          <Field label="Booking"><select className="field-input" value={form.booking_id} onChange={(e) => set('booking_id', e.target.value)}><option value="">Select…</option>{bookings.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}</select></Field>
          <Field label="Override type (optional)"><select className="field-input" value={form.commission_type} onChange={(e) => set('commission_type', e.target.value)}><option value="">Use agent default</option><option value="Percentage">Percentage</option><option value="Fixed">Fixed</option></select></Field>
          <Field label="Override value (optional)"><input className="field-input" type="number" step="any" min="0" value={form.commission_value} onChange={(e) => set('commission_value', e.target.value)} /></Field>
        </div>
        <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button type="submit" className="btn btn-primary">Add</button></div>
      </form>
    </Modal>
  );
}

function EditForm({ row, onClose, onSaved }) {
  const [form, setForm] = useState({ commission_type: row.commission_type, commission_value: row.commission_value, notes: row.notes || '' });
  const [error, setError] = useState('');
  async function submit(e) {
    e.preventDefault();
    const res = await window.api.commissions.update(row.id, form);
    if (!res.ok) return setError(res.error);
    onSaved();
  }
  return (
    <Modal title={`Edit commission - ${row.booking_code}`} onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error">{error}</div>}
        <div style={{ display: 'grid', gap: 12 }}>
          <Field label="Type"><select className="field-input" value={form.commission_type} onChange={(e) => setForm({ ...form, commission_type: e.target.value })}><option>Percentage</option><option>Fixed</option></select></Field>
          <Field label={form.commission_type === 'Percentage' ? 'Rate (%)' : 'Amount'}><input className="field-input" type="number" step="any" min="0" value={form.commission_value} onChange={(e) => setForm({ ...form, commission_value: e.target.value })} /></Field>
          <Field label="Notes"><input className="field-input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
        </div>
        <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button type="submit" className="btn btn-primary">Save</button></div>
      </form>
    </Modal>
  );
}

function PayForm({ row, onClose, onSaved }) {
  const { can } = useAuth();
  const [banks, setBanks] = useState([]);
  const [cashes, setCashes] = useState([]);
  const [form, setForm] = useState({ payment_method: 'Bank Transfer', account: '', paid_date: new Date().toISOString().slice(0, 10), notes: '' });
  const [error, setError] = useState('');
  useEffect(() => {
    window.api.bankAccounts.list().then((r) => r.ok && setBanks(r.data));
    window.api.cashAccounts.list().then((r) => r.ok && setCashes(r.data));
  }, []);
  async function submit(e) {
    e.preventDefault();
    const [type, id] = form.account ? form.account.split(':') : [null, null];
    const res = await window.api.commissions.pay(row.id, { payment_method: form.payment_method, paid_date: form.paid_date, notes: form.notes, account_type: type, account_id: id ? Number(id) : null });
    if (!res.ok) return setError(res.error);
    onSaved();
  }
  return (
    <Modal title={`Pay ${row.currency} ${num(row.commission_amount)} to ${row.agent_name}`} onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error">{error}</div>}
        <div style={{ display: 'grid', gap: 12 }}>
          <Field label="Paid from">
            <select className="field-input" value={form.account} onChange={(e) => setForm({ ...form, account: e.target.value })}>
              <option value="">No account selected</option>
              {banks.map((a) => <option key={`b${a.id}`} value={`Bank:${a.id}`}>Bank - {a.account_name} ({num(a.current_balance)} {a.currency})</option>)}
              {cashes.map((a) => <option key={`c${a.id}`} value={`Cash:${a.id}`}>Cash - {a.account_name} ({num(a.current_balance)} {a.currency})</option>)}
            </select>
          </Field>
          <Field label="Method"><select className="field-input" value={form.payment_method} onChange={(e) => setForm({ ...form, payment_method: e.target.value })}>{METHODS.map((m) => <option key={m}>{m}</option>)}</select></Field>
          <Field label="Date paid"><input className="field-input" type="date" value={form.paid_date} onChange={(e) => setForm({ ...form, paid_date: e.target.value })} /></Field>
          <Field label="Notes"><input className="field-input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
        </div>
        <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button type="submit" className="btn btn-primary">Pay</button></div>
      </form>
    </Modal>
  );
}
