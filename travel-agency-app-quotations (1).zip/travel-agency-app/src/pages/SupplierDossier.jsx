import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BookOpen, RefreshCw, ChevronUp, ChevronDown, FileDown, Printer, FileSpreadsheet, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchAllPages } from '../utils/fetchAllPages.js';
import './customers.css';
import { useIpcData } from '../utils/useIpcData.js';
import ErrorRetry from '../components/ErrorRetry.jsx';

// Supplier 360 (master prompt: Supplier Dossier). All figures come from
// window.api.supplier360.* — real supplier_invoices / supplier_payments /
// supplier_ledger_entries and the five booking-service tables. Nothing here
// is invented; an idle supplier shows zeros.

const TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'services', label: 'Services' },
  { key: 'bookings', label: 'Bookings' },
  { key: 'invoices', label: 'Invoices' },
  { key: 'payments', label: 'Payments' },
  { key: 'timeline', label: 'Timeline' }
];

const money = (currency) => (n) => {
  const v = Number(n || 0);
  try { return new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v); }
  catch (_) { return `${currency} ${v.toLocaleString()}`; }
};
const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function SupplierDossier() {
  const { hasCapability } = useAuth();
  const { supplierId } = useParams();
  const id = Number(supplierId);
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');
  const [dossier, setDossier] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [exportBusy, setExportBusy] = useState(false);
  const [exportError, setExportError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const res = await window.api.supplier360.dossier(id);
    setLoading(false);
    if (!res.ok) return setError(res.error);
    setDossier(res.data);
  }, [id]);
  useEffect(() => { load(); }, [load]);

  const m = useMemo(() => money(dossier?.header.currency || 'PKR'), [dossier]);

  if (loading && !dossier) return <div className="card" style={{ padding: 30 }}>Loading supplier dossier…</div>;
  if (error) {
    return (
      <div className="card" style={{ padding: 30 }}>
        <p className="login-error">{error}</p>
        <button className="btn btn-secondary" onClick={load}><RefreshCw size={14} /> Retry</button>
      </div>
    );
  }
  const { header, summary } = dossier;

  async function exportDossier(format) {
    setExportBusy(true); setExportError('');
    // Complete-or-cancel: every part is fetched in full, and a failed part
    // cancels the export with a clear message instead of exporting an empty section.
    const parts = { Services: null, Bookings: null, Invoices: null, Payments: null, Timeline: null };
    [parts.Services, parts.Bookings, parts.Invoices, parts.Payments, parts.Timeline] = await Promise.all([
      window.api.supplier360.services(id, { pageSize: 0 }),
      window.api.supplier360.bookings(id),
      window.api.supplier360.invoices(id),
      window.api.supplier360.payments(id),
      fetchAllPages((p) => window.api.supplier360.timeline(id, p), { pick: (d) => d.items })
    ]);
    setExportBusy(false);
    const failed = Object.entries(parts).find(([, r]) => !r.ok);
    if (failed) { setExportError(`Export cancelled - could not load ${failed[0]}: ${failed[1].error}`); return; }
    const [svc, bk, inv, pay, tl] = [parts.Services, parts.Bookings, parts.Invoices, parts.Payments, parts.Timeline];
    const sections = [
      { title: 'Supplier Info', columns: Object.keys(header).map((k) => ({ key: k, label: k })), rows: [header] },
      { title: 'Services', columns: [{ key: 'service_type', label: 'Type' }, { key: 'booking_code', label: 'Booking' }, { key: 'customer_name', label: 'Customer' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: svc.ok ? svc.data.items : [] },
      { title: 'Bookings', columns: [{ key: 'booking_code', label: 'Booking' }, { key: 'customer_name', label: 'Customer' }, { key: 'invoiced', label: 'Invoiced', money: true }, { key: 'paid', label: 'Paid', money: true }, { key: 'payable', label: 'Payable', money: true }], rows: bk.ok ? bk.data : [] },
      { title: 'Invoices', columns: [{ key: 'invoice_number', label: 'Invoice #' }, { key: 'invoice_date', label: 'Date' }, { key: 'total', label: 'Total', money: true }, { key: 'remaining_amount', label: 'Remaining', money: true }, { key: 'status', label: 'Status' }], rows: inv.ok ? inv.data : [] },
      { title: 'Payments', columns: [{ key: 'payment_date', label: 'Date' }, { key: 'amount', label: 'Amount', money: true }, { key: 'payment_method', label: 'Method' }, { key: 'reference', label: 'Reference' }], rows: pay.ok ? pay.data : [] },
      { title: 'Timeline', columns: [{ key: 'at', label: 'Date' }, { key: 'event', label: 'Event' }, { key: 'reference', label: 'Reference' }], rows: tl.data }
    ];
    const reportData = { title: `Supplier Dossier - ${header.name}`, dateRangeLabel: 'All dates', filtersSummary: `Payable: ${m(summary.invoices.payable)}`, sections };
    let res;
    if (format === 'pdf') res = await window.api.reportExport.exportPdf(reportData);
    else if (format === 'print') res = await window.api.reportExport.print(reportData);
    else res = await window.api.reportExport.exportExcel(sections.map((s) => ({ name: s.title, columns: s.columns, rows: s.rows })), `Supplier-Dossier-${header.name}.xlsx`);
    if (!res.ok) setExportError(res.error);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="link-cell" onClick={() => navigate('/suppliers')} style={{ marginBottom: 6, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <ArrowLeft size={13} /> Back to Suppliers
          </button>
          <h1>{header.name}</h1>
          <p>
            {header.supplier_code} · {header.service_type || 'Supplier'} ·{' '}
            <span className={`status-pill ${header.status === 'Active' ? 'on' : 'off'}`}>{header.status}</span>
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {hasCapability('export_reports') && (
            <>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('pdf')}><FileDown size={14} /> PDF</button>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('excel')}><FileSpreadsheet size={14} /> Excel</button>
              <button className="btn btn-secondary" disabled={exportBusy} onClick={() => exportDossier('print')}><Printer size={14} /> Print</button>
            </>
          )}
          <button className="btn btn-secondary" onClick={() => navigate('/supplier-ledger', { state: { supplierId: id, supplierLabel: header.name } })}>
            <BookOpen size={14} /> Full Ledger
          </button>
        </div>
      </div>

      {exportError && <div className="login-error" style={{ marginBottom: 12 }}>{exportError}</div>}

      <div className="tabs" style={{ marginBottom: 16 }}>
        {TABS.map((t) => <button key={t.key} className={tab === t.key ? 'tab active' : 'tab'} onClick={() => setTab(t.key)}>{t.label}</button>)}
      </div>

      {tab === 'overview' && <Overview header={header} summary={summary} money={m} canViewCosts={hasCapability('view_supplier_costs')} />}
      {tab === 'services' && <ServicesTab id={id} types={dossier.serviceTypes} money={m} />}
      {tab === 'bookings' && <BookingsTab id={id} money={m} navigate={navigate} />}
      {tab === 'invoices' && <InvoicesTab id={id} money={m} />}
      {tab === 'payments' && <PaymentsTab id={id} money={m} />}
      {tab === 'timeline' && <TimelineTab id={id} />}
    </div>
  );
}

function Overview({ header, summary, money, canViewCosts }) {
  const cards = [
    ['Total Invoices', summary.invoices.count],
    ['Total Billed', money(summary.invoices.total_billed)],
    ['Paid on Invoices', money(summary.invoices.paid_on_invoices)],
    ['Payable', money(summary.invoices.payable), summary.invoices.payable > 0 ? 'var(--color-danger)' : undefined],
    ['Overdue Invoices', summary.invoices.overdue_count],
    ['Overdue Amount', money(summary.invoices.overdue), summary.invoices.overdue > 0 ? 'var(--color-danger)' : undefined],
    ['Total Paid', money(summary.payments.total_paid)],
    ['Paid Not Against Invoice', money(summary.payments.not_against_invoice)],
    ['Ledger Balance', money(summary.ledger_balance), summary.ledger_balance > 0 ? 'var(--color-danger)' : 'var(--color-success)'],
    ['Services Used', summary.services.count],
    ['Bookings Involved', summary.services.bookings],
    ...(canViewCosts ? [
      ['Service Cost (est.)', money(summary.services.service_cost)],
      ['Service Selling (est.)', money(summary.services.service_selling)],
      ['Service Profit (est.)', money(summary.services.service_profit)]
    ] : []),
    ['Last Payment', day(summary.payments.last_payment_date)]
  ];
  return (
    <>
      <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 12 }}>Supplier Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13 }}>
          <Info label="Company" value={header.company} />
          <Info label="Contact Person" value={header.contact_person} />
          <Info label="Phone" value={header.phone} />
          <Info label="Email" value={header.email} />
          <Info label="Address" value={header.address} />
          <Info label="Payment Terms" value={header.payment_terms} />
          <Info label="Currency" value={header.currency} />
          <Info label="Opening Balance" value={header.opening_balance} />
          <Info label="Notes" value={header.notes} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 12, marginBottom: 16 }}>
        {cards.map(([label, value, color]) => (
          <div key={label} className="card" style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: color || 'inherit', marginTop: 2 }}>{value}</div>
          </div>
        ))}
      </div>

      {canViewCosts ? (
        <>
          <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
            <h3 style={{ fontSize: 13.5, marginBottom: 4 }}>Service Cost by Type</h3>
            <table className="data-table">
              <thead><tr><th>Service Type</th><th>Count</th><th style={{ textAlign: 'right' }}>Cost</th><th style={{ textAlign: 'right' }}>Selling</th></tr></thead>
              <tbody>
                {summary.services.by_type.length === 0 && <tr><td colSpan={4} style={{ padding: 16, textAlign: 'center', color: 'var(--color-text-muted)' }}>No services yet</td></tr>}
                {summary.services.by_type.map((r) => (
                  <tr key={r.service_type}><td>{r.service_type}</td><td>{r.count}</td><td style={{ textAlign: 'right' }}>{money(r.cost)}</td><td style={{ textAlign: 'right' }}>{money(r.selling)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card" style={{ padding: '18px 22px' }}>
            <h3 style={{ fontSize: 13.5, marginBottom: 4 }}>Estimated vs. Actual Cost</h3>
            <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 10 }}>
              Estimated is what the booking services say this supplier should cost. Actual is what the supplier has invoiced. These are shown side by side and never added together.
            </p>
            <table className="data-table">
              <tbody>
                <tr><td>Estimated service cost</td><td style={{ textAlign: 'right' }}>{money(summary.cost_check.estimated_service_cost)}</td></tr>
                <tr><td>Actually invoiced</td><td style={{ textAlign: 'right' }}>{money(summary.cost_check.actually_invoiced)}</td></tr>
                <tr><td><strong>Difference</strong></td><td style={{ textAlign: 'right', fontWeight: 600 }}>{money(summary.cost_check.difference)}</td></tr>
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <div className="card" style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 10, color: 'var(--color-text-muted)' }}>
          <Lock size={14} /> Supplier cost figures are restricted for your role.
        </div>
      )}
    </>
  );
}

function Info({ label, value }) {
  return <div><div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div><div>{value || '—'}</div></div>;
}

function ServicesTab({ id, types, money }) {
  const empty = { search: '', serviceType: 'All', dateFrom: '', dateTo: '' };
  const [filters, setFilters] = useState(empty);
  const [applied, setApplied] = useState(empty);
  const [sort, setSort] = useState({ by: 'service_date', dir: 'desc' });
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setError('');
    const res = await window.api.supplier360.services(id, { ...applied, sortBy: sort.by, sortDir: sort.dir, page, pageSize });
    if (res.ok) setData(res.data); else setError(res.error);
  }, [id, applied, sort, page]);
  useEffect(() => { load(); }, [load]);

  const set = (k, v) => setFilters((f) => ({ ...f, [k]: v }));
  const toggleSort = (col) => { setPage(1); setSort((s) => (s.by === col ? { by: col, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { by: col, dir: 'asc' })); };
  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  const cols = [['service_type', 'Type'], ['service_date', 'Date'], ['booking_code', 'Booking'], ['customer_name', 'Customer'], ['cost', 'Cost'], ['selling_price', 'Selling'], ['profit', 'Profit'], ['status', 'Status']];

  return (
    <div>
      <div className="card" style={{ padding: '14px 18px', marginBottom: 14, display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'flex-end' }}>
        <input className="field-input" style={{ width: 200 }} placeholder="Search booking / customer" value={filters.search} onChange={(e) => set('search', e.target.value)} />
        <select className="field-input" value={filters.serviceType} onChange={(e) => set('serviceType', e.target.value)}>
          <option value="All">All types</option>{types.map((t) => <option key={t}>{t}</option>)}
        </select>
        <input className="field-input" type="date" value={filters.dateFrom} onChange={(e) => set('dateFrom', e.target.value)} />
        <input className="field-input" type="date" value={filters.dateTo} onChange={(e) => set('dateTo', e.target.value)} />
        <button className="btn btn-primary btn-sm" onClick={() => { setPage(1); setApplied(filters); }}>Apply</button>
        <button className="btn btn-secondary btn-sm" onClick={() => { setFilters(empty); setApplied(empty); setPage(1); }}>Reset</button>
      </div>
      <ErrorRetry error={error} onRetry={load} />
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr>{cols.map(([k, l]) => (
            <th key={k} onClick={() => toggleSort(k)} style={{ cursor: 'pointer' }}>{l}{sort.by === k && (sort.dir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />)}</th>
          ))}</tr></thead>
          <tbody>
            {!data && !error && <tr><td colSpan={8} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.items.length === 0 && <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No services found</td></tr>}
            {data && data.items.map((r) => (
              <tr key={`${r.service_type}-${r.service_id}`}>
                <td>{r.service_type}</td><td>{day(r.service_date)}</td><td>{r.booking_code || '—'}</td><td>{r.customer_name || '—'}</td>
                <td>{money(r.cost)}</td><td>{money(r.selling_price)}</td>
                <td style={{ color: r.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{money(r.profit)}</td><td>{r.status || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}

function BookingsTab({ id, money, navigate }) {
  const { data: rows, error, retry } = useIpcData(() => window.api.supplier360.bookings(id), [id]);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      <ErrorRetry error={error} onRetry={retry} />
      <table className="data-table">
        <thead><tr><th>Booking</th><th>Customer</th><th>Type</th><th>Services</th><th>Service Cost</th><th>Invoiced</th><th>Paid</th><th>Payable</th><th>Status</th></tr></thead>
        <tbody>
          {!rows && !error && <tr><td colSpan={9} style={{ padding: 24 }}>Loading…</td></tr>}
          {rows && rows.length === 0 && <tr><td colSpan={9} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No bookings yet</td></tr>}
          {rows && rows.map((r) => (
            <tr key={r.id}>
              <td><button className="link-cell" onClick={() => navigate(`/customers/${r.customer_id}/360`)}>{r.booking_code}</button></td>
              <td>{r.customer_name || '—'}</td><td>{r.booking_type}</td><td>{r.services}</td>
              <td>{money(r.service_cost)}</td><td>{money(r.invoiced)}</td><td>{money(r.paid)}</td>
              <td style={{ color: r.payable > 0 ? 'var(--color-danger)' : 'inherit' }}>{money(r.payable)}</td><td>{r.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function InvoicesTab({ id, money }) {
  const { data: rows, error, retry } = useIpcData(() => window.api.supplier360.invoices(id), [id]);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      <ErrorRetry error={error} onRetry={retry} />
      <table className="data-table">
        <thead><tr><th>Invoice #</th><th>Date</th><th>Booking</th><th>Total</th><th>Paid</th><th>Remaining</th><th>Status</th></tr></thead>
        <tbody>
          {!rows && !error && <tr><td colSpan={7} style={{ padding: 24 }}>Loading…</td></tr>}
          {rows && rows.length === 0 && <tr><td colSpan={7} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No invoices yet</td></tr>}
          {rows && rows.map((r) => (
            <tr key={r.id}>
              <td><strong>{r.invoice_number}</strong></td><td>{day(r.invoice_date)}</td><td>{r.booking_code || '—'}</td>
              <td>{money(r.total)}</td><td>{money(r.paid_amount)}</td>
              <td style={{ color: r.remaining_amount > 0 ? 'var(--color-danger)' : 'inherit' }}>{money(r.remaining_amount)}</td><td>{r.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PaymentsTab({ id, money }) {
  const { data: rows, error, retry } = useIpcData(() => window.api.supplier360.payments(id), [id]);
  return (
    <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
      <ErrorRetry error={error} onRetry={retry} />
      <table className="data-table">
        <thead><tr><th>Date</th><th>Invoice</th><th>Booking</th><th>Method</th><th>Amount</th><th>Reference</th></tr></thead>
        <tbody>
          {!rows && !error && <tr><td colSpan={6} style={{ padding: 24 }}>Loading…</td></tr>}
          {rows && rows.length === 0 && <tr><td colSpan={6} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No payments yet</td></tr>}
          {rows && rows.map((r) => (
            <tr key={r.id}>
              <td>{day(r.payment_date)}</td><td>{r.invoice_number || '—'}</td><td>{r.booking_code || '—'}</td>
              <td>{r.payment_method}</td><td>{money(r.amount)}</td><td>{r.reference || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TimelineTab({ id }) {
  const [page, setPage] = useState(1);
  const pageSize = 25;
  const { data, error, retry } = useIpcData(() => window.api.supplier360.timeline(id, { page, pageSize }), [id, page]);
  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  return (
    <div>
      <ErrorRetry error={error} onRetry={retry} />
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Date / Time</th><th>Event</th><th>Reference</th><th>Notes</th></tr></thead>
          <tbody>
            {!data && !error && <tr><td colSpan={4} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.items.length === 0 && <tr><td colSpan={4} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No activity yet</td></tr>}
            {data && data.items.map((e, i) => (
              <tr key={`${e.at}-${i}`}><td style={{ whiteSpace: 'nowrap' }}>{String(e.at).slice(0, 16).replace('T', ' ')}</td><td><strong>{e.event}</strong></td><td>{e.reference || '—'}</td><td>{e.notes || '—'}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
