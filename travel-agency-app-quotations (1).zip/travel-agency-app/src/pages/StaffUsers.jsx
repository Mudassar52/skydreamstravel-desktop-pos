import { useEffect, useState } from 'react';
import { UserPlus, KeyRound, ShieldCheck, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import './staffusers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

export default function StaffUsers() {
  const { can } = useAuth();
  const [tab, setTab] = useState('users');

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Staff & Users</h1>
          <p>Manage logins, roles, and what each role is allowed to do.</p>
        </div>
        {tab === 'users' && can('staff', 'create') && (
          <AddUserButton />
        )}
      </div>

      <div className="tabs">
        <button className={tab === 'users' ? 'tab active' : 'tab'} onClick={() => setTab('users')}>Users</button>
        <button className={tab === 'permissions' ? 'tab active' : 'tab'} onClick={() => setTab('permissions')}>Permissions</button>
      </div>

      {tab === 'users' && <UsersTable />}
      {tab === 'permissions' && <PermissionsMatrix />}
    </div>
  );
}

// ---------------------------------------------------------------------
function UsersTable() {
  const { can } = useAuth();
  const [users, setUsers] = useState([]);
  const pg = usePagination(users, 25);
  const [roles, setRoles] = useState([]);
  const [resetTarget, setResetTarget] = useState(null);
  const [notice, setNotice] = useState('');

  async function reload() {
    const [u, r] = await Promise.all([window.api.users.list(), window.api.roles.list()]);
    if (u.ok) setUsers(u.data);
    if (r.ok) setRoles(r.data);
  }

  useEffect(() => { reload(); }, []);

  async function toggleActive(u) {
    const res = await window.api.users.update(u.id, {
      fullName: u.full_name, roleId: u.role_id, phone: u.phone, email: u.email, isActive: u.is_active ? 0 : 1
    });
    if (res.ok) reload();
  }

  return (
    <div className="card" style={{ padding: 0 }}>
      {notice && <div className="inline-notice">{notice}</div>}
      <table className="data-table">
        <thead>
          <tr>
            <th>Name</th><th>Username</th><th>Role</th><th>Phone</th><th>Status</th><th></th>
          </tr>
        </thead>
        <tbody>
          {pg.pageRows.map((u) => (
            <tr key={u.id}>
              <td>{u.full_name}</td>
              <td>{u.username}</td>
              <td><span className="role-badge">{u.role_name}</span></td>
              <td>{u.phone || '—'}</td>
              <td>
                <span className={`status-dot ${u.is_active ? 'on' : 'off'}`} />
                {u.is_active ? 'Active' : 'Disabled'}
              </td>
              <td className="row-actions">
                {can('staff', 'edit') && (
                  <button className="btn btn-secondary btn-sm" onClick={() => toggleActive(u)}>
                    {u.is_active ? 'Disable' : 'Enable'}
                  </button>
                )}
                {can('staff', 'edit') && (
                  <button className="btn btn-secondary btn-sm" onClick={() => setResetTarget(u)}>
                    <KeyRound size={13} /> Reset Password
                  </button>
                )}
              </td>
            </tr>
          ))}
          {users.length === 0 && (
            <tr><td colSpan={6} className="empty-row">No users yet.</td></tr>
          )}
        </tbody>
      </table>
        <Pagination {...pg.pagerProps} label="users" />

      {resetTarget && (
        <ResetPasswordModal
          user={resetTarget}
          onClose={() => setResetTarget(null)}
          onDone={(msg) => { setResetTarget(null); setNotice(msg); setTimeout(() => setNotice(''), 3500); }}
        />
      )}
    </div>
  );
}

function ResetPasswordModal({ user, onClose, onDone }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    const res = await window.api.users.resetPassword(user.id, password);
    if (!res.ok) return setError(res.error);
    onDone(`Password updated for ${user.full_name}.`);
  }

  return (
    <Modal title={`Reset password — ${user.full_name}`} onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
        <label className="field-label">New password</label>
        <input className="field-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary">Save</button>
        </div>
      </form>
    </Modal>
  );
}

function AddUserButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="btn btn-primary" onClick={() => setOpen(true)}><UserPlus size={15} /> Add User</button>
      {open && <AddUserModal onClose={() => setOpen(false)} />}
    </>
  );
}

function AddUserModal({ onClose }) {
  const [roles, setRoles] = useState([]);
  const [form, setForm] = useState({ fullName: '', username: '', password: '', roleId: '', phone: '', email: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    window.api.roles.list().then((r) => { if (r.ok) { setRoles(r.data); setForm((f) => ({ ...f, roleId: r.data[0]?.id || '' })); } });
  }, []);

  async function submit(e) {
    e.preventDefault();
    const res = await window.api.users.create(form);
    if (!res.ok) return setError(res.error);
    window.location.reload();
  }

  return (
    <Modal title="Add user" onClose={onClose}>
      <form onSubmit={submit}>
        {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
        <label className="field-label">Full name</label>
        <input className="field-input" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
        <label className="field-label">Username</label>
        <input className="field-input" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        <label className="field-label">Password</label>
        <input className="field-input" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <label className="field-label">Role</label>
        <select className="field-input" value={form.roleId} onChange={(e) => setForm({ ...form, roleId: Number(e.target.value) })}>
          {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
        </select>
        <label className="field-label">Phone (optional)</label>
        <input className="field-input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary">Create User</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------------
function PermissionsMatrix() {
  const { can } = useAuth();
  const [data, setData] = useState(null);

  async function reload() {
    const res = await window.api.permissions.getMatrix();
    if (res.ok) setData(res.data);
  }
  useEffect(() => { reload(); }, []);

  async function toggle(roleId, module, field, currentGrant) {
    if (!can('staff', 'edit')) return;
    const next = { ...currentGrant, [field]: currentGrant[field] ? 0 : 1 };
    await window.api.permissions.update({ roleId, module, ...next });
    reload();
  }

  if (!data) return null;

  const grantFor = (roleId, module) =>
    data.grants.find((g) => g.role_id === roleId && g.module === module) ||
    { can_view: 0, can_create: 0, can_edit: 0, can_delete: 0 };

  return (
    <div className="card" style={{ padding: '18px 20px', overflowX: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <ShieldCheck size={16} color="var(--color-primary)" />
        <strong style={{ fontSize: 13.5 }}>Module permissions by role</strong>
      </div>
      {data.roles.map((role) => (
        <div key={role.id} style={{ marginBottom: 22 }}>
          <div className="role-badge" style={{ marginBottom: 8 }}>{role.name}</div>
          <table className="data-table permissions-table">
            <thead>
              <tr>
                <th>Module</th><th>View</th><th>Create</th><th>Edit</th><th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {data.modules.map((mod) => {
                const grant = grantFor(role.id, mod.key);
                return (
                  <tr key={mod.key}>
                    <td>{mod.label}</td>
                    {['can_view', 'can_create', 'can_edit', 'can_delete'].map((field) => (
                      <td key={field}>
                        <input
                          type="checkbox"
                          checked={!!grant[field]}
                          disabled={!can('staff', 'edit') || role.name === 'Admin'}
                          onChange={() => toggle(role.id, mod.key, field, grant)}
                        />
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ))}
      <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)' }}>Admin always has full access and can't be restricted here.</p>
      <CapabilitiesMatrix />
    </div>
  );
}

// Global capabilities (master prompt section 48): View Profit / View
// Supplier Costs / Export Reports - cross-module financial-sensitivity
// flags, separate from the per-module grid above. Gates the profit/cost
// figures and export buttons across Customer/Supplier/Booking/Package 360,
// the Custom Report Builder, and the Ledger pages.
function CapabilitiesMatrix() {
  const { can, user } = useAuth();
  const [data, setData] = useState(null);

  async function reload() {
    const res = await window.api.capabilities.getMatrix();
    if (res.ok) setData(res.data);
  }
  useEffect(() => { reload(); }, []);

  async function toggle(roleId, capability, currentlyGranted) {
    if (!can('staff', 'edit')) return;
    await window.api.capabilities.update({ roleId, capability, granted: !currentlyGranted, actingUserId: user?.id || null });
    reload();
  }

  if (!data) return null;
  const grantFor = (roleId, capability) => !!data.grants.find((g) => g.role_id === roleId && g.capability === capability)?.granted;

  return (
    <div style={{ marginTop: 26, borderTop: '1px solid var(--color-border)', paddingTop: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <ShieldCheck size={16} color="var(--color-primary)" />
        <strong style={{ fontSize: 13.5 }}>Financial visibility by role</strong>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginBottom: 12 }}>
        Controls whether a role can see profit and supplier cost figures (across customer/supplier/booking dossiers and reports) and whether it can export reports to PDF/Excel/Print.
      </p>
      <table className="data-table permissions-table">
        <thead><tr><th>Role</th>{data.capabilities.map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
        <tbody>
          {data.roles.map((role) => (
            <tr key={role.id}>
              <td><span className="role-badge">{role.name}</span></td>
              {data.capabilities.map((c) => (
                <td key={c.key}>
                  <input
                    type="checkbox"
                    checked={grantFor(role.id, c.key)}
                    disabled={!can('staff', 'edit') || role.name === 'Admin'}
                    onChange={() => toggle(role.id, c.key, grantFor(role.id, c.key))}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------
function Modal({ title, onClose, children }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <strong>{title}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}
