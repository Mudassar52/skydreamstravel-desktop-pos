import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, ArrowDownCircle, ArrowUpCircle, ArrowLeftRight, History } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function BankAccounts() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [txnModal, setTxnModal] = useState(null);
  const [historyId, setHistoryId] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.bankAccounts.list({ includeInactive: true });
    if (res.ok) setRows(res.data); else setError(res.error);
  }, []);
  useEffect(() => { load(); }, [load]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Bank Accounts</h1>
          <p>{rows.length.toLocaleString()} account{rows.length === 1 ? '' : 's'}</p>
        </div>
        {can('bank_accounts', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}><Plus size={15} /> Add Bank Account</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Account</th><th>Bank</th><th>Account #</th><th>Currency</th><th>Current Balance</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {pg.pageRows.map((a) => (
              <tr key={a.id}>
                <td>{a.account_name}</td>
                <td>{a.bank_name}</td>
                <td>{a.account_number || '—'}</td>
                <td>{a.currency}</td>
                <td style={{ fontWeight: 600 }}>{money(a.current_balance)}</td>
                <td><span className={`status-pill ${a.status === 'Active' ? 'on' : 'off'}`}>{a.status}</span></td>
                <td className="row-actions">
                  {can('bank_accounts', 'edit') && (
                    <>
                      <button className="icon-btn" title="Deposit" onClick={() => setTxnModal({ mode: 'deposit', account: a })}><ArrowDownCircle size={14} /></button>
                      <button className="icon-btn" title="Withdraw" onClick={() => setTxnModal({ mode: 'withdraw', account: a })}><ArrowUpCircle size={14} /></button>
                      <button className="icon-btn" title="Transfer" onClick={() => setTxnModal({ mode: 'transfer', account: a })}><ArrowLeftRight size={14} /></button>
                      <button className="icon-btn" title="History" onClick={() => setHistoryId(a.id)}><History size={14} /></button>
                      <button className="icon-btn" title="Edit" onClick={() => { setEditingId(a.id); setFormOpen(true); }}><Pencil size={14} /></button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No bank accounts yet.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="accounts" />
      </div>

      {formOpen && (
        <AccountFormModal type="Bank" accountId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}
      {txnModal && (
        <TransactionModal type="Bank" mode={txnModal.mode} account={txnModal.account} onClose={() => setTxnModal(null)} onDone={(msg) => { setTxnModal(null); flash(msg); load(); }} />
      )}
      {historyId && (
        <HistoryModal type="Bank" accountId={historyId} onClose={() => setHistoryId(null)} />
      )}
    </div>
  );
}

export const EMPTY_ACCOUNT = { account_name: '', bank_name: '', account_number: '', currency: 'PKR', opening_balance: 0, status: 'Active' };

export function AccountFormModal({ type, accountId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY_ACCOUNT);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!accountId) return;
    window.api.accounts.get(type, accountId).then((res) => { if (res.ok) setForm({ ...EMPTY_ACCOUNT, ...res.data }); });
  }, [type, accountId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.account_name.trim()) return setError('Account name is required.');
    setSaving(true);
    const res = accountId ? await window.api.accounts.update(type, accountId, form) : await window.api.accounts.create(type, form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(accountId ? 'Account updated.' : 'Account added.');
  }

  return (
    <Modal title={accountId ? `Edit ${type} Account` : `Add ${type} Account`} onClose={onClose} width={460}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Account Name *" full><input className="field-input" value={form.account_name} onChange={(e) => set('account_name', e.target.value)} /></Field>
          {type === 'Bank' && (
            <>
              <Field label="Bank Name *"><input className="field-input" value={form.bank_name || ''} onChange={(e) => set('bank_name', e.target.value)} /></Field>
              <Field label="Account Number"><input className="field-input" value={form.account_number || ''} onChange={(e) => set('account_number', e.target.value)} /></Field>
            </>
          )}
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          {!accountId && <Field label="Opening Balance"><input type="number" className="field-input" value={form.opening_balance} onChange={(e) => set('opening_balance', e.target.value)} /></Field>}
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              <option>Active</option><option>Inactive</option>
            </select>
          </Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Account'}</button>
        </div>
      </form>
    </Modal>
  );
}

export function TransactionModal({ type, mode, account, onClose, onDone }) {
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [toType, setToType] = useState('Cash');
  const [toId, setToId] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [targets, setTargets] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (mode !== 'transfer') return;
    const loader = toType === 'Bank' ? window.api.bankAccounts.list : window.api.cashAccounts.list;
    loader({}).then((res) => { if (res.ok) setTargets(res.data.filter((a) => !(toType === type && a.id === account.id))); });
  }, [mode, toType, type, account]);

  async function submit(e) {
    e.preventDefault();
    if (!(Number(amount) > 0)) return setError('Amount must be greater than zero.');
    setSaving(true);
    let res;
    if (mode === 'deposit') res = await window.api.accounts.deposit({ account_type: type, account_id: account.id, amount, description });
    else if (mode === 'withdraw') res = await window.api.accounts.withdraw({ account_type: type, account_id: account.id, amount, description });
    else {
      if (!toId) { setSaving(false); return setError('Please select a destination account.'); }
      res = await window.api.accounts.transfer({ from_type: type, from_id: account.id, to_type: toType, to_id: toId, amount, to_amount: toAmount ? Number(toAmount) : null, description });
    }
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onDone(`${mode === 'deposit' ? 'Deposit' : mode === 'withdraw' ? 'Withdrawal' : 'Transfer'} recorded.`);
  }

  const title = mode === 'deposit' ? `Deposit to ${account.account_name}` : mode === 'withdraw' ? `Withdraw from ${account.account_name}` : `Transfer from ${account.account_name}`;

  return (
    <Modal title={title} onClose={onClose} width={420}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Amount *"><input type="number" className="field-input" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
          {mode === 'transfer' && (
            <>
              <Field label="Destination Type">
                <select className="field-input" value={toType} onChange={(e) => { setToType(e.target.value); setToId(''); }}>
                  <option>Bank</option><option>Cash</option>
                </select>
              </Field>
              <Field label="Destination Account">
                <select className="field-input" value={toId} onChange={(e) => { setToId(e.target.value); setToAmount(''); }}>
                  <option value="">— Select —</option>
                  {targets.map((t) => <option key={t.id} value={t.id}>{t.account_name} ({t.currency})</option>)}
                </select>
              </Field>
              {(() => {
                const dest = targets.find((t) => String(t.id) === String(toId));
                if (!dest || !account.currency || String(dest.currency).toUpperCase() === String(account.currency).toUpperCase()) return null;
                return (
                  <Field label={`Amount arriving (${String(dest.currency).toUpperCase()}) *`} full>
                    <input type="number" step="any" className="field-input" value={toAmount} onChange={(e) => setToAmount(e.target.value)} />
                    <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 4 }}>The accounts hold different currencies ({String(account.currency).toUpperCase()} → {String(dest.currency).toUpperCase()}). Enter what lands in the destination.</div>
                  </Field>
                );
              })()}
            </>
          )}
          <Field label="Description" full><input className="field-input" value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Confirm'}</button>
        </div>
      </form>
    </Modal>
  );
}

export function HistoryModal({ type, accountId, onClose }) {
  const [account, setAccount] = useState(null);
  const txPg = usePagination(account?.transactions || [], 10);

  useEffect(() => { window.api.accounts.get(type, accountId).then((res) => { if (res.ok) setAccount(res.data); }); }, [type, accountId]);
  if (!account) return null;

  return (
    <Modal title={`Transaction History — ${account.account_name}`} onClose={onClose} width={560}>
      <div style={{ marginBottom: 10, fontSize: 13 }}>Current balance: <strong>{money(account.current_balance)}</strong></div>
      {txPg.pageRows.map((t) => (
        <div className="info-row" key={t.id}>
          <span>{t.transaction_type} — {t.description || ''}</span>
          <span style={{ color: t.direction === 'In' ? 'var(--color-success)' : 'var(--color-danger)' }}>
            {t.direction === 'In' ? '+' : '-'}{money(t.amount)}
          </span>
        </div>
      ))}
      {account.transactions.length === 0 && <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No transactions yet.</p>}
      <Pagination {...txPg.pagerProps} label="transactions" />
    </Modal>
  );
}
