import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, RefreshCw, FileDown, Printer, FileSpreadsheet, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useIpcData } from '../utils/useIpcData.js';
import ErrorRetry from '../components/ErrorRetry.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

// Booking 360 (master prompt sections 26 / 60-A.9). Every tab is filtered by
// this ONE booking's relationships, via window.api.bookingDossier.get and
// window.api.vouchers.*. Estimated (booking service cost/selling) and actual
// (real invoices/supplier invoices) figures are always shown separately.

const TABS = [
  'Overview', 'Customer', 'Travellers', 'Package', 'Flights', 'Visa', 'Hotels', 'Transport', 'Ziyarat',
  'Suppliers', 'Invoices', 'Payments', 'Advances', 'Outstanding', 'Supplier Costs', 'Profit',
  'Documents', 'Vouchers', 'Timeline & Activity', 'Notes'
];

const money = (currency) => (n) => {
  const v = Number(n || 0);
  try { return new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v); }
  catch (_) { return `${currency} ${v.toLocaleString()}`; }
};
const day = (s) => (s ? String(s).slice(0, 10) : '—');
const T = ({ cols, rows, empty, render }) => {
  const pg = usePagination(rows, 10);
  return (
    <>
      <table className="data-table">
        <thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={cols.length} style={{ padding: 20, textAlign: 'center', color: 'var(--color-text-muted)' }}>{empty}</td></tr>}
          {pg.pageRows.map((r, i) => <tr key={r.id || i}>{render(r)}</tr>)}
        </tbody>
      </table>
      <Pagination {...pg.pagerProps} label="rows" />
    </>
  );
};
const Card = ({ children, style }) => <div className="card" style={{ padding: 0, overflowX: 'auto', ...style }}>{children}</div>;
const Info = ({ label, value }) => <div><div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div><div>{value || '—'}</div></div>;
const Stat = ({ label, value, color }) => (
  <div className="card" style={{ padding: '12px 16px' }}>
    <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
    <div style={{ fontSize: 17, fontWeight: 700, color: color || 'inherit', marginTop: 2 }}>{value}</div>
  </div>
);

export default function BookingDossier() {
  const { hasCapability } = useAuth();
  const { bookingId } = useParams();
  const id = Number(bookingId);
  const navigate = useNavigate();
  const [tab, setTab] = useState('Overview');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const res = await window.api.bookingDossier.get(id);
    setLoading(false);
    if (!res.ok) return setError(res.error);
    setData(res.data);
  }, [id]);
  useEffect(() => { load(); }, [load]);

  const m = useMemo(() => money(data?.header.currency || 'PKR'), [data]);
  // Cost and profit arrive as null when the role lacks View Profit (blanked by the main process) - show a dash.
  const mc = (v) => (v === null || v === undefined ? '—' : m(v));
  if (loading && !data) return <div className="card" style={{ padding: 30 }}>Loading booking dossier…</div>;
  if (error) return (
    <div className="card" style={{ padding: 30 }}>
      <p className="login-error">{error}</p>
      <button className="btn btn-secondary" onClick={load}><RefreshCw size={14} /> Retry</button>
    </div>
  );
  const { header: h } = data;

  async function exportDossier(format) {
    const sections = [
      { title: 'Booking Info', columns: ['booking_code', 'booking_type', 'status', 'departure_date', 'return_date', 'total_price'].map((k) => ({ key: k, label: k, money: k === 'total_price' })), rows: [h] },
      { title: 'Travellers', columns: [{ key: 'full_name', label: 'Name' }, { key: 'relationship', label: 'Relationship' }, { key: 'passport_number', label: 'Passport' }], rows: data.travellers },
      { title: 'Flights', columns: [{ key: 'airline', label: 'Airline' }, { key: 'flight_number', label: 'Flight #' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: data.flights },
      { title: 'Hotels', columns: [{ key: 'hotel_name', label: 'Hotel' }, { key: 'check_in', label: 'Check-in' }, { key: 'check_out', label: 'Check-out' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: data.hotels },
      { title: 'Visa', columns: [{ key: 'country', label: 'Country' }, { key: 'visa_type', label: 'Type' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: data.visa },
      { title: 'Transport', columns: [{ key: 'pickup_location', label: 'Pickup' }, { key: 'drop_location', label: 'Drop' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: data.transport },
      { title: 'Ziyarat', columns: [{ key: 'service_type', label: 'Service' }, { key: 'description', label: 'Description' }, { key: 'cost', label: 'Cost', money: true }, { key: 'selling_price', label: 'Selling', money: true }], rows: data.ziyarat },
      { title: 'Suppliers', columns: [{ key: 'name', label: 'Supplier' }, { key: 'service_type', label: 'Service Type' }, { key: 'service_count', label: 'Services' }], rows: data.suppliers },
      { title: 'Invoices', columns: [{ key: 'invoice_number', label: 'Invoice #' }, { key: 'total', label: 'Total', money: true }, { key: 'remaining_amount', label: 'Remaining', money: true }, { key: 'status', label: 'Status' }], rows: data.invoices },
      { title: 'Payments', columns: [{ key: 'payment_date', label: 'Date' }, { key: 'payment_type', label: 'Type' }, { key: 'amount', label: 'Amount', money: true }], rows: data.payments },
      { title: 'Documents', columns: [{ key: 'file_name', label: 'File' }, { key: 'document_type', label: 'Type' }], rows: data.documents },
      { title: 'Timeline', columns: [{ key: 'at', label: 'Date' }, { key: 'event', label: 'Event' }, { key: 'reference', label: 'Reference' }], rows: data.timeline },
      ...(hasCapability('view_profit') ? [{ title: 'Profit', columns: Object.keys(data.profit).map((k) => ({ key: k, label: k })), rows: [data.profit] }] : [])
    ];
    const reportData = { title: `Booking Dossier - ${h.booking_code}`, dateRangeLabel: 'All dates', filtersSummary: `Customer: ${h.customer?.full_name || '—'}`, sections };
    let res;
    if (format === 'pdf') res = await window.api.reportExport.exportPdf(reportData);
    else if (format === 'print') res = await window.api.reportExport.print(reportData);
    else res = await window.api.reportExport.exportExcel(sections.map((s) => ({ name: s.title, columns: s.columns, rows: s.rows })), `Booking-Dossier-${h.booking_code}.xlsx`);
    if (!res.ok) window.alert(res.error);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="link-cell" onClick={() => navigate('/bookings')} style={{ marginBottom: 6, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <ArrowLeft size={13} /> Back to Bookings
          </button>
          <h1>{h.booking_code}</h1>
          <p>{h.booking_type} · {h.destination || 'No destination set'} · <span className="status-pill on">{h.status}</span></p>
        </div>
        {hasCapability('export_reports') && (
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-secondary" onClick={() => exportDossier('pdf')}><FileDown size={14} /> PDF</button>
            <button className="btn btn-secondary" onClick={() => exportDossier('excel')}><FileSpreadsheet size={14} /> Excel</button>
            <button className="btn btn-secondary" onClick={() => exportDossier('print')}><Printer size={14} /> Print</button>
          </div>
        )}
      </div>

      <div className="tabs" style={{ marginBottom: 16, flexWrap: 'wrap' }}>
        {TABS.map((t) => <button key={t} className={tab === t ? 'tab active' : 'tab'} onClick={() => setTab(t)}>{t}</button>)}
      </div>

      {tab === 'Overview' && <Overview h={h} data={data} money={m} canViewProfit={hasCapability('view_profit')} />}
      {tab === 'Customer' && <CustomerTab h={h} navigate={navigate} />}
      {tab === 'Travellers' && <Card><T cols={['Name', 'Relationship', 'Gender', 'Passport', 'Passport Expiry', 'Nationality', 'Notes']} rows={data.travellers} empty="No travellers linked to this booking." render={(t) => (<>
        <td><strong>{t.full_name}</strong></td><td>{t.relationship || '—'}</td><td>{t.gender || '—'}</td><td>{t.passport_number || '—'}</td>
        <td>{day(t.passport_expiry_date)}</td><td>{t.nationality || '—'}</td><td>{t.booking_notes || '—'}</td></>)} /></Card>}
      {tab === 'Package' && <PackageTab h={h} money={m} />}
      {tab === 'Flights' && <Card><T cols={['Airline', 'Flight #', 'PNR', 'Route', 'Departure', 'Cost', 'Selling', 'Profit', 'Supplier', 'Status']} rows={data.flights} empty="No flights recorded." render={(f) => (<>
        <td>{f.airline || '—'}</td><td>{f.flight_number || '—'}</td><td>{f.pnr || '—'}</td><td>{[f.departure_airport, f.arrival_airport].filter(Boolean).join(' → ') || '—'}</td>
        <td>{day(f.departure_date)}</td><td>{mc(f.cost)}</td><td>{m(f.selling_price)}</td><td style={{ color: f.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{mc(f.profit)}</td>
        <td>{f.supplier_name || '—'}</td><td>{f.status || '—'}</td></>)} /></Card>}
      {tab === 'Visa' && <Card><T cols={['Country', 'Type', 'Application #', 'Cost', 'Selling', 'Profit', 'Supplier', 'Status']} rows={data.visa} empty="No visa applications recorded." render={(v) => (<>
        <td>{v.country || '—'}</td><td>{v.visa_type || '—'}</td><td>{v.application_number || '—'}</td>
        <td>{mc(v.cost)}</td><td>{m(v.selling_price)}</td><td style={{ color: v.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{mc(v.profit)}</td>
        <td>{v.supplier_name || '—'}</td><td>{v.status || '—'}</td></>)} /></Card>}
      {tab === 'Hotels' && <Card><T cols={['Hotel', 'City', 'Check-in', 'Check-out', 'Room', 'Cost', 'Selling', 'Profit', 'Supplier', 'Confirmation']} rows={data.hotels} empty="No hotels recorded." render={(hh) => (<>
        <td>{hh.hotel_name}</td><td>{hh.city || '—'}</td><td>{day(hh.check_in)}</td><td>{day(hh.check_out)}</td><td>{hh.room_type || '—'}</td>
        <td>{mc(hh.cost)}</td><td>{m(hh.selling_price)}</td><td style={{ color: hh.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{mc(hh.profit)}</td>
        <td>{hh.supplier_name || '—'}</td><td>{hh.confirmation_number || hh.booking_reference || '—'}</td></>)} /></Card>}
      {tab === 'Transport' && <Card><T cols={['Type', 'Vehicle', 'Route', 'Pickup', 'Cost', 'Selling', 'Profit', 'Supplier', 'Status']} rows={data.transport} empty="No transport recorded." render={(t) => (<>
        <td>{t.transport_type || '—'}</td><td>{t.vehicle || '—'}</td><td>{[t.pickup_location, t.drop_location].filter(Boolean).join(' → ') || '—'}</td>
        <td>{day(t.pickup_date)}</td><td>{mc(t.cost)}</td><td>{m(t.selling_price)}</td><td style={{ color: t.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{mc(t.profit)}</td>
        <td>{t.supplier_name || '—'}</td><td>{t.status || '—'}</td></>)} /></Card>}
      {tab === 'Ziyarat' && <Card><T cols={['Service', 'Description', 'Date', 'Cost', 'Selling', 'Profit', 'Supplier', 'Status']} rows={data.ziyarat} empty="No Ziyarat / other services recorded." render={(z) => (<>
        <td>{z.service_type}</td><td>{z.description || '—'}</td><td>{day(z.service_date)}</td>
        <td>{mc(z.cost)}</td><td>{m(z.selling_price)}</td><td style={{ color: z.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{mc(z.profit)}</td>
        <td>{z.supplier_name || '—'}</td><td>{z.status || '—'}</td></>)} /></Card>}
      {tab === 'Suppliers' && <Card><T cols={['Supplier', 'Code', 'Service Type', 'Phone', 'Services on this Booking']} rows={data.suppliers} empty="No suppliers involved yet." render={(s) => (<>
        <td><strong>{s.name}</strong></td><td>{s.supplier_code}</td><td>{s.service_type || '—'}</td><td>{s.phone || '—'}</td><td>{s.service_count}</td></>)} /></Card>}
      {tab === 'Invoices' && <Card><T cols={['Invoice #', 'Date', 'Total', 'Paid', 'Remaining', 'Status']} rows={data.invoices} empty="No invoices raised for this booking." render={(i) => (<>
        <td><strong>{i.invoice_number}</strong></td><td>{day(i.invoice_date)}</td><td>{m(i.total)}</td><td>{m(i.paid_amount)}</td>
        <td style={{ color: i.remaining_amount > 0 ? 'var(--color-danger)' : 'inherit' }}>{m(i.remaining_amount)}</td><td>{i.status}</td></>)} /></Card>}
      {tab === 'Payments' && <Card><T cols={['Date', 'Invoice', 'Method', 'Type', 'Amount', 'Reference']} rows={data.payments} empty="No payments recorded for this booking." render={(p) => (<>
        <td>{day(p.payment_date)}</td><td>{p.invoice_number || '—'}</td><td>{p.payment_method}</td><td>{p.payment_type}</td>
        <td style={{ color: p.payment_type === 'Refund' ? 'var(--color-danger)' : 'inherit' }}>{p.payment_type === 'Refund' ? '−' : ''}{m(p.amount)}</td><td>{p.reference || '—'}</td></>)} /></Card>}
      {tab === 'Advances' && <AdvancesTab data={data.advances} money={m} />}
      {tab === 'Outstanding' && <OutstandingTab data={data.outstanding} money={m} />}
      {tab === 'Supplier Costs' && (hasCapability('view_supplier_costs') ? <SupplierCostsTab data={data.supplierCosts} money={m} /> : <Restricted text="Supplier cost figures" />)}
      {tab === 'Profit' && (hasCapability('view_profit') ? <ProfitTab p={data.profit} money={m} /> : <Restricted text="Profit figures" />)}
      {tab === 'Documents' && <Card><T cols={['Document', 'Type', 'Uploaded', 'Notes']} rows={data.documents} empty="No documents uploaded for this booking." render={(d) => (<>
        <td>{d.file_name}</td><td>{d.document_type || '—'}</td><td>{day(d.uploaded_at)}</td><td>{d.notes || '—'}</td></>)} /></Card>}
      {tab === 'Vouchers' && <VouchersTab bookingId={id} />}
      {(tab === 'Timeline & Activity') && <Card><T cols={['Date / Time', 'Event', 'Reference', 'Notes']} rows={data.timeline} empty="No activity yet." render={(e) => (<>
        <td style={{ whiteSpace: 'nowrap' }}>{String(e.at).slice(0, 16).replace('T', ' ')}</td><td><strong>{e.event}</strong></td><td>{e.reference || '—'}</td><td>{e.notes || '—'}</td></>)} /></Card>}
      {tab === 'Notes' && <NotesTab h={h} />}
    </div>
  );
}

function Overview({ h, data, money, canViewProfit }) {
  const cards = [
    ['Total Price', money(h.total_price)],
    ['Passengers', h.number_of_passengers || '—'],
    ['Departure', day(h.departure_date)],
    ['Return', day(h.return_date)],
    ['Travellers', data.travellers.length],
    ['Flights', data.flights.length],
    ['Hotels', data.hotels.length],
    ['Visa Applications', data.visa.length],
    ['Transport', data.transport.length],
    ['Ziyarat/Other', data.ziyarat.length],
    ['Suppliers Involved', data.suppliers.length],
    ['Invoices', data.invoices.length],
    ['Outstanding', money(data.outstanding.outstanding), data.outstanding.outstanding > 0 ? 'var(--color-danger)' : undefined],
    ...(canViewProfit ? [
      ['Estimated Profit', money(data.profit.estimated_profit)],
      ['Actual Profit', money(data.profit.actual_profit), data.profit.actual_profit < 0 ? 'var(--color-danger)' : 'var(--color-success)']
    ] : [])
  ];
  return (
    <>
      <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 12 }}>Booking Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13 }}>
          <Info label="Booking Code" value={h.booking_code} />
          <Info label="Type" value={h.booking_type} />
          <Info label="Status" value={h.status} />
          <Info label="Destination" value={h.destination} />
          <Info label="Booking Date" value={day(h.booking_date)} />
          <Info label="Currency" value={h.currency} />
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 12 }}>
        {cards.map(([label, value, color]) => <Stat key={label} label={label} value={value} color={color} />)}
      </div>
    </>
  );
}

function CustomerTab({ h, navigate }) {
  return (
    <div className="card" style={{ padding: '18px 22px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13, marginBottom: 14 }}>
        <Info label="Name" value={h.customer.full_name} />
        <Info label="Phone" value={h.customer.phone} />
        <Info label="WhatsApp" value={h.customer.whatsapp} />
        <Info label="Email" value={h.customer.email} />
      </div>
      <button className="btn btn-secondary btn-sm" onClick={() => navigate(`/customers/${h.customer.id}/360`)}>Open Customer Dossier</button>
    </div>
  );
}

function PackageTab({ h, money }) {
  const s = h.package_snapshot;
  if (!s) return <div className="card" style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>This booking was not created from a package.</div>;
  return (
    <div className="card" style={{ padding: '18px 22px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13, marginBottom: 14 }}>
        <Info label="Package Name" value={s.package_name} />
        <Info label="Type" value={s.package_type} />
        <Info label="Destination" value={s.destination} />
        <Info label="Duration" value={s.duration} />
        <Info label="Package Price (at booking time)" value={money(s.package_price)} />
        <Info label="Currency" value={s.currency} />
      </div>
      <h4 style={{ fontSize: 13, marginBottom: 8 }}>Components (frozen at booking time)</h4>
      <table className="data-table">
        <thead><tr><th>Component</th><th>Description</th><th>Cost</th><th>Selling</th></tr></thead>
        <tbody>
          {(s.components || []).map((c, i) => <tr key={i}><td>{c.component_type}</td><td>{c.description || '—'}</td><td>{money(c.cost)}</td><td>{money(c.selling_price)}</td></tr>)}
        </tbody>
      </table>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 8 }}>This is a frozen snapshot — editing the master package later does not change what was sold here.</p>
    </div>
  );
}

function AdvancesTab({ data, money }) {
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 14 }}>
        <Stat label="Advance Received" value={money(data.received)} />
        <Stat label="Advance Used" value={money(data.used)} />
        <Stat label="Remaining Advance" value={money(data.remaining)} />
      </div>
      <Card><T cols={['Date', 'Amount', 'Method', 'Reference']} rows={data.rows} empty="No advances recorded for this booking." render={(r) => (<>
        <td>{day(r.payment_date)}</td><td>{money(r.amount)}</td><td>{r.payment_method}</td><td>{r.reference || '—'}</td></>)} /></Card>
    </div>
  );
}

function OutstandingTab({ data, money }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
      <Stat label="Selling Price" value={money(data.selling)} />
      <Stat label="Paid (net of refunds)" value={money(data.paid)} />
      <Stat label="Outstanding" value={money(data.outstanding)} color={data.outstanding > 0 ? 'var(--color-danger)' : 'var(--color-success)'} />
    </div>
  );
}

function SupplierCostsTab({ data, money }) {
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 14 }}>
        <Stat label="Total Invoiced" value={money(data.invoiced)} />
        <Stat label="Total Paid" value={money(data.paid)} />
        <Stat label="Payable" value={money(data.payable)} color={data.payable > 0 ? 'var(--color-danger)' : 'var(--color-success)'} />
      </div>
      <h4 style={{ fontSize: 13, margin: '4px 0 8px' }}>Supplier Invoices</h4>
      <Card style={{ marginBottom: 14 }}><T cols={['Supplier', 'Invoice #', 'Date', 'Total', 'Paid', 'Remaining', 'Status']} rows={data.invoices} empty="No supplier invoices for this booking." render={(i) => (<>
        <td>{i.supplier_name}</td><td>{i.invoice_number}</td><td>{day(i.invoice_date)}</td><td>{money(i.total)}</td><td>{money(i.paid_amount)}</td><td>{money(i.remaining_amount)}</td><td>{i.status}</td></>)} /></Card>
      <h4 style={{ fontSize: 13, margin: '4px 0 8px' }}>Supplier Payments</h4>
      <Card><T cols={['Supplier', 'Date', 'Amount', 'Method', 'Reference']} rows={data.payments} empty="No supplier payments for this booking." render={(p) => (<>
        <td>{p.supplier_name}</td><td>{day(p.payment_date)}</td><td>{money(p.amount)}</td><td>{p.payment_method}</td><td>{p.reference || '—'}</td></>)} /></Card>
    </div>
  );
}

function ProfitTab({ p, money }) {
  return (
    <div className="card" style={{ padding: '18px 22px' }}>
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 12 }}>
        Estimated compares the sold price to booking-service costs. Actual uses real invoiced revenue, real supplier invoices (or estimate if none exist yet) and any expenses tagged to this booking. Never mixed.
      </p>
      <table className="data-table">
        <tbody>
          <tr><td colSpan={2}><strong>Estimated</strong></td></tr>
          <tr><td>Revenue</td><td style={{ textAlign: 'right' }}>{money(p.estimated_revenue)}</td></tr>
          <tr><td>Cost</td><td style={{ textAlign: 'right' }}>{money(p.estimated_cost)}</td></tr>
          <tr><td><strong>Profit</strong></td><td style={{ textAlign: 'right', fontWeight: 600 }}>{money(p.estimated_profit)}</td></tr>
          <tr><td colSpan={2} style={{ paddingTop: 16 }}><strong>Actual</strong></td></tr>
          <tr><td>Revenue (invoiced)</td><td style={{ textAlign: 'right' }}>{money(p.actual_revenue)}</td></tr>
          <tr><td>Supplier Cost</td><td style={{ textAlign: 'right' }}>{money(p.actual_supplier_cost)}</td></tr>
          <tr><td>Expenses</td><td style={{ textAlign: 'right' }}>{money(p.expenses)}</td></tr>
          <tr><td><strong>Profit</strong></td><td style={{ textAlign: 'right', fontWeight: 700 }}>{money(p.actual_profit)}</td></tr>
          <tr><td>Margin</td><td style={{ textAlign: 'right' }}>{p.margin_percent === null ? '—' : `${p.margin_percent}%`}</td></tr>
        </tbody>
      </table>
    </div>
  );
}

function VouchersTab({ bookingId }) {
  const { data: av, error: loadError, retry } = useIpcData(() => window.api.vouchers.available(bookingId), [bookingId]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function act(fn) { setBusy(true); setError(''); const r = await fn(); setBusy(false); if (!r.ok) setError(r.error); }

  if (loadError) return <ErrorRetry error={`Could not load vouchers: ${loadError}`} onRetry={retry} />;
  if (!av) return <div className="card" style={{ padding: 24 }}>Loading…</div>;
  return (
    <div>
      {error && <div className="login-error">{error}</div>}
      <h4 style={{ fontSize: 13, marginBottom: 8 }}>Hotel Vouchers</h4>
      <Card style={{ marginBottom: 16 }}>
        <T cols={['Hotel', 'Check-in', 'Check-out', 'Actions']} rows={av.hotels} empty="No hotels on this booking yet." render={(h) => (<>
          <td>{h.hotel_name}</td><td>{day(h.check_in)}</td><td>{day(h.check_out)}</td>
          <td style={{ whiteSpace: 'nowrap' }}>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.vouchers.hotelPrint(bookingId, h.id))}><Printer size={13} /> Print</button>{' '}
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.vouchers.hotelPdf(bookingId, h.id))}><FileDown size={13} /> Save PDF</button>
          </td></>)} />
      </Card>
      <h4 style={{ fontSize: 13, marginBottom: 8 }}>Transport Vouchers</h4>
      <Card>
        <T cols={['Route', 'Pickup Date', 'Actions']} rows={av.transport} empty="No transport on this booking yet." render={(t) => (<>
          <td>{[t.pickup_location, t.drop_location].filter(Boolean).join(' → ') || '—'}</td><td>{day(t.pickup_date)}</td>
          <td style={{ whiteSpace: 'nowrap' }}>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.vouchers.transportPrint(bookingId, t.id))}><Printer size={13} /> Print</button>{' '}
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => act(() => window.api.vouchers.transportPdf(bookingId, t.id))}><FileDown size={13} /> Save PDF</button>
          </td></>)} />
      </Card>
    </div>
  );
}

function Restricted({ text }) {
  return (
    <div className="card" style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 10, color: 'var(--color-text-muted)' }}>
      <Lock size={14} /> {text} are restricted for your role.
    </div>
  );
}

function NotesTab({ h }) {
  return (
    <div className="card" style={{ padding: '18px 22px' }}>
      {h.notes ? <p style={{ fontSize: 13, whiteSpace: 'pre-wrap' }}>{h.notes}</p> : <p style={{ color: 'var(--color-text-muted)' }}>No notes recorded for this booking. Edit the booking to add notes.</p>}
    </div>
  );
}
