import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const TYPE_COLOR = {
  FlightDeparture: '#2563eb', FlightArrival: '#0ea5e9', HotelCheckIn: '#16a34a', HotelCheckOut: '#65a30d',
  VisaDeadline: '#dc2626', PaymentDeadline: '#d97706', SupplierPaymentDeadline: '#b45309', BookingDeadline: '#7c3aed',
  CustomerFollowUp: '#0891b2', StaffTask: '#4b5563', TravelDate: '#111827'
};

function pad(n) { return String(n).padStart(2, '0'); }
function toISO(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }

export default function TravelCalendar() {
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(new Date());
  const [view, setView] = useState('month');
  const [eventType, setEventType] = useState('All');
  const [types, setTypes] = useState([]);
  const [events, setEvents] = useState([]);
  const pg = usePagination(events, 25);
  const [error, setError] = useState('');

  useEffect(() => { window.api.calendar.eventTypes().then((res) => res.ok && setTypes(res.data)); }, []);

  useEffect(() => {
    const from = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const to = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    window.api.calendar.list({ from: toISO(from), to: toISO(to), eventType }).then((res) => {
      if (res.ok) setEvents(res.data); else setError(res.error);
    });
  }, [cursor, eventType]);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const eventsByDay = {};
  events.forEach((e) => {
    const day = e.date?.slice(0, 10);
    if (!eventsByDay[day]) eventsByDay[day] = [];
    eventsByDay[day].push(e);
  });

  function openEvent(e) {
    if (e.bookingId) navigate('/bookings');
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Travel Calendar</h1>
          <p>Flights, hotels, deadlines, follow-ups, tasks, and travel dates — all in one view</p>
        </div>
      </div>

      <div className="customers-toolbar">
        <button className="icon-btn" onClick={() => setCursor(new Date(year, month - 1, 1))}><ChevronLeft size={16} /></button>
        <strong style={{ minWidth: 140, textAlign: 'center' }}>{cursor.toLocaleString('en-US', { month: 'long', year: 'numeric' })}</strong>
        <button className="icon-btn" onClick={() => setCursor(new Date(year, month + 1, 1))}><ChevronRight size={16} /></button>
        <button className="btn btn-sm btn-secondary" onClick={() => setCursor(new Date())}>Today</button>
        <select className="field-input" style={{ width: 190 }} value={eventType} onChange={(e) => setEventType(e.target.value)}>
          <option value="All">All event types</option>
          {types.map((t) => <option key={t}>{t}</option>)}
        </select>
        <button className={`btn btn-sm ${view === 'month' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setView('month')}>Month</button>
        <button className={`btn btn-sm ${view === 'agenda' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setView('agenda')}>Agenda</button>
      </div>

      {error && <div className="login-error">{error}</div>}

      {view === 'month' && (
        <div className="card" style={{ padding: 12 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginBottom: 4 }}>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
              <div key={d} style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-text-muted)', textAlign: 'center', padding: 4 }}>{d}</div>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
            {cells.map((d, idx) => {
              const iso = d ? `${year}-${pad(month + 1)}-${pad(d)}` : null;
              const dayEvents = iso ? (eventsByDay[iso] || []) : [];
              return (
                <div key={idx} style={{ minHeight: 76, border: '1px solid var(--color-border)', borderRadius: 6, padding: 5, background: d ? 'var(--color-surface)' : 'transparent' }}>
                  {d && <div style={{ fontSize: 11, color: 'var(--color-text-faint)', marginBottom: 3 }}>{d}</div>}
                  {dayEvents.slice(0, 3).map((e) => (
                    <div
                      key={e.id}
                      onClick={() => openEvent(e)}
                      title={e.title}
                      style={{ fontSize: 9.5, padding: '1.5px 4px', borderRadius: 3, marginBottom: 2, color: '#fff', background: TYPE_COLOR[e.type] || '#6b7280', cursor: e.bookingId ? 'pointer' : 'default', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                    >
                      {e.title}
                    </div>
                  ))}
                  {dayEvents.length > 3 && <div style={{ fontSize: 9, color: 'var(--color-text-faint)' }}>+{dayEvents.length - 3} more</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {view === 'agenda' && (
        <div className="card" style={{ padding: 0 }}>
          <table className="data-table">
            <thead><tr><th>Date</th><th>Type</th><th>Event</th><th>Booking</th><th>Customer</th></tr></thead>
            <tbody>
              {pg.pageRows.map((e) => (
                <tr key={e.id} onClick={() => openEvent(e)} style={{ cursor: e.bookingId ? 'pointer' : 'default' }}>
                  <td>{e.date}</td>
                  <td><span className="status-pill on" style={{ background: TYPE_COLOR[e.type], color: '#fff' }}>{e.type}</span></td>
                  <td>{e.title}</td>
                  <td>{e.bookingCode || '—'}</td>
                  <td>{e.customerName || '—'}</td>
                </tr>
              ))}
              {events.length === 0 && <tr><td colSpan={5} className="empty-row">No events this month.</td></tr>}
            </tbody>
          </table>
        <Pagination {...pg.pagerProps} label="events" />
        </div>
      )}
    </div>
  );
}
