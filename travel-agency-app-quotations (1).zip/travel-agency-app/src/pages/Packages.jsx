import PackageManager from '../components/PackageManager.jsx';

export default function Packages() {
  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Packages</h1>
          <p>One central Umrah / Hajj / Tour / Custom package catalogue, connected straight to Bookings.</p>
        </div>
      </div>
      <PackageManager />
    </div>
  );
}
