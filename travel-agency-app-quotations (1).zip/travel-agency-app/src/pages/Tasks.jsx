import { useEffect, useState, useCallback } from 'react';
import { Plus, Check, X as XIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['All', 'Pending', 'In Progress', 'Overdue', 'Completed', 'Cancelled'];
const pillTone = (s) => (s === 'Overdue' || s === 'Cancelled' ? 'off' : 'on');

export default function Tasks() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.tasks.list({ search, status, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function setDone(row, newStatus) {
    const res = await window.api.tasks.markStatus(row.id, newStatus);
    if (!res.ok) setError(res.error); else { flash(`Task marked ${newStatus}.`); load(); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Tasks</h1>
          <p>{total.toLocaleString()} task{total === 1 ? '' : 's'}</p>
        </div>
        {can('tasks', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Add Task</button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <input placeholder="Search title, customer, booking..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Title</th><th>Linked To</th><th>Assigned</th><th>Due Date</th><th>Priority</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>{t.title}</td>
                <td>{t.customer_name || t.booking_code || '—'}</td>
                <td>{t.agent_name || '—'}</td>
                <td>{t.due_date || '—'}</td>
                <td>{t.priority}</td>
                <td><span className={`status-pill ${pillTone(t.effective_status)}`}>{t.effective_status}</span></td>
                <td className="row-actions">
                  {!['Completed', 'Cancelled'].includes(t.effective_status) && can('tasks', 'edit') && (
                    <>
                      <button className="icon-btn" title="Mark Completed" onClick={() => setDone(t, 'Completed')}><Check size={14} /></button>
                      <button className="icon-btn" title="Cancel" onClick={() => setDone(t, 'Cancelled')}><XIcon size={14} /></button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No tasks found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <TaskFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}
    </div>
  );
}

const EMPTY = { title: '', description: '', customer_id: '', customer_label: '', priority: 'Medium', due_date: '' };

function TaskFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [priorities, setPriorities] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.tasks.priorities().then((res) => res.ok && setPriorities(res.data)); }, []);
  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.title.trim()) return setError('Task title is required.');
    setSaving(true);
    const res = await window.api.tasks.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Task added.');
  }

  return (
    <Modal title="Add Task" onClose={onClose} width={480}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Title *" full><input className="field-input" value={form.title} onChange={(e) => set('title', e.target.value)} /></Field>
          <Field label="Customer (optional)" full>
            <CustomerSearchSelect value={form.customer_id} valueLabel={form.customer_label} onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))} />
          </Field>
          <Field label="Due Date"><input type="date" className="field-input" value={form.due_date} onChange={(e) => set('due_date', e.target.value)} /></Field>
          <Field label="Priority">
            <select className="field-input" value={form.priority} onChange={(e) => set('priority', e.target.value)}>
              {priorities.map((p) => <option key={p}>{p}</option>)}
            </select>
          </Field>
          <Field label="Description" full><textarea className="field-input" rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Add Task'}</button>
        </div>
      </form>
    </Modal>
  );
}
