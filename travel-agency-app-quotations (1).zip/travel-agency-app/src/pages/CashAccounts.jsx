import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, ArrowDownCircle, ArrowUpCircle, ArrowLeftRight, History } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { AccountFormModal, TransactionModal, HistoryModal } from './BankAccounts.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function CashAccounts() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [txnModal, setTxnModal] = useState(null);
  const [historyId, setHistoryId] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.cashAccounts.list({ includeInactive: true });
    if (res.ok) setRows(res.data); else setError(res.error);
  }, []);
  useEffect(() => { load(); }, [load]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Cash Accounts</h1>
          <p>{rows.length.toLocaleString()} account{rows.length === 1 ? '' : 's'}</p>
        </div>
        {can('cash_accounts', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}><Plus size={15} /> Add Cash Account</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Account</th><th>Currency</th><th>Current Balance</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {pg.pageRows.map((a) => (
              <tr key={a.id}>
                <td>{a.account_name}</td>
                <td>{a.currency}</td>
                <td style={{ fontWeight: 600 }}>{money(a.current_balance)}</td>
                <td><span className={`status-pill ${a.status === 'Active' ? 'on' : 'off'}`}>{a.status}</span></td>
                <td className="row-actions">
                  {can('cash_accounts', 'edit') && (
                    <>
                      <button className="icon-btn" title="Cash Received" onClick={() => setTxnModal({ mode: 'deposit', account: a })}><ArrowDownCircle size={14} /></button>
                      <button className="icon-btn" title="Cash Paid" onClick={() => setTxnModal({ mode: 'withdraw', account: a })}><ArrowUpCircle size={14} /></button>
                      <button className="icon-btn" title="Transfer" onClick={() => setTxnModal({ mode: 'transfer', account: a })}><ArrowLeftRight size={14} /></button>
                      <button className="icon-btn" title="History" onClick={() => setHistoryId(a.id)}><History size={14} /></button>
                      <button className="icon-btn" title="Edit" onClick={() => { setEditingId(a.id); setFormOpen(true); }}><Pencil size={14} /></button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="empty-row">No cash accounts yet.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="accounts" />
      </div>

      {formOpen && (
        <AccountFormModal type="Cash" accountId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}
      {txnModal && (
        <TransactionModal type="Cash" mode={txnModal.mode} account={txnModal.account} onClose={() => setTxnModal(null)} onDone={(msg) => { setTxnModal(null); flash(msg); load(); }} />
      )}
      {historyId && (
        <HistoryModal type="Cash" accountId={historyId} onClose={() => setHistoryId(null)} />
      )}
    </div>
  );
}
