import { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { UserPlus, Search, Eye, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import CustomerFormModal from '../components/CustomerFormModal.jsx';
import './customers.css';

const PAGE_SIZE = 15;

export default function Customers() {
  const { can } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Arriving from Dashboard's "New Customer" quick action.
  useEffect(() => {
    if (location.state?.openAdd) {
      setEditingId(null);
      setFormOpen(true);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  const load = useCallback(async () => {
    const res = await window.api.customers.list({ search, status, page, pageSize: PAGE_SIZE });
    if (res.ok) {
      setRows(res.data.rows);
      setTotal(res.data.total);
    } else {
      setError(res.error);
    }
  }, [search, status, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function flash(msg) {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3000);
  }

  async function confirmDelete() {
    const res = await window.api.customers.delete(deleteTarget.id);
    if (!res.ok) {
      setError(res.error);
    } else {
      flash(`${deleteTarget.full_name} deleted.`);
      load();
    }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Customers</h1>
          <p>{total.toLocaleString()} total customer{total === 1 ? '' : 's'}</p>
        </div>
        {can('customers', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <UserPlus size={15} /> Add Customer
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <Search size={15} />
          <input
            placeholder="Search name, CNIC, passport, phone, email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select className="field-input" style={{ width: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All statuses</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th><th>CNIC</th><th>Passport #</th><th>Phone</th><th>Nationality</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id}>
                <td>
                  <button className="link-cell" onClick={() => navigate(`/customers/${c.id}/360`)}>{c.full_name}</button>
                </td>
                <td>{c.cnic || '—'}</td>
                <td>{c.passport_number || '—'}</td>
                <td>{c.phone || c.whatsapp || '—'}</td>
                <td>{c.nationality || '—'}</td>
                <td><span className={`status-pill ${c.status === 'Active' ? 'on' : 'off'}`}>{c.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="Open Complete Travel Dossier" onClick={() => navigate(`/customers/${c.id}/360`)}><Eye size={14} /></button>
                  {can('customers', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(c.id); setFormOpen(true); }}>
                      <Pencil size={14} />
                    </button>
                  )}
                  {can('customers', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(c)}>
                      <Trash2 size={14} />
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={7} className="empty-row">No customers found.</td></tr>
            )}
          </tbody>
        </table>

        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <CustomerFormModal
          customerId={editingId}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }}
        />
      )}

      {deleteTarget && (
        <div className="modal-backdrop" onClick={() => setDeleteTarget(null)}>
          <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header"><strong>Delete customer</strong></div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                Delete <strong>{deleteTarget.full_name}</strong>? This can't be undone.
              </p>
              <div className="modal-actions">
                <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
                <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
