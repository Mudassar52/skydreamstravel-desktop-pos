import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Upload, Search, ExternalLink, Download, Pencil, Trash2, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 20;

const FILTER_TYPES = ['All', 'CNIC', 'Passport', 'Visa', 'Flight Ticket', 'Hotel Voucher', 'Payment Receipt', 'Other'];

export default function Documents() {
  const { can } = useAuth();
  const location = useLocation();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [documentType, setDocumentType] = useState(location.state?.presetType || 'All');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [renameTarget, setRenameTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.documents.list({ search, documentType, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }
  useEffect(() => { reload(); }, [search, documentType, page]);
  useEffect(() => { setPage(1); }, [search, documentType]);
  // A sidebar entry like "Hotel Vouchers" links to this same route with a
  // different navState - re-apply it whenever it changes (same-path
  // navigations don't remount the page, so the initial useState alone misses this).
  useEffect(() => {
    if (location.state?.presetType) setDocumentType(location.state.presetType);
  }, [location.state]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3500); }

  async function handleOpen(id) {
    const res = await window.api.documents.open(id);
    if (!res.ok) setError(res.error);
  }

  async function handleDownload(id) {
    const res = await window.api.documents.downloadAs(id);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) flash(`Saved to ${res.data.filePath}`);
  }

  async function confirmDelete() {
    const res = await window.api.documents.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Document deleted.'); reload(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Documents</h1>
          <p>{total.toLocaleString()} document{total === 1 ? '' : 's'} — CNIC, passports, visas, tickets, vouchers and receipts, attached to customers or bookings.</p>
        </div>
        {can('documents', 'create') && (
          <button className="btn btn-primary" onClick={() => setUploadOpen(true)}><Upload size={15} /> Upload Document</button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <Search size={15} />
          <input placeholder="Search by file name or type..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 170 }} value={documentType} onChange={(e) => setDocumentType(e.target.value)}>
          {FILTER_TYPES.map((t) => <option key={t} value={t}>{t === 'All' ? 'All Types' : t}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>File</th><th>Type</th><th>Attached To</th><th>Uploaded</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((d) => (
              <tr key={d.id}>
                <td style={{ display: 'flex', alignItems: 'center', gap: 8 }}><FileText size={14} color="var(--color-text-faint)" /> {d.file_name}</td>
                <td><span className="role-badge">{d.document_type}</span></td>
                <td>{d.customer_name || d.booking_code || '—'}</td>
                <td>{d.uploaded_at?.slice(0, 10)}</td>
                <td className="row-actions">
                  <button className="icon-btn" title="Open" onClick={() => handleOpen(d.id)}><ExternalLink size={14} /></button>
                  <button className="icon-btn" title="Download / Save As" onClick={() => handleDownload(d.id)}><Download size={14} /></button>
                  {can('documents', 'edit') && (
                    <button className="icon-btn" title="Rename" onClick={() => setRenameTarget(d)}><Pencil size={14} /></button>
                  )}
                  {can('documents', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(d)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="empty-row">No documents uploaded yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {uploadOpen && (
        <UploadModal onClose={() => setUploadOpen(false)} onDone={(msg) => { setUploadOpen(false); flash(msg); reload(); }} />
      )}

      {renameTarget && (
        <RenameModal doc={renameTarget} onClose={() => setRenameTarget(null)} onDone={(msg) => { setRenameTarget(null); flash(msg); reload(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete document" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.file_name}</strong>? The file will be removed from storage too.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const DOC_TYPES = ['CNIC', 'Passport', 'Visa', 'Flight Ticket', 'Hotel Voucher', 'Payment Receipt', 'Other'];

function UploadModal({ onClose, onDone }) {
  const [customerId, setCustomerId] = useState('');
  const [customerLabel, setCustomerLabel] = useState('');
  const [bookingId, setBookingId] = useState('');
  const [bookingOptions, setBookingOptions] = useState([]);
  const [documentType, setDocumentType] = useState('CNIC');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => { window.api.bookings.options().then((res) => { if (res.ok) setBookingOptions(res.data); }); }, []);

  async function handleUpload() {
    if (!customerId && !bookingId) return setError('Attach this document to a customer or a booking.');
    setUploading(true);
    setError('');
    const res = await window.api.documents.upload({
      customerId: customerId || null,
      bookingId: bookingId || null,
      documentType,
      notes
    });
    setUploading(false);
    if (!res.ok) return setError(res.error);
    if (res.data.uploaded.length === 0) return; // dialog was cancelled
    onDone(`${res.data.uploaded.length} file${res.data.uploaded.length === 1 ? '' : 's'} uploaded.`);
  }

  return (
    <Modal title="Upload Document" onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <div className="form-grid">
        <Field label="Customer" full>
          <CustomerSearchSelect value={customerId} valueLabel={customerLabel} onChange={(id, label) => { setCustomerId(id); setCustomerLabel(label); }} />
        </Field>
        <Field label="Or attach to a Booking" full>
          <select className="field-input" value={bookingId} onChange={(e) => setBookingId(e.target.value ? Number(e.target.value) : '')}>
            <option value="">— None —</option>
            {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
          </select>
        </Field>
        <Field label="Document Type">
          <select className="field-input" value={documentType} onChange={(e) => setDocumentType(e.target.value)}>
            {DOC_TYPES.map((t) => <option key={t}>{t}</option>)}
          </select>
        </Field>
        <Field label="Notes"><input className="field-input" value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginTop: 6 }}>
        Clicking upload opens your file browser — you can select more than one file at a time.
      </p>
      <div className="modal-actions">
        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button type="button" className="btn btn-primary" disabled={uploading} onClick={handleUpload}>
          <Upload size={14} /> {uploading ? 'Uploading…' : 'Choose File(s) & Upload'}
        </button>
      </div>
    </Modal>
  );
}

function RenameModal({ doc, onClose, onDone }) {
  const [name, setName] = useState(doc.file_name);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = await window.api.documents.rename(doc.id, name);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onDone('Document renamed.');
  }

  return (
    <Modal title="Rename Document" onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <Field label="File Name"><input className="field-input" value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Rename'}</button>
        </div>
      </form>
    </Modal>
  );
}
