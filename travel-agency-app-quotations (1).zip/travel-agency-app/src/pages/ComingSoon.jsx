import { Construction } from 'lucide-react';

export default function ComingSoon({ label, phase }) {
  return (
    <div>
      <div className="page-header">
        <div>
          <h1>{label}</h1>
          <p>Planned for Phase {phase} of the build.</p>
        </div>
      </div>
      <div className="card" style={{ padding: '48px 32px', textAlign: 'center' }}>
        <Construction size={30} color="var(--color-text-faint)" />
        <h3 style={{ marginTop: 14, color: 'var(--color-text)' }}>Not built yet</h3>
        <p style={{ color: 'var(--color-text-muted)', fontSize: 13, marginTop: 6 }}>
          This module is scheduled for Phase {phase} of the development plan and hasn't been
          implemented yet. It'll appear here, fully working and wired to the database, once that
          phase is built.
        </p>
      </div>
    </div>
  );
}
