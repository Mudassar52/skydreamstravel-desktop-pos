import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, TrendingUp, Wallet, X } from 'lucide-react';
import Pagination from '../components/Pagination.jsx';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';
import '../components/statcard.css';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];
const EMPTY = { expense_date: new Date().toISOString().slice(0, 10), category_id: '', description: '', amount: '', payment_method: 'Cash', related_booking_id: '', notes: '' };

export default function Expenses() {
  const [tab, setTab] = useState('expenses');
  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Expenses</h1>
          <p>Business costs, kept separate from sales so profit stays accurate.</p>
        </div>
      </div>
      <div className="tabs">
        <button className={tab === 'expenses' ? 'tab active' : 'tab'} onClick={() => setTab('expenses')}>Expenses</button>
        <button className={tab === 'profit' ? 'tab active' : 'tab'} onClick={() => setTab('profit')}>Profit Overview</button>
      </div>
      {tab === 'expenses' ? <ExpensesTab /> : <ProfitTab />}
    </div>
  );
}

function ExpensesTab() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [count, setCount] = useState(0);
  const [sumAmount, setSumAmount] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [categories, setCategories] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const [e, c] = await Promise.all([window.api.expenses.list({ page, pageSize }), window.api.expenses.categories.list()]);
    if (e.ok && e.data.rows.length === 0 && page > 1) { setPage(page - 1); return; }
    if (e.ok) { setRows(e.data.rows); setCount(e.data.total); setSumAmount(e.data.totalAmount || 0); }
    if (c.ok) setCategories(c.data);
  }
  useEffect(() => { reload(); }, [page, pageSize]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.expenses.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Expense deleted.'); reload(); }
    setDeleteTarget(null);
  }


  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <div className="card" style={{ padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <Wallet size={16} color="var(--color-primary)" />
          <span style={{ fontSize: 13 }}>Total (all {count.toLocaleString()} expenses): <strong>{money(sumAmount)}</strong></span>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-secondary" onClick={() => setCategoryModalOpen(true)}>Manage Categories</button>
          {can('expenses', 'create') && (
            <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
              <Plus size={15} /> New Expense
            </button>
          )}
        </div>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead><tr><th>Date</th><th>Category</th><th>Description</th><th>Booking</th><th>Amount</th><th></th></tr></thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id}>
                <td>{e.expense_date}</td>
                <td><span className="role-badge">{e.category_name || '—'}</span></td>
                <td>{e.description || '—'}</td>
                <td>{e.booking_code || '—'}</td>
                <td>{money(e.amount)}</td>
                <td className="row-actions">
                  {can('expenses', 'edit') && <button className="icon-btn" onClick={() => { setEditingId(e.id); setFormOpen(true); }}><Pencil size={14} /></button>}
                  {can('expenses', 'delete') && <button className="icon-btn" onClick={() => setDeleteTarget(e)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No expenses recorded yet.</td></tr>}
          </tbody>
        </table>
        <Pagination page={page} pageSize={pageSize} total={count} onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} label="expenses" />
      </div>

      {formOpen && (
        <ExpenseFormModal expenseId={editingId} categories={categories} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }} />
      )}

      {categoryModalOpen && (
        <CategoryManagerModal categories={categories} onClose={() => setCategoryModalOpen(false)} onChanged={reload} />
      )}

      {deleteTarget && (
        <Modal title="Delete expense" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete this expense of <strong>{money(deleteTarget.amount)}</strong>?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function ExpenseFormModal({ expenseId, categories, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [bookingOptions, setBookingOptions] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.bookings.options().then((res) => { if (res.ok) setBookingOptions(res.data); });
    if (expenseId) window.api.expenses.get(expenseId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
    else if (categories[0]) setForm((f) => ({ ...f, category_id: categories[0].id }));
  }, [expenseId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.category_id) return setError('Please select a category.');
    if (!(Number(form.amount) > 0)) return setError('Amount must be greater than zero.');
    setSaving(true);
    const res = expenseId ? await window.api.expenses.update(expenseId, form) : await window.api.expenses.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(expenseId ? 'Expense updated.' : 'Expense added.');
  }

  return (
    <Modal title={expenseId ? 'Edit Expense' : 'New Expense'} onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Date"><input type="date" className="field-input" value={form.expense_date} onChange={(e) => set('expense_date', e.target.value)} /></Field>
          <Field label="Category">
            <select className="field-input" value={form.category_id} onChange={(e) => set('category_id', Number(e.target.value))}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Amount (Rs.)"><input type="number" className="field-input" value={form.amount} onChange={(e) => set('amount', e.target.value)} /></Field>
          <Field label="Payment Method">
            <select className="field-input" value={form.payment_method} onChange={(e) => set('payment_method', e.target.value)}>
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
          </Field>
          <Field label="Related Booking (optional)" full>
            <select className="field-input" value={form.related_booking_id || ''} onChange={(e) => set('related_booking_id', e.target.value ? Number(e.target.value) : '')}>
              <option value="">— Not linked to a booking —</option>
              {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
            </select>
          </Field>
          <Field label="Description" full><input className="field-input" value={form.description || ''} onChange={(e) => set('description', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Expense'}</button>
        </div>
      </form>
    </Modal>
  );
}

function CategoryManagerModal({ categories, onClose, onChanged }) {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  async function add(e) {
    e.preventDefault();
    const res = await window.api.expenses.categories.create(name);
    if (!res.ok) return setError(res.error);
    setName('');
    onChanged();
  }

  async function remove(id) {
    const res = await window.api.expenses.categories.delete(id);
    if (!res.ok) setError(res.error); else onChanged();
  }

  return (
    <Modal title="Manage Expense Categories" onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={add} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input className="field-input" placeholder="New category name" value={name} onChange={(e) => setName(e.target.value)} style={{ flex: 1 }} />
        <button className="btn btn-primary btn-sm" type="submit"><Plus size={13} /> Add</button>
      </form>
      {categories.map((c) => (
        <div className="info-row" key={c.id}>
          <span>{c.name}</span>
          <button className="icon-btn" onClick={() => remove(c.id)}><X size={13} /></button>
        </div>
      ))}
    </Modal>
  );
}

// ---------------------------------------------------------------------
function ProfitTab() {
  const [summary, setSummary] = useState(null);
  const [monthly, setMonthly] = useState([]);
  const [byType, setByType] = useState([]);

  useEffect(() => {
    window.api.profit.getSummary().then((res) => { if (res.ok) setSummary(res.data); });
    window.api.profit.getMonthly(6).then((res) => { if (res.ok) setMonthly(res.data); });
    window.api.profit.getByBookingType().then((res) => { if (res.ok) setByType(res.data); });
  }, []);

  if (!summary) return null;

  return (
    <div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', marginBottom: 20 }}>
        <MiniStat icon={TrendingUp} label="Revenue (Sales)" value={money(summary.revenue)} tone="primary" />
        <MiniStat icon={Wallet} label="Expenses" value={money(summary.expenses)} tone="warning" />
        <MiniStat icon={TrendingUp} label="Profit" value={money(summary.profit)} tone={summary.profit >= 0 ? 'success' : 'danger'} />
      </div>

      <div className="card" style={{ padding: '20px 24px', marginBottom: 20 }}>
        <h3 style={{ fontSize: 14, marginBottom: 16 }}>Revenue vs Expenses vs Profit (last 6 months)</h3>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={monthly}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E4E9F2" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#5B6B8C' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: '#8B97B3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
            <Tooltip formatter={(v) => money(v)} />
            <Legend />
            <Bar dataKey="revenue" name="Revenue" fill="#1E4FA3" radius={[4, 4, 0, 0]} />
            <Bar dataKey="expenses" name="Expenses" fill="#C23B3B" radius={[4, 4, 0, 0]} />
            <Bar dataKey="profit" name="Profit" fill="#1B8A5A" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead><tr><th>Type</th><th>Revenue</th><th>Expenses</th><th>Profit</th></tr></thead>
          <tbody>
            {byType.map((t) => (
              <tr key={t.type}>
                <td>{t.type}</td>
                <td>{money(t.revenue)}</td>
                <td>{money(t.expenses)}</td>
                <td style={{ color: t.profit >= 0 ? 'var(--color-success)' : 'var(--color-danger)', fontWeight: 600 }}>{money(t.profit)}</td>
              </tr>
            ))}
            {byType.length === 0 && <tr><td colSpan={4} className="empty-row">No revenue or expenses recorded yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginTop: 10 }}>
        A full filterable Profit Report (by customer, by individual booking, custom date ranges) arrives with Phase 12 — Reports.
      </p>
    </div>
  );
}

function MiniStat({ icon: Icon, label, value, tone }) {
  return (
    <div className="card stat-card">
      <div className={`stat-icon tone-${tone}`}><Icon size={19} /></div>
      <div className="stat-body">
        <span className="stat-label">{label}</span>
        <strong className="stat-value">{value}</strong>
      </div>
    </div>
  );
}
