import { useEffect, useState, useCallback } from 'react';
import { Truck, Search, Pencil, Trash2, ChevronLeft, ChevronRight, BookUser, FolderOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import '../pages/customers.css';

const PAGE_SIZE = 15;
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Suppliers() {
  const { can } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [serviceType, setServiceType] = useState('All');
  const [serviceTypes, setServiceTypes] = useState([]);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  useEffect(() => { window.api.suppliers.serviceTypes().then((res) => res.ok && setServiceTypes(res.data)); }, []);

  const load = useCallback(async () => {
    const res = await window.api.suppliers.list({ search, serviceType, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, serviceType, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, serviceType]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.suppliers.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${deleteTarget.name} deleted.`); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Suppliers</h1>
          <p>{total.toLocaleString()} supplier{total === 1 ? '' : 's'}</p>
        </div>
        {can('suppliers', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Truck size={15} /> Add Supplier
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <Search size={15} />
          <input placeholder="Search name, code, phone, email..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 180 }} value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
          <option value="All">All service types</option>
          {serviceTypes.map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Code</th><th>Name</th><th>Type</th><th>Contact</th><th>Currency</th><th>Balance</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.id}>
                <td>{s.supplier_code}</td>
                <td><strong>{s.name}</strong>{s.company ? <div style={{ fontSize: 11, color: 'var(--color-text-faint)' }}>{s.company}</div> : null}</td>
                <td>{s.service_type || '—'}</td>
                <td>{s.phone || s.email || '—'}</td>
                <td>{s.currency}</td>
                <td style={{ fontWeight: 600, color: s.current_balance > 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>
                  {money(Math.abs(s.current_balance || 0))} {s.current_balance > 0 ? 'payable' : ''}
                </td>
                <td><span className={`status-pill ${s.status === 'Active' ? 'on' : 'off'}`}>{s.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="Open Supplier Dossier" onClick={() => navigate(`/suppliers/${s.id}/360`)}><FolderOpen size={14} /></button>
                  <button className="icon-btn" title="Ledger" onClick={() => navigate('/supplier-ledger', { state: { supplierId: s.id, supplierLabel: s.name } })}>
                    <BookUser size={14} />
                  </button>
                  {can('suppliers', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(s.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('suppliers', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(s)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="empty-row">No suppliers found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <SupplierFormModal supplierId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete supplier" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.name}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  name: '', company: '', contact_person: '', phone: '', email: '', address: '',
  service_type: 'Airline', currency: 'PKR', payment_terms: '', opening_balance: 0, notes: '', status: 'Active'
};
const CURRENCIES = ['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'];

function SupplierFormModal({ supplierId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [serviceTypes, setServiceTypes] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.suppliers.serviceTypes().then((res) => res.ok && setServiceTypes(res.data)); }, []);
  useEffect(() => {
    if (!supplierId) return;
    window.api.suppliers.get(supplierId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
  }, [supplierId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = supplierId ? await window.api.suppliers.update(supplierId, form) : await window.api.suppliers.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(supplierId ? 'Supplier updated.' : 'Supplier added.');
  }

  return (
    <Modal title={supplierId ? 'Edit Supplier' : 'Add Supplier'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Supplier Name *" full><input className="field-input" value={form.name} onChange={(e) => set('name', e.target.value)} /></Field>
          <Field label="Company"><input className="field-input" value={form.company || ''} onChange={(e) => set('company', e.target.value)} /></Field>
          <Field label="Contact Person"><input className="field-input" value={form.contact_person || ''} onChange={(e) => set('contact_person', e.target.value)} /></Field>
          <Field label="Phone"><input className="field-input" value={form.phone || ''} onChange={(e) => set('phone', e.target.value)} /></Field>
          <Field label="Email"><input className="field-input" value={form.email || ''} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="Service Type">
            <select className="field-input" value={form.service_type || ''} onChange={(e) => set('service_type', e.target.value)}>
              {serviceTypes.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Payment Terms"><input className="field-input" value={form.payment_terms || ''} onChange={(e) => set('payment_terms', e.target.value)} placeholder="e.g. Net 15" /></Field>
          <Field label="Opening Balance (payable)"><input type="number" className="field-input" value={form.opening_balance} onChange={(e) => set('opening_balance', e.target.value)} disabled={!!supplierId} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              <option>Active</option><option>Inactive</option>
            </select>
          </Field>
          <Field label="Address" full><input className="field-input" value={form.address || ''} onChange={(e) => set('address', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Supplier'}</button>
        </div>
      </form>
    </Modal>
  );
}
