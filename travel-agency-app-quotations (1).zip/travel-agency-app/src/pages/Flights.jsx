import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Users as UsersIcon, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import FlightPassengersDrawer from '../components/FlightPassengersDrawer.jsx';
import './customers.css';

const EMPTY = {
  booking_id: '', airline: '', flight_number: '', pnr: '', departure_airport: '',
  arrival_airport: '', departure_date: '', departure_time: '', arrival_date: '',
  arrival_time: '', class: 'Economy', ticket_number: '', status: 'Confirmed', notes: ''
};
const STATUSES = ['Confirmed', 'Pending', 'Cancelled', 'Completed'];
const PAGE_SIZE = 15;

export default function Flights() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [bookingOptions, setBookingOptions] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [passengersFor, setPassengersFor] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [error, setError] = useState('');

  async function reload() {
    const [f, b] = await Promise.all([window.api.flights.list({ search, page, pageSize: PAGE_SIZE }), window.api.bookings.options()]);
    if (f.ok) { setRows(f.data.rows); setTotal(f.data.total); }
    if (b.ok) setBookingOptions(b.data);
  }
  useEffect(() => { reload(); }, [search, page]);
  useEffect(() => { setPage(1); }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  async function confirmDelete() {
    const res = await window.api.flights.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  const bookingLabel = (id) => bookingOptions.find((b) => b.id === id)?.label || '—';

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Flights</h1>
          <p>{total.toLocaleString()} flight{total === 1 ? '' : 's'}</p>
        </div>
        {can('flights', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Flight
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <Search size={15} />
          <input placeholder="Search flight number, airline, PNR..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Flight</th><th>Route</th><th>Departure</th><th>Booking</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((f) => (
              <tr key={f.id}>
                <td>{f.airline ? `${f.airline} ` : ''}{f.flight_number}</td>
                <td>{[f.departure_airport, f.arrival_airport].filter(Boolean).join(' → ') || '—'}</td>
                <td>{f.departure_date || '—'} {f.departure_time || ''}</td>
                <td>{bookingLabel(f.booking_id)}</td>
                <td><span className={`status-pill ${f.status === 'Confirmed' || f.status === 'Completed' ? 'on' : 'off'}`}>{f.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="Passengers" onClick={() => setPassengersFor(f.id)}><UsersIcon size={14} /></button>
                  {can('flights', 'edit') && <button className="icon-btn" onClick={() => { setEditingId(f.id); setFormOpen(true); }}><Pencil size={14} /></button>}
                  {can('flights', 'delete') && <button className="icon-btn" onClick={() => setDeleteTarget(f)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No flights yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <FlightFormModal flightId={editingId} bookingOptions={bookingOptions} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {passengersFor && (
        <FlightPassengersDrawer
          flight={rows.find((r) => r.id === passengersFor) || { id: passengersFor }}
          onClose={() => setPassengersFor(null)}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete flight" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete flight <strong>{deleteTarget.flight_number}</strong>?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function FlightFormModal({ flightId, bookingOptions, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (flightId) window.api.flights.get(flightId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
  }, [flightId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.flight_number.trim()) return setError('Flight number is required.');
    setSaving(true);
    const res = flightId ? await window.api.flights.update(flightId, form) : await window.api.flights.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={flightId ? 'Edit Flight' : 'New Flight'} onClose={onClose} width={580}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Booking (optional)" full>
            <select className="field-input" value={form.booking_id || ''} onChange={(e) => set('booking_id', e.target.value ? Number(e.target.value) : '')}>
              <option value="">— Not linked to a booking —</option>
              {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
            </select>
          </Field>
          <Field label="Airline"><input className="field-input" value={form.airline || ''} onChange={(e) => set('airline', e.target.value)} /></Field>
          <Field label="Flight Number *"><input className="field-input" value={form.flight_number} onChange={(e) => set('flight_number', e.target.value)} /></Field>
          <Field label="PNR"><input className="field-input" value={form.pnr || ''} onChange={(e) => set('pnr', e.target.value)} /></Field>
          <Field label="Ticket Number"><input className="field-input" value={form.ticket_number || ''} onChange={(e) => set('ticket_number', e.target.value)} /></Field>
          <Field label="Departure Airport"><input className="field-input" value={form.departure_airport || ''} onChange={(e) => set('departure_airport', e.target.value)} /></Field>
          <Field label="Arrival Airport"><input className="field-input" value={form.arrival_airport || ''} onChange={(e) => set('arrival_airport', e.target.value)} /></Field>
          <Field label="Departure Date"><input type="date" className="field-input" value={form.departure_date || ''} onChange={(e) => set('departure_date', e.target.value)} /></Field>
          <Field label="Departure Time"><input type="time" className="field-input" value={form.departure_time || ''} onChange={(e) => set('departure_time', e.target.value)} /></Field>
          <Field label="Arrival Date"><input type="date" className="field-input" value={form.arrival_date || ''} onChange={(e) => set('arrival_date', e.target.value)} /></Field>
          <Field label="Arrival Time"><input type="time" className="field-input" value={form.arrival_time || ''} onChange={(e) => set('arrival_time', e.target.value)} /></Field>
          <Field label="Class">
            <select className="field-input" value={form.class || ''} onChange={(e) => set('class', e.target.value)}>
              <option>Economy</option><option>Business</option><option>First</option>
            </select>
          </Field>
          <Field label="Status">
            <select className="field-input" value={form.status || ''} onChange={(e) => set('status', e.target.value)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Flight'}</button>
        </div>
      </form>
    </Modal>
  );
}
