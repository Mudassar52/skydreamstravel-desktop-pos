import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { RotateCcw, Trash2, Search } from 'lucide-react';
import './customers.css';

// Report History (master prompt section 42): every report generated through
// the Custom Report Builder is logged here with its full spec, so an
// authorized user can reopen/regenerate it against current data.

const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function ReportHistory() {
  const navigate = useNavigate();
  const [reportType, setReportType] = useState('All');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const pageSize = 15;

  const load = useCallback(async () => {
    const res = await window.api.reportHistory.list({ reportType, search, page, pageSize });
    if (res.ok) setData(res.data); else setError(res.error);
  }, [reportType, search, page]);
  useEffect(() => { load(); }, [load]);

  async function remove(id) {
    if (!window.confirm('Delete this report history entry?')) return;
    const res = await window.api.reportHistory.remove(id);
    if (!res.ok) return setError(res.error);
    load();
  }

  async function regenerate(id) {
    const res = await window.api.reportHistory.regenerate(id);
    if (!res.ok) return setError(res.error);
    // Hand the spec back to the builder via session storage and navigate there.
    sessionStorage.setItem('reopenReportSpec', JSON.stringify(res.data.entry.spec));
    navigate('/custom-reports');
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;

  return (
    <div>
      <div className="page-header">
        <div><h1>Report History</h1><p>Every report generated through the Custom Report Builder, with its filters preserved for reopening.</p></div>
      </div>

      <div className="card" style={{ padding: '14px 18px', marginBottom: 16, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <div className="global-search" style={{ width: 240 }}>
          <Search size={14} />
          <input placeholder="Search report name" value={search} onChange={(e) => { setPage(1); setSearch(e.target.value); }} />
        </div>
        <select className="field-input" value={reportType} onChange={(e) => { setPage(1); setReportType(e.target.value); }}>
          <option value="All">All types</option>
          <option value="customer">Customer</option><option value="supplier">Supplier</option><option value="booking">Booking</option>
          <option value="service">Service</option><option value="financial">Financial</option><option value="profitability">Profitability</option>
          <option value="travel_ops">Travel Operations</option><option value="payment">Payment</option><option value="ledger">Ledger</option>
        </select>
      </div>

      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Report Name</th><th>Type</th><th>Date Range</th><th>Format</th><th>Related</th><th>Generated</th><th></th></tr></thead>
          <tbody>
            {!data && <tr><td colSpan={7} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.rows.length === 0 && <tr><td colSpan={7} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No reports generated yet.</td></tr>}
            {data && data.rows.map((r) => (
              <tr key={r.id}>
                <td><strong>{r.report_name}</strong></td>
                <td>{r.report_type}</td>
                <td>{r.date_from || r.date_to ? `${day(r.date_from)} – ${day(r.date_to)}` : 'All dates'}</td>
                <td>{r.generated_format}</td>
                <td>{r.customer_name || r.supplier_name || r.booking_code || '—'}</td>
                <td>{day(r.created_at)}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="icon-btn" title="Reopen / Regenerate" onClick={() => regenerate(r.id)}><RotateCcw size={14} /></button>
                  <button className="icon-btn" title="Delete" onClick={() => remove(r.id)}><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
