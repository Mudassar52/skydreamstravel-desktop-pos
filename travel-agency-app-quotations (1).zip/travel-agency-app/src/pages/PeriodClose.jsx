import { useEffect, useState, useCallback } from 'react';
import { Lock, Unlock, Undo2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const num = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function PeriodClose() {
  const { can } = useAuth();
  const canEdit = can('financial_statements', 'edit');
  const [status, setStatus] = useState(null);
  const pg = usePagination(status?.closes || [], 10);
  const [lockDate, setLockDate] = useState('');
  const [closeDate, setCloseDate] = useState('');
  const [preview, setPreview] = useState(null);
  const [confirm, setConfirm] = useState(null); // 'close' | 'undo'
  const [notes, setNotes] = useState('');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.periodLock.status();
    if (res.ok) { setStatus(res.data); setError(''); } else setError(res.error);
  }, []);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!closeDate) { setPreview(null); return; }
    window.api.periodLock.preview(closeDate).then((r) => setPreview(r.ok ? r.data : null));
  }, [closeDate]);

  function flash(m) { setNotice(m); setTimeout(() => setNotice(''), 3500); }
  async function run(fn, msg) {
    const res = await fn();
    setConfirm(null);
    if (!res.ok) return setError(res.error);
    setError(''); flash(msg); setCloseDate(''); setNotes(''); load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Period Close</h1>
          <p>Lock finished periods so past figures can't change, and close the year into Retained Earnings.</p>
        </div>
      </div>
      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      {status && (
        <div className="card" style={{ padding: 16, marginBottom: 16 }}>
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>
            {status.locked_through
              ? <><Lock size={14} style={{ verticalAlign: -2 }} /> Books are locked through {status.locked_through}</>
              : <><Unlock size={14} style={{ verticalAlign: -2 }} /> Nothing is locked</>}
          </div>
          <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', margin: 0 }}>
            Invoices, payments, expenses, supplier bills and manual entries dated on or before the lock date can't be added, changed, voided or deleted.
            Fix a mistake in a locked period with a new correcting entry dated today.
          </p>
        </div>
      )}

      {canEdit && status && (
        <div className="card" style={{ padding: 16, marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8 }}>Lock without closing the year</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <input type="date" className="field-input" style={{ width: 170 }} value={lockDate} max={status.today} onChange={(e) => setLockDate(e.target.value)} />
            <button className="btn btn-secondary" disabled={!lockDate} onClick={() => run(() => window.api.periodLock.setManualLock(lockDate), 'Lock date saved.')}>Lock through this date</button>
            {status.manual_lock && <button className="btn btn-secondary" onClick={() => run(() => window.api.periodLock.setManualLock(null), 'Manual lock removed.')}>Remove manual lock ({status.manual_lock})</button>}
          </div>
          <p style={{ fontSize: 12, color: 'var(--color-text-muted)', margin: '8px 0 0' }}>A year-end close always locks too and cannot be lifted by removing the manual lock - undo the close instead.</p>
        </div>
      )}

      {canEdit && status && (
        <div className="card" style={{ padding: 16, marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8 }}>Close the year</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <label className="field-label" style={{ margin: 0 }}>Year ends on</label>
            <input type="date" className="field-input" style={{ width: 170 }} value={closeDate} max={status.today} onChange={(e) => setCloseDate(e.target.value)} />
            <button className="btn btn-primary" disabled={!closeDate} onClick={() => setConfirm('close')}>Close year…</button>
          </div>
          {preview && (
            <p style={{ fontSize: 13, marginTop: 10 }}>
              Profit / (loss) to carry into Retained Earnings: <strong>{preview.base_currency} {num(preview.profit_to_carry_forward)}</strong>
              {!preview.balanced && <span style={{ color: 'var(--color-danger, #B42318)' }}> - the books are out of balance on this date; check the Trial Balance before closing.</span>}
            </p>
          )}
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: '12px 16px', fontWeight: 600, fontSize: 13, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>Year-end closes</span>
          {canEdit && status && status.closes.length > 0 && <button className="btn btn-secondary btn-sm" onClick={() => setConfirm('undo')}><Undo2 size={13} /> Undo latest close</button>}
        </div>
        <table className="data-table">
          <thead><tr><th>Closed through</th><th>Done by</th><th>On</th><th>Notes</th></tr></thead>
          <tbody>
            {status && pg.pageRows.map((c) => <tr key={c.id}><td><strong>{c.close_date}</strong></td><td>{c.created_by_name || '—'}</td><td>{String(c.created_at).slice(0, 16)}</td><td>{c.notes || ''}</td></tr>)}
            {status && status.closes.length === 0 && <tr><td colSpan={4} className="empty-row">No year has been closed yet.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="closes" />
      </div>

      {confirm === 'close' && (
        <Modal title={`Close the year through ${closeDate}?`} onClose={() => setConfirm(null)}>
          <p style={{ fontSize: 13 }}>
            This locks everything dated up to {closeDate} and moves that period's revenue and expenses into Retained Earnings
            {preview ? ` (${preview.base_currency} ${num(preview.profit_to_carry_forward)})` : ''}. You can undo it later, but only the most recent close can be undone.
          </p>
          <input className="field-input" placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setConfirm(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={() => run(() => window.api.periodLock.closeYear({ closeDate, notes }), 'Year closed.')}>Close Year</button>
          </div>
        </Modal>
      )}
      {confirm === 'undo' && status && (
        <Modal title="Undo the latest close?" onClose={() => setConfirm(null)}>
          <p style={{ fontSize: 13 }}>Reopens the period ending {status.closes[0] && status.closes[0].close_date} and removes its closing entry. Records in that period become editable again.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setConfirm(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={() => run(() => window.api.periodLock.reopenLastClose(), 'Close undone.')}>Undo Close</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
