import { useEffect, useState, useCallback } from 'react';
import { FileDown, FileSpreadsheet, Printer, Eye, CheckCircle2, AlertTriangle } from 'lucide-react';
import PreviewPane from '../components/PreviewPane.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const num = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const R = { textAlign: 'right' };

function Warnings({ list }) {
  if (!list || !list.length) return null;
  return <div className="login-error" style={{ marginBottom: 12 }}>{list.map((w, i) => <div key={i}>{w}</div>)}</div>;
}

function ExportBar({ data, name }) {
  const { hasCapability } = useAuth();
  const [msg, setMsg] = useState('');
  const [html, setHtml] = useState(null);
  if (!hasCapability('export_reports') || !data) return null;
  const e = data.export;
  const run = async (fn) => { const r = await fn(); setMsg(r.ok ? (r.data && r.data.saved === false ? '' : 'Done.') : r.error); };
  async function openPreview() {
    const r = await window.api.financialStatements.preview(e);
    if (r.ok) setHtml(r.data); else setMsg(r.error);
  }
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <button className="btn btn-secondary btn-sm" onClick={openPreview}><Eye size={13} /> Preview</button>
      <button className="btn btn-secondary btn-sm" onClick={() => run(() => window.api.financialStatements.exportPdf(e))}><FileDown size={13} /> PDF</button>
      <button className="btn btn-secondary btn-sm" onClick={() => run(() => window.api.reportExport.exportExcel([{ name, columns: e.columns, rows: e.rows }], `${name}.xlsx`))}><FileSpreadsheet size={13} /> Excel</button>
      <button className="btn btn-secondary btn-sm" onClick={() => run(() => window.api.financialStatements.print(e))}><Printer size={13} /> Print</button>
      {msg && <span style={{ fontSize: 12 }}>{msg}</span>}
      {html && <PreviewPane title={e.title} html={html} onClose={() => setHtml(null)} onSave={() => run(() => window.api.financialStatements.exportPdf(e))} onPrint={() => run(() => window.api.financialStatements.print(e))} />}
    </div>
  );
}

function Header({ title, subtitle, children }) {
  return (
    <div className="page-header">
      <div><h1>{title}</h1><p>{subtitle}</p></div>
      {children}
    </div>
  );
}

function Check({ ok, okText, badText }) {
  return ok
    ? <span style={{ color: 'var(--color-success, #027A48)', fontSize: 13 }}><CheckCircle2 size={14} style={{ verticalAlign: -2 }} /> {okText}</span>
    : <span style={{ color: 'var(--color-danger, #B42318)', fontSize: 13 }}><AlertTriangle size={14} style={{ verticalAlign: -2 }} /> {badText}</span>;
}

// ------------------------------------------------------------------ Trial Balance
export function TrialBalancePage() {
  const [asOf, setAsOf] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    const res = await window.api.financialStatements.trialBalance({ asOf: asOf || null });
    if (res.ok) { setData(res.data); setError(''); } else setError(res.error);
  }, [asOf]);
  useEffect(() => { load(); }, [load]);
  return (
    <div>
      <Header title="Trial Balance" subtitle={data ? `All figures in ${data.base_currency}, as at ${asOf || 'today'}` : ''}>
        <ExportBar data={data} name="Trial-Balance" />
      </Header>
      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', gap: 12, alignItems: 'center' }}>
        <label className="field-label" style={{ margin: 0 }}>As at</label>
        <input type="date" className="field-input" style={{ width: 170 }} value={asOf} onChange={(e) => setAsOf(e.target.value)} />
        {asOf && <button className="btn btn-secondary btn-sm" onClick={() => setAsOf('')}>Today</button>}
        {data && <Check ok={data.balanced} okText="Debits equal credits" badText={`Out of balance by ${num(data.difference)}`} />}
      </div>
      <Warnings list={data && data.warnings} />
      {data && (
        <div className="card" style={{ padding: 0 }}>
          <table className="data-table">
            <thead><tr><th>Code</th><th>Account</th><th>Type</th><th style={R}>Debit</th><th style={R}>Credit</th></tr></thead>
            <tbody>
              {data.rows.map((r) => <tr key={r.code}><td>{r.code}</td><td>{r.name}</td><td>{r.type}</td><td style={R}>{r.debit ? num(r.debit) : ''}</td><td style={R}>{r.credit ? num(r.credit) : ''}</td></tr>)}
              {data.rows.length === 0 && <tr><td colSpan={5} className="empty-row">No transactions yet.</td></tr>}
              <tr style={{ fontWeight: 700, borderTop: '2px solid var(--color-border, #D0D5DD)' }}><td colSpan={3}>Total</td><td style={R}>{num(data.total_debit)}</td><td style={R}>{num(data.total_credit)}</td></tr>
            </tbody>
          </table>
        </div>
      )}
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 10 }}>
        Built from invoices, payments, supplier bills, expenses and bank/cash movements. "Manual" accounts come from Finance › Profit &amp; Loss manual entries and are balanced against Suspense.
      </p>
    </div>
  );
}

// ------------------------------------------------------------------ Balance Sheet
export function BalanceSheetPage() {
  const [asOf, setAsOf] = useState('');
  const [data, setData] = useState(null);
  const [rec, setRec] = useState(null);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    const [b, r] = await Promise.all([window.api.financialStatements.balanceSheet({ asOf: asOf || null }), window.api.financialStatements.reconcile()]);
    if (b.ok) { setData(b.data); setError(''); } else setError(b.error);
    if (r.ok) setRec(r.data);
  }, [asOf]);
  useEffect(() => { load(); }, [load]);

  const Section = ({ title, rows, total }) => (
    <div className="card" style={{ padding: 0, marginBottom: 12 }}>
      <table className="data-table">
        <thead><tr><th colSpan={2}>{title}</th></tr></thead>
        <tbody>
          {rows.map((r, i) => <tr key={i}><td>{r.label}<span style={{ color: 'var(--color-text-muted)', fontSize: 11.5 }}> {r.group ? `· ${r.group}` : ''}</span></td><td style={R}>{num(r.amount)}</td></tr>)}
          {rows.length === 0 && <tr><td colSpan={2} className="empty-row">Nothing</td></tr>}
          <tr style={{ fontWeight: 700, borderTop: '2px solid var(--color-border, #D0D5DD)' }}><td>Total {title}</td><td style={R}>{num(total)}</td></tr>
        </tbody>
      </table>
    </div>
  );
  const mismatches = (rec || []).filter((r) => !r.matches);

  return (
    <div>
      <Header title="Balance Sheet" subtitle={data ? `All figures in ${data.base_currency}, as at ${asOf || 'today'}` : ''}>
        <ExportBar data={data} name="Balance-Sheet" />
      </Header>
      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', gap: 12, alignItems: 'center' }}>
        <label className="field-label" style={{ margin: 0 }}>As at</label>
        <input type="date" className="field-input" style={{ width: 170 }} value={asOf} onChange={(e) => setAsOf(e.target.value)} />
        {asOf && <button className="btn btn-secondary btn-sm" onClick={() => setAsOf('')}>Today</button>}
        {data && <Check ok={data.balanced} okText="Assets = Liabilities + Equity" badText={`Out of balance by ${num(data.difference)}`} />}
      </div>
      <Warnings list={data && data.warnings} />
      {mismatches.length > 0 && (
        <div className="login-error" style={{ marginBottom: 12 }}>
          <strong>Bank/cash accounts that don't match the books:</strong>
          {mismatches.map((m) => <div key={m.account}>{m.account}: books say {num(m.gl_balance)} {m.currency}, account says {num(m.account_balance)} (difference {num(m.difference)}). Usually an expense or payment edited after it was recorded.</div>)}
        </div>
      )}
      {data && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, alignItems: 'start' }}>
          <Section title="Assets" rows={data.assets} total={data.total_assets} />
          <div>
            <Section title="Liabilities" rows={data.liabilities} total={data.total_liabilities} />
            <Section title="Equity" rows={data.equity} total={data.total_equity} />
            <div className="card" style={{ padding: '10px 16px', display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}><span>Liabilities + Equity</span><span>{num(data.total_liabilities_and_equity)}</span></div>
          </div>
        </div>
      )}
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 10 }}>
        Customers who have paid more than they were invoiced appear as Customer Advances (a liability); suppliers paid more than billed appear as Supplier Advances (an asset). "Profit / (Loss) to date" is all revenue minus all costs and expenses recorded up to the date - there is no year-end close.
      </p>
    </div>
  );
}

function GeneralLedgerSection({ s }) {
  const pg = usePagination(s.rows, 50);
  return (
    <div className="card" style={{ padding: 0, marginBottom: 12 }}>
      <div style={{ padding: '10px 16px', fontWeight: 600 }}>{s.account.code} · {s.account.name} <span style={{ fontWeight: 400, color: 'var(--color-text-muted)', fontSize: 12 }}>({s.account.type}, normal balance {s.normal_side})</span></div>
      <table className="data-table">
        <thead><tr><th>Date</th><th>Source</th><th>Reference</th><th>Description</th><th style={R}>Debit</th><th style={R}>Credit</th><th style={R}>Balance</th></tr></thead>
        <tbody>
          <tr style={{ fontStyle: 'italic' }}><td colSpan={6}>Opening balance</td><td style={R}>{num(s.opening)}</td></tr>
          {pg.pageRows.map((r, i) => <tr key={i}><td>{r.date}</td><td>{r.source}</td><td>{r.ref}</td><td>{r.description}</td><td style={R}>{r.debit ? num(r.debit) : ''}</td><td style={R}>{r.credit ? num(r.credit) : ''}</td><td style={R}>{num(r.balance)}</td></tr>)}
          <tr style={{ fontWeight: 700, borderTop: '2px solid var(--color-border, #D0D5DD)' }}><td colSpan={4}>Closing balance</td><td style={R}>{num(s.total_debit)}</td><td style={R}>{num(s.total_credit)}</td><td style={R}>{num(s.closing)}</td></tr>
        </tbody>
      </table>
      <Pagination {...pg.pagerProps} label="entries" />
    </div>
  );
}

// ------------------------------------------------------------------ General Ledger
export function GeneralLedgerPage() {
  const [accounts, setAccounts] = useState([]);
  const [code, setCode] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { window.api.financialStatements.accounts().then((r) => { if (r.ok) { setAccounts(r.data); if (r.data.length) setCode((c) => c || r.data[0].code); } }); }, []);
  const load = useCallback(async () => {
    if (!code) { setData(null); return; }
    const res = await window.api.financialStatements.generalLedger({ accountCode: code === '*' ? null : code, dateFrom: dateFrom || null, dateTo: dateTo || null });
    if (res.ok) { setData(res.data); setError(''); } else setError(res.error);
  }, [code, dateFrom, dateTo]);
  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <Header title="General Ledger" subtitle={data ? `All figures in ${data.base_currency}` : ''}>
        <ExportBar data={data} name="General-Ledger" />
      </Header>
      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 12, marginBottom: 12, display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <select className="field-input" style={{ width: 320 }} value={code} onChange={(e) => setCode(e.target.value)}>
          <option value="*">All accounts</option>
          {accounts.map((a) => <option key={a.code} value={a.code}>{a.code} · {a.name}</option>)}
        </select>
        <label className="field-label" style={{ margin: 0 }}>From</label>
        <input type="date" className="field-input" style={{ width: 160 }} value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
        <label className="field-label" style={{ margin: 0 }}>To</label>
        <input type="date" className="field-input" style={{ width: 160 }} value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
      </div>
      <Warnings list={data && data.warnings} />
      {data && data.truncated && <div className="inline-notice">Showing the first 5,000 lines. Pick one account or narrow the dates to see everything.</div>}
      {data && data.sections.map((s) => <GeneralLedgerSection key={s.account.code} s={s} />)}
      {data && data.sections.length === 0 && <div className="card" style={{ padding: 24, textAlign: 'center' }}>No postings for this selection.</div>}
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 10 }}>
        Receivable and payable accounts are control accounts for all customers/suppliers - for one person's statement use Customer Ledger or Supplier Ledger.
      </p>
    </div>
  );
}

export default TrialBalancePage;
