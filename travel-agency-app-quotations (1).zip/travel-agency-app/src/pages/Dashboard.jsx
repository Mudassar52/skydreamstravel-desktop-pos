import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, CalendarCheck, PlaneTakeoff, TrendingUp, Wallet, AlertCircle,
  FileCheck2, CreditCard, Landmark, Target,
  Truck, CalendarRange
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Legend
} from 'recharts';
import StatCard from '../components/StatCard.jsx';
import UpcomingFlights from '../components/UpcomingFlights.jsx';
import UpcomingUmrah from '../components/UpcomingUmrah.jsx';
import { DepartureAlert, ToursHajjPanel, WeekDeparturesPanel, HotelsPanel, TransportPanel } from '../components/OperationsPanels.jsx';
import defaultBanner from '../assets/dashboard-banner.svg';

// Banner: put your own PNG at src/assets/dashboard-banner.png (jpg / jpeg /
// webp also work) and it replaces the built-in SVG automatically.
const customBanners = import.meta.glob('../assets/dashboard-banner.{png,jpg,jpeg,webp}', { eager: true, import: 'default' });
const bannerImg = Object.values(customBanners)[0] || defaultBanner;

// Shown only when the Electron IPC bridge (window.api) isn't available yet,
// e.g. previewing the UI in a plain browser tab, or when the database is
// genuinely empty on a first run - so the dashboard still looks complete.
// Once real customers/bookings/invoices exist, real numbers replace this.
const MOCK_STATS = {
  totalCustomers: 184, totalBookings: 96, activeBookings: 37, upcomingTrips: 12,
  totalSales: 18540000, totalReceived: 12760000, totalOutstanding: 5780000,
  totalExpenses: 6120000, estimatedProfit: 6640000, pendingVisas: 9,
  upcomingFlights: 14, upcomingTours: 5, customerPayments: 12760000, supplierPayments: 8100000,
  newLeadsThisMonth: 14, newBookingsThisMonth: 22, customerReceivables: 5780000,
  supplierPayables: 2340000, cashBalance: 480000, bankBalance: 3120000, actualProfit: 5210000,
  todayPayments: 185000, thisMonthSales: 3900000, thisMonthProfit: 1920000,
  pendingPaymentsCount: 11, pendingSupplierPaymentsCount: 6
};

const dayOffset = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return toISODate(d); };
const mockUpcoming = () => ({
  flights: [
    { id: 1, airline: 'Saudi Airlines', flight_number: 'SV 727', pnr: 'X7K2LM', class: 'Economy', status: 'Confirmed', departure_airport: 'Lahore (LHE)', arrival_airport: 'Jeddah (JED)', departure_date: dayOffset(2), departure_time: '03:45', arrival_date: dayOffset(2), arrival_time: '07:10', passengers: 42 },
    { id: 2, airline: 'Emirates', flight_number: 'EK 623', pnr: 'QW81ZP', class: 'Business', departure_airport: 'Karachi (KHI)', arrival_airport: 'Dubai (DXB)', departure_date: dayOffset(4), departure_time: '09:20', passengers: 3 },
    { id: 3, airline: 'PIA', flight_number: 'PK 301', class: 'Economy', departure_airport: 'Islamabad (ISB)', arrival_airport: 'London (LHR)', departure_date: dayOffset(9), departure_time: '21:00', passengers: 5 }
  ],
  umrahGroups: [
    { id: 1, group_name: 'Ramadan Group A', package_name: 'Premium Umrah 15 Days', departure_date: dayOffset(12), return_date: dayOffset(27), total_passengers: 38, visa_status: 'Approved', makkah_nights: 8, madinah_nights: 6, airline: 'Saudi Airlines', flight_number: 'SV 727', departure_airport: 'Lahore (LHE)', arrival_airport: 'Jeddah (JED)', departure_time: '03:45' },
    { id: 2, group_name: 'Economy Group B', package_name: 'Economy Umrah 21 Days', departure_date: dayOffset(30), return_date: dayOffset(51), total_passengers: 25, visa_status: 'Pending' }
  ]
});

const mockOperations = () => ({
  tours: [
    { id: 1, tour_name: 'Northern Areas Summer Tour', destination: 'Hunza', start_date: dayOffset(6), total_seats: 30, available_seats: 4, seats_filled: 26, seats_free: 4, passengers: 26 },
    { id: 2, tour_name: 'Turkey Highlights', destination: 'Istanbul', start_date: dayOffset(18), total_seats: 24, available_seats: 15, seats_filled: 9, seats_free: 15, passengers: 9 }
  ],
  hajjGroups: [{ id: 1, group_name: 'Hajj Group A', package_name: 'Hajj Premium', departure_date: dayOffset(40), total_pilgrims: 45, total_seats: 50, seats_filled: 45, seats_free: 5 }],
  departures: [
    { kind: 'Flight', id: 1, title: 'Saudi Airlines SV 727', detail: 'Lahore (LHE) → Jeddah (JED)', date: dayOffset(1), time: '03:45', route: '/flights' },
    { kind: 'Umrah', id: 1, title: 'Ramadan Group A', detail: '38 pilgrims', date: dayOffset(3), route: '/umrah' },
    { kind: 'Tour', id: 1, title: 'Northern Areas Summer Tour', detail: 'Hunza', date: dayOffset(6), route: '/tours' }
  ],
  hotelCheckIns: [{ id: 1, hotel_name: 'Hilton Makkah', city: 'Makkah', check_in: dayOffset(0), number_of_rooms: 6, guests: 18 }],
  hotelCheckOuts: [{ id: 2, hotel_name: 'Pullman Zamzam', city: 'Madinah', check_out: dayOffset(1), number_of_rooms: 4, guests: 12 }],
  transportToday: [{ id: 1, pickup_time: '14:30', pickup_location: 'Jeddah Airport', drop_location: 'Hilton Makkah', vehicle: 'Coaster', vehicle_number: 'LEB-1234', driver: 'Ahmed', driver_phone: '0300-1234567', status: 'Scheduled' }]
});

const MOCK_MONTHLY = [
  { month: 'Apr', sales: 2100000, payments: 1600000, expenses: 720000, profit: 880000 },
  { month: 'May', sales: 2600000, payments: 2000000, expenses: 810000, profit: 1190000 },
  { month: 'Jun', sales: 2350000, payments: 1900000, expenses: 690000, profit: 1210000 },
  { month: 'Jul', sales: 3100000, payments: 2450000, expenses: 980000, profit: 1470000 },
  { month: 'Aug', sales: 3400000, payments: 2700000, expenses: 1050000, profit: 1650000 },
  { month: 'Sep', sales: 3900000, payments: 3100000, expenses: 1180000, profit: 1920000 }
];

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

function pad2(n) { return String(n).padStart(2, '0'); }
function toISODate(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }

// Turns a preset id (or a custom from/to pair) into the {from, to} range
// sent to the backend. 'all' resolves to null, meaning "no date filter" -
// every dashboard number then reflects all-time totals, same as before
// this filter existed.
function resolveRange(preset, customFrom, customTo) {
  const today = new Date();
  const todayISO = toISODate(today);
  if (preset === 'today') return { from: todayISO, to: todayISO };
  if (preset === 'week') {
    const start = new Date(today);
    start.setDate(start.getDate() - 6);
    return { from: toISODate(start), to: todayISO };
  }
  if (preset === 'month') {
    const start = new Date(today.getFullYear(), today.getMonth(), 1);
    return { from: toISODate(start), to: todayISO };
  }
  if (preset === 'lastMonth') {
    const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const end = new Date(today.getFullYear(), today.getMonth(), 0);
    return { from: toISODate(start), to: toISODate(end) };
  }
  if (preset === 'year') {
    const start = new Date(today.getFullYear(), 0, 1);
    return { from: toISODate(start), to: todayISO };
  }
  if (preset === 'custom') {
    if (!customFrom || !customTo) return null;
    return { from: customFrom, to: customTo };
  }
  return null; // 'all'
}

function periodLabel(preset) {
  switch (preset) {
    case 'today': return 'today';
    case 'week': return 'last 7 days';
    case 'month': return 'this month';
    case 'lastMonth': return 'last month';
    case 'year': return 'this year';
    case 'custom': return 'selected range';
    default: return 'all time';
  }
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [monthly, setMonthly] = useState(null);
  const [usingSampleData, setUsingSampleData] = useState(false);
  const [upcoming, setUpcoming] = useState(null);
  const [upcomingError, setUpcomingError] = useState('');
  const [ops, setOps] = useState(null);

  const [preset, setPreset] = useState('all');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const range = useMemo(() => resolveRange(preset, customFrom, customTo), [preset, customFrom, customTo]);

  // Loaded once: the 6-month trend and upcoming
  // panels aren't period-bound, so the date filter doesn't refetch them.
  useEffect(() => {
    async function load() {
      if (window.api?.dashboard) {
        const [m, u, o] = await Promise.all([
          window.api.dashboard.getMonthlyFinancials(),
          window.api.dashboard.getUpcomingPanels(),
          window.api.dashboard.getOperationsPanels()
        ]);
        if (o?.ok) setOps(o.data);
        setMonthly(m.ok ? m.data : MOCK_MONTHLY);
        if (u.ok) { setUpcoming(u.data); setUpcomingError(''); } else setUpcomingError(u.error || 'Could not load upcoming data.');
      } else {
        setMonthly(MOCK_MONTHLY);
        setUpcoming(mockUpcoming());
        setOps(mockOperations());
      }
    }
    load();
  }, []);

  // Refetched whenever the date filter changes - these are the numbers the
  // stat cards actually show.
  useEffect(() => {
    async function load() {
      if (window.api?.dashboard) {
        const s = await window.api.dashboard.getStats(range);
        const isEmpty = s.ok && s.data.totalCustomers === 0 && s.data.totalBookings === 0 && preset === 'all';
        setStats(isEmpty ? MOCK_STATS : s.data);
        setUsingSampleData(isEmpty);
      } else {
        setStats(MOCK_STATS);
        setUsingSampleData(true);
      }
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range]);

  // On a brand-new (empty) database, show sample flights/groups like the
  // stat cards do, so the panels never look broken on first run.
  const sampleUpcoming = useMemo(() => mockUpcoming(), []);
  const hasRealUpcoming = !!(upcoming?.flights?.length || upcoming?.umrahGroups?.length);
  const shownUpcoming = usingSampleData && !hasRealUpcoming && !upcomingError ? sampleUpcoming : upcoming;

  const sampleOps = useMemo(() => mockOperations(), []);
  const hasRealOps = !!ops && Object.values(ops).some((v) => v?.length);
  const shownOps = usingSampleData && !hasRealOps ? sampleOps : ops;

  if (!stats) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p>
            Overview of your agency's business
            {usingSampleData && ' — showing sample data until real records exist'}
          </p>
        </div>
      </div>

      <div style={{ marginBottom: 20, borderRadius: 14, overflow: 'hidden', boxShadow: '0 8px 24px rgba(22, 35, 63, 0.14)' }}>
        <img src={bannerImg} alt="Dashboard banner" style={{ display: 'block', width: '100%', height: 170, objectFit: 'cover' }} />
      </div>

      <DepartureAlert departures={shownOps?.departures || []} />

      <PeriodFilter
        preset={preset}
        setPreset={setPreset}
        customFrom={customFrom}
        customTo={customTo}
        setCustomFrom={setCustomFrom}
        setCustomTo={setCustomTo}
      />

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 20 }}>
        <StatCard icon={TrendingUp} label="Total Sales" value={money(stats.totalSales)} tone="primary" onClick={() => navigate('/invoices')} />
        <StatCard icon={CreditCard} label="Customer Payments" value={money(stats.customerPayments)} tone="success" onClick={() => navigate('/payments')} />
        <StatCard icon={Truck} label="Supplier Payments" value={money(stats.supplierPayments)} tone="rose" onClick={() => navigate('/supplier-payments')} />
        <StatCard icon={Target} label={`New Leads (${periodLabel(preset)})`} value={stats.newLeadsThisMonth} tone="primary" onClick={() => navigate('/leads')} />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 20 }}>
        <StatCard icon={CalendarCheck} label={`New Bookings (${periodLabel(preset)})`} value={stats.newBookingsThisMonth} tone="primary" onClick={() => navigate('/bookings')} />
        <StatCard icon={AlertCircle} label="Customer Receivables" value={money(stats.customerReceivables)} tone="rose" onClick={() => navigate('/invoices')} />
        <StatCard icon={Truck} label="Supplier Payables" value={money(stats.supplierPayables)} tone="rose" onClick={() => navigate('/supplier-invoices')} />
        <StatCard icon={Wallet} label="Total Expenses" value={money(stats.totalExpenses)} tone="rose" onClick={() => navigate('/expenses')} />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 20 }}>
        <StatCard icon={TrendingUp} label="Estimated Profit" value={money(stats.estimatedProfit)} tone="success" />
        <StatCard icon={TrendingUp} label="Actual Profit" value={money(stats.actualProfit)} tone="success" />
        <StatCard icon={Landmark} label="Cash Balance" value={money(stats.cashBalance)} tone="primary" onClick={() => navigate('/cash-accounts')} />
        <StatCard icon={Landmark} label="Bank Balance" value={money(stats.bankBalance)} tone="primary" onClick={() => navigate('/bank-accounts')} />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 24 }}>
        <StatCard icon={Users} label="Total Customers" value={stats.totalCustomers} tone="primary" onClick={() => navigate('/customers')} />
        <StatCard icon={CalendarCheck} label="Active Bookings" value={stats.activeBookings} tone="success" onClick={() => navigate('/bookings')} />
        <StatCard icon={FileCheck2} label="Pending Visa Applications" value={stats.pendingVisas} tone="rose" onClick={() => navigate('/visa')} />
        <StatCard icon={PlaneTakeoff} label="Upcoming Flights" value={stats.upcomingFlights} tone="primary" onClick={() => navigate('/flights')} />
      </div>

      <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr', marginBottom: 24, alignItems: 'stretch' }}>
        <div className="card" style={{ padding: '20px 24px' }}>
          <h3 style={{ fontSize: 14, marginBottom: 16 }}>Sales, Payments & Expenses (last 6 months)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={monthly}>
              <defs>
                <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1E4FA3" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#1E4FA3" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E4E9F2" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#5B6B8C' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#8B97B3' }} axisLine={false} tickLine={false}
                tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} />
              <Tooltip formatter={(v) => money(v)} />
              <Legend />
              <Area type="monotone" dataKey="sales" name="Sales" stroke="#1E4FA3" fill="url(#salesGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="payments" name="Payments" stroke="#1B8A5A" fill="transparent" strokeWidth={2} />
              <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#E0485A" fill="transparent" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card" style={{ padding: '20px 24px' }}>
          <h3 style={{ fontSize: 14, marginBottom: 16 }}>Monthly Profit Trend</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E4E9F2" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#5B6B8C' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#8B97B3' }} axisLine={false} tickLine={false}
                tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} />
              <Tooltip formatter={(v) => money(v)} />
              <Bar dataKey="profit" name="Profit" fill="#F2707F" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="up-grid">
        <UpcomingFlights flights={shownUpcoming?.flights || []} error={upcomingError} />
        <UpcomingUmrah groups={shownUpcoming?.umrahGroups || []} error={upcomingError} />
      </div>

      {shownOps && (
        <div className="ops-grid">
          <ToursHajjPanel tours={shownOps.tours} hajjGroups={shownOps.hajjGroups} />
          <WeekDeparturesPanel departures={shownOps.departures} />
          <HotelsPanel checkIns={shownOps.hotelCheckIns} checkOuts={shownOps.hotelCheckOuts} />
          <TransportPanel pickups={shownOps.transportToday} />
        </div>
      )}
    </div>
  );
}

// Dashboard date filter - replaces the old "New Customer" / "New Booking"
// quick-action buttons, and replaces the earlier full month-grid calendar
// widget (that was for browsing dates, not filtering data). This is a
// plain field: pick a quick period, or pick a custom From/To range, and
// the stat cards + charts above refetch for exactly that window. It does
// not navigate anywhere - it only filters what's shown on this page.
const PRESETS = [
  { id: 'today', label: 'Today' },
  { id: 'week', label: 'Week' },
  { id: 'month', label: 'Month' },
  { id: 'lastMonth', label: 'Last Month' },
  { id: 'year', label: 'Year' },
  { id: 'all', label: 'All Time' }
];

function PeriodFilter({ preset, setPreset, customFrom, customTo, setCustomFrom, setCustomTo }) {
  return (
    <div className="card" style={{ padding: '14px 18px', marginBottom: 20, display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <CalendarRange size={16} color="var(--color-primary)" />
        <strong style={{ fontSize: 13 }}>Period</strong>
      </div>

      <div className="tabs" style={{ margin: 0 }}>
        {PRESETS.map((p) => (
          <button
            key={p.id}
            className={preset === p.id ? 'tab active' : 'tab'}
            onClick={() => setPreset(p.id)}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 'auto' }}>
        <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Custom:</span>
        <input
          type="date"
          className="field-input"
          style={{ width: 145 }}
          value={customFrom}
          onChange={(e) => { setCustomFrom(e.target.value); setPreset('custom'); }}
        />
        <span style={{ fontSize: 12, color: 'var(--color-text-faint)' }}>to</span>
        <input
          type="date"
          className="field-input"
          style={{ width: 145 }}
          value={customTo}
          onChange={(e) => { setCustomTo(e.target.value); setPreset('custom'); }}
        />
      </div>
    </div>
  );
}
