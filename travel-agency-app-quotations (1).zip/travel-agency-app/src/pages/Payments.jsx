import { useEffect, useState, useCallback } from 'react';
import { Plus, Undo2 } from 'lucide-react';
import Pagination from '../components/Pagination.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import CrossCurrencyField from '../components/CrossCurrencyField.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import DateRangeFilter from '../components/DateRangeFilter.jsx';
import SavedFiltersBar from '../components/SavedFiltersBar.jsx';
import './customers.css';

const METHODS = ['Cash', 'Bank Transfer', 'Card', 'Online Transfer', 'Other'];
const TYPES = ['Advance', 'Partial', 'Full', 'Refund'];
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Payments() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [dateFilter, setDateFilter] = useState({ preset: '', from: '', to: '' });
  const [formOpen, setFormOpen] = useState(false);
  const [voidTarget, setVoidTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const reload = useCallback(async () => {
    const res = await window.api.payments.list({ dateFrom: dateFilter.from || null, dateTo: dateFilter.to || null, page, pageSize });
    if (res.ok && res.data.rows.length === 0 && page > 1) { setPage(page - 1); return; }
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [dateFilter, page, pageSize]);
  useEffect(() => { reload(); }, [reload]);
  useEffect(() => { setPage(1); }, [dateFilter]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmVoid() {
    const res = await window.api.payments.void(voidTarget.id);
    if (!res.ok) setError(res.error); else { flash('Payment voided.'); reload(); }
    setVoidTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Payments</h1>
          <p>{total.toLocaleString()} recorded payment{total === 1 ? '' : 's'}</p>
        </div>
        {can('payments', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Record Payment</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="customers-toolbar" style={{ flexWrap: 'wrap', rowGap: 10 }}>
        <DateRangeFilter value={dateFilter} onChange={setDateFilter} />
      </div>

      <div style={{ marginBottom: 14 }}>
        <SavedFiltersBar
          module="payments"
          currentFilter={{ dateFilter }}
          onApply={(f) => setDateFilter(f.dateFilter || { preset: '', from: '', to: '' })}
        />
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Date</th><th>Customer</th><th>Linked To</th><th>Amount</th><th>Method</th><th>Type</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id}>
                <td>{p.payment_date?.slice(0, 10)}</td>
                <td>{p.customer_name}</td>
                <td>{p.invoice_number || p.booking_code || '—'}</td>
                <td>{money(p.amount)}</td>
                <td>{p.payment_method}</td>
                <td><span className={`status-pill ${p.payment_type === 'Refund' ? 'off' : 'on'}`}>{p.payment_type}</span></td>
                <td className="row-actions">
                  {can('payments', 'delete') && (
                    <button className="icon-btn" title="Void payment" onClick={() => setVoidTarget(p)}><Undo2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No payments recorded yet.</td></tr>}
          </tbody>
        </table>
        <Pagination page={page} pageSize={pageSize} total={total} onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} label="payments" />
      </div>

      {formOpen && (
        <PaymentFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }} />
      )}

      {voidTarget && (
        <Modal title="Void payment" onClose={() => setVoidTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
            Void the {voidTarget.payment_type.toLowerCase()} payment of <strong>{money(voidTarget.amount)}</strong> for <strong>{voidTarget.customer_name}</strong>?
            This reverses its effect on the linked invoice/booking and the customer ledger.
          </p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setVoidTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmVoid}>Void Payment</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  customer_id: '', customer_label: '', invoice_id: '', booking_id: '',
  amount: '', payment_method: 'Cash', payment_type: 'Partial', reference: '', notes: '',
  account_type: '', account_id: '', received_amount: ''
};

function PaymentFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [invoices, setInvoices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [linkTo, setLinkTo] = useState('none'); // none | invoice | booking
  const [bankAccounts, setBankAccounts] = useState([]);
  const [cashAccounts, setCashAccounts] = useState([]);

  useEffect(() => {
    window.api.bankAccounts.list({}).then((res) => res.ok && setBankAccounts(res.data));
    window.api.cashAccounts.list({}).then((res) => res.ok && setCashAccounts(res.data));
  }, []);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!form.customer_id) { setInvoices([]); setBookings([]); return; }
    window.api.invoices.listByCustomer(form.customer_id).then((res) => { if (res.ok) setInvoices(res.data.filter((i) => i.remaining_amount > 0)); });
    window.api.bookings.listByCustomer(form.customer_id).then((res) => { if (res.ok) setBookings(res.data.filter((b) => b.remaining_amount > 0)); });
  }, [form.customer_id]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    if (!(Number(form.amount) > 0)) return setError('Amount must be greater than zero.');
    setSaving(true);
    const payload = {
      ...form,
      invoice_id: linkTo === 'invoice' ? Number(form.invoice_id) || null : null,
      booking_id: linkTo === 'booking' ? Number(form.booking_id) || null : null,
      account_type: form.account_type || null,
      account_id: form.account_id ? Number(form.account_id) : null,
      received_amount: form.received_amount ? Number(form.received_amount) : null
    };
    const res = await window.api.payments.create(payload);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Payment recorded.');
  }

  const accountOptions = form.account_type === 'Bank' ? bankAccounts : form.account_type === 'Cash' ? cashAccounts : [];
  const selectedAccount = accountOptions.find((a) => String(a.id) === String(form.account_id)) || null;
  const linked = linkTo === 'invoice' ? invoices.find((i) => String(i.id) === String(form.invoice_id)) : linkTo === 'booking' ? bookings.find((b) => String(b.id) === String(form.booking_id)) : null;
  const docCurrency = linked && linked.currency ? linked.currency : null;

  return (
    <Modal title="Record Payment" onClose={onClose} width={520}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            <CustomerSearchSelect
              value={form.customer_id}
              valueLabel={form.customer_label}
              onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label, invoice_id: '', booking_id: '' }))}
            />
          </Field>

          <Field label="Link Payment To" full>
            <select className="field-input" value={linkTo} onChange={(e) => setLinkTo(e.target.value)}>
              <option value="none">Not linked (general/advance payment)</option>
              <option value="invoice" disabled={invoices.length === 0}>An Invoice{invoices.length === 0 ? ' (none with a balance)' : ''}</option>
              <option value="booking" disabled={bookings.length === 0}>A Booking{bookings.length === 0 ? ' (none with a balance)' : ''}</option>
            </select>
          </Field>

          {linkTo === 'invoice' && (
            <Field label="Invoice" full>
              <select className="field-input" value={form.invoice_id} onChange={(e) => set('invoice_id', e.target.value)}>
                <option value="">— Select —</option>
                {invoices.map((i) => <option key={i.id} value={i.id}>{i.invoice_number} — Balance {money(i.remaining_amount)}</option>)}
              </select>
            </Field>
          )}
          {linkTo === 'booking' && (
            <Field label="Booking" full>
              <select className="field-input" value={form.booking_id} onChange={(e) => set('booking_id', e.target.value)}>
                <option value="">— Select —</option>
                {bookings.map((b) => <option key={b.id} value={b.id}>{b.booking_code} — Balance {money(b.remaining_amount)}</option>)}
              </select>
            </Field>
          )}

          <Field label={`Amount (${docCurrency || 'Rs.'}) *`}><input type="number" className="field-input" value={form.amount} onChange={(e) => set('amount', e.target.value)} /></Field>
          <Field label="Payment Method">
            <select className="field-input" value={form.payment_method} onChange={(e) => set('payment_method', e.target.value)}>
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
          </Field>
          <Field label="Payment Type">
            <select className="field-input" value={form.payment_type} onChange={(e) => set('payment_type', e.target.value)}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Received Into (optional)">
            <select className="field-input" value={form.account_type} onChange={(e) => setForm((s) => ({ ...s, account_type: e.target.value, account_id: '', received_amount: '' }))}>
              <option value="">Not tracked against an account</option>
              <option value="Bank" disabled={bankAccounts.length === 0}>Bank Account{bankAccounts.length === 0 ? ' (none set up yet)' : ''}</option>
              <option value="Cash" disabled={cashAccounts.length === 0}>Cash Account{cashAccounts.length === 0 ? ' (none set up yet)' : ''}</option>
            </select>
          </Field>
          {form.account_type && (
            <Field label={`${form.account_type} Account`}>
              <select className="field-input" value={form.account_id} onChange={(e) => setForm((s) => ({ ...s, account_id: e.target.value, received_amount: '' }))}>
                <option value="">— Select —</option>
                {accountOptions.map((a) => <option key={a.id} value={a.id}>{a.account_name} ({a.currency})</option>)}
              </select>
            </Field>
          )}
          <CrossCurrencyField docCurrency={docCurrency} account={selectedAccount} label="Amount received" value={form.received_amount} onChange={(v) => set('received_amount', v)} />
          <Field label="Reference"><input className="field-input" value={form.reference} onChange={(e) => set('reference', e.target.value)} placeholder="e.g. transaction ID" /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Record Payment'}</button>
        </div>
      </form>
    </Modal>
  );
}
