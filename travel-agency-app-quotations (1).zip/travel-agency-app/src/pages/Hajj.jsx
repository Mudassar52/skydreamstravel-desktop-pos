import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Users as UsersIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import MembersDrawer from '../components/MembersDrawer.jsx';
import PackageManager from '../components/PackageManager.jsx';
import '../pages/customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const GROUP_EMPTY = { group_name: '', package_id: '', departure_date: '', return_date: '', total_seats: '', visa_status: 'Documents Pending', notes: '' };

export default function Hajj() {
  const [tab, setTab] = useState('packages');
  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Hajj</h1>
          <p>Hajj packages (from the central Package catalogue) and pilgrim groups.</p>
        </div>
      </div>
      <div className="tabs">
        <button className={tab === 'packages' ? 'tab active' : 'tab'} onClick={() => setTab('packages')}>Packages</button>
        <button className={tab === 'groups' ? 'tab active' : 'tab'} onClick={() => setTab('groups')}>Groups</button>
      </div>
      {tab === 'packages' ? <PackageManager fixedType="Hajj" permissionModule="hajj" /> : <GroupsTab />}
    </div>
  );
}
function GroupsTab() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [packages, setPackages] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [membersFor, setMembersFor] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [error, setError] = useState('');

  async function reload() {
    const [g, p] = await Promise.all([window.api.hajj.groups.list(), window.api.hajj.packages.list()]);
    if (g.ok) setRows(g.data);
    if (p.ok) setPackages(p.data);
  }
  useEffect(() => { reload(); }, []);

  const packageName = (id) => packages.find((p) => p.id === id)?.package_name || '—';

  async function confirmDelete() {
    const res = await window.api.hajj.groups.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  return (
    <div>
      {can('hajj', 'create') && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Group
          </button>
        </div>
      )}
      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Group</th><th>Package</th><th>Departure</th><th>Pilgrims / Seats</th><th>Visa Status</th><th></th></tr>
          </thead>
          <tbody>
            {pg.pageRows.map((g) => (
              <tr key={g.id}>
                <td>{g.group_name}</td>
                <td>{packageName(g.package_id)}</td>
                <td>{g.departure_date || '—'}</td>
                <td>{g.total_pilgrims || 0}{g.total_seats > 0 ? ` / ${g.total_seats}` : ''}</td>
                <td>{g.visa_status || '—'}</td>
                <td className="row-actions">
                  <button className="icon-btn" title="Pilgrims" onClick={() => setMembersFor(g.id)}><UsersIcon size={14} /></button>
                  {can('hajj', 'edit') && (
                    <button className="icon-btn" onClick={() => { setEditingId(g.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('hajj', 'delete') && (
                    <button className="icon-btn" onClick={() => setDeleteTarget(g)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No Hajj groups yet.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="groups" />
      </div>

      {formOpen && (
        <GroupFormModal groupId={editingId} packages={packages} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {membersFor && (
        <MembersDrawer
          title={`Pilgrims — ${rows.find((r) => r.id === membersFor)?.group_name || ''}`}
          groupId={membersFor}
          api={window.api.hajj.groups.pilgrims}
          onClose={() => { setMembersFor(null); reload(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete group" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.group_name}</strong>? Its pilgrim list will be removed too.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function GroupFormModal({ groupId, packages, onClose, onSaved }) {
  const [form, setForm] = useState(GROUP_EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (groupId) {
      window.api.hajj.groups.get(groupId).then((res) => { if (res.ok) setForm({ ...GROUP_EMPTY, ...res.data }); });
    } else if (packages[0]) {
      setForm((f) => ({ ...f, package_id: packages[0].id }));
    }
  }, [groupId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.group_name.trim()) return setError('Group name is required.');
    setSaving(true);
    const res = groupId ? await window.api.hajj.groups.update(groupId, form) : await window.api.hajj.groups.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={groupId ? 'Edit Group' : 'New Hajj Group'} onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Group Name *" full><input className="field-input" value={form.group_name} onChange={(e) => set('group_name', e.target.value)} /></Field>
          <Field label="Package" full>
            <select className="field-input" value={form.package_id || ''} onChange={(e) => set('package_id', Number(e.target.value))}>
              <option value="">— None —</option>
              {packages.map((p) => <option key={p.id} value={p.id}>{p.package_name}</option>)}
            </select>
          </Field>
          <Field label="Departure Date"><input type="date" className="field-input" value={form.departure_date || ''} onChange={(e) => set('departure_date', e.target.value)} /></Field>
          <Field label="Return Date"><input type="date" className="field-input" value={form.return_date || ''} onChange={(e) => set('return_date', e.target.value)} /></Field>
          <Field label="Total Seats" full><input type="number" min="0" className="field-input" placeholder="0 = no limit" value={form.total_seats ?? ''} onChange={(e) => set('total_seats', e.target.value)} /></Field>
          <Field label="Visa Status" full>
            <select className="field-input" value={form.visa_status || ''} onChange={(e) => set('visa_status', e.target.value)}>
              {['Documents Pending', 'Ready to Apply', 'Applied', 'Processing', 'Approved', 'Rejected', 'Expired'].map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Group'}</button>
        </div>
      </form>
    </Modal>
  );
}
