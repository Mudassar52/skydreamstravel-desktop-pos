import { useEffect, useState, useCallback } from 'react';
import { Plus, Check, X as XIcon, ChevronLeft, ChevronRight, PhoneCall, History } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import FollowUpFormModal from '../components/FollowUpFormModal.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['All', 'Pending', 'Overdue', 'Completed', 'Cancelled'];
const pillTone = (s) => (s === 'Overdue' ? 'off' : s === 'Cancelled' ? 'off' : 'on');

export default function FollowUps() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [formInitial, setFormInitial] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.followups.list({ search, status, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  function openForm(initial) { setFormInitial(initial); setFormOpen(true); }

  // Pre-fills the form from a scheduled follow-up so "I just called them" is one click.
  function logFrom(f) {
    const mode = f.lead_id ? 'inquiry' : f.customer_id ? 'customer' : 'manual';
    const name = f.customer_name || f.lead_name || f.contact_name || '';
    openForm({
      mode, existing_follow_up_id: f.id, lead_id: f.lead_id, customer_id: f.customer_id, booking_id: f.booking_id,
      picked_label: f.lead_code ? `${f.lead_code} · ${name}` : name, contact_name: name, contact_phone: f.contact_phone || '',
      reference_code: f.lead_code || f.booking_code || '', purpose: f.purpose || '', contact_method: f.contact_method || '',
      priority: f.priority || 'Medium', notes: ''
    });
  }

  async function setDone(row, newStatus) {
    const res = await window.api.followups.markStatus(row.id, newStatus);
    if (!res.ok) setError(res.error); else { flash(`Follow-up marked ${newStatus}.`); load(); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Follow-ups</h1>
          <p>{total.toLocaleString()} follow-up{total === 1 ? '' : 's'}</p>
        </div>
        {can('followups', 'create') && (
          <div style={{ display: 'flex', gap: 8 }}>
            <Link to="/followup-history" className="btn btn-secondary"><History size={15} /> History</Link>
            <button className="btn btn-primary" onClick={() => openForm(null)}><Plus size={15} /> New Follow-up</button>
          </div>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <input placeholder="Search customer, lead, booking, notes..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Due Date</th><th>Customer / Inquiry</th><th>Purpose</th><th>Priority</th><th>Notes</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((f) => (
              <tr key={f.id}>
                <td>{f.follow_up_date}{f.reminder_time ? <span className="fu-cell-sub">{f.reminder_time}</span> : null}</td>
                <td>
                  {f.customer_name || f.lead_name || f.contact_name || f.booking_code || '—'}
                  {(f.lead_code || f.contact_phone) && <span className="fu-cell-sub">{[f.lead_code, f.contact_phone].filter(Boolean).join(' · ')}</span>}
                </td>
                <td>{f.purpose || '—'}</td>
                <td>{f.priority}</td>
                <td style={{ maxWidth: 260 }}>{f.notes || '—'}</td>
                <td><span className={`status-pill ${pillTone(f.effective_status)}`}>{f.effective_status}</span></td>
                <td className="row-actions">
                  {f.effective_status !== 'Completed' && f.effective_status !== 'Cancelled' && can('followups', 'edit') && (
                    <>
                      <button className="icon-btn" title="Log contact (call / message done)" onClick={() => logFrom(f)}><PhoneCall size={14} /></button>
                      <button className="icon-btn" title="Mark Completed" onClick={() => setDone(f, 'Completed')}><Check size={14} /></button>
                      <button className="icon-btn" title="Cancel" onClick={() => setDone(f, 'Cancelled')}><XIcon size={14} /></button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No follow-ups found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <FollowUpFormModal initial={formInitial} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}
    </div>
  );
}
