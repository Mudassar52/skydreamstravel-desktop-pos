import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const STATUSES = ['Scheduled', 'In Progress', 'Completed', 'Cancelled'];
const EMPTY = {
  booking_id: '', vehicle: '', vehicle_number: '', driver: '', driver_phone: '',
  pickup_location: '', drop_location: '', pickup_date: '', pickup_time: '',
  cost: '', selling_price: '', status: 'Scheduled', notes: ''
};
const PAGE_SIZE = 15;

export default function Transportation() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [bookingOptions, setBookingOptions] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [error, setError] = useState('');
  const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

  async function reload() {
    const [t, b] = await Promise.all([window.api.transportation.list({ search, page, pageSize: PAGE_SIZE }), window.api.bookings.options()]);
    if (t.ok) { setRows(t.data.rows); setTotal(t.data.total); }
    if (b.ok) setBookingOptions(b.data);
  }
  useEffect(() => { reload(); }, [search, page]);
  useEffect(() => { setPage(1); }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  async function confirmDelete() {
    const res = await window.api.transportation.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Transportation</h1>
          <p>{total.toLocaleString()} assignment{total === 1 ? '' : 's'}</p>
        </div>
        {can('transportation', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Assignment
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <Search size={15} />
          <input placeholder="Search pickup, drop-off, driver, vehicle..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Vehicle</th><th>Driver</th><th>Route</th><th>Pickup</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>{t.vehicle || '—'} {t.vehicle_number ? `(${t.vehicle_number})` : ''}</td>
                <td>{t.driver || '—'}</td>
                <td>{[t.pickup_location, t.drop_location].filter(Boolean).join(' → ')}</td>
                <td>{t.pickup_date || '—'} {t.pickup_time || ''}</td>
                <td><span className={`status-pill ${t.status === 'Completed' || t.status === 'Scheduled' ? 'on' : 'off'}`}>{t.status}</span></td>
                <td className="row-actions">
                  {can('transportation', 'edit') && <button className="icon-btn" onClick={() => { setEditingId(t.id); setFormOpen(true); }}><Pencil size={14} /></button>}
                  {can('transportation', 'delete') && <button className="icon-btn" onClick={() => setDeleteTarget(t)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No transportation assignments yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <TransportFormModal transportId={editingId} bookingOptions={bookingOptions} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete assignment" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete this transportation assignment?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function TransportFormModal({ transportId, bookingOptions, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (transportId) window.api.transportation.get(transportId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
  }, [transportId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.pickup_location.trim()) return setError('Pickup location is required.');
    setSaving(true);
    const res = transportId ? await window.api.transportation.update(transportId, form) : await window.api.transportation.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={transportId ? 'Edit Assignment' : 'New Transportation Assignment'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Booking (optional)" full>
            <select className="field-input" value={form.booking_id || ''} onChange={(e) => set('booking_id', e.target.value ? Number(e.target.value) : '')}>
              <option value="">— Not linked to a booking —</option>
              {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
            </select>
          </Field>
          <Field label="Vehicle"><input className="field-input" value={form.vehicle || ''} onChange={(e) => set('vehicle', e.target.value)} placeholder="e.g. Toyota Hiace" /></Field>
          <Field label="Vehicle Number"><input className="field-input" value={form.vehicle_number || ''} onChange={(e) => set('vehicle_number', e.target.value)} /></Field>
          <Field label="Driver"><input className="field-input" value={form.driver || ''} onChange={(e) => set('driver', e.target.value)} /></Field>
          <Field label="Driver Phone"><input className="field-input" value={form.driver_phone || ''} onChange={(e) => set('driver_phone', e.target.value)} /></Field>
          <Field label="Pickup Location *"><input className="field-input" value={form.pickup_location} onChange={(e) => set('pickup_location', e.target.value)} /></Field>
          <Field label="Drop Location"><input className="field-input" value={form.drop_location || ''} onChange={(e) => set('drop_location', e.target.value)} /></Field>
          <Field label="Pickup Date"><input type="date" className="field-input" value={form.pickup_date || ''} onChange={(e) => set('pickup_date', e.target.value)} /></Field>
          <Field label="Pickup Time"><input type="time" className="field-input" value={form.pickup_time || ''} onChange={(e) => set('pickup_time', e.target.value)} /></Field>
          <Field label="Cost (Rs.)"><input type="number" className="field-input" value={form.cost || ''} onChange={(e) => set('cost', e.target.value)} /></Field>
          <Field label="Selling Price (Rs.)"><input type="number" className="field-input" value={form.selling_price || ''} onChange={(e) => set('selling_price', e.target.value)} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status || ''} onChange={(e) => set('status', e.target.value)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Assignment'}</button>
        </div>
      </form>
    </Modal>
  );
}
