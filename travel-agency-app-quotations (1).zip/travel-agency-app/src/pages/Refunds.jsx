import { useEffect, useState } from 'react';
import { Plus, Undo2 } from 'lucide-react';
import Pagination from '../components/Pagination.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import CrossCurrencyField from '../components/CrossCurrencyField.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Refunds() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [formOpen, setFormOpen] = useState(false);
  const [voidTarget, setVoidTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.refunds.list({ page, pageSize });
    if (res.ok && res.data.rows.length === 0 && page > 1) { setPage(page - 1); return; }
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }
  useEffect(() => { reload(); }, [page, pageSize]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmVoid() {
    const res = await window.api.refunds.delete(voidTarget.id);
    if (!res.ok) setError(res.error); else { flash('Refund voided.'); reload(); }
    setVoidTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Refunds</h1>
          <p>{total.toLocaleString()} refund{total === 1 ? '' : 's'}</p>
        </div>
        {can('refunds', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Issue Refund</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Date</th><th>Customer</th><th>Invoice</th><th>Amount</th><th>Reason</th><th>Method</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.refund_date?.slice(0, 10)}</td>
                <td>{r.customer_name}</td>
                <td>{r.invoice_number || r.booking_code || '—'}</td>
                <td>{money(r.refund_amount)}</td>
                <td>{r.reason || '—'}</td>
                <td>{r.payment_method}</td>
                <td className="row-actions">
                  {can('refunds', 'delete') && (
                    <button className="icon-btn" title="Void refund" onClick={() => setVoidTarget(r)}><Undo2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No refunds issued yet.</td></tr>}
          </tbody>
        </table>
        <Pagination page={page} pageSize={pageSize} total={total} onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} label="refunds" />
      </div>

      {formOpen && (
        <RefundFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }} />
      )}

      {voidTarget && (
        <Modal title="Void refund" onClose={() => setVoidTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
            Void the refund of <strong>{money(voidTarget.refund_amount)}</strong> to <strong>{voidTarget.customer_name}</strong>?
            This reverses its effect on the invoice/booking balance, customer ledger, and any linked account.
          </p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setVoidTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmVoid}>Void Refund</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  customer_id: '', customer_label: '', invoice_id: '', refund_amount: '',
  reason: '', payment_method: 'Bank Transfer', account_type: '', account_id: '', received_amount: '', notes: ''
};

function RefundFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [invoices, setInvoices] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [cashAccounts, setCashAccounts] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.bankAccounts.list({}).then((res) => res.ok && setBankAccounts(res.data));
    window.api.cashAccounts.list({}).then((res) => res.ok && setCashAccounts(res.data));
  }, []);

  useEffect(() => {
    if (!form.customer_id) { setInvoices([]); return; }
    window.api.invoices.listByCustomer(form.customer_id).then((res) => { if (res.ok) setInvoices(res.data.filter((i) => i.paid_amount > 0)); });
  }, [form.customer_id]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    if (!(Number(form.refund_amount) > 0)) return setError('Refund amount must be greater than zero.');
    setSaving(true);
    const res = await window.api.refunds.create({ ...form, invoice_id: form.invoice_id || null, account_id: form.account_id || null, received_amount: form.received_amount ? Number(form.received_amount) : null });
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Refund issued.');
  }

  const accountOptions = form.account_type === 'Bank' ? bankAccounts : form.account_type === 'Cash' ? cashAccounts : [];
  const selectedAccount = accountOptions.find((a) => String(a.id) === String(form.account_id)) || null;
  const refundInvoice = invoices.find((i) => String(i.id) === String(form.invoice_id));

  return (
    <Modal title="Issue Refund" onClose={onClose} width={520}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            <CustomerSearchSelect value={form.customer_id} valueLabel={form.customer_label} onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label, invoice_id: '' }))} />
          </Field>
          <Field label="Invoice (optional)" full>
            <select className="field-input" value={form.invoice_id} onChange={(e) => set('invoice_id', e.target.value)}>
              <option value="">Not linked to a specific invoice</option>
              {invoices.map((i) => <option key={i.id} value={i.id}>{i.invoice_number} — Paid {money(i.paid_amount)}</option>)}
            </select>
          </Field>
          <Field label="Refund Amount *"><input type="number" className="field-input" value={form.refund_amount} onChange={(e) => set('refund_amount', e.target.value)} /></Field>
          <Field label="Payment Method">
            <select className="field-input" value={form.payment_method} onChange={(e) => set('payment_method', e.target.value)}>
              {['Bank Transfer', 'Cash', 'Card', 'Cheque', 'Other'].map((m) => <option key={m}>{m}</option>)}
            </select>
          </Field>
          <Field label="Refund From (optional)">
            <select className="field-input" value={form.account_type} onChange={(e) => setForm((s) => ({ ...s, account_type: e.target.value, account_id: '' }))}>
              <option value="">Not tracked against an account</option>
              <option value="Bank">Bank Account</option>
              <option value="Cash">Cash Account</option>
            </select>
          </Field>
          {form.account_type && (
            <Field label={`${form.account_type} Account`}>
              <select className="field-input" value={form.account_id} onChange={(e) => setForm((s) => ({ ...s, account_id: e.target.value, received_amount: '' }))}>
                <option value="">— Select —</option>
                {accountOptions.map((a) => <option key={a.id} value={a.id}>{a.account_name} ({a.currency})</option>)}
              </select>
            </Field>
          )}
          <CrossCurrencyField docCurrency={refundInvoice && refundInvoice.currency} account={selectedAccount} label="Amount paid out" value={form.received_amount} onChange={(v) => set('received_amount', v)} />
          <Field label="Reason" full><input className="field-input" value={form.reason} onChange={(e) => set('reason', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Issue Refund'}</button>
        </div>
      </form>
    </Modal>
  );
}
