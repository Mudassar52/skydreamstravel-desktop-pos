import { useEffect, useState } from 'react';
import { DatabaseBackup, Upload, FolderOpen, HardDrive, Files, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import './customers.css';

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

export default function Backup() {
  const { can } = useAuth();
  const [config, setConfig] = useState(null);
  const [info, setInfo] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [confirmRestore, setConfirmRestore] = useState(false);
  const [restoring, setRestoring] = useState(false);

  async function reload() {
    const [c, i] = await Promise.all([window.api.backup.getConfig(), window.api.backup.getInfo()]);
    if (c.ok) setConfig(c.data);
    if (i.ok) setInfo(i.data);
  }
  useEffect(() => { reload(); }, []);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 4000); }

  async function handleBackup() {
    setBusy(true); setError('');
    const res = await window.api.backup.create();
    setBusy(false);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) flash(`Backup saved to ${res.data.filePath}`);
  }

  async function handleChooseFolder() {
    const res = await window.api.backup.chooseFolder();
    if (!res.ok) return setError(res.error);
    if (res.data.chosen) { flash('Backup folder set.'); reload(); }
  }

  async function handleToggleAuto() {
    const res = await window.api.backup.setAutoEnabled(!config.autoBackupEnabled);
    if (!res.ok) return setError(res.error);
    reload();
  }

  async function handleRestore() {
    setRestoring(true);
    setError('');
    const res = await window.api.backup.restore();
    if (!res.ok) {
      setRestoring(false);
      setConfirmRestore(false);
      return setError(res.error);
    }
    if (!res.data.restored) {
      setRestoring(false);
      setConfirmRestore(false);
      return; // dialog was cancelled
    }
    flash('Restore complete. Restarting the application…');
    setTimeout(() => window.api.backup.relaunch(), 1500);
  }

  if (!config || !info) return null;
  const canManage = can('backup', 'edit');

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Backup & Restore</h1>
          <p>Move your complete data — database and documents — to another computer, or protect against data loss.</p>
        </div>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="grid" style={{ gridTemplateColumns: 'repeat(2, 1fr)', gap: 16, marginBottom: 20 }}>
        <div className="card" style={{ padding: '16px 20px', display: 'flex', gap: 12, alignItems: 'center' }}>
          <HardDrive size={20} color="var(--color-primary)" />
          <div>
            <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Database Size</div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>{formatBytes(info.dbSizeBytes)}</div>
          </div>
        </div>
        <div className="card" style={{ padding: '16px 20px', display: 'flex', gap: 12, alignItems: 'center' }}>
          <Files size={20} color="var(--color-primary)" />
          <div>
            <div style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>Documents</div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>{info.documentCount} files · {formatBytes(info.documentsSizeBytes)}</div>
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: '18px 22px', marginBottom: 18 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 6 }}>Backup Now</h3>
        <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', marginBottom: 14 }}>
          Creates one .zip file containing the full database and every uploaded document — everything needed to move the software to another Windows computer.
        </p>
        {config.lastManualBackupAt && (
          <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginBottom: 10 }}>Last manual backup: {new Date(config.lastManualBackupAt).toLocaleString()}</p>
        )}
        {canManage && (
          <button className="btn btn-primary" onClick={handleBackup} disabled={busy}>
            <DatabaseBackup size={15} /> {busy ? 'Backing up…' : 'Backup Now (Choose Location)'}
          </button>
        )}
      </div>

      <div className="card" style={{ padding: '18px 22px', marginBottom: 18 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 6 }}>Automatic Backup</h3>
        <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', marginBottom: 14 }}>
          When enabled, a backup is silently created in the chosen folder once a day, the first time the app is opened that day.
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <label className="checkbox-row" style={{ padding: 0 }}>
            <input type="checkbox" checked={config.autoBackupEnabled} disabled={!canManage} onChange={handleToggleAuto} /> Enable daily automatic backup
          </label>
          {canManage && (
            <button className="btn btn-secondary btn-sm" onClick={handleChooseFolder}><FolderOpen size={13} /> {config.backupLocation ? 'Change Folder' : 'Choose Folder'}</button>
          )}
          {config.backupLocation && <span style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{config.backupLocation}</span>}
        </div>
        {config.lastAutoBackupAt && (
          <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginTop: 10 }}>Last automatic backup: {new Date(config.lastAutoBackupAt).toLocaleString()}</p>
        )}
        {config.autoBackupEnabled && !config.backupLocation && (
          <p style={{ fontSize: 11.5, color: 'var(--color-warning)', marginTop: 10 }}>Choose a folder above — automatic backup is on but has nowhere to save to yet.</p>
        )}
      </div>

      <div className="card" style={{ padding: '18px 22px', borderColor: 'var(--color-danger)' }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 6, color: 'var(--color-danger)' }}>Restore from Backup</h3>
        <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', marginBottom: 14 }}>
          Replaces everything currently in the app — all customers, bookings, invoices, documents, everything — with what's inside the selected backup file. The app restarts automatically afterward.
        </p>
        {canManage && (
          <button className="btn btn-secondary" style={{ borderColor: 'var(--color-danger)', color: 'var(--color-danger)' }} onClick={() => setConfirmRestore(true)}>
            <Upload size={15} /> Restore from Backup File…
          </button>
        )}
      </div>

      {confirmRestore && (
        <Modal title="Restore from backup" onClose={() => !restoring && setConfirmRestore(false)}>
          <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
            <AlertTriangle size={20} color="var(--color-danger)" style={{ flexShrink: 0 }} />
            <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
              This will <strong>permanently replace</strong> all current data with the contents of the backup file you choose next.
              This cannot be undone. Consider taking a fresh backup of the current data first.
            </p>
          </div>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setConfirmRestore(false)} disabled={restoring}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={handleRestore} disabled={restoring}>
              {restoring ? 'Restoring…' : 'Choose File & Restore'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
