import { useEffect, useState } from 'react';
import { FileDown, FileSpreadsheet, Printer, BarChart3, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

// Which filter controls each report type uses.
const FILTER_CONFIG = {
  sales: { dateRange: true, customer: true, status: ['Unpaid', 'Partially Paid', 'Paid', 'Cancelled'] },
  bookings: { dateRange: true, customer: true, status: ['Inquiry', 'Pending', 'Confirmed', 'Cancelled', 'Completed'], type: ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transportation', 'Custom'] },
  customers: {},
  payments: { dateRange: true, customer: true },
  outstanding: { customer: true },
  expenses: { dateRange: true },
  profit: {},
  umrah: {},
  hajj: {},
  tours: {},
  flights: {},
  hotels: {},
  visa: { customer: true, status: ['Documents Pending', 'Ready to Apply', 'Applied', 'Processing', 'Approved', 'Rejected', 'Expired'] },
  ledger: { customer: true }
};

export default function Reports() {
  const { hasCapability } = useAuth();
  const [types, setTypes] = useState([]);
  const [key, setKey] = useState('sales');
  const [filters, setFilters] = useState({ dateFrom: '', dateTo: '', customerId: '', customerLabel: '', status: '', type: '' });
  const [report, setReport] = useState(null);
  const pg = usePagination(report?.rows || [], 50);
  useEffect(() => { pg.reset(); }, [report]);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.reports.listTypes().then((res) => { if (res.ok) setTypes(res.data); }); }, []);

  async function runReport() {
    setLoading(true);
    setError('');
    const res = await window.api.reports.run(key, {
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined,
      customerId: filters.customerId || undefined,
      status: filters.status || undefined,
      type: filters.type || undefined
    });
    setLoading(false);
    if (!res.ok) return setError(res.error);
    setReport(res.data);
  }

  useEffect(() => { runReport(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [key]);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3500); }

  async function handleExportCsv() {
    const res = await window.api.reports.exportCsv(report);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) flash(`Saved to ${res.data.filePath}`);
  }
  async function handleExportPdf() {
    const res = await window.api.reports.exportPdf(report);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) flash(`Saved to ${res.data.filePath}`);
  }
  async function handlePrint() {
    const res = await window.api.reports.print(report);
    if (!res.ok) setError(res.error);
  }

  const config = FILTER_CONFIG[key] || {};

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Reports</h1>
          <p>Filter, view, and export any report as CSV, PDF, or print it directly.</p>
        </div>
      </div>

      <div className="card" style={{ padding: '14px 20px', marginBottom: 16, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <div>
          <label className="field-label">Report</label>
          <select className="field-input" style={{ width: 220 }} value={key} onChange={(e) => setKey(e.target.value)}>
            {types.filter((t) => hasCapability('view_profit') || t.key !== 'profit').map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
          </select>
        </div>

        {config.dateRange && (
          <>
            <div><label className="field-label">From</label><input type="date" className="field-input" value={filters.dateFrom} onChange={(e) => setFilters((f) => ({ ...f, dateFrom: e.target.value }))} /></div>
            <div><label className="field-label">To</label><input type="date" className="field-input" value={filters.dateTo} onChange={(e) => setFilters((f) => ({ ...f, dateTo: e.target.value }))} /></div>
          </>
        )}
        {config.customer && (
          <div style={{ width: 240 }}>
            <label className="field-label">Customer</label>
            <CustomerSearchSelect value={filters.customerId} valueLabel={filters.customerLabel} onChange={(id, label) => setFilters((f) => ({ ...f, customerId: id, customerLabel: label }))} />
          </div>
        )}
        {config.status && (
          <div>
            <label className="field-label">Status</label>
            <select className="field-input" style={{ width: 160 }} value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}>
              <option value="">All</option>
              {config.status.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        )}
        {config.type && (
          <div>
            <label className="field-label">Type</label>
            <select className="field-input" style={{ width: 160 }} value={filters.type} onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value }))}>
              <option value="">All</option>
              {config.type.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        )}

        <button className="btn btn-primary" onClick={runReport} disabled={loading}>
          <BarChart3 size={15} /> {loading ? 'Running…' : 'Run Report'}
        </button>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      {report && (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15 }}>{report.title} <span style={{ color: 'var(--color-text-faint)', fontWeight: 400, fontSize: 12.5 }}>({report.rows.length} rows)</span></h3>
            {hasCapability('export_reports') ? (
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-secondary btn-sm" onClick={handleExportCsv}><FileSpreadsheet size={13} /> CSV</button>
                <button className="btn btn-secondary btn-sm" onClick={handleExportPdf}><FileDown size={13} /> PDF</button>
                <button className="btn btn-secondary btn-sm" onClick={handlePrint}><Printer size={13} /> Print</button>
              </div>
            ) : (
              <span style={{ fontSize: 11.5, color: 'var(--color-text-faint)', display: 'flex', alignItems: 'center', gap: 5 }}><Lock size={12} /> Export is restricted for your role</span>
            )}
          </div>

          <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>{report.columns.map((c) => <th key={c.key}>{c.label}</th>)}</tr>
              </thead>
              <tbody>
                {pg.pageRows.map((row, idx) => (
                  <tr key={idx}>
                    {report.columns.map((c) => (
                      <td key={c.key}>{c.money ? money(row[c.key]) : (row[c.key] ?? '—')}</td>
                    ))}
                  </tr>
                ))}
                {report.rows.length === 0 && <tr><td colSpan={report.columns.length} className="empty-row">No data for this report/filter combination.</td></tr>}
              </tbody>
              {report.totals && (
                <tfoot>
                  <tr style={{ fontWeight: 700, borderTop: '2px solid var(--color-primary)' }}>
                    {report.columns.map((c) => (
                      <td key={c.key}>{report.totals[c.key] !== undefined ? (c.money ? money(report.totals[c.key]) : report.totals[c.key]) : ''}</td>
                    ))}
                  </tr>
                </tfoot>
              )}
            </table>
        <Pagination {...pg.pagerProps} label="rows" />
          </div>
        </>
      )}
    </div>
  );
}
