import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, ChevronLeft, ChevronRight, BedDouble } from 'lucide-react';
import HotelGuestsDrawer from '../components/HotelGuestsDrawer.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const EMPTY = {
  booking_id: '', hotel_name: '', country: '', city: '', address: '', contact: '',
  check_in: '', check_out: '', room_type: '', number_of_rooms: 1, number_of_nights: 1,
  booking_reference: '', cost: '', selling_price: '', notes: ''
};
const PAGE_SIZE = 15;

export default function Hotels() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [bookingOptions, setBookingOptions] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [guestsFor, setGuestsFor] = useState(null);
  const [error, setError] = useState('');
  const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

  async function reload() {
    const [h, b] = await Promise.all([window.api.hotels.list({ search, page, pageSize: PAGE_SIZE }), window.api.bookings.options()]);
    if (h.ok) { setRows(h.data.rows); setTotal(h.data.total); }
    if (b.ok) setBookingOptions(b.data);
  }
  useEffect(() => { reload(); }, [search, page]);
  useEffect(() => { setPage(1); }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  async function confirmDelete() {
    const res = await window.api.hotels.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else reload();
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Hotels</h1>
          <p>{total.toLocaleString()} hotel booking{total === 1 ? '' : 's'}</p>
        </div>
        {can('hotels', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Hotel Booking
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 300 }}>
          <Search size={15} />
          <input placeholder="Search hotel, city, country..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {error && <div className="login-error">{error}</div>}
      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Hotel</th><th>City</th><th>Check-in → Check-out</th><th>Rooms/Nights</th><th>Selling Price</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((h) => (
              <tr key={h.id}>
                <td>{h.hotel_name}</td>
                <td>{[h.city, h.country].filter(Boolean).join(', ') || '—'}</td>
                <td>{h.check_in || '—'} → {h.check_out || '—'}</td>
                <td>{h.number_of_rooms || 0} / {h.number_of_nights || 0}</td>
                <td>{money(h.selling_price)}</td>
                <td className="row-actions">
                  <button className="icon-btn" title="Guests & rooms" onClick={() => setGuestsFor(h)}><BedDouble size={14} /></button>
                  {can('hotels', 'edit') && <button className="icon-btn" onClick={() => { setEditingId(h.id); setFormOpen(true); }}><Pencil size={14} /></button>}
                  {can('hotels', 'delete') && <button className="icon-btn" onClick={() => setDeleteTarget(h)}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="empty-row">No hotel bookings yet.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <HotelFormModal hotelId={editingId} bookingOptions={bookingOptions} onClose={() => setFormOpen(false)} onSaved={() => { setFormOpen(false); reload(); }} />
      )}

      {guestsFor && <HotelGuestsDrawer hotel={guestsFor} onClose={() => setGuestsFor(null)} />}

      {deleteTarget && (
        <Modal title="Delete hotel booking" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.hotel_name}</strong>?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function HotelFormModal({ hotelId, bookingOptions, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (hotelId) window.api.hotels.get(hotelId).then((res) => { if (res.ok) setForm({ ...EMPTY, ...res.data }); });
  }, [hotelId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.hotel_name.trim()) return setError('Hotel name is required.');
    setSaving(true);
    const res = hotelId ? await window.api.hotels.update(hotelId, form) : await window.api.hotels.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved();
  }

  return (
    <Modal title={hotelId ? 'Edit Hotel Booking' : 'New Hotel Booking'} onClose={onClose} width={580}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Booking (optional)" full>
            <select className="field-input" value={form.booking_id || ''} onChange={(e) => set('booking_id', e.target.value ? Number(e.target.value) : '')}>
              <option value="">— Not linked to a booking —</option>
              {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
            </select>
          </Field>
          <Field label="Hotel Name *" full><input className="field-input" value={form.hotel_name} onChange={(e) => set('hotel_name', e.target.value)} /></Field>
          <Field label="Country"><input className="field-input" value={form.country || ''} onChange={(e) => set('country', e.target.value)} /></Field>
          <Field label="City"><input className="field-input" value={form.city || ''} onChange={(e) => set('city', e.target.value)} /></Field>
          <Field label="Address" full><input className="field-input" value={form.address || ''} onChange={(e) => set('address', e.target.value)} /></Field>
          <Field label="Contact"><input className="field-input" value={form.contact || ''} onChange={(e) => set('contact', e.target.value)} /></Field>
          <Field label="Room Type"><input className="field-input" value={form.room_type || ''} onChange={(e) => set('room_type', e.target.value)} /></Field>
          <Field label="Check-in"><input type="date" className="field-input" value={form.check_in || ''} onChange={(e) => set('check_in', e.target.value)} /></Field>
          <Field label="Check-out" error={error === 'Check-out date cannot be before check-in date.' ? error : undefined}>
            <input type="date" className="field-input" value={form.check_out || ''} onChange={(e) => set('check_out', e.target.value)} />
          </Field>
          <Field label="Number of Rooms"><input type="number" className="field-input" value={form.number_of_rooms} onChange={(e) => set('number_of_rooms', e.target.value)} /></Field>
          <Field label="Number of Nights"><input type="number" className="field-input" value={form.number_of_nights} onChange={(e) => set('number_of_nights', e.target.value)} /></Field>
          <Field label="Booking Reference"><input className="field-input" value={form.booking_reference || ''} onChange={(e) => set('booking_reference', e.target.value)} /></Field>
          <Field label="Cost (Rs.)"><input type="number" className="field-input" value={form.cost || ''} onChange={(e) => set('cost', e.target.value)} /></Field>
          <Field label="Selling Price (Rs.)"><input type="number" className="field-input" value={form.selling_price || ''} onChange={(e) => set('selling_price', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Hotel Booking'}</button>
        </div>
      </form>
    </Modal>
  );
}
