import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CalendarCheck, RefreshCw, FileDown, Printer, FileSpreadsheet, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import './customers.css';
import { Paged } from '../components/Pagination.jsx';

// Package 360 (master prompt: Package Dossier / sold-from analytics).
// "Sold" figures come from bookings linked to this package (bookings.package_id)
// via window.api.package360.dossier — real invoices/payments, not the package's
// own listed price. A cancelled booking is listed but excluded from revenue.

const money = (currency) => (n) => {
  const v = Number(n || 0);
  try { return new Intl.NumberFormat('en-GB', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v); }
  catch (_) { return `${currency} ${v.toLocaleString()}`; }
};
const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function PackageDossier() {
  const { packageId } = useParams();
  const id = Number(packageId);
  const navigate = useNavigate();
  const { can, hasCapability } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const res = await window.api.package360.dossier(id);
    setLoading(false);
    if (!res.ok) return setError(res.error);
    setData(res.data);
  }, [id]);
  useEffect(() => { load(); }, [load]);

  const m = useMemo(() => money(data?.header.currency || 'PKR'), [data]);

  if (loading && !data) return <div className="card" style={{ padding: 30 }}>Loading package dossier…</div>;
  if (error) {
    return (
      <div className="card" style={{ padding: 30 }}>
        <p className="login-error">{error}</p>
        <button className="btn btn-secondary" onClick={load}><RefreshCw size={14} /> Retry</button>
      </div>
    );
  }
  const { header, summary, bookings } = data;

  async function exportDossier(format) {
    const sections = [
      { title: 'Package Info', columns: (hasCapability('view_profit') ? ['package_name', 'package_type', 'destination', 'duration', 'selling_price', 'estimated_cost', 'estimated_profit'] : ['package_name', 'package_type', 'destination', 'duration', 'selling_price']).map((k) => ({ key: k, label: k, money: ['selling_price', 'estimated_cost', 'estimated_profit'].includes(k) })), rows: [header] },
      { title: 'Components', columns: [{ key: 'component_type', label: 'Component' }, { key: 'description', label: 'Description' }, { key: 'supplier_name', label: 'Supplier' }, ...(hasCapability('view_profit') ? [{ key: 'cost', label: 'Cost', money: true }] : []), { key: 'selling_price', label: 'Selling', money: true }], rows: header.components },
      { title: 'Bookings', columns: [{ key: 'booking_code', label: 'Booking #' }, { key: 'customer_name', label: 'Customer' }, { key: 'selling', label: 'Selling', money: true }, { key: 'paid', label: 'Paid', money: true }, ...(hasCapability('view_profit') ? [{ key: 'profit', label: 'Profit', money: true }] : []), { key: 'status', label: 'Status' }], rows: bookings }
    ];
    const reportData = { title: `Package Dossier - ${header.package_name}`, dateRangeLabel: 'All dates', filtersSummary: `Revenue: ${m(summary.sold.revenue)} | Profit: ${m(summary.sold.profit)}`, sections };
    let res;
    if (format === 'pdf') res = await window.api.reportExport.exportPdf(reportData);
    else if (format === 'print') res = await window.api.reportExport.print(reportData);
    else res = await window.api.reportExport.exportExcel(sections.map((s) => ({ name: s.title, columns: s.columns, rows: s.rows })), `Package-Dossier-${header.package_name}.xlsx`);
    if (!res.ok) window.alert(res.error);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="link-cell" onClick={() => navigate('/packages')} style={{ marginBottom: 6, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <ArrowLeft size={13} /> Back to Packages
          </button>
          <h1>{header.package_name}</h1>
          <p>{header.package_type} · {header.destination || 'No destination set'} · <span className={`status-pill ${header.status === 'Active' ? 'on' : 'off'}`}>{header.status}</span></p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {hasCapability('export_reports') && (
            <>
              <button className="btn btn-secondary" onClick={() => exportDossier('pdf')}><FileDown size={14} /> PDF</button>
              <button className="btn btn-secondary" onClick={() => exportDossier('excel')}><FileSpreadsheet size={14} /> Excel</button>
              <button className="btn btn-secondary" onClick={() => exportDossier('print')}><Printer size={14} /> Print</button>
            </>
          )}
          {header.status === 'Active' && can('bookings', 'create') && (
            <button className="btn btn-primary" onClick={() => navigate('/bookings', { state: { openAdd: true, packageId: header.id, packageType: header.package_type } })}>
              <CalendarCheck size={14} /> Book This Package
            </button>
          )}
        </div>
      </div>

      <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 12 }}>Package Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 24px', fontSize: 13 }}>
          <Info label="Duration" value={header.duration} />
          <Info label="Departure" value={day(header.departure_date)} />
          <Info label="Return" value={day(header.return_date)} />
          <Info label="List Price" value={m(header.selling_price)} />
          {hasCapability('view_profit') && <Info label="Estimated Cost" value={m(header.estimated_cost)} />}
          {hasCapability('view_profit') && <Info label="Estimated Profit" value={m(header.estimated_profit)} />}
          {hasCapability('view_profit') && <Info label="Estimated Margin" value={header.estimated_margin_percent === null ? '—' : `${header.estimated_margin_percent}%`} />}
          <Info label="Currency" value={header.currency} />
          <Info label="Description" value={header.description} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 12, marginBottom: 16 }}>
        {[
          ['Total Bookings', summary.bookings.total],
          ['Active', summary.bookings.active],
          ['Completed', summary.bookings.completed],
          ['Cancelled', summary.bookings.cancelled],
          ['Revenue (billed)', m(summary.sold.revenue)],
          ['Collected', m(summary.sold.collected)],
          ['Outstanding', m(summary.sold.outstanding), summary.sold.outstanding > 0 ? 'var(--color-danger)' : undefined],
          ...(hasCapability('view_profit') ? [
            ['Total Cost', m(summary.sold.cost)],
            ['Profit', m(summary.sold.profit), summary.sold.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)'],
            ['Margin', summary.sold.margin_percent === null ? '—' : `${summary.sold.margin_percent}%`]
          ] : [])
        ].map(([label, value, color]) => (
          <div key={label} className="card" style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: color || 'inherit', marginTop: 2 }}>{value}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: '18px 22px', marginBottom: 16 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 12 }}>Package Components</h3>
        <table className="data-table">
          <thead><tr><th>Component</th><th>Description</th><th>Supplier</th>{hasCapability('view_profit') && <th style={{ textAlign: 'right' }}>Cost</th>}<th style={{ textAlign: 'right' }}>Selling</th></tr></thead>
          <tbody>
            {header.components.map((c) => (
              <tr key={c.id}><td>{c.component_type}</td><td>{c.description || '—'}</td><td>{c.supplier_name || '—'}</td>
                {hasCapability('view_profit') && <td style={{ textAlign: 'right' }}>{m(c.cost)}</td>}<td style={{ textAlign: 'right' }}>{m(c.selling_price)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ padding: '18px 22px' }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 4 }}>Bookings from this Package</h3>
        {summary.suppliers.length > 0 && (
          <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 10 }}>Suppliers on this package: {summary.suppliers.join(', ')}</p>
        )}
        <Paged rows={bookings} size={25} label="bookings">{(pageRows) => (
        <table className="data-table">
          <thead><tr><th>Booking</th><th>Customer</th><th>Date</th><th>Departure</th><th>Selling</th><th>Paid</th><th>Outstanding</th>{hasCapability('view_profit') && <><th>Cost</th><th>Profit</th></>}<th>Status</th></tr></thead>
          <tbody>
            {bookings.length === 0 && <tr><td colSpan={10} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No bookings from this package yet</td></tr>}
            {pageRows.map((b) => (
              <tr key={b.id}>
                <td><button className="link-cell" onClick={() => navigate(`/customers/${b.customer_id}/360`)}>{b.booking_code}</button></td>
                <td>{b.customer_name || '—'}</td><td>{day(b.booking_date)}</td><td>{day(b.departure_date)}</td>
                <td>{m(b.selling)}</td><td>{m(b.paid)}</td>
                <td style={{ color: b.outstanding > 0 ? 'var(--color-danger)' : 'inherit' }}>{m(b.outstanding)}</td>
                {hasCapability('view_profit') && <><td>{m(b.cost)}</td>
                <td style={{ color: b.profit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>{m(b.profit)}</td></>}
                <td>{b.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
        )}</Paged>
      </div>
    </div>
  );
}

function Info({ label, value }) {
  return <div><div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>{label}</div><div>{value || '—'}</div></div>;
}
