import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Star, Code } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';
import Pagination, { usePagination } from '../components/Pagination.jsx';

export default function InvoiceTemplates() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [tokens, setTokens] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const [t, tok] = await Promise.all([window.api.invoiceTemplates.list(), window.api.invoiceTemplates.tokens()]);
    if (t.ok) setRows(t.data);
    if (tok.ok) setTokens(tok.data);
  }
  useEffect(() => { reload(); }, []);

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function makeDefault(id) {
    const res = await window.api.invoiceTemplates.setDefault(id);
    if (!res.ok) setError(res.error); else { flash('Default template updated.'); reload(); }
  }

  async function confirmDelete() {
    const res = await window.api.invoiceTemplates.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Template deleted.'); reload(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Invoice Templates</h1>
          <p>Invoice visual designs — fully independent from customer, booking and payment data. Add as many as you like.</p>
        </div>
        {can('invoice_templates', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> New Template
          </button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0, marginBottom: 20 }}>
        <table className="data-table">
          <thead><tr><th>Template</th><th>Status</th><th>Default</th><th></th></tr></thead>
          <tbody>
            {pg.pageRows.map((t) => (
              <tr key={t.id}>
                <td>{t.template_name}</td>
                <td><span className={`status-pill ${t.status === 'Active' ? 'on' : 'off'}`}>{t.status}</span></td>
                <td>
                  {t.is_default ? (
                    <span className="role-badge"><Star size={11} style={{ verticalAlign: 'text-bottom', marginRight: 4 }} />Default</span>
                  ) : (
                    can('invoice_templates', 'edit') && (
                      <button className="btn btn-secondary btn-sm" onClick={() => makeDefault(t.id)}>Set as Default</button>
                    )
                  )}
                </td>
                <td className="row-actions">
                  {can('invoice_templates', 'edit') && (
                    <button className="icon-btn" onClick={() => { setEditingId(t.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('invoice_templates', 'delete') && !t.is_default && (
                    <button className="icon-btn" onClick={() => setDeleteTarget(t)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={4} className="empty-row">No templates yet.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="templates" />
      </div>

      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <Code size={15} color="var(--color-primary)" />
          <strong style={{ fontSize: 13.5 }}>Available tokens</strong>
        </div>
        <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 10 }}>
          Use these inside a template's HTML. Double braces are HTML-escaped; the line-items token uses triple braces since it's pre-rendered HTML.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '4px 20px' }}>
          {tokens.map((t) => (
            <div key={t.token} style={{ fontSize: 12 }}>
              <code style={{ background: 'var(--color-primary-light)', color: 'var(--color-primary)', padding: '1px 6px', borderRadius: 4 }}>{t.token}</code>
              <span style={{ color: 'var(--color-text-muted)', marginLeft: 8 }}>{t.description}</span>
            </div>
          ))}
        </div>
      </div>

      {formOpen && (
        <TemplateFormModal
          templateId={editingId}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); reload(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete template" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.template_name}</strong>?</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function TemplateFormModal({ templateId, onClose, onSaved }) {
  const [form, setForm] = useState({ template_name: '', status: 'Active', html: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (templateId) {
      window.api.invoiceTemplates.get(templateId).then((res) => {
        if (res.ok) setForm({ template_name: res.data.template_name, status: res.data.status, html: res.data.html });
      });
    }
  }, [templateId]);

  async function submit(e) {
    e.preventDefault();
    if (!form.template_name.trim()) return setError('Template name is required.');
    if (!form.html.trim()) return setError('Template HTML cannot be empty.');
    setSaving(true);
    const res = templateId ? await window.api.invoiceTemplates.update(templateId, form) : await window.api.invoiceTemplates.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(templateId ? 'Template updated.' : 'Template created.');
  }

  return (
    <Modal title={templateId ? 'Edit Template' : 'New Template'} onClose={onClose} width={720}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Template Name *"><input className="field-input" value={form.template_name} onChange={(e) => setForm((s) => ({ ...s, template_name: e.target.value }))} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => setForm((s) => ({ ...s, status: e.target.value }))}>
              <option>Active</option><option>Inactive</option>
            </select>
          </Field>
          <Field label="Template HTML *" full>
            <textarea
              className="field-input"
              style={{ fontFamily: 'monospace', fontSize: 11.5 }}
              rows={16}
              value={form.html}
              onChange={(e) => setForm((s) => ({ ...s, html: e.target.value }))}
            />
          </Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Template'}</button>
        </div>
      </form>
    </Modal>
  );
}
