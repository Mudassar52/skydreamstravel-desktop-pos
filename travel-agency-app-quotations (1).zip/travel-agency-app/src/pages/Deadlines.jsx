import { useEffect, useState, useCallback } from 'react';
import { Plus, Check, ChevronLeft, ChevronRight, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['All', 'Pending', 'Overdue', 'Completed', 'Cancelled'];
const pillTone = (s) => (s === 'Overdue' ? 'off' : s === 'Cancelled' ? 'off' : 'on');

export default function Deadlines() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [deadlineType, setDeadlineType] = useState('All');
  const [types, setTypes] = useState([]);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.deadlines.types().then((res) => res.ok && setTypes(res.data)); }, []);

  const load = useCallback(async () => {
    const res = await window.api.deadlines.list({ search, status, deadlineType, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, deadlineType, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status, deadlineType]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function complete(row) {
    const res = await window.api.deadlines.markStatus(row.id, 'Completed');
    if (!res.ok) setError(res.error); else { flash('Deadline marked completed.'); load(); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Deadlines</h1>
          <p>{total.toLocaleString()} deadline{total === 1 ? '' : 's'} — reservation, ticketing, payment, visa, and cancellation windows</p>
        </div>
        {can('deadlines', 'create') && (
          <button className="btn btn-primary" onClick={() => setFormOpen(true)}><Plus size={15} /> Add Deadline</button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 260 }}>
          <input placeholder="Search title, booking, traveller..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 160 }} value={deadlineType} onChange={(e) => setDeadlineType(e.target.value)}>
          <option value="All">All types</option>
          {types.map((t) => <option key={t}>{t}</option>)}
        </select>
        <select className="field-input" style={{ width: 150 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Type</th><th>Title</th><th>Booking</th><th>Due Date</th><th>Reminder</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((d) => (
              <tr key={d.id}>
                <td>{d.deadline_type}</td>
                <td>{d.title || '—'}</td>
                <td>{d.booking_code || '—'}</td>
                <td>{d.due_date}</td>
                <td>
                  {d.reminderLevel && (
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11.5, color: d.reminderLevel === 'Overdue' ? 'var(--color-danger)' : 'var(--color-warning, #b45309)' }}>
                      <AlertTriangle size={12} /> {d.reminderLevel}
                    </span>
                  )}
                </td>
                <td><span className={`status-pill ${pillTone(d.effective_status)}`}>{d.effective_status}</span></td>
                <td className="row-actions">
                  {!['Completed', 'Cancelled'].includes(d.effective_status) && can('deadlines', 'edit') && (
                    <button className="icon-btn" title="Mark Completed" onClick={() => complete(d)}><Check size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No deadlines found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <DeadlineFormModal onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}
    </div>
  );
}

const EMPTY = { deadline_type: 'Visa', title: '', due_date: '', notes: '' };

function DeadlineFormModal({ onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [types, setTypes] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.deadlines.types().then((res) => res.ok && setTypes(res.data)); }, []);
  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.due_date) return setError('Due date is required.');
    setSaving(true);
    const res = await window.api.deadlines.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved('Deadline added.');
  }

  return (
    <Modal title="Add Deadline" onClose={onClose} width={460}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Deadline Type *">
            <select className="field-input" value={form.deadline_type} onChange={(e) => set('deadline_type', e.target.value)}>
              {types.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Due Date *"><input type="date" className="field-input" value={form.due_date} onChange={(e) => set('due_date', e.target.value)} /></Field>
          <Field label="Title" full><input className="field-input" value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="e.g. Submit visa documents" /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Add Deadline'}</button>
        </div>
      </form>
    </Modal>
  );
}
