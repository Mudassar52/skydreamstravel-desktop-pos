import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Wallet, FolderOpen } from 'lucide-react';
import './customers.css';

// Customer Advances (master prompt section 44, Finance group). Lists every
// standalone advance payment across every customer - a booking-tied advance
// is absorbed automatically when its invoice is generated (see
// advanceService.js) so it is not listed here as something to act on.

const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const day = (s) => (s ? String(s).slice(0, 10) : '—');

export default function CustomerAdvances() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [onlyAvailable, setOnlyAvailable] = useState(true);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const pageSize = 20;

  const load = useCallback(async () => {
    const res = await window.api.advances.listAll({ search, onlyAvailable, page, pageSize });
    if (res.ok) setData(res.data); else setError(res.error);
  }, [search, onlyAvailable, page]);
  useEffect(() => { load(); }, [load]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;

  return (
    <div>
      <div className="page-header">
        <div><h1>Customer Advances</h1><p>Standalone advance payments not yet applied to an invoice - apply them from a customer's invoice drawer.</p></div>
      </div>

      {data && (
        <div className="card" style={{ padding: '14px 18px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
          <Wallet size={18} color="var(--color-primary)" />
          <div>
            <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>Total Available Advance</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{money(data.totalAvailable)}</div>
          </div>
        </div>
      )}

      <div className="card" style={{ padding: '14px 18px', marginBottom: 16, display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="global-search" style={{ width: 240 }}>
          <Search size={14} />
          <input placeholder="Search by customer name" value={search} onChange={(e) => { setPage(1); setSearch(e.target.value); }} />
        </div>
        <label style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 6 }}>
          <input type="checkbox" checked={onlyAvailable} onChange={(e) => { setPage(1); setOnlyAvailable(e.target.checked); }} /> Only show advances with a remaining balance
        </label>
      </div>

      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="data-table">
          <thead><tr><th>Customer</th><th>Date</th><th>Method</th><th>Reference</th><th>Amount</th><th>Applied</th><th>Available</th><th></th></tr></thead>
          <tbody>
            {!data && <tr><td colSpan={8} style={{ padding: 24 }}>Loading…</td></tr>}
            {data && data.rows.length === 0 && <tr><td colSpan={8} style={{ padding: 24, textAlign: 'center', color: 'var(--color-text-muted)' }}>No advances found.</td></tr>}
            {data && data.rows.map((r) => (
              <tr key={r.id}>
                <td><strong>{r.customer_name}</strong></td>
                <td>{day(r.payment_date)}</td>
                <td>{r.payment_method}</td>
                <td>{r.reference || '—'}</td>
                <td>{money(r.amount)}</td>
                <td>{money(r.applied)}</td>
                <td style={{ fontWeight: 600, color: r.available > 0 ? 'var(--color-success)' : 'inherit' }}>{money(r.available)}</td>
                <td><button className="icon-btn" title="Open Customer Dossier" onClick={() => navigate(`/customers/${r.customer_id}/360`)}><FolderOpen size={14} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data && data.total > pageSize && (
        <div className="pagination">
          <button className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button className="btn btn-secondary btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
