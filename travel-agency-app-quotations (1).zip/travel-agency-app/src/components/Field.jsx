export default function Field({ label, error, full, children }) {
  return (
    <div style={{ gridColumn: full ? '1 / -1' : 'auto' }}>
      {label && <label className="field-label">{label}</label>}
      {children}
      {error && <div className="field-error">{error}</div>}
    </div>
  );
}
