import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

/** Who stays at this hotel and in which room. The lead customer + the booking's travellers; printed on the hotel voucher. */
export default function HotelGuestsDrawer({ hotel, onClose }) {
  const [guests, setGuests] = useState(null);
  const [linked, setLinked] = useState(true);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    window.api.hotels.guests.list(hotel.id).then((res) => {
      if (!res.ok) return setError(res.error);
      setLinked(res.data.linked);
      setGuests(res.data.guests);
    });
  }, [hotel.id]);

  const patch = (i, p) => { setSaved(false); setGuests((g) => g.map((x, idx) => (idx === i ? { ...x, ...p } : x))); };

  async function save() {
    setError('');
    const res = await window.api.hotels.guests.update(hotel.id, guests);
    if (!res.ok) return setError(res.error);
    setSaved(true);
  }

  const selected = (guests || []).filter((g) => g.selected).length;
  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <strong>Guests &amp; Rooms — {hotel.hotel_name}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="drawer-body">
          {error && <div className="login-error" style={{ marginBottom: 8 }}>{error}</div>}
          {!linked && <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>Link this hotel stay to a booking first (Edit → Booking), then its family/group members appear here.</p>}
          {guests && linked && (
            <>
              <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', marginTop: 0 }}>
                Tick who stays here and type their room. Only ticked guests are printed on the hotel voucher. Add more people from Bookings → Travellers.
              </p>
              {guests.map((g, i) => (
                <div className="member-row" key={g.traveller_id ?? 'lead'} style={{ alignItems: 'center', gap: 8 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
                    <input type="checkbox" checked={g.selected} onChange={(e) => patch(i, { selected: e.target.checked })} />
                    <span>
                      <div>{g.name}</div>
                      <div className="member-meta">{g.relationship}</div>
                    </span>
                  </label>
                  <input className="field-input" style={{ width: 96 }} placeholder="Room" value={g.room_number} disabled={!g.selected}
                    onChange={(e) => patch(i, { room_number: e.target.value })} />
                </div>
              ))}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12 }}>
                <button className="btn btn-primary btn-sm" onClick={save}>Save</button>
                <span style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>{saved ? 'Saved.' : `${selected} of ${guests.length} guests selected`}</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
