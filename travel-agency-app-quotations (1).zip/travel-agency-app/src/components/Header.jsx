import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Bell, LogOut, Loader2, ChevronDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { logoIconSrc } from './brandLogo.js';
import './header.css';

export default function Header({ title }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const initial = (user?.fullName || '?').trim().charAt(0).toUpperCase();

  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searching, setSearching] = useState(false);

  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const searchTimer = useRef(null);

  useEffect(() => {
    refreshUnread();
    const interval = setInterval(refreshUnread, 30000);
    return () => clearInterval(interval);
  }, []);

  function refreshUnread() {
    window.api?.notifications?.unreadCount().then((res) => { if (res.ok) setUnreadCount(res.data); });
  }

  function onSearchChange(value) {
    setQuery(value);
    setSearchOpen(true);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    if (!value.trim()) { setResults(null); return; }
    setSearching(true);
    searchTimer.current = setTimeout(async () => {
      const res = await window.api.search.query(value);
      setSearching(false);
      if (res.ok) setResults(res.data);
    }, 250);
  }

  function openResult(item) {
    setSearchOpen(false);
    setQuery('');
    setResults(null);
    navigate(item.route);
  }

  async function openNotifications() {
    setProfileOpen(false);
    setNotifOpen((v) => !v);
    if (!notifOpen) {
      const res = await window.api.notifications.list({ limit: 20 });
      if (res.ok) setNotifications(res.data);
    }
  }

  async function markRead(n) {
    await window.api.notifications.markRead(n.id);
    setNotifications((list) => list.map((x) => (x.id === n.id ? { ...x, is_read: 1 } : x)));
    refreshUnread();
    if (n.record_type === 'invoices') navigate('/invoices');
    else if (n.record_type === 'supplier_invoices') navigate('/supplier-invoices');
    else if (n.record_type === 'deadlines') navigate('/deadlines');
    else if (n.record_type === 'travellers') navigate('/travellers');
    else if (n.record_type === 'follow_ups') navigate('/followups');
    else if (n.record_type === 'tasks') navigate('/tasks');
    else if (n.record_type === 'bookings') navigate('/bookings');
    setNotifOpen(false);
  }

  async function markAll() {
    await window.api.notifications.markAllRead();
    setNotifications((list) => list.map((x) => ({ ...x, is_read: 1 })));
    setUnreadCount(0);
  }

  return (
    <header className="app-header">
      <div className="header-title">
        {logoIconSrc
          ? <img className="header-logo" src={logoIconSrc} alt={title} title={title} draggable={false} />
          : <h2>{title}</h2>}
      </div>

      <div className="header-actions">
        <div style={{ position: 'relative' }}>
          <div className="global-search">
            <Search size={15} />
            <input
              placeholder="Search customers, bookings, invoices..."
              value={query}
              onFocus={() => setSearchOpen(true)}
              onChange={(e) => onSearchChange(e.target.value)}
            />
            {searching && <Loader2 size={13} className="spin" />}
          </div>
          {searchOpen && results && (
            <div className="search-dropdown">
              {results.groups.length === 0 && <div className="search-empty">No results for "{results.query}"</div>}
              {results.groups.map((g) => (
                <div key={g.category}>
                  <div className="search-group-label">{g.category}</div>
                  {g.items.map((item) => (
                    <button key={`${g.category}-${item.id}`} className="search-result" onClick={() => openResult(item)}>
                      <span>{item.label}</span>
                      <span className="search-result-sub">{item.sub}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          )}
          {searchOpen && (
            <button className="search-scrim" onClick={() => setSearchOpen(false)} tabIndex={-1} />
          )}
        </div>

        <div style={{ position: 'relative' }}>
          <button className="icon-btn" title="Notifications" onClick={openNotifications}>
            <Bell size={17} />
            {unreadCount > 0 && <span className="notif-badge">{unreadCount > 99 ? '99+' : unreadCount}</span>}
          </button>
          {notifOpen && (
            <div className="notif-dropdown">
              <div className="notif-dropdown-header">
                <strong>Notifications</strong>
                <button className="link-btn" onClick={markAll}>Mark all read</button>
              </div>
              {notifications.length === 0 && <div className="search-empty">No notifications.</div>}
              {notifications.map((n) => (
                <button key={n.id} className={`notif-item ${n.is_read ? '' : 'unread'}`} onClick={() => markRead(n)}>
                  <strong>{n.title}</strong>
                  {n.message && <span>{n.message}</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="profile-wrap">
          <button
            type="button"
            className={`profile-menu${profileOpen ? ' open' : ''}`}
            onClick={() => { setNotifOpen(false); setProfileOpen((v) => !v); }}
          >
            <div className="avatar">{initial}</div>
            <div className="profile-text">
              <strong>{user?.fullName}</strong>
              <span>{user?.role}</span>
            </div>
            <ChevronDown size={15} className="profile-chevron" />
          </button>
          {profileOpen && (
            <>
              <button className="profile-scrim" onClick={() => setProfileOpen(false)} tabIndex={-1} aria-label="Close menu" />
              <div className="profile-dropdown">
                <div className="profile-dropdown-head">
                  <div className="avatar">{initial}</div>
                  <div>
                    <strong>{user?.fullName}</strong>
                    <span>{user?.role}</span>
                  </div>
                </div>
                <button className="profile-item" onClick={() => { setProfileOpen(false); logout(); }}>
                  <LogOut size={16} /> Logout
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
