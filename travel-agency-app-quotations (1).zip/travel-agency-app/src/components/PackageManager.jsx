import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, ChevronLeft, ChevronRight, X as XIcon, CalendarCheck, FolderOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from './Modal.jsx';
import Field from './Field.jsx';
import '../pages/customers.css';
import Pagination, { usePagination } from './Pagination.jsx';

const PAGE_SIZE = 15;
const ALL_PACKAGE_TYPES = ['Umrah', 'Hajj', 'Tour', 'Custom'];
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

/**
 * The central Package Management UI (list + form), shared by the generic
 * Packages page and by the Umrah/Hajj "Packages" tabs. Pass `fixedType` to
 * lock everything to one package_type (hides the type picker/filter) so an
 * Umrah page only ever creates/sees Umrah packages, while still writing to
 * the one shared `packages` table behind the scenes.
 */
export default function PackageManager({ fixedType, permissionModule = 'packages', showBookAction = true }) {
  const { can } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const pg = usePagination(rows, 25);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [packageType, setPackageType] = useState(fixedType || 'All');
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.packages.list({ search, packageType: fixedType || packageType, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, packageType, page, fixedType]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, packageType]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.packages.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Package deleted.'); load(); }
    setDeleteTarget(null);
  }

  function bookPackage(pkg) {
    navigate('/bookings', { state: { openAdd: true, packageId: pkg.id, packageType: pkg.package_type } });
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 10, flexWrap: 'wrap' }}>
        <div className="global-search" style={{ width: 280 }}>
          <input placeholder="Search package or destination..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {!fixedType && (
            <select className="field-input" style={{ width: 160 }} value={packageType} onChange={(e) => setPackageType(e.target.value)}>
              <option value="All">All package types</option>
              {ALL_PACKAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          )}
          {can(permissionModule, 'create') && (
            <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}><Plus size={15} /> New Package</button>
          )}
        </div>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Package</th>
              {!fixedType && <th>Type</th>}
              <th>Destination</th><th>Duration</th><th>Components</th><th>Package Price</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {pg.pageRows.map((p) => (
              <tr key={p.id}>
                <td>{p.package_name}</td>
                {!fixedType && <td><span className="status-pill on">{p.package_type}</span></td>}
                <td>{p.destination || '—'}</td>
                <td>{p.duration || '—'}</td>
                <td>{p.component_count}</td>
                <td>{money(p.package_price)}</td>
                <td><span className={`status-pill ${p.status === 'Active' ? 'on' : 'off'}`}>{p.status}</span></td>
                <td className="row-actions">
                  {can('packages', 'view') && <button className="icon-btn" title="Open Package Dossier" onClick={() => navigate(`/packages/${p.id}/360`)}><FolderOpen size={14} /></button>}
                  {showBookAction && p.status === 'Active' && can('bookings', 'create') && (
                    <button className="icon-btn" title="Book This Package" onClick={() => bookPackage(p)}><CalendarCheck size={14} /></button>
                  )}
                  {can(permissionModule, 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(p.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can(permissionModule, 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(p)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={fixedType ? 7 : 8} className="empty-row">No packages found.</td></tr>}
          </tbody>
        </table>
        <Pagination {...pg.pagerProps} label="packages" />
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <PackageFormModal
          packageId={editingId}
          fixedType={fixedType}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete package" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.package_name}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function emptyForm(fixedType) {
  return {
    package_name: '', package_type: fixedType || 'Umrah', destination: '', duration: '',
    departure_date: '', return_date: '', number_of_days: '',
    description: '', supplier_cost: 0, selling_price: 0, currency: 'PKR', status: 'Active', components: []
  };
}
const EMPTY_COMPONENT = { component_type: '', description: '', cost: 0, selling_price: 0, supplier_id: '' };

function PackageFormModal({ packageId, fixedType, onClose, onSaved }) {
  const [form, setForm] = useState(emptyForm(fixedType));
  const [componentTypesByType, setComponentTypesByType] = useState({});
  const [suppliers, setSuppliers] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.packages.componentTypesByType().then((res) => res.ok && setComponentTypesByType(res.data));
    window.api.suppliers.options().then((res) => res.ok && setSuppliers(res.data));
  }, []);
  useEffect(() => {
    if (!packageId) return;
    window.api.packages.get(packageId).then((res) => { if (res.ok) setForm({ ...emptyForm(fixedType), ...res.data }); });
  }, [packageId, fixedType]);

  const allowedComponentTypes = componentTypesByType[form.package_type] || [];

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }
  function changePackageType(newType) {
    const allowed = componentTypesByType[newType] || [];
    setForm((s) => ({ ...s, package_type: newType, components: s.components.filter((c) => allowed.includes(c.component_type)) }));
  }
  function setComponent(idx, f, v) {
    setForm((s) => ({ ...s, components: s.components.map((c, i) => (i === idx ? { ...c, [f]: v } : c)) }));
  }
  function addComponent() {
    setForm((s) => ({ ...s, components: [...s.components, { ...EMPTY_COMPONENT, component_type: allowedComponentTypes[0] || '' }] }));
  }
  function removeComponent(idx) { setForm((s) => ({ ...s, components: s.components.filter((_, i) => i !== idx) })); }

  const componentCostTotal = form.components.reduce((sum, c) => sum + Number(c.cost || 0), 0);
  const componentSellTotal = form.components.reduce((sum, c) => sum + Number(c.selling_price || 0), 0);
  const estimatedProfit = Number(form.selling_price || 0) - componentCostTotal;

  async function submit(e) {
    e.preventDefault();
    if (!form.package_name.trim()) return setError('Package name is required.');
    setSaving(true);
    const res = packageId ? await window.api.packages.update(packageId, form) : await window.api.packages.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(packageId ? 'Package updated.' : 'Package created.');
  }

  return (
    <Modal title={packageId ? 'Edit Package' : 'New Package'} onClose={onClose} width={700}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          {!fixedType && (
            <Field label="Package Type *">
              <select className="field-input" value={form.package_type} onChange={(e) => changePackageType(e.target.value)}>
                {ALL_PACKAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
          )}
          <Field label="Package Name *" full><input className="field-input" value={form.package_name} onChange={(e) => set('package_name', e.target.value)} /></Field>
          <Field label="Destination"><input className="field-input" value={form.destination || ''} onChange={(e) => set('destination', e.target.value)} /></Field>
          <Field label="Duration"><input className="field-input" value={form.duration || ''} onChange={(e) => set('duration', e.target.value)} placeholder="e.g. 15 Days" /></Field>
          <Field label="Departure Date"><input type="date" className="field-input" value={form.departure_date || ''} onChange={(e) => set('departure_date', e.target.value)} /></Field>
          <Field label="Return Date"><input type="date" className="field-input" value={form.return_date || ''} onChange={(e) => set('return_date', e.target.value)} /></Field>
          <Field label="Estimated Cost (auto)">
            <input className="field-input" value={money(componentCostTotal)} disabled style={{ background: 'var(--color-bg)', color: 'var(--color-text-muted)' }} />
          </Field>
          <Field label="Package Price *"><input type="number" className="field-input" value={form.selling_price} onChange={(e) => set('selling_price', e.target.value)} /></Field>
          <Field label="Estimated Profit (auto)">
            <input className="field-input" value={money(estimatedProfit)} disabled style={{ background: 'var(--color-bg)', color: estimatedProfit < 0 ? 'var(--color-danger)' : 'var(--color-success)' }} />
          </Field>
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              <option>Active</option><option>Inactive</option>
            </select>
          </Field>
          <Field label="Description" full><textarea className="field-input" rows={2} value={form.description || ''} onChange={(e) => set('description', e.target.value)} /></Field>
        </div>

        <div style={{ marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <h3 style={{ fontSize: 13 }}>Components &amp; Suppliers</h3>
            <button type="button" className="btn btn-secondary btn-sm" onClick={addComponent}><Plus size={12} /> Add Component</button>
          </div>
          {form.components.map((c, idx) => (
            <div key={idx} style={{ display: 'grid', gridTemplateColumns: '150px 1fr 140px 90px 90px 28px', gap: 8, marginBottom: 6, alignItems: 'center' }}>
              <select className="field-input" value={c.component_type} onChange={(e) => setComponent(idx, 'component_type', e.target.value)}>
                {allowedComponentTypes.map((t) => <option key={t}>{t}</option>)}
              </select>
              <input className="field-input" placeholder="Description (e.g. hotel/flight name)" value={c.description || ''} onChange={(e) => setComponent(idx, 'description', e.target.value)} />
              <select className="field-input" value={c.supplier_id || ''} onChange={(e) => setComponent(idx, 'supplier_id', e.target.value ? Number(e.target.value) : '')}>
                <option value="">— Supplier —</option>
                {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <input type="number" className="field-input" placeholder="Cost" value={c.cost} onChange={(e) => setComponent(idx, 'cost', e.target.value)} />
              <input type="number" className="field-input" placeholder="Sell" value={c.selling_price} onChange={(e) => setComponent(idx, 'selling_price', e.target.value)} />
              <button type="button" className="icon-btn" onClick={() => removeComponent(idx)}><XIcon size={13} /></button>
            </div>
          ))}
          {form.components.length > 0 && (
            <div style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 4 }}>
              Component totals — Cost: {money(componentCostTotal)} · Sell: {money(componentSellTotal)}
            </div>
          )}
          <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginTop: 8 }}>
            When this package is booked, each component here is automatically turned into its own linked
            Flight / Visa / Hotel / Transport / Other Service record on that booking.
          </p>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Package'}</button>
        </div>
      </form>
    </Modal>
  );
}
