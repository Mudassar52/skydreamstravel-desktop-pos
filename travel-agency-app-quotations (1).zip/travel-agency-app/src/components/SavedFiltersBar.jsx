import { useEffect, useState } from 'react';
import { Bookmark, Plus, X as XIcon } from 'lucide-react';

/**
 * Lists saved filters for a module and lets the person apply one with a
 * click, or save the page's current filter state under a name. Backed by
 * the real saved_filters table (savedFilterService) - not cosmetic.
 */
export default function SavedFiltersBar({ module, currentFilter, onApply }) {
  const [filters, setFilters] = useState([]);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState('');

  async function load() {
    const res = await window.api.savedFilters.list(module);
    if (res.ok) setFilters(res.data);
  }
  useEffect(() => { load(); }, [module]);

  async function save() {
    if (!name.trim()) return;
    const res = await window.api.savedFilters.create({ name: name.trim(), module, filter: currentFilter });
    if (res.ok) { setName(''); setSaving(false); load(); }
  }

  async function remove(id, e) {
    e.stopPropagation();
    await window.api.savedFilters.delete(id);
    load();
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
      {filters.map((f) => (
        <button
          key={f.id}
          type="button"
          onClick={() => onApply(f.filter)}
          style={{
            display: 'flex', alignItems: 'center', gap: 5, border: '1px solid var(--color-border)',
            background: 'var(--color-surface)', borderRadius: 14, padding: '4px 10px', fontSize: 11.5, cursor: 'pointer'
          }}
        >
          <Bookmark size={11} />
          {f.name}
          <span onClick={(e) => remove(f.id, e)} style={{ display: 'flex', color: 'var(--color-text-faint)' }}><XIcon size={11} /></span>
        </button>
      ))}

      {!saving ? (
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => setSaving(true)}>
          <Plus size={12} /> Save Filter
        </button>
      ) : (
        <div style={{ display: 'flex', gap: 6 }}>
          <input
            className="field-input"
            style={{ width: 160 }}
            placeholder="Filter name..."
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />
          <button type="button" className="btn btn-primary btn-sm" onClick={save}>Save</button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => { setSaving(false); setName(''); }}>Cancel</button>
        </div>
      )}
    </div>
  );
}
