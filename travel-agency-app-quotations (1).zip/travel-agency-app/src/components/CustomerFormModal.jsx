import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { validateCustomer } from '../utils/validators';
import '../pages/customers.css';

const EMPTY = {
  full_name: '', father_husband_name: '', cnic: '', passport_number: '',
  passport_issue_date: '', passport_expiry_date: '', date_of_birth: '', gender: '',
  nationality: '', phone: '', whatsapp: '', email: '', address: '',
  emergency_contact: '', notes: '', status: 'Active'
};

export default function CustomerFormModal({ customerId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (customerId) {
      window.api.customers.get(customerId).then((res) => {
        if (res.ok) setForm({ ...EMPTY, ...res.data });
      });
    }
  }, [customerId]);

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function submit(e) {
    e.preventDefault();
    const { valid, errors: fieldErrors } = validateCustomer(form);
    setErrors(fieldErrors);
    if (!valid) return;

    setSaving(true);
    setServerError('');
    const res = customerId
      ? await window.api.customers.update(customerId, form)
      : await window.api.customers.create(form);
    setSaving(false);

    if (!res.ok) return setServerError(res.error);
    onSaved(customerId ? `${form.full_name} updated.` : `${form.full_name} added.`);
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel" style={{ width: 560 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <strong>{customerId ? 'Edit Customer' : 'Add Customer'}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
          {serverError && <div className="login-error" style={{ marginBottom: 12 }}>{serverError}</div>}
          <form onSubmit={submit}>
            <div className="form-grid">
              <div className="form-section-title">Personal Information</div>

              <Field label="Full Name *" error={errors.full_name}>
                <input className="field-input" value={form.full_name} onChange={(e) => set('full_name', e.target.value)} />
              </Field>
              <Field label="Father / Husband Name">
                <input className="field-input" value={form.father_husband_name || ''} onChange={(e) => set('father_husband_name', e.target.value)} />
              </Field>
              <Field label="CNIC">
                <input className="field-input" value={form.cnic || ''} onChange={(e) => set('cnic', e.target.value)} />
              </Field>
              <Field label="Date of Birth">
                <input type="date" className="field-input" value={form.date_of_birth || ''} onChange={(e) => set('date_of_birth', e.target.value)} />
              </Field>
              <Field label="Gender">
                <select className="field-input" value={form.gender || ''} onChange={(e) => set('gender', e.target.value)}>
                  <option value="">Select</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </Field>
              <Field label="Nationality">
                <input className="field-input" value={form.nationality || ''} onChange={(e) => set('nationality', e.target.value)} />
              </Field>
              <Field label="Phone" error={errors.phone}>
                <input className="field-input" value={form.phone || ''} onChange={(e) => set('phone', e.target.value)} />
              </Field>
              <Field label="WhatsApp" error={errors.whatsapp}>
                <input className="field-input" value={form.whatsapp || ''} onChange={(e) => set('whatsapp', e.target.value)} />
              </Field>
              <Field label="Email" error={errors.email}>
                <input className="field-input" value={form.email || ''} onChange={(e) => set('email', e.target.value)} />
              </Field>
              <Field label="Status">
                <select className="field-input" value={form.status || 'Active'} onChange={(e) => set('status', e.target.value)}>
                  <option>Active</option>
                  <option>Inactive</option>
                </select>
              </Field>
              <Field label="Address" full>
                <input className="field-input" value={form.address || ''} onChange={(e) => set('address', e.target.value)} />
              </Field>
              <Field label="Emergency Contact" full>
                <input className="field-input" value={form.emergency_contact || ''} onChange={(e) => set('emergency_contact', e.target.value)} />
              </Field>

              <div className="form-section-title">Passport Information</div>
              <Field label="Passport Number">
                <input className="field-input" value={form.passport_number || ''} onChange={(e) => set('passport_number', e.target.value)} />
              </Field>
              <Field label="">
                <div />
              </Field>
              <Field label="Passport Issue Date">
                <input type="date" className="field-input" value={form.passport_issue_date || ''} onChange={(e) => set('passport_issue_date', e.target.value)} />
              </Field>
              <Field label="Passport Expiry Date" error={errors.passport_expiry_date}>
                <input type="date" className="field-input" value={form.passport_expiry_date || ''} onChange={(e) => set('passport_expiry_date', e.target.value)} />
              </Field>

              <div className="form-section-title">Notes</div>
              <Field label="" full>
                <textarea className="field-input" rows={3} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} />
              </Field>
            </div>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? 'Saving…' : customerId ? 'Save Changes' : 'Add Customer'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function Field({ label, error, full, children }) {
  return (
    <div style={{ gridColumn: full ? '1 / -1' : 'auto' }}>
      {label && <label className="field-label">{label}</label>}
      {children}
      {error && <div className="field-error">{error}</div>}
    </div>
  );
}
