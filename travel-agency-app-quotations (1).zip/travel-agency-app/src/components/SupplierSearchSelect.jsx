import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import './picker.css';

export default function SupplierSearchSelect({ value, valueLabel, onChange }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let active = true;
    if (!query.trim()) { setResults([]); return; }
    window.api.suppliers.list({ search: query, pageSize: 8 }).then((res) => {
      if (active && res.ok) setResults(res.data.rows);
    });
    return () => { active = false; };
  }, [query]);

  return (
    <div style={{ position: 'relative' }}>
      <div className="global-search" style={{ width: '100%' }}>
        <Search size={14} />
        <input
          placeholder="Search supplier by name, code, phone..."
          value={open ? query : (valueLabel || '')}
          onFocus={() => { setOpen(true); setQuery(''); }}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>
      {open && results.length > 0 && (
        <div className="picker-results" style={{ position: 'absolute', zIndex: 10, width: '100%' }}>
          {results.map((s) => (
            <button
              key={s.id}
              className="picker-result"
              onClick={() => { onChange(s.id, s.name); setOpen(false); }}
            >
              {s.name} <span>{s.supplier_code} {s.service_type ? `· ${s.service_type}` : ''}</span>
            </button>
          ))}
        </div>
      )}
      {open && (
        <button
          type="button"
          onClick={() => setOpen(false)}
          style={{ position: 'fixed', inset: 0, zIndex: 5, background: 'transparent', border: 'none', cursor: 'default' }}
          tabIndex={-1}
        />
      )}
    </div>
  );
}
