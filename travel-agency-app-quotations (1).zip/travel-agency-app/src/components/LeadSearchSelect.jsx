import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import './picker.css';

/** Search-and-pick an inquiry (lead). onChange receives the full lead row. */
export default function LeadSearchSelect({ valueLabel, onChange }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return undefined;
    let active = true;
    window.api.leads.list({ search: query, pageSize: 8 }).then((res) => {
      if (active && res.ok) setResults(res.data.rows);
    });
    return () => { active = false; };
  }, [query, open]);

  return (
    <div style={{ position: 'relative' }}>
      <div className="global-search" style={{ width: '100%' }}>
        <Search size={14} />
        <input
          placeholder="Search inquiry by code, name or phone..."
          value={open ? query : (valueLabel || '')}
          onFocus={() => { setOpen(true); setQuery(''); }}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>
      {open && results.length > 0 && (
        <div className="picker-results" style={{ position: 'absolute', zIndex: 10, width: '100%' }}>
          {results.map((l) => (
            <button key={l.id} type="button" className="picker-result" onClick={() => { onChange(l); setOpen(false); }}>
              {l.lead_code} · {l.full_name} <span>{l.phone || l.destination || ''}</span>
            </button>
          ))}
        </div>
      )}
      {open && results.length === 0 && (
        <div className="picker-results" style={{ position: 'absolute', zIndex: 10, width: '100%', padding: 10, fontSize: 12.5, color: 'var(--color-text-muted)' }}>
          No inquiries found.
        </div>
      )}
      {open && (
        <button type="button" onClick={() => setOpen(false)} tabIndex={-1}
          style={{ position: 'fixed', inset: 0, zIndex: 5, background: 'transparent', border: 'none', cursor: 'default' }} />
      )}
    </div>
  );
}
