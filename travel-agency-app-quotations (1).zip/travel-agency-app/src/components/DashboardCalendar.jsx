import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react';
import { useIpcData } from '../utils/useIpcData.js';
import ErrorRetry from './ErrorRetry.jsx';

// Dashboard Calendar (master prompt section 41): a real month-grid of
// departures, arrivals, hotel check-ins/outs, visa expiry, payments and
// follow-ups, built from window.api.dashboard.getCalendarEvents(year, month).
// Clicking a day shows that day's events; clicking an event navigates to its
// real record (booking/customer dossier) rather than duplicating detail here.

const TYPE_COLORS = {
  Departure: '#1E4FA3', Arrival: '#3B6FD6', 'Hotel Check-in': '#1B8A5A', 'Hotel Check-out': '#C9A227',
  'Visa Expiry': '#C23B3B', Payment: '#0EA5A5', 'Follow-up': '#8b5cf6'
};

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export default function DashboardCalendar() {
  const navigate = useNavigate();
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth() + 1); // 1-indexed
  const [selectedDay, setSelectedDay] = useState(null);
  // While a month is loading (or if it failed) the grid shows empty days; a failure is
  // reported with a Retry rather than looking like "nothing happens this month".
  const { data, error, retry } = useIpcData(() => window.api.dashboard.getCalendarEvents(year, month), [year, month]);
  const events = data || {};

  useEffect(() => { setSelectedDay(null); }, [year, month]);

  function prevMonth() { if (month === 1) { setMonth(12); setYear((y) => y - 1); } else setMonth((m) => m - 1); }
  function nextMonth() { if (month === 12) { setMonth(1); setYear((y) => y + 1); } else setMonth((m) => m + 1); }
  function goToday() { setYear(today.getFullYear()); setMonth(today.getMonth() + 1); }

  const cells = useMemo(() => {
    const first = new Date(year, month - 1, 1);
    const startWeekday = first.getDay(); // 0=Sun
    const daysInMonth = new Date(year, month, 0).getDate();
    const out = [];
    for (let i = 0; i < startWeekday; i++) out.push(null);
    for (let d = 1; d <= daysInMonth; d++) out.push(d);
    return out;
  }, [year, month]);

  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const dateKey = (d) => `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

  return (
    <div className="card" style={{ padding: '18px 20px', marginBottom: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <CalendarDays size={16} color="var(--color-primary)" />
          <strong style={{ fontSize: 13.5 }}>{MONTH_NAMES[month - 1]} {year}</strong>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-secondary btn-sm" onClick={prevMonth}><ChevronLeft size={13} /></button>
          <button className="btn btn-secondary btn-sm" onClick={goToday}>Today</button>
          <button className="btn btn-secondary btn-sm" onClick={nextMonth}><ChevronRight size={13} /></button>
        </div>
      </div>

      <ErrorRetry error={error ? `Could not load calendar events: ${error}` : ''} onRetry={retry} />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, fontSize: 11, color: 'var(--color-text-muted)', marginBottom: 4 }}>
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => <div key={d} style={{ textAlign: 'center', padding: '2px 0' }}>{d}</div>)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
        {cells.map((d, i) => {
          if (!d) return <div key={`blank-${i}`} />;
          const key = dateKey(d);
          const dayEvents = events[key] || [];
          const isToday = key === todayStr;
          const isSelected = key === selectedDay;
          return (
            <button
              key={key}
              onClick={() => setSelectedDay(isSelected ? null : key)}
              style={{
                textAlign: 'left', padding: '6px 6px 4px', minHeight: 56, border: isSelected ? '2px solid var(--color-primary)' : '1px solid var(--color-border)',
                borderRadius: 6, background: isToday ? 'rgba(30,79,163,0.06)' : 'var(--color-surface)', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: 3
              }}
            >
              <span style={{ fontSize: 11.5, fontWeight: isToday ? 700 : 500, color: isToday ? 'var(--color-primary)' : 'inherit' }}>{d}</span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                {dayEvents.slice(0, 4).map((e, idx) => (
                  <span key={idx} title={e.type} style={{ width: 6, height: 6, borderRadius: '50%', background: TYPE_COLORS[e.type] || '#9aa6bd' }} />
                ))}
                {dayEvents.length > 4 && <span style={{ fontSize: 9, color: 'var(--color-text-faint)' }}>+{dayEvents.length - 4}</span>}
              </div>
            </button>
          );
        })}
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 12, fontSize: 10.5, color: 'var(--color-text-muted)' }}>
        {Object.entries(TYPE_COLORS).map(([type, color]) => (
          <span key={type} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: color, display: 'inline-block' }} /> {type}
          </span>
        ))}
      </div>

      {selectedDay && (
        <div style={{ marginTop: 14, borderTop: '1px solid var(--color-border)', paddingTop: 12 }}>
          <strong style={{ fontSize: 12.5 }}>{selectedDay}</strong>
          {(events[selectedDay] || []).length === 0 && <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 6 }}>No events this day.</p>}
          <ul style={{ listStyle: 'none', padding: 0, margin: '8px 0 0' }}>
            {(events[selectedDay] || []).map((e, idx) => (
              <li key={idx} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', fontSize: 12.5 }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: TYPE_COLORS[e.type] || '#9aa6bd', flexShrink: 0 }} />
                <span style={{ fontWeight: 600, minWidth: 100 }}>{e.type}</span>
                {e.link ? <button className="link-cell" onClick={() => navigate(e.link)}>{e.label}</button> : <span>{e.label}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
