import { Printer, FileDown, X } from 'lucide-react';

/**
 * Full-size in-app preview of a document (invoice, statement) before it is saved as a PDF or printed.
 * `html` is the same HTML the PDF/print is rendered from, shown in a sandboxed frame (no scripts run in it).
 */
export default function PreviewPane({ title, html, onClose, onSave, onPrint, busy }) {
  return (
    <div className="modal-backdrop" style={{ zIndex: 1000 }}>
      <div className="card" style={{ position: 'fixed', inset: 24, display: 'flex', flexDirection: 'column', padding: 0, overflow: 'hidden', background: 'var(--color-surface, #fff)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', borderBottom: '1px solid var(--color-border, #D0D5DD)' }}>
          <strong style={{ flex: 1, fontSize: 14 }}>{title || 'Preview'}</strong>
          {onSave && <button className="btn btn-secondary btn-sm" disabled={busy} onClick={onSave}><FileDown size={13} /> Save PDF</button>}
          {onPrint && <button className="btn btn-secondary btn-sm" disabled={busy} onClick={onPrint}><Printer size={13} /> Print</button>}
          <button className="icon-btn" title="Close" onClick={onClose}><X size={16} /></button>
        </div>
        <div style={{ flex: 1, background: '#e5e7eb', padding: 16, overflow: 'auto' }}>
          <iframe title={title || 'Preview'} sandbox="" srcDoc={html} style={{ width: '100%', maxWidth: 860, height: '100%', minHeight: 600, display: 'block', margin: '0 auto', border: 0, background: '#fff', boxShadow: '0 1px 6px rgba(0,0,0,.2)' }} />
        </div>
      </div>
    </div>
  );
}
