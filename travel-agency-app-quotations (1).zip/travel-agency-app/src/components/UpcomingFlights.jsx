import { useNavigate } from 'react-router-dom';
import { PlaneTakeoff, PlaneLanding, Users, Ticket, Armchair, CalendarClock, Plane } from 'lucide-react';
import PlaneGlyph from './PlaneGlyph.jsx';
import { airlineLogo, parseAirport, countdownLabel, fmtDate } from '../utils/travelDisplay.js';
import './upcoming.css';

export function Clouds() {
  return (
    <svg className="up-clouds" viewBox="0 0 600 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <g fill="#fff" opacity="0.75">
        <ellipse cx="90" cy="150" rx="70" ry="16" /><ellipse cx="140" cy="140" rx="44" ry="14" />
        <ellipse cx="470" cy="60" rx="80" ry="16" /><ellipse cx="530" cy="50" rx="46" ry="13" />
        <ellipse cx="330" cy="190" rx="60" ry="12" />
      </g>
    </svg>
  );
}

export function AirlineLogo({ airline, small, Fallback = Plane }) {
  const url = airlineLogo(airline);
  return (
    <div className={`up-logo${small ? ' sm' : ''}`} title={airline || ''}>
      {url ? <img src={url} alt={airline} /> : <Fallback size={small ? 16 : 19} />}
    </div>
  );
}

export function RouteLine({ caption }) {
  return (
    <div className="up-line">
      <div className="up-line-track">
        <span className="up-dot" />
        <span style={{ flex: 1 }} />
        <span className="up-dot end" />
        <span className="up-plane"><PlaneGlyph size={20} /></span>
      </div>
      {caption && <span className="up-line-caption">{caption}</span>}
    </div>
  );
}

function FlightHero({ f, onOpen }) {
  const from = parseAirport(f.departure_airport);
  const to = parseAirport(f.arrival_airport);
  return (
    <div className="up-hero" onClick={onOpen} role="button">
      <Clouds />
      <div className="up-hero-top">
        <AirlineLogo airline={f.airline} />
        <div className="up-airline">
          {f.airline || 'Flight'}
          <span>{f.flight_number || 'No flight number'}</span>
        </div>
        <span className="up-pill"><CalendarClock size={13} />{countdownLabel(f.departure_date)}</span>
      </div>

      <div className="up-route">
        <div className="up-place">
          <div className="code">{from.code}</div>
          <div className="city">{from.name || 'Departure'}</div>
          <div className="when">{fmtDate(f.departure_date, false)}{f.departure_time ? ` · ${f.departure_time}` : ''}</div>
        </div>
        <RouteLine caption={f.status || 'Confirmed'} />
        <div className="up-place right">
          <div className="code">{to.code}</div>
          <div className="city">{to.name || 'Arrival'}</div>
          <div className="when">
            {f.arrival_date ? fmtDate(f.arrival_date, false) : fmtDate(f.departure_date, false)}{f.arrival_time ? ` · ${f.arrival_time}` : ''}
          </div>
        </div>
      </div>

      <div className="up-perf" />
      <div className="up-meta">
        <div><Ticket size={14} /> PNR <strong>{f.pnr || '—'}</strong></div>
        <div><Armchair size={14} /> Class <strong>{f.class || '—'}</strong></div>
        <div><Users size={14} /> Passengers <strong>{f.passengers || 0}</strong></div>
        <div><PlaneTakeoff size={14} /> <strong>{fmtDate(f.departure_date)}</strong></div>
      </div>
    </div>
  );
}

function FlightRow({ f, onOpen }) {
  const from = parseAirport(f.departure_airport);
  const to = parseAirport(f.arrival_airport);
  return (
    <div className="up-row" onClick={onOpen} role="button">
      <AirlineLogo airline={f.airline} small />
      <div className="who">
        {f.airline || 'Flight'}
        <span>{f.flight_number || ''}{f.passengers ? ` · ${f.passengers} pax` : ''}</span>
      </div>
      <div className="up-mini">
        <span>{from.code}</span>
        <span className="mini-line"><PlaneGlyph size={16} /></span>
        <span>{to.code}</span>
      </div>
      <div className="end">
        <strong>{fmtDate(f.departure_date, false)}{f.departure_time ? ` · ${f.departure_time}` : ''}</strong>
        {countdownLabel(f.departure_date)}
      </div>
    </div>
  );
}

export default function UpcomingFlights({ flights = [], error }) {
  const navigate = useNavigate();
  const [next, ...rest] = flights;
  return (
    <div className="card up-panel">
      <div className="up-head">
        <div className="up-head-icon"><PlaneTakeoff size={18} /></div>
        <div>
          <h3>Upcoming Flights</h3>
          <small>{error ? 'Could not load flights' : !flights.length ? 'Nothing scheduled' : flights[0].is_past ? 'No upcoming flights — showing latest' : `${flights.length} departure${flights.length > 1 ? 's' : ''} ahead`}</small>
        </div>
        <button type="button" className="up-viewall" onClick={() => navigate('/flights')}>View all</button>
      </div>

      {next ? (
        <>
          <FlightHero f={next} onOpen={() => navigate('/flights')} />
          {rest.length > 0 && (
            <>
              <div className="up-sub">Next after this</div>
              <div className="up-list">
                {rest.map((f) => <FlightRow key={f.id} f={f} onOpen={() => navigate('/flights')} />)}
              </div>
            </>
          )}
          {rest.length === 0 && <div className="up-bottom-pad" />}
        </>
      ) : (
        <div className="up-empty"><PlaneLanding size={26} /><div>{error || 'No flights added yet. Add one from the Flights page.'}</div></div>
      )}
    </div>
  );
}
