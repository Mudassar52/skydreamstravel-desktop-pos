import { useState } from 'react';
import { Calendar } from 'lucide-react';

const PRESETS = [
  { key: 'today', label: 'Today' },
  { key: 'yesterday', label: 'Yesterday' },
  { key: 'thisWeek', label: 'This Week' },
  { key: 'lastWeek', label: 'Last Week' },
  { key: 'thisMonth', label: 'This Month' },
  { key: 'lastMonth', label: 'Last Month' },
  { key: 'thisQuarter', label: 'This Quarter' },
  { key: 'thisYear', label: 'This Year' },
  { key: 'lastYear', label: 'Last Year' },
  { key: 'custom', label: 'Custom Range' }
];

function iso(d) { return d.toISOString().slice(0, 10); }

/** Resolves a preset key into a concrete { from, to } ISO date pair, computed fresh each call so "Today" always means today. */
export function resolvePreset(key) {
  const now = new Date();
  const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

  switch (key) {
    case 'today': { const d = startOfDay(now); return { from: iso(d), to: iso(d) }; }
    case 'yesterday': { const d = startOfDay(now); d.setDate(d.getDate() - 1); return { from: iso(d), to: iso(d) }; }
    case 'thisWeek': { const d = startOfDay(now); d.setDate(d.getDate() - d.getDay()); const end = new Date(d); end.setDate(end.getDate() + 6); return { from: iso(d), to: iso(end) }; }
    case 'lastWeek': { const d = startOfDay(now); d.setDate(d.getDate() - d.getDay() - 7); const end = new Date(d); end.setDate(end.getDate() + 6); return { from: iso(d), to: iso(end) }; }
    case 'thisMonth': { const d = new Date(now.getFullYear(), now.getMonth(), 1); const end = new Date(now.getFullYear(), now.getMonth() + 1, 0); return { from: iso(d), to: iso(end) }; }
    case 'lastMonth': { const d = new Date(now.getFullYear(), now.getMonth() - 1, 1); const end = new Date(now.getFullYear(), now.getMonth(), 0); return { from: iso(d), to: iso(end) }; }
    case 'thisQuarter': { const q = Math.floor(now.getMonth() / 3); const d = new Date(now.getFullYear(), q * 3, 1); const end = new Date(now.getFullYear(), q * 3 + 3, 0); return { from: iso(d), to: iso(end) }; }
    case 'thisYear': { return { from: iso(new Date(now.getFullYear(), 0, 1)), to: iso(new Date(now.getFullYear(), 11, 31)) }; }
    case 'lastYear': { return { from: iso(new Date(now.getFullYear() - 1, 0, 1)), to: iso(new Date(now.getFullYear() - 1, 11, 31)) }; }
    default: return { from: '', to: '' };
  }
}

/**
 * A reusable preset + custom date-range picker, optionally with a
 * date-field selector (Booking Date / Travel Date / Invoice Date / ...).
 * Calls onChange({ preset, from, to, dateField }) whenever the resolved
 * range changes - the parent page owns fetching filtered data with it.
 */
export default function DateRangeFilter({ value, onChange, dateFieldOptions }) {
  const [customFrom, setCustomFrom] = useState(value?.from || '');
  const [customTo, setCustomTo] = useState(value?.to || '');

  function selectPreset(key) {
    if (key === 'custom') {
      onChange({ ...value, preset: 'custom', from: customFrom, to: customTo });
      return;
    }
    if (!key) { onChange({ ...value, preset: '', from: '', to: '' }); return; }
    const { from, to } = resolvePreset(key);
    onChange({ ...value, preset: key, from, to });
  }

  function applyCustom() {
    onChange({ ...value, preset: 'custom', from: customFrom, to: customTo });
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
      <Calendar size={14} style={{ color: 'var(--color-text-faint)' }} />
      <select className="field-input" style={{ width: 150 }} value={value?.preset || ''} onChange={(e) => selectPreset(e.target.value)}>
        <option value="">All dates</option>
        {PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
      </select>

      {value?.preset === 'custom' && (
        <>
          <input type="date" className="field-input" style={{ width: 145 }} value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} />
          <span style={{ color: 'var(--color-text-faint)', fontSize: 12 }}>to</span>
          <input type="date" className="field-input" style={{ width: 145 }} value={customTo} onChange={(e) => setCustomTo(e.target.value)} />
          <button type="button" className="btn btn-secondary btn-sm" onClick={applyCustom}>Apply</button>
        </>
      )}

      {dateFieldOptions && dateFieldOptions.length > 0 && (
        <select
          className="field-input"
          style={{ width: 150 }}
          value={value?.dateField || dateFieldOptions[0].value}
          onChange={(e) => onChange({ ...value, dateField: e.target.value })}
        >
          {dateFieldOptions.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
        </select>
      )}
    </div>
  );
}
