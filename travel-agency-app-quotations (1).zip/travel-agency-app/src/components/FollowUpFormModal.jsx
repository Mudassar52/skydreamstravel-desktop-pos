import { useEffect, useState } from 'react';
import Modal from './Modal.jsx';
import Field from './Field.jsx';
import CustomerSearchSelect from './CustomerSearchSelect.jsx';
import LeadSearchSelect from './LeadSearchSelect.jsx';
import './followups.css';

const OTHER = '__other__';

function tomorrow() {
  const d = new Date(); d.setDate(d.getDate() + 1);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Row of single-choice pills (Contact Method / What did you do?). */
function Pills({ options, value, onChange }) {
  return (
    <div className="fu-seg">
      {options.map((o) => (
        <button type="button" key={o} className={value === o ? 'active' : ''} onClick={() => onChange(value === o ? '' : o)}>{o}</button>
      ))}
    </div>
  );
}

/** Dropdown with a built-in "Other..." that reveals a free-text box, so any kind of value can be entered. */
function SelectWithOther({ options, value, onChange, placeholder }) {
  const isCustom = value && !options.includes(value);
  const [other, setOther] = useState(!!isCustom);
  return (
    <>
      <select
        className="field-input"
        value={other ? OTHER : value}
        onChange={(e) => {
          if (e.target.value === OTHER) { setOther(true); onChange(''); } else { setOther(false); onChange(e.target.value); }
        }}
      >
        <option value="">{placeholder}</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
        <option value={OTHER}>Other…</option>
      </select>
      {other && (
        <input className="field-input" style={{ marginTop: 8 }} placeholder="Type here..." value={value} onChange={(e) => onChange(e.target.value)} />
      )}
    </>
  );
}

const BLANK = {
  mode: 'inquiry', // inquiry | customer | manual
  existing_follow_up_id: null,
  lead_id: null, customer_id: null, booking_id: null, picked_label: '',
  contact_name: '', contact_phone: '', reference_code: '',
  contact_method: '', activity: '', purpose: '', outcome: '', notes: '',
  next_follow_up_date: '', reminder_time: '', priority: 'Medium'
};

/**
 * Follow-up form: pick an inquiry / customer (details auto-fill) or just type a name, record what
 * was done now, and optionally schedule the next follow-up.
 * `initial` pre-fills it (used by the "Log contact" button on a scheduled follow-up).
 */
export default function FollowUpFormModal({ initial, onClose, onSaved }) {
  const [form, setForm] = useState({ ...BLANK, next_follow_up_date: tomorrow(), ...(initial || {}) });
  const [opts, setOpts] = useState({ contactMethods: [], activities: [], purposes: [], outcomes: [], priorities: ['Low', 'Medium', 'High'] });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.followups.options().then((r) => r.ok && setOpts(r.data)); }, []);
  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));

  function switchMode(mode) {
    setForm((s) => ({
      ...s, mode,
      lead_id: null, customer_id: null, picked_label: '',
      contact_name: '', contact_phone: '', reference_code: ''
    }));
  }

  function pickLead(l) {
    setForm((s) => ({
      ...s, lead_id: l.id, customer_id: l.converted_customer_id || null, picked_label: `${l.lead_code} · ${l.full_name}`,
      contact_name: l.full_name || '', contact_phone: l.phone || '', reference_code: l.lead_code || ''
    }));
  }

  async function pickCustomer(id, label) {
    setForm((s) => ({ ...s, customer_id: id, lead_id: null, picked_label: label, contact_name: label, reference_code: '' }));
    const res = await window.api.customers.get(id);
    if (res.ok && res.data) {
      setForm((s) => (s.customer_id === id ? { ...s, contact_phone: res.data.whatsapp || res.data.phone || '' } : s));
    }
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (!form.contact_name.trim() && !form.lead_id && !form.customer_id) return setError('Select an inquiry/customer or type a name.');
    const loggingContact = !!form.activity;
    if (loggingContact && !form.contact_method) return setError('Please choose a contact method.');
    if (!loggingContact && !form.next_follow_up_date) return setError('Choose what you did, or set a next follow-up date.');

    setSaving(true);
    const payload = {
      existing_follow_up_id: form.existing_follow_up_id,
      lead_id: form.lead_id, customer_id: form.customer_id, booking_id: form.booking_id,
      contact_name: form.contact_name.trim(), contact_phone: form.contact_phone.trim(), reference_code: form.reference_code.trim(),
      contact_method: form.contact_method, activity: form.activity, purpose: form.purpose.trim(), outcome: form.outcome.trim(),
      notes: form.notes.trim(), next_follow_up_date: form.next_follow_up_date, reminder_time: form.reminder_time, priority: form.priority
    };
    // Only scheduling (nothing done yet) -> plain scheduled follow-up, no history row.
    const res = loggingContact
      ? await window.api.followups.logContact(payload)
      : await window.api.followups.create({ ...payload, follow_up_date: payload.next_follow_up_date, notes: payload.notes });
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(loggingContact
      ? (form.next_follow_up_date ? 'Follow-up recorded and next follow-up scheduled.' : 'Follow-up recorded.')
      : 'Follow-up scheduled.');
  }

  const nextPending = !!form.next_follow_up_date;

  return (
    <Modal title="Follow-up" onClose={onClose} width={720}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <div className="form-section-title">Customer Information</div>
          <Field label="Follow-up for" full>
            <div className="fu-seg">
              {[['inquiry', 'Select from Inquiries'], ['customer', 'Select Customer'], ['manual', 'Type name manually']].map(([k, label]) => (
                <button type="button" key={k} className={form.mode === k ? 'active' : ''} onClick={() => switchMode(k)}>{label}</button>
              ))}
            </div>
          </Field>

          {form.mode === 'inquiry' && (
            <Field label="Inquiry" full><LeadSearchSelect valueLabel={form.picked_label} onChange={pickLead} /></Field>
          )}
          {form.mode === 'customer' && (
            <Field label="Customer" full><CustomerSearchSelect value={form.customer_id} valueLabel={form.picked_label} onChange={pickCustomer} /></Field>
          )}

          <Field label={form.mode === 'manual' ? 'Customer Name *' : 'Customer Name (auto-filled, editable)'}>
            <input className="field-input" value={form.contact_name} onChange={(e) => set('contact_name', e.target.value)} placeholder="Muhammad Ahmed" />
          </Field>
          <Field label="Phone / WhatsApp">
            <input className="field-input" value={form.contact_phone} onChange={(e) => set('contact_phone', e.target.value)} placeholder="+92 3XX XXXXXXX" />
          </Field>
          <Field label="Inquiry / Booking" full>
            <input className="field-input" value={form.reference_code} onChange={(e) => set('reference_code', e.target.value)} placeholder="e.g. INQ-00125 (optional)" />
          </Field>

          <div className="form-section-title">Follow-up Details</div>
          <Field label="Contact Method" full><Pills options={opts.contactMethods} value={form.contact_method} onChange={(v) => set('contact_method', v)} /></Field>
          <Field label="What did you do?" full><Pills options={opts.activities} value={form.activity} onChange={(v) => set('activity', v)} /></Field>
          <div className="fu-hint">Leave “What did you do?” empty if you only want to schedule a future follow-up.</div>
          <Field label="Follow-up Purpose">
            <SelectWithOther options={opts.purposes} value={form.purpose} onChange={(v) => set('purpose', v)} placeholder="Select purpose" />
          </Field>
          <Field label="Customer Response / Outcome">
            <SelectWithOther options={opts.outcomes} value={form.outcome} onChange={(v) => set('outcome', v)} placeholder="Select outcome" />
          </Field>
          <Field label="Notes / Conversation Summary" full>
            <textarea className="field-input" rows={3} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
          </Field>

          <div className="form-section-title">Next Follow-up Schedule</div>
          <Field label="Next Follow-up Date"><input type="date" className="field-input" value={form.next_follow_up_date} onChange={(e) => set('next_follow_up_date', e.target.value)} /></Field>
          <Field label="Reminder Time"><input type="time" className="field-input" value={form.reminder_time} onChange={(e) => set('reminder_time', e.target.value)} /></Field>
          <Field label="Priority">
            <select className="field-input" value={form.priority} onChange={(e) => set('priority', e.target.value)}>
              {opts.priorities.map((p) => <option key={p}>{p}</option>)}
            </select>
          </Field>

          <div className="form-section-title">Follow-up Status</div>
          <div className="fu-status-box">
            <p>The current contact is recorded as completed while the next follow-up remains pending.</p>
            <div className="fu-status-row">
              <span>Current activity: {form.activity ? 'Completed' : '—'}</span>
              <span>Next action: {nextPending ? 'Pending' : 'Not scheduled'}</span>
            </div>
          </div>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Follow-up'}</button>
        </div>
      </form>
    </Modal>
  );
}
