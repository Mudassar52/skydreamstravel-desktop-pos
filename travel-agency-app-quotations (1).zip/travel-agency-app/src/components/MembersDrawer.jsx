import { useEffect, useState } from 'react';
import { X, Trash2 } from 'lucide-react';
import CustomerPicker from './CustomerPicker.jsx';

/**
 * @param api - object with { list(groupId), add(groupId, customerId, notes), remove(membershipId, groupId) }
 *              each returning the standard { ok, data|error } IPC envelope.
 */
export default function MembersDrawer({ title, groupId, api, onClose }) {
  const [members, setMembers] = useState([]);

  async function reload() {
    const res = await api.list(groupId);
    if (res.ok) setMembers(res.data);
  }

  useEffect(() => { reload(); }, [groupId]);

  async function handleAdd(customerId, notes) {
    const res = await api.add(groupId, customerId, notes);
    if (res.ok) reload();
    return res;
  }

  async function handleRemove(membershipId) {
    await api.remove(membershipId, groupId);
    reload();
  }

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <strong>{title}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="drawer-body">
          <CustomerPicker buttonLabel="Add" onAdd={handleAdd} />
          {members.map((m) => (
            <div className="member-row" key={m.membership_id}>
              <div>
                <div>{m.full_name}</div>
                <div className="member-meta">
                  {[m.phone, m.passport_number].filter(Boolean).join(' · ')}{m.notes ? ` — ${m.notes}` : ''}
                </div>
              </div>
              <button className="icon-btn" title="Remove" onClick={() => handleRemove(m.membership_id)}>
                <Trash2 size={14} />
              </button>
            </div>
          ))}
          {members.length === 0 && (
            <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No one added yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
