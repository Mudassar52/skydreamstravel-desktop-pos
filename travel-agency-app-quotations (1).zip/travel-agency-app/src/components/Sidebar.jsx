import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronsLeft, ChevronsRight, Plane } from 'lucide-react';
import { NAV_ITEMS } from '../utils/navConfig';
import { useAuth } from '../context/AuthContext.jsx';
import { logoSrc, logoIconSrc } from './brandLogo.js';

import './sidebar.css';

const EXPANDED_STORAGE_KEY = 'sidebar.expandedGroups';

function loadExpandedState() {
  try {
    const raw = localStorage.getItem(EXPANDED_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    // Older saved state may have more than one group set to true; keep only
    // the first one so we never render with multiple dropdowns open.
    let keptOne = false;
    const sanitized = {};
    Object.keys(parsed).forEach((group) => {
      if (parsed[group] && !keptOne) {
        sanitized[group] = true;
        keptOne = true;
      } else {
        sanitized[group] = false;
      }
    });
    return sanitized;
  } catch {
    return {};
  }
}

function isGroupActive(item, pathname) {
  if (!item.children) return false;
  return item.children.some((child) =>
    child.path === '/' ? pathname === '/' : pathname.startsWith(child.path)
  );
}

export default function Sidebar({ collapsed, onToggle }) {
  const { can } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState(loadExpandedState);
  // The collapsed sidebar's flyout (a group's children, shown on hover) is
  // rendered through a portal at a fixed screen position instead of as a
  // normal absolutely-positioned child. The sidebar's own nav list scrolls
  // when it's tall, and any ancestor with vertical scroll clips horizontal
  // overflow too (a CSS quirk), which was cutting the flyout off - a portal
  // renders it straight onto <body>, outside that scrolling box entirely.
  const [flyout, setFlyout] = useState(null); // { group, top, left } | null
  const closeTimer = useRef(null);

  const cancelClose = () => { if (closeTimer.current) { clearTimeout(closeTimer.current); closeTimer.current = null; } };
  const scheduleClose = () => { cancelClose(); closeTimer.current = setTimeout(() => setFlyout(null), 150); };
  const openFlyout = (group, el) => {
    cancelClose();
    const rect = el.getBoundingClientRect();
    setFlyout({ group, top: rect.top, left: rect.right + 6 });
  };
  useEffect(() => () => cancelClose(), []);
  // Collapsing/expanding the sidebar, or navigating, should never leave a
  // stale flyout floating on screen.
  useEffect(() => { setFlyout(null); }, [collapsed, location.pathname]);

  // Only one dropdown group should ever be open at a time, so this always
  // rebuilds the expanded map from scratch instead of merging into it.
  const openOnlyGroup = (group) => {
    const next = {};
    NAV_ITEMS.forEach((item) => {
      if (item.children) next[item.group] = item.group === group;
    });
    return next;
  };

  // A group containing the active route auto-expands (closing any other
  // open group), without clobbering the user's own open/closed choice
  // once they've already opened that same group.
  useEffect(() => {
    const activeGroup = NAV_ITEMS.find((item) => isGroupActive(item, location.pathname));
    if (activeGroup) {
      setExpanded((prev) => (prev[activeGroup.group] ? prev : openOnlyGroup(activeGroup.group)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  useEffect(() => {
    localStorage.setItem(EXPANDED_STORAGE_KEY, JSON.stringify(expanded));
  }, [expanded]);

  const toggleGroup = (group) =>
    setExpanded((prev) => (prev[group] ? { ...prev, [group]: false } : openOnlyGroup(group)));

  const visibleTopLevel = NAV_ITEMS.map((item) => {
    if (item.children) {
      const visibleChildren = item.children.filter((child) => can(child.module, 'view'));
      return visibleChildren.length ? { ...item, children: visibleChildren } : null;
    }
    return can(item.module, 'view') ? item : null;
  }).filter(Boolean);

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className={`sidebar-brand ${logoIconSrc ? 'has-logo' : ''}`}>
        {logoIconSrc ? (
          <img
            className={collapsed ? 'brand-logo' : 'brand-logo-icon'}
            src={collapsed ? logoSrc : logoIconSrc}
            alt="Company logo"
            draggable={false}
          />
        ) : (
          <>
            <div className="brand-mark">
              <Plane size={18} />
            </div>
            {!collapsed && (
              <div className="brand-text">
                <strong>Travel Agency</strong>
                <span>Manager</span>
              </div>
            )}
          </>
        )}
      </div>

      <nav className="sidebar-nav">
        {visibleTopLevel.map((item) => {
          if (item.children) {
            const isOpen = collapsed ? false : !!expanded[item.group];
            const groupActive = isGroupActive(item, location.pathname);
            const GroupIcon = item.icon;
            return (
              <div
                key={item.group}
                className={`nav-group ${groupActive ? 'active-group' : ''}`}
                onMouseEnter={collapsed ? (e) => openFlyout(item.group, e.currentTarget) : undefined}
                onMouseLeave={collapsed ? scheduleClose : undefined}
              >
                <button
                  type="button"
                  className="nav-item nav-group-toggle"
                  onClick={() => (collapsed ? navigate(item.children[0].path) : toggleGroup(item.group))}
                  title={collapsed ? item.label : undefined}
                >
                  <span className="nav-icon" style={{ '--ic': item.color }}><GroupIcon size={17} strokeWidth={2.1} /></span>
                  {!collapsed && (
                    <>
                      <span>{item.label}</span>
                      <ChevronDown size={15} className={`chevron ${isOpen ? 'open' : ''}`} />
                    </>
                  )}
                </button>
                {!collapsed && (
                  <div className={`nav-subgroup ${isOpen ? 'open' : ''}`}>
                    {item.children.map(({ label, path, icon: Icon, navState }) => (
                      <NavLink
                        key={path}
                        to={path}
                        state={navState}
                        className={({ isActive }) => `nav-item nav-subitem ${isActive ? 'active' : ''}`}
                      >
                        <span className="nav-icon" style={{ '--ic': item.color }}><Icon size={15} strokeWidth={2.1} /></span>
                        <span>{label}</span>
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          const Icon = item.icon;
          const isLastVisible = visibleTopLevel[visibleTopLevel.length - 1] === item;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              state={item.navState}
              end={item.path === '/'}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
              title={collapsed ? item.label : undefined}
              style={isLastVisible ? undefined : { marginBottom: '16px' }}
            >
              <span className="nav-icon" style={{ '--ic': item.color }}><Icon size={17} strokeWidth={2.1} /></span>
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          );
        })}
      </nav>

      <button className="sidebar-toggle" onClick={onToggle}>
        {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        {!collapsed && <span>Collapse</span>}
      </button>

      {flyout && collapsed && (() => {
        const flyoutItem = visibleTopLevel.find((i) => i.group === flyout.group);
        if (!flyoutItem) return null;
        return createPortal(
          <div
            className="nav-subgroup-flyout"
            style={{
              left: flyout.left,
              // keep the whole flyout on screen: shift it up when the group sits low,
              // and cap its height so anything longer scrolls inside it
              maxHeight: window.innerHeight - 16,
              top: Math.max(8, Math.min(flyout.top, window.innerHeight - 8 - Math.min(flyoutItem.children.length * 41 + 14, window.innerHeight - 16)))
            }}
            onMouseEnter={cancelClose}
            onMouseLeave={scheduleClose}
          >
            {flyoutItem.children.map(({ label, path, icon: Icon, navState }) => (
              <NavLink
                key={path}
                to={path}
                state={navState}
                className={({ isActive }) => `nav-item nav-subitem ${isActive ? 'active' : ''}`}
                title={label}
              >
                <span className="nav-icon" style={{ '--ic': flyoutItem.color }}><Icon size={15} strokeWidth={2.1} /></span>
                <span>{label}</span>
              </NavLink>
            ))}
          </div>,
          document.body
        );
      })()}
    </aside>
  );
}
