import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react';
import './pagination.css';

export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

/**
 * Shared pager bar used by every list in the app.
 * Controlled: the page owns `page` / `pageSize` and passes `total` (all matching rows).
 * Renders nothing when there is nothing to page through (total <= smallest page size and no size picker needed).
 */
export default function Pagination({ page, pageSize, total, onPage, onPageSize, label = 'records' }) {
  const totalPages = Math.max(1, Math.ceil((total || 0) / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  if (!total || total <= PAGE_SIZE_OPTIONS[0]) {
    return total ? <div className="pager"><span className="pager-info">Showing all {total.toLocaleString()} {label}</span></div> : null;
  }

  // Compact window of page numbers: 1 … (p-1) p (p+1) … last
  const nums = [];
  const add = (n) => { if (n >= 1 && n <= totalPages && !nums.includes(n)) nums.push(n); };
  add(1); add(page - 1); add(page); add(page + 1); add(totalPages);
  nums.sort((a, b) => a - b);
  const items = [];
  nums.forEach((n, i) => { if (i > 0 && n - nums[i - 1] > 1) items.push(`gap${n}`); items.push(n); });

  return (
    <div className="pager">
      <span className="pager-info">Showing {from.toLocaleString()}–{to.toLocaleString()} of {total.toLocaleString()} {label}</span>
      <div className="pager-controls">
        {onPageSize && (
          <label className="pager-size">
            Rows
            <select value={pageSize} onChange={(e) => onPageSize(Number(e.target.value))}>
              {PAGE_SIZE_OPTIONS.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </label>
        )}
        <button className="icon-btn" title="First page" disabled={page <= 1} onClick={() => onPage(1)}><ChevronsLeft size={14} /></button>
        <button className="icon-btn" title="Previous page" disabled={page <= 1} onClick={() => onPage(page - 1)}><ChevronLeft size={14} /></button>
        {items.map((it) => (typeof it === 'string'
          ? <span key={it} className="pager-gap">…</span>
          : <button key={it} className={`pager-num${it === page ? ' active' : ''}`} onClick={() => onPage(it)}>{it}</button>))}
        <button className="icon-btn" title="Next page" disabled={page >= totalPages} onClick={() => onPage(page + 1)}><ChevronRight size={14} /></button>
        <button className="icon-btn" title="Last page" disabled={page >= totalPages} onClick={() => onPage(totalPages)}><ChevronsRight size={14} /></button>
      </div>
    </div>
  );
}

/**
 * Client-side paging for lists that already hold every row in memory.
 * Resets to page 1 whenever the row set changes size (filter/search/reload) and clamps if rows shrink.
 */
export function usePagination(rows, initialSize = 25) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialSize);
  const total = rows?.length || 0;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  useEffect(() => { if (page > totalPages) setPage(totalPages); }, [page, totalPages]);
  const pageRows = useMemo(() => (rows || []).slice((page - 1) * pageSize, page * pageSize), [rows, page, pageSize]);
  const changeSize = (n) => { setPageSize(n); setPage(1); };
  const reset = () => setPage(1);
  return { page, pageSize, total, pageRows, setPage, setPageSize: changeSize, reset, pagerProps: { page, pageSize, total, onPage: setPage, onPageSize: changeSize } };
}

/**
 * Render-prop wrapper for places where a hook can't be called inline (after early returns, inside map(), etc.):
 *   <Paged rows={list} label="bookings">{(pageRows) => <table>…{pageRows.map(...)}…</table>}</Paged>
 */
export function Paged({ rows, size = 25, label = 'records', children }) {
  const pg = usePagination(rows, size);
  return (
    <>
      {children(pg.pageRows)}
      <Pagination {...pg.pagerProps} label={label} />
    </>
  );
}
