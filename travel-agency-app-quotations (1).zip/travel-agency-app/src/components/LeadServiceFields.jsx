import { Plus, X } from 'lucide-react';
import Field from './Field.jsx';

export const SERVICE_TYPES = ['Umrah', 'Hajj', 'Visa', 'Tour', 'Flight', 'Hotel', 'Transportation'];
const STARS = ['1', '2', '3', '4', '5'];
const COUNTRIES = [
  'Pakistan', 'India', 'Bangladesh', 'Afghanistan', 'Saudi Arabia', 'United Arab Emirates', 'United Kingdom',
  'United States', 'Canada', 'Australia', 'Turkey', 'Egypt', 'Malaysia', 'Indonesia', 'Sri Lanka', 'Nepal',
  'Iran', 'Iraq', 'Kuwait', 'Qatar', 'Oman', 'Bahrain', 'Germany', 'France', 'Italy', 'Spain'
];
const MAX_AGE_ROWS = 30;

const num = (v) => Math.max(0, Math.min(MAX_AGE_ROWS, parseInt(v, 10) || 0));
const resize = (arr, n) => Array.from({ length: n }, (_, i) => (arr && arr[i] !== undefined ? arr[i] : ''));

const MEALS = ['None', 'Breakfast', 'Half board', 'Full board'];
const ROOM_TYPES = ['Single', 'Double', 'Triple', 'Quad', 'Suite', 'Family'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const FLEXIBILITY = ['Fixed dates', '± 1-2 days', '± 1 week', 'Flexible within the month', 'Fully flexible'];

/** Old leads stored one star value as a string; new ones store an array of ticked stars. */
const starList = (v) => (Array.isArray(v) ? v : (v ? [String(v).replace(/\s*star/i, '')] : [])).map(String);

/** Tick as many star ratings as you like. */
function StarChecks({ label, value, onChange }) {
  const picked = starList(value);
  const toggle = (s) => onChange(picked.includes(s) ? picked.filter((x) => x !== s) : [...picked, s].sort());
  return (
    <Field label={label} full>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}>
        {STARS.map((s) => (
          <label key={s} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer' }}>
            <input type="checkbox" checked={picked.includes(s)} onChange={() => toggle(s)} />
            {s} Star
          </label>
        ))}
      </div>
    </Field>
  );
}

/** Room type + how many rooms of that type; add a row for each different type. */
function RoomRows({ value, onChange, label = 'Room type & number of rooms' }) {
  const rows = value && value.length ? value : [{ type: '', count: '' }];
  return (
    <Field label={label} full>
      {rows.map((r, i) => (
        <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
          <select className="field-input" value={r.type || ''} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)))}>
            <option value="">Room type</option>
            {ROOM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <input type="number" min="0" className="field-input" style={{ width: 140 }} placeholder="No. of rooms" value={r.count ?? ''} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, count: e.target.value } : x)))} />
          {rows.length > 1 && <button type="button" className="icon-btn" title="Remove" onClick={() => onChange(rows.filter((_, j) => j !== i))}><X size={14} /></button>}
        </div>
      ))}
      <button type="button" className="btn btn-secondary btn-sm" onClick={() => onChange([...rows, { type: '', count: '' }])}><Plus size={13} /> Add another room type</button>
    </Field>
  );
}

/** Hotel preference block used for Makkah and Madinah (Umrah / Hajj). */
function CityHotels({ title, value, onChange }) {
  const v = value || { stars: [], nights: '', hotels: [''], rooms: [], meals: '' };
  const hotels = v.hotels && v.hotels.length ? v.hotels : [''];
  const patch = (p) => onChange({ ...v, hotels, ...p });
  return (
    <div style={{ gridColumn: '1 / -1', border: '1px solid var(--color-border)', borderRadius: 8, padding: 12 }}>
      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>{title}</div>
      <div className="form-grid">
        <StarChecks label={`${title} hotel star rating`} value={v.stars} onChange={(stars) => patch({ stars })} />
        <Field label="Nights">
          <input type="number" min="0" className="field-input" value={v.nights || ''} onChange={(e) => patch({ nights: e.target.value })} />
        </Field>
        <Field label="Meals">
          <select className="field-input" value={v.meals || ''} onChange={(e) => patch({ meals: e.target.value })}>
            <option value="">Select</option>
            {MEALS.map((m) => <option key={m}>{m}</option>)}
          </select>
        </Field>
        <RoomRows value={v.rooms} onChange={(rooms) => patch({ rooms })} />
        <Field label="Preferred hotel names (add as many as you like)" full>
          {hotels.map((name, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
              <input
                className="field-input"
                placeholder={`Hotel name ${i + 1}`}
                value={name}
                onChange={(e) => patch({ hotels: hotels.map((h, j) => (j === i ? e.target.value : h)) })}
              />
              {hotels.length > 1 && (
                <button type="button" className="icon-btn" title="Remove" onClick={() => patch({ hotels: hotels.filter((_, j) => j !== i) })}><X size={14} /></button>
              )}
            </div>
          ))}
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => patch({ hotels: [...hotels, ''] })}><Plus size={13} /> Add another hotel</button>
        </Field>
      </div>
    </div>
  );
}

function Select({ value, onChange, options, placeholder = 'Select' }) {
  return (
    <select className="field-input" value={value || ''} onChange={(e) => onChange(e.target.value)}>
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o}>{o}</option>)}
    </select>
  );
}

/** Passport countries: add as many countries as needed, each with how many passports of that country. */
function PassportRows({ d, set }) {
  // Older leads stored a single `passport_country` string - show it as the first row.
  const rows = d.passports && d.passports.length
    ? d.passports
    : [{ country: d.passport_country || '', count: d.passport_country ? '1' : '' }];
  const update = (next) => set('passports', next);
  const total = rows.reduce((sum, r) => sum + (parseInt(r.count, 10) || 0), 0);
  return (
    <Field label="Which passport do they hold? (nationality + number of passports)" full>
      <datalist id="lead-countries">{COUNTRIES.map((c) => <option key={c} value={c} />)}</datalist>
      {rows.map((r, i) => (
        <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
          <input
            className="field-input"
            list="lead-countries"
            placeholder="Passport country, e.g. Pakistan"
            value={r.country || ''}
            onChange={(e) => update(rows.map((x, j) => (j === i ? { ...x, country: e.target.value } : x)))}
          />
          <input
            type="number"
            min="0"
            className="field-input"
            style={{ width: 130 }}
            placeholder="No. of passports"
            value={r.count ?? ''}
            onChange={(e) => update(rows.map((x, j) => (j === i ? { ...x, count: e.target.value } : x)))}
          />
          {rows.length > 1 && (
            <button type="button" className="icon-btn" title="Remove" onClick={() => update(rows.filter((_, j) => j !== i))}><X size={14} /></button>
          )}
        </div>
      ))}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => update([...rows, { country: '', count: '' }])}><Plus size={13} /> Add another country</button>
        {total > 0 && <span style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>Total passports: {total}</span>}
      </div>
    </Field>
  );
}

/** Travellers section, in order: 1) when they want to go + flexibility, 2) how many people (+ child ages), 3) passport / nationality. */
function TravellerFields({ d, set, travelDate, onTravelDateChange }) {
  const children = num(d.children);
  const ages = d.ages || { adults: [], children: [] };
  const setChildAge = (i, v) => {
    const list = resize(ages.children, children);
    list[i] = v;
    set('ages', { ...ages, children: list });
  };
  return (
    <>
      <div className="form-section-title">Travellers</div>

      {/* 1. When do they want to go */}
      <Field label="1. In which month do they want to go?">
        <select className="field-input" value={d.travel_month || ''} onChange={(e) => set('travel_month', e.target.value)}>
          <option value="">Select month</option>
          {MONTHS.map((m) => <option key={m}>{m}</option>)}
        </select>
      </Field>
      {onTravelDateChange && (
        <Field label="Travel date (if known)">
          <input type="date" className="field-input" value={travelDate || ''} onChange={(e) => onTravelDateChange(e.target.value)} />
        </Field>
      )}
      <Field label="Flexibility" full>
        <select className="field-input" value={d.date_flexibility || ''} onChange={(e) => set('date_flexibility', e.target.value)}>
          <option value="">Select flexibility</option>
          {FLEXIBILITY.map((f) => <option key={f}>{f}</option>)}
        </select>
      </Field>

      {/* 2. How many people */}
      <Field label="2. Adults">
        <input type="number" min="0" className="field-input" value={d.adults ?? ''} onChange={(e) => set('adults', e.target.value)} />
      </Field>
      <Field label="Children">
        <input type="number" min="0" className="field-input" value={d.children ?? ''} onChange={(e) => set('children', e.target.value)} />
      </Field>
      <Field label="Infants">
        <input type="number" min="0" className="field-input" value={d.infants ?? ''} onChange={(e) => set('infants', e.target.value)} />
      </Field>
      {children > 0 && (
        <Field label="Child ages" full>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {Array.from({ length: children }, (_, i) => (
              <label key={`c${i}`} style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>
                Child {i + 1}
                <input type="number" min="0" className="field-input" style={{ width: 84 }} placeholder="Age" value={(ages.children || [])[i] ?? ''} onChange={(e) => setChildAge(i, e.target.value)} />
              </label>
            ))}
          </div>
        </Field>
      )}

      {/* 3. Passport / nationality */}
      <PassportRows d={d} set={set} />
    </>
  );
}

/** Form fields that change with the selected service type. `d` is the lead's `details` object. */
export default function LeadServiceFields({ serviceType, details, onChange, travelDate, onTravelDateChange }) {
  const d = details || {};
  const set = (k, v) => onChange({ ...d, [k]: v });
  const text = (k, label, props = {}) => (
    <Field label={label} full={props.full}>
      <input className="field-input" type={props.type || 'text'} placeholder={props.placeholder} value={d[k] || ''} onChange={(e) => set(k, e.target.value)} />
    </Field>
  );
  const pick = (k, label, options, full) => (
    <Field label={label} full={full}><Select value={d[k]} onChange={(v) => set(k, v)} options={options} /></Field>
  );

  return (
    <>
      <TravellerFields d={d} set={set} travelDate={travelDate} onTravelDateChange={onTravelDateChange} />

      {serviceType && <div className="form-section-title">{serviceType} details</div>}

      {(serviceType === 'Umrah' || serviceType === 'Hajj') && (
        <>
          {text('departure_airport', 'Departure airport', { placeholder: 'e.g. Lahore (LHE), Karachi (KHI)' })}
          {serviceType === 'Hajj'
            ? pick('package_category', 'Package category', ['Economy', 'Standard', 'Premium', 'VIP'])
            : text('stay_days', 'Total stay (days)', { type: 'number' })}
          <CityHotels title="Makkah" value={d.makkah} onChange={(v) => set('makkah', v)} />
          <CityHotels title="Madinah" value={d.madinah} onChange={(v) => set('madinah', v)} />
          {pick('flight_included', 'Flight required?', ['Yes', 'No'])}
          {pick('transport_included', 'Ground transport required?', ['Yes', 'No'])}
          {pick('visa_included', 'Visa required?', ['Yes', 'No'])}
        </>
      )}

      {serviceType === 'Visa' && (
        <>
          {text('visa_country', 'Visa for country', { placeholder: 'e.g. Saudi Arabia' })}
          {pick('visa_type', 'Visa type', ['Tourist', 'Business', 'Visit / Family', 'Umrah', 'Work', 'Student', 'Transit'])}
          {pick('entries', 'Entries', ['Single', 'Multiple'])}
          {text('duration_days', 'Duration (days)', { type: 'number' })}
          {text('passport_expiry', 'Passport expiry date', { type: 'date' })}
          {pick('urgency', 'Processing', ['Normal', 'Urgent', 'Express'])}
        </>
      )}

      {serviceType === 'Tour' && (
        <>
          {text('tour_cities', 'Cities / places to visit', { full: true, placeholder: 'e.g. Istanbul, Cappadocia' })}
          {text('nights', 'Nights', { type: 'number' })}
          {pick('tour_style', 'Tour style', ['Group', 'Private / Family', 'Honeymoon', 'Corporate'])}
          <StarChecks label="Hotel star rating" value={d.hotel_stars} onChange={(v) => set('hotel_stars', v)} />
          {pick('meal_plan', 'Meals', ['None', 'Breakfast', 'Half board', 'Full board'])}
          {pick('flight_included', 'Flight required?', ['Yes', 'No'])}
          {pick('transport_included', 'Ground transport required?', ['Yes', 'No'])}
          {pick('visa_included', 'Visa required?', ['Yes', 'No'])}
          {text('activities', 'Activities / special requests', { full: true })}
        </>
      )}

      {serviceType === 'Flight' && (
        <>
          {pick('trip_type', 'Trip type', ['One way', 'Return', 'Multi-city'])}
          {pick('cabin_class', 'Cabin class', ['Economy', 'Premium Economy', 'Business', 'First'])}
          {text('from_city', 'From')}
          {text('to_city', 'To')}
          {text('departure_date', 'Departure date', { type: 'date' })}
          {d.trip_type !== 'One way' && text('return_date', 'Return date', { type: 'date' })}
          {text('preferred_airline', 'Preferred airline')}
          {pick('flexible_dates', 'Flexible dates?', ['Yes', 'No'])}
        </>
      )}

      {serviceType === 'Hotel' && (
        <>
          {text('city', 'City')}
          <StarChecks label="Hotel star rating" value={d.hotel_stars} onChange={(v) => set('hotel_stars', v)} />
          {text('check_in', 'Check-in', { type: 'date' })}
          {text('check_out', 'Check-out', { type: 'date' })}
          <RoomRows value={d.room_list} onChange={(v) => set('room_list', v)} />
          {pick('meal_plan', 'Meals', ['None', 'Breakfast', 'Half board', 'Full board'])}
          <Field label="Preferred hotel names" full>
            {(d.hotel_names && d.hotel_names.length ? d.hotel_names : ['']).map((name, i, arr) => (
              <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                <input className="field-input" placeholder={`Hotel name ${i + 1}`} value={name} onChange={(e) => set('hotel_names', arr.map((h, j) => (j === i ? e.target.value : h)))} />
                {arr.length > 1 && <button type="button" className="icon-btn" title="Remove" onClick={() => set('hotel_names', arr.filter((_, j) => j !== i))}><X size={14} /></button>}
              </div>
            ))}
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => set('hotel_names', [...(d.hotel_names && d.hotel_names.length ? d.hotel_names : ['']), ''])}><Plus size={13} /> Add another hotel</button>
          </Field>
        </>
      )}

      {serviceType === 'Transportation' && (
        <>
          {pick('transport_type', 'Transport type', ['Airport transfer', 'City to city', 'Ziyarat', 'Full trip', 'Other'])}
          {pick('vehicle_type', 'Vehicle', ['Sedan', 'SUV', 'Van / Hiace', 'Coaster', 'Bus'])}
          {text('pickup', 'Pickup location')}
          {text('dropoff', 'Drop-off location')}
          {text('pickup_date', 'Pickup date', { type: 'date' })}
          {pick('trip_type', 'Trip type', ['One way', 'Round trip'])}
          {text('luggage', 'Luggage (pieces)', { type: 'number' })}
        </>
      )}
    </>
  );
}

const LABELS = {
  departure_city: 'Departure city', departure_airport: 'Departure airport', stay_days: 'Total stay (days)', package_category: 'Package category',
  flight_included: 'Flight required', transport_included: 'Ground transport required', visa_included: 'Visa required',
  meal_plan: 'Meals', visa_country: 'Visa for country', visa_type: 'Visa type', entries: 'Entries',
  duration_days: 'Duration (days)', passport_expiry: 'Passport expiry', urgency: 'Processing', tour_cities: 'Cities / places',
  nights: 'Nights', tour_style: 'Tour style', activities: 'Activities / requests',
  trip_type: 'Trip type', cabin_class: 'Cabin class', from_city: 'From', to_city: 'To', departure_date: 'Departure date',
  return_date: 'Return date', preferred_airline: 'Preferred airline', flexible_dates: 'Flexible dates', city: 'City',
  check_in: 'Check-in', check_out: 'Check-out', rooms: 'Rooms', room_type: 'Room type', transport_type: 'Transport type',
  vehicle_type: 'Vehicle', pickup: 'Pickup', dropoff: 'Drop-off', pickup_date: 'Pickup date', luggage: 'Luggage (pieces)'
};

const roomText = (rows) => (rows || []).filter((r) => r && r.type).map((r) => `${parseInt(r.count, 10) || 1} × ${r.type}`).join(', ');

/** Flattens `details` into [label, value] rows for the read-only view. */
export function summarizeLeadDetails(d = {}) {
  const rows = [];
  const add = (label, value) => { if (value !== undefined && value !== null && String(value).trim() !== '') rows.push([label, String(value)]); };
  const passports = (d.passports && d.passports.length ? d.passports : (d.passport_country ? [{ country: d.passport_country, count: '1' }] : []))
    .filter((p) => p.country && p.country.trim())
    .map((p) => `${p.country.trim()} × ${parseInt(p.count, 10) || 1}`);
  add('Travel month', d.travel_month);
  add('Flexibility', d.date_flexibility);
  add('Passport / nationality', passports.join(', '));
  const parts = [];
  if (num(d.adults)) parts.push(`${num(d.adults)} adult${num(d.adults) > 1 ? 's' : ''}`);
  if (num(d.children)) parts.push(`${num(d.children)} child${num(d.children) > 1 ? 'ren' : ''}`);
  if (num(d.infants)) parts.push(`${num(d.infants)} infant${num(d.infants) > 1 ? 's' : ''}`);
  add('Travellers', parts.join(', '));
  const ageList = (arr, label) => (arr || []).map((a, i) => (String(a).trim() ? `${label} ${i + 1}: ${a}` : null)).filter(Boolean);
  add('Child ages', [...ageList(d.ages?.adults, 'Adult'), ...ageList(d.ages?.children, 'Child')].join(' · '));
  for (const [key, title] of [['makkah', 'Makkah'], ['madinah', 'Madinah']]) {
    const c = d[key];
    if (!c) continue;
    add(`${title} star rating`, starList(c.stars).map((x) => `${x} Star`).join(', '));
    add(`${title} nights`, c.nights);
    add(`${title} meals`, c.meals);
    add(`${title} rooms`, roomText(c.rooms));
    add(`${title} preferred hotels`, (c.hotels || []).filter((h) => h && h.trim()).join(', '));
  }
  add('Preferred hotels', (d.hotel_names || []).filter((h) => h && h.trim()).join(', '));
  add('Hotel star rating', starList(d.hotel_stars).map((x) => `${x} Star`).join(', '));
  add('Rooms', roomText(d.room_list));
  for (const [key, label] of Object.entries(LABELS)) add(label, d[key]);
  return rows;
}
