import { RefreshCw } from 'lucide-react';

/** Inline load-failure banner with a Retry button. Renders nothing when there is no error. */
export default function ErrorRetry({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="login-error" style={{ margin: '0 0 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ flex: 1 }}>{error}</span>
      {onRetry && <button className="btn btn-secondary btn-sm" onClick={onRetry}><RefreshCw size={12} /> Retry</button>}
    </div>
  );
}
