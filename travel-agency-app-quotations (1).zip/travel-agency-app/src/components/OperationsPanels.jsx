import { useNavigate } from 'react-router-dom';
import {
  Map, Armchair, Tent, BellRing, PlaneTakeoff, MoonStar, CalendarDays,
  LogIn, LogOut, Hotel, BusFront, Phone, Clock3, Users, MapPin, CalendarRange
} from 'lucide-react';
import { countdownLabel, daysUntil, fmtDate, airlineLogo } from '../utils/travelDisplay.js';
import './operations.css';

const KIND_ICON = { Flight: PlaneTakeoff, Umrah: MoonStar, Hajj: Tent, Tour: Map };

function Panel({ tone, icon: Icon, title, sub, viewAll, children }) {
  const navigate = useNavigate();
  return (
    <div className={`card ops-panel ${tone}`}>
      <div className="ops-head">
        <div className="ops-head-icon"><Icon size={18} /></div>
        <div>
          <h3>{title}</h3>
          <small>{sub}</small>
        </div>
        {viewAll && <button type="button" className="up-viewall" onClick={() => navigate(viewAll)}>View all</button>}
      </div>
      {children}
    </div>
  );
}

function Empty({ text }) {
  return <div className="ops-empty"><CalendarRange size={22} /><div>{text}</div></div>;
}

/* Seats bar: filled vs free. Turns amber when nearly full, red when sold out. */
function SeatBar({ filled, total }) {
  const pct = total ? Math.min(100, Math.round((filled / total) * 100)) : 0;
  const state = total && filled >= total ? 'full' : pct >= 80 ? 'warn' : 'ok';
  return (
    <div className={`ops-seatbar ${state}`} role="img" aria-label={`${filled} of ${total} seats filled`}>
      <span style={{ width: `${pct}%` }} />
    </div>
  );
}

/* ---- Departing tomorrow / today alert ---- */
export function DepartureAlert({ departures = [] }) {
  const navigate = useNavigate();
  const tomorrow = departures.filter((d) => daysUntil(d.date) === 1);
  const today = departures.filter((d) => daysUntil(d.date) === 0);
  if (!tomorrow.length && !today.length) return null;
  const names = (list) => list.slice(0, 3).map((d) => d.title).join(', ') + (list.length > 3 ? ` +${list.length - 3} more` : '');
  return (
    <div className="ops-alert" role="status">
      <div className="ops-alert-icon"><BellRing size={20} /></div>
      <div className="ops-alert-text">
        {tomorrow.length > 0 && <div><strong>Kal ja rahe hain ({tomorrow.length}):</strong> {names(tomorrow)}</div>}
        {today.length > 0 && <div><strong>Aaj ja rahe hain ({today.length}):</strong> {names(today)}</div>}
      </div>
      <button type="button" className="ops-alert-btn" onClick={() => navigate((tomorrow[0] || today[0]).route)}>Open</button>
    </div>
  );
}

/* ---- Tours + Hajj seats ---- */
export function ToursHajjPanel({ tours = [], hajjGroups = [] }) {
  const navigate = useNavigate();
  const empty = !tours.length && !hajjGroups.length;
  return (
    <Panel tone="tours" icon={Map} title="Upcoming Tours & Hajj" viewAll="/tours"
      sub={empty ? 'Nothing scheduled' : `${tours.length} tour${tours.length === 1 ? '' : 's'} · ${hajjGroups.length} Hajj group${hajjGroups.length === 1 ? '' : 's'}`}>
      {empty ? <Empty text="No upcoming tours or Hajj groups. Add one from the Tours or Hajj page." /> : (
        <div className="ops-list">
          {tours.map((t) => {
            const total = Number(t.total_seats) || 0;
            return (
              <div key={`t${t.id}`} className="ops-item click" onClick={() => navigate('/tours')} role="button">
                <div className="ops-ico tours"><Map size={16} /></div>
                <div className="ops-main">
                  <div className="ops-title">{t.tour_name}</div>
                  <div className="ops-sub">{[t.destination || t.city, fmtDate(t.start_date, false)].filter(Boolean).join(' · ')}</div>
                  {total > 0 && <SeatBar filled={t.seats_filled} total={total} />}
                </div>
                <div className="ops-end">
                  {total > 0 ? (
                    <>
                      <strong><Armchair size={12} /> {t.seats_filled}/{total}</strong>
                      <span className={t.seats_free === 0 ? 'bad' : ''}>{t.seats_free === 0 ? 'Full' : `${t.seats_free} free`}</span>
                    </>
                  ) : <span>{t.passengers} pax</span>}
                  <span className="ops-count">{countdownLabel(t.start_date)}</span>
                </div>
              </div>
            );
          })}
          {hajjGroups.map((g) => (
            <div key={`h${g.id}`} className="ops-item click" onClick={() => navigate('/hajj')} role="button">
              <div className="ops-ico hajj"><Tent size={16} /></div>
              <div className="ops-main">
                <div className="ops-title">{g.group_name}</div>
                <div className="ops-sub">{[g.package_name || 'Hajj group', fmtDate(g.departure_date, false)].join(' · ')}</div>
                {g.total_seats > 0 && <SeatBar filled={g.seats_filled} total={g.total_seats} />}
              </div>
              <div className="ops-end">
                {g.total_seats > 0 ? (
                  <>
                    <strong><Armchair size={12} /> {g.seats_filled}/{g.total_seats}</strong>
                    <span className={g.seats_free === 0 ? 'bad' : ''}>{g.seats_free === 0 ? 'Full' : `${g.seats_free} free`}</span>
                  </>
                ) : <strong><Users size={12} /> {g.total_pilgrims} pilgrims</strong>}
                <span className="ops-count">{countdownLabel(g.departure_date)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}

/* ---- This week's departures ---- */
export function WeekDeparturesPanel({ departures = [] }) {
  const navigate = useNavigate();
  return (
    <Panel tone="week" icon={CalendarDays} title="Departures This Week" viewAll="/travel-calendar"
      sub={departures.length ? `${departures.length} departure${departures.length === 1 ? '' : 's'} in the next 7 days` : 'No departures in the next 7 days'}>
      {!departures.length ? <Empty text="Koi departure is hafte nahi hai." /> : (
        <div className="ops-list">
          {departures.map((d) => {
            const Icon = KIND_ICON[d.kind] || PlaneTakeoff;
            const n = daysUntil(d.date);
            const logo = d.kind === 'Flight' ? airlineLogo(d.title) : null;
            return (
              <div key={`${d.kind}${d.id}`} className="ops-item click" onClick={() => navigate(d.route)} role="button">
                <div className={`ops-ico ${d.kind.toLowerCase()}`}>
                  {logo ? <img src={logo} alt="" /> : <Icon size={16} />}
                </div>
                <div className="ops-main">
                  <div className="ops-title">{d.title}</div>
                  <div className="ops-sub">{[d.kind, d.detail].filter(Boolean).join(' · ')}</div>
                </div>
                <div className="ops-end">
                  <strong>{fmtDate(d.date, false)}{d.time ? ` · ${d.time}` : ''}</strong>
                  <span className={`ops-chip ${n <= 1 ? 'hot' : ''}`}>{countdownLabel(d.date)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Panel>
  );
}

/* ---- Hotel check-ins and check-outs ---- */
function HotelRow({ h, kind, onOpen }) {
  const date = kind === 'in' ? h.check_in : h.check_out;
  const Icon = kind === 'in' ? LogIn : LogOut;
  return (
    <div className="ops-item click" onClick={onOpen} role="button">
      <div className={`ops-ico hotel-${kind}`}><Icon size={16} /></div>
      <div className="ops-main">
        <div className="ops-title">{h.hotel_name}</div>
        <div className="ops-sub">{[h.city, `${h.number_of_rooms || 1} room${(h.number_of_rooms || 1) > 1 ? 's' : ''}`, h.guests ? `${h.guests} guests` : null].filter(Boolean).join(' · ')}</div>
      </div>
      <div className="ops-end">
        <strong>{fmtDate(date, false)}</strong>
        <span className={`ops-chip ${daysUntil(date) <= 0 ? 'hot' : ''}`}>{countdownLabel(date)}</span>
      </div>
    </div>
  );
}

export function HotelsPanel({ checkIns = [], checkOuts = [] }) {
  const navigate = useNavigate();
  const total = checkIns.length + checkOuts.length;
  return (
    <Panel tone="hotels" icon={Hotel} title="Hotel Check-in & Check-out" viewAll="/hotels"
      sub={total ? `${checkIns.length} in · ${checkOuts.length} out in the next 3 days` : 'Nothing in the next 3 days'}>
      {!total ? <Empty text="Agle 3 din koi check-in ya check-out nahi hai." /> : (
        <div className="ops-list">
          {checkIns.length > 0 && <div className="ops-group"><LogIn size={13} /> Check-in</div>}
          {checkIns.map((h) => <HotelRow key={`i${h.id}`} h={h} kind="in" onOpen={() => navigate('/hotels')} />)}
          {checkOuts.length > 0 && <div className="ops-group"><LogOut size={13} /> Check-out</div>}
          {checkOuts.map((h) => <HotelRow key={`o${h.id}`} h={h} kind="out" onOpen={() => navigate('/hotels')} />)}
        </div>
      )}
    </Panel>
  );
}

/* ---- Today's transport pickups ---- */
function statusTone(s) {
  if (s === 'Completed') return 'done';
  if (s === 'In Progress') return 'live';
  return 'wait';
}

export function TransportPanel({ pickups = [] }) {
  const navigate = useNavigate();
  return (
    <Panel tone="transport" icon={BusFront} title="Today's Transport Pickups" viewAll="/transportation"
      sub={pickups.length ? `${pickups.length} pickup${pickups.length === 1 ? '' : 's'} today` : 'No pickups today'}>
      {!pickups.length ? <Empty text="Aaj koi transport pickup nahi hai." /> : (
        <div className="ops-list">
          {pickups.map((p) => (
            <div key={p.id} className="ops-item click" onClick={() => navigate('/transportation')} role="button">
              <div className="ops-ico transport"><BusFront size={16} /></div>
              <div className="ops-main">
                <div className="ops-title"><Clock3 size={12} /> {p.pickup_time || 'Time not set'} · {p.pickup_location}</div>
                <div className="ops-sub">
                  <MapPin size={11} /> {p.drop_location || 'Drop not set'}
                  {(p.vehicle || p.vehicle_number) && ` · ${[p.vehicle, p.vehicle_number].filter(Boolean).join(' ')}`}
                </div>
                {p.driver && <div className="ops-sub"><Users size={11} /> {p.driver}{p.driver_phone && <> · <Phone size={11} /> {p.driver_phone}</>}</div>}
              </div>
              <div className="ops-end"><span className={`ops-status ${statusTone(p.status)}`}>{p.status || 'Scheduled'}</span></div>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}
