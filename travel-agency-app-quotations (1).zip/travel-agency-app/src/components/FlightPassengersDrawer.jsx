import { useEffect, useState } from 'react';
import { X, Trash2, UsersRound } from 'lucide-react';
import CustomerPicker from './CustomerPicker.jsx';

/**
 * Passengers on one flight: the booking's family/group members (travellers) and any stand-alone customers.
 * "Add all" puts everybody from the booking on the flight in one click.
 */
export default function FlightPassengersDrawer({ flight, onClose }) {
  const [travellers, setTravellers] = useState([]);   // on this flight
  const [bookingTravellers, setBookingTravellers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [pick, setPick] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  async function reload() {
    const calls = [window.api.flights.travellers.list(flight.id), window.api.flights.passengers.list(flight.id)];
    if (flight.booking_id) calls.push(window.api.travellers.bookings.list(flight.booking_id));
    const [t, c, bt] = await Promise.all(calls);
    if (t.ok) setTravellers(t.data);
    if (c.ok) setCustomers(c.data);
    if (bt && bt.ok) setBookingTravellers(bt.data);
  }
  useEffect(() => { reload(); }, [flight.id]);

  const onFlight = new Set(travellers.map((t) => t.traveller_id));
  const available = bookingTravellers.filter((t) => !onFlight.has(t.id));

  async function addOne() {
    if (!pick) return;
    setError(''); setNotice('');
    const res = await window.api.flights.travellers.add(flight.id, Number(pick));
    if (!res.ok) return setError(res.error);
    setPick(''); reload();
  }
  async function addAll() {
    setError(''); setNotice('');
    const res = await window.api.flights.travellers.addAll(flight.id);
    if (!res.ok) return setError(res.error);
    setNotice(res.data.total === 0 ? 'This booking has no travellers yet — add them from Bookings → Travellers first.' : `${res.data.added} added.`);
    reload();
  }
  async function removeTraveller(id) { await window.api.flights.travellers.remove(id); reload(); }
  async function addCustomer(customerId) {
    const res = await window.api.flights.passengers.add(flight.id, customerId);
    if (res.ok) reload();
    return res;
  }
  async function removeCustomer(id) { await window.api.flights.passengers.remove(id, flight.id); reload(); }

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <strong>Passengers — {flight.flight_number || `Flight #${flight.id}`}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="drawer-body">
          {error && <div className="login-error" style={{ marginBottom: 8 }}>{error}</div>}
          {notice && <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>{notice}</p>}

          {flight.booking_id ? (
            <>
              <div style={{ fontWeight: 600, fontSize: 13, margin: '0 0 6px' }}>Booking travellers</div>
              {travellers.map((t) => (
                <div className="member-row" key={t.membership_id}>
                  <div>
                    <div>{t.full_name}</div>
                    <div className="member-meta">{[t.relationship, t.passport_number && `Passport ${t.passport_number}`].filter(Boolean).join(' · ')}</div>
                  </div>
                  <button className="icon-btn" title="Remove" onClick={() => removeTraveller(t.membership_id)}><Trash2 size={14} /></button>
                </div>
              ))}
              {travellers.length === 0 && <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No booking travellers on this flight yet.</p>}
              <div style={{ display: 'flex', gap: 8, margin: '10px 0 18px', flexWrap: 'wrap' }}>
                <button className="btn btn-primary btn-sm" onClick={addAll}><UsersRound size={13} /> Add all from booking</button>
                {available.length > 0 && (
                  <>
                    <select className="field-input" style={{ maxWidth: 200 }} value={pick} onChange={(e) => setPick(e.target.value)}>
                      <option value="">Add one…</option>
                      {available.map((t) => <option key={t.id} value={t.id}>{t.full_name}</option>)}
                    </select>
                    <button className="btn btn-secondary btn-sm" disabled={!pick} onClick={addOne}>Add</button>
                  </>
                )}
              </div>
            </>
          ) : (
            <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>Link this flight to a booking to add its family/group travellers here.</p>
          )}

          <div style={{ fontWeight: 600, fontSize: 13, margin: '0 0 6px' }}>Other customers</div>
          <CustomerPicker buttonLabel="Add" onAdd={addCustomer} />
          {customers.map((m) => (
            <div className="member-row" key={m.membership_id}>
              <div>
                <div>{m.full_name}</div>
                <div className="member-meta">{[m.phone, m.passport_number].filter(Boolean).join(' · ')}</div>
              </div>
              <button className="icon-btn" title="Remove" onClick={() => removeCustomer(m.membership_id)}><Trash2 size={14} /></button>
            </div>
          ))}
          {customers.length === 0 && <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No one added yet.</p>}
        </div>
      </div>
    </div>
  );
}
