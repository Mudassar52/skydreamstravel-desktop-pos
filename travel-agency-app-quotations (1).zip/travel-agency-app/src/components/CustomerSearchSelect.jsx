import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import './picker.css';

export default function CustomerSearchSelect({ value, valueLabel, onChange }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let active = true;
    if (!query.trim()) { setResults([]); return; }
    window.api.customers.list({ search: query, pageSize: 8 }).then((res) => {
      if (active && res.ok) setResults(res.data.rows);
    });
    return () => { active = false; };
  }, [query]);

  return (
    <div style={{ position: 'relative' }}>
      <div className="global-search" style={{ width: '100%' }}>
        <Search size={14} />
        <input
          placeholder="Search customer by name, phone, CNIC..."
          value={open ? query : (valueLabel || '')}
          onFocus={() => { setOpen(true); setQuery(''); }}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>
      {open && results.length > 0 && (
        <div className="picker-results" style={{ position: 'absolute', zIndex: 10, width: '100%' }}>
          {results.map((c) => (
            <button
              key={c.id}
              type="button" className="picker-result"
              onClick={() => { onChange(c.id, c.full_name, c); setOpen(false); }}
            >
              {c.full_name} <span>{c.phone || c.cnic || ''}</span>
            </button>
          ))}
        </div>
      )}
      {open && (
        <button
          type="button"
          onClick={() => setOpen(false)}
          style={{ position: 'fixed', inset: 0, zIndex: 5, background: 'transparent', border: 'none', cursor: 'default' }}
          tabIndex={-1}
        />
      )}
    </div>
  );
}
