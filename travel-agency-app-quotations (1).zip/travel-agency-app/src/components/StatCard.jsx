import './statcard.css';

export default function StatCard({ icon: Icon, label, value, tone = 'primary', suffix, onClick }) {
  return (
    <div className={`card stat-card${onClick ? ' stat-card-clickable' : ''}`} onClick={onClick} role={onClick ? 'button' : undefined}>
      <div className={`stat-icon tone-${tone}`}>
        <Icon size={19} strokeWidth={2} />
      </div>
      <div className="stat-body">
        <span className="stat-label">{label}</span>
        <strong className="stat-value">
          {value}
          {suffix && <span className="stat-suffix">{suffix}</span>}
        </strong>
      </div>
    </div>
  );
}
