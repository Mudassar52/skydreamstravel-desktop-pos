// Company logo files go in  src/assets/ :
//   logo-icon.png -> shown everywhere (sidebar, header, login)
//   logo.png      -> shown only when the sidebar is collapsed
// jpg / jpeg / webp / svg also work. With no logo file the app falls back to the plane icon.
//
// Matching is forgiving on purpose: "Logo.PNG", "logo.png.png" (Windows hiding the extension) and
// "logo-icon.jpg" are all found. Anything in src/assets whose name starts with "logo" is picked up.
const files = import.meta.glob('../assets/*.{png,PNG,jpg,JPG,jpeg,JPEG,webp,WEBP,svg,SVG}', { eager: true, import: 'default' });

function find(test) {
  const hit = Object.entries(files).find(([path]) => test(path.split('/').pop().toLowerCase()));
  return hit ? hit[1] : null;
}

const fullLogo = find((name) => /^logo(\.|$)/.test(name));
const iconLogo = find((name) => /^logo[-_ ]?icon(\.|$)/.test(name));

// logo-icon is the one used everywhere; the full logo.png is shown only in the collapsed sidebar.
// If only one of the two files exists, it is used for both.
export const logoIconSrc = iconLogo || fullLogo;
export const logoSrc = fullLogo || iconLogo;

if (import.meta.env.DEV && !logoIconSrc) {
  console.warn('[logo] No logo found. Put logo.png inside src/assets/ and restart the dev server (npm run dev).');
}
