import { useState } from 'react';
import { Search, Plus } from 'lucide-react';
import './picker.css';

export default function CustomerPicker({ onAdd, buttonLabel = 'Add' }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  async function search(q) {
    setQuery(q);
    setSelected(null);
    setError('');
    if (!q.trim()) { setResults([]); return; }
    const res = await window.api.customers.list({ search: q, pageSize: 8 });
    if (res.ok) setResults(res.data.rows);
  }

  async function handleAdd() {
    setError('');
    const res = await onAdd(selected.id, notes);
    if (res && !res.ok) {
      setError(res.error);
      return;
    }
    setSelected(null);
    setQuery('');
    setNotes('');
  }

  return (
    <div className="passenger-picker">
      <div className="global-search" style={{ width: '100%' }}>
        <Search size={14} />
        <input
          placeholder="Search customer by name, phone, passport..."
          value={selected ? selected.full_name : query}
          onChange={(e) => search(e.target.value)}
        />
      </div>

      {results.length > 0 && !selected && (
        <div className="picker-results">
          {results.map((c) => (
            <button key={c.id} className="picker-result" onClick={() => { setSelected(c); setResults([]); }}>
              {c.full_name} <span>{c.phone || c.passport_number || ''}</span>
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          <input
            className="field-input"
            placeholder="Notes (optional)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            style={{ flex: 1 }}
          />
          <button className="btn btn-primary btn-sm" onClick={handleAdd}>
            <Plus size={13} /> {buttonLabel}
          </button>
        </div>
      )}
      {error && <div className="field-error">{error}</div>}
    </div>
  );
}
