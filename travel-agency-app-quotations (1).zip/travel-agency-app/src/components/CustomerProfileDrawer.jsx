import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Pencil, CalendarCheck, Receipt, Wallet, Files, BookOpen, UserSquare2, BellRing } from 'lucide-react';
import '../pages/customers.css';

const TABS = [
  { key: 'profile', label: 'Profile' },
  { key: 'bookings', label: 'Bookings', icon: CalendarCheck, phase: 6, implemented: true },
  { key: 'travellers', label: 'Travellers', icon: UserSquare2, phase: 19, implemented: true },
  { key: 'invoices', label: 'Invoices', icon: Receipt, phase: 8, implemented: true },
  { key: 'payments', label: 'Payments', icon: Wallet, phase: 9, implemented: true },
  { key: 'followups', label: 'Follow-ups', icon: BellRing, phase: 19, implemented: true },
  { key: 'documents', label: 'Documents', icon: Files, phase: 11, implemented: true }
];

export default function CustomerProfileDrawer({ customerId, onClose, onEdit }) {
  const navigate = useNavigate();
  const [customer, setCustomer] = useState(null);
  const [tab, setTab] = useState('profile');
  const [bookings, setBookings] = useState(null);
  const [payments, setPayments] = useState(null);
  const [documents, setDocuments] = useState(null);
  const [travellers, setTravellers] = useState(null);
  const [invoices, setInvoices] = useState(null);
  const [followups, setFollowups] = useState(null);

  useEffect(() => {
    window.api.customers.get(customerId).then((res) => { if (res.ok) setCustomer(res.data); });
  }, [customerId]);

  useEffect(() => {
    if (tab === 'bookings' && bookings === null) {
      window.api.bookings.listByCustomer(customerId).then((res) => { if (res.ok) setBookings(res.data); });
    }
    if (tab === 'payments' && payments === null) {
      window.api.payments.list({ customerId }).then((res) => { if (res.ok) setPayments(res.data.rows); });
    }
    if (tab === 'documents' && documents === null) {
      window.api.documents.list({ customerId, pageSize: 100 }).then((res) => { if (res.ok) setDocuments(res.data.rows); });
    }
    if (tab === 'travellers' && travellers === null) {
      window.api.travellers.listByCustomer(customerId).then((res) => { if (res.ok) setTravellers(res.data); });
    }
    if (tab === 'invoices' && invoices === null) {
      window.api.invoices.listByCustomer(customerId).then((res) => { if (res.ok) setInvoices(res.data); });
    }
    if (tab === 'followups' && followups === null) {
      window.api.followups.list({ search: '', status: 'All', pageSize: 100 }).then((res) => {
        if (res.ok) setFollowups(res.data.rows.filter((f) => f.customer_id === customerId));
      });
    }
  }, [tab, customerId, bookings, payments, documents, travellers, invoices, followups]);

  if (!customer) return null;

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <div>
            <h2 style={{ fontSize: 17 }}>{customer.full_name}</h2>
            <span className={`status-pill ${customer.status === 'Active' ? 'on' : 'off'}`} style={{ marginTop: 6, display: 'inline-block' }}>
              {customer.status}
            </span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary btn-sm" onClick={() => navigate(`/customers/${customerId}/360`)}>
              <BookOpen size={13} /> Open Complete Travel Dossier
            </button>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/ledger', { state: { customerId, customerLabel: customer.full_name } })}>
              <BookOpen size={13} /> Ledger
            </button>
            <button className="btn btn-secondary btn-sm" onClick={onEdit}><Pencil size={13} /> Edit</button>
            <button className="icon-btn" onClick={onClose}><X size={15} /></button>
          </div>
        </div>

        <div className="tabs" style={{ padding: '0 24px' }}>
          {TABS.map((t) => (
            <button key={t.key} className={tab === t.key ? 'tab active' : 'tab'} onClick={() => setTab(t.key)}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="drawer-body">
          {tab === 'profile' && (
            <>
              <SummaryStrip customer={customer} />

              <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Personal Information</h3>
              <InfoRow label="Father / Husband Name" value={customer.father_husband_name} />
              <InfoRow label="CNIC" value={customer.cnic} />
              <InfoRow label="Date of Birth" value={customer.date_of_birth} />
              <InfoRow label="Gender" value={customer.gender} />
              <InfoRow label="Nationality" value={customer.nationality} />
              <InfoRow label="Phone" value={customer.phone} />
              <InfoRow label="WhatsApp" value={customer.whatsapp} />
              <InfoRow label="Email" value={customer.email} />
              <InfoRow label="Address" value={customer.address} />
              <InfoRow label="Emergency Contact" value={customer.emergency_contact} />

              <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Passport Information</h3>
              <InfoRow label="Passport Number" value={customer.passport_number} />
              <InfoRow label="Issue Date" value={customer.passport_issue_date} />
              <InfoRow label="Expiry Date" value={customer.passport_expiry_date} />

              {customer.notes && (
                <>
                  <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Notes</h3>
                  <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{customer.notes}</p>
                </>
              )}
            </>
          )}

          {tab !== 'profile' && tab !== 'bookings' && tab !== 'payments' && tab !== 'documents' && tab !== 'travellers' && tab !== 'invoices' && tab !== 'followups' && (
            <PendingTab tab={TABS.find((t) => t.key === tab)} />
          )}

          {tab === 'bookings' && (
            <div>
              {(bookings || []).map((b) => (
                <div className="info-row" key={b.id}>
                  <span>{b.booking_code} · {b.booking_type}</span>
                  <span>{b.status} · Rs. {Number(b.total_price || 0).toLocaleString('en-PK')}</span>
                </div>
              ))}
              {bookings && bookings.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No bookings yet.</p>
              )}
            </div>
          )}

          {tab === 'payments' && (
            <div>
              {(payments || []).map((p) => (
                <div className="info-row" key={p.id}>
                  <span>{p.payment_date?.slice(0, 10)} · {p.payment_type} · {p.payment_method}</span>
                  <span>Rs. {Number(p.amount || 0).toLocaleString('en-PK')}</span>
                </div>
              ))}
              {payments && payments.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No payments recorded yet.</p>
              )}
            </div>
          )}

          {tab === 'documents' && (
            <div>
              {(documents || []).map((d) => (
                <div className="info-row" key={d.id}>
                  <span>{d.file_name}</span>
                  <span>{d.document_type}</span>
                </div>
              ))}
              {documents && documents.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No documents uploaded yet.</p>
              )}
            </div>
          )}

          {tab === 'travellers' && (
            <div>
              {(travellers || []).map((t) => (
                <div className="info-row" key={t.id}>
                  <span>{t.full_name} · {t.relationship || 'Traveller'}</span>
                  <span>{t.passport_number || 'No passport on file'}</span>
                </div>
              ))}
              {travellers && travellers.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No travellers linked to this customer yet.</p>
              )}
            </div>
          )}

          {tab === 'invoices' && (
            <div>
              {(invoices || []).map((i) => (
                <div className="info-row" key={i.id}>
                  <span>{i.invoice_number} · {i.status}</span>
                  <span>Rs. {Number(i.total || 0).toLocaleString('en-PK')} · Balance Rs. {Number(i.remaining_amount || 0).toLocaleString('en-PK')}</span>
                </div>
              ))}
              {invoices && invoices.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No invoices raised yet.</p>
              )}
            </div>
          )}

          {tab === 'followups' && (
            <div>
              {(followups || []).map((f) => (
                <div className="info-row" key={f.id}>
                  <span>{f.follow_up_date} · {f.priority}</span>
                  <span>{f.effective_status}</span>
                </div>
              ))}
              {followups && followups.length === 0 && (
                <p style={{ fontSize: 12.5, color: 'var(--color-text-faint)' }}>No follow-ups scheduled for this customer.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryStrip({ customer }) {
  return (
    <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
      <MiniStat label="Bookings" value={customer.bookingsCount} />
      <MiniStat label="Invoices" value={customer.invoicesCount} />
      <MiniStat label="Outstanding" value={`Rs. ${Number(customer.outstanding || 0).toLocaleString('en-PK')}`} />
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="card" style={{ padding: '12px 14px' }}>
      <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 700, marginTop: 2 }}>{value}</div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="info-row">
      <span>{label}</span>
      <span>{value || '—'}</span>
    </div>
  );
}

function PendingTab({ tab }) {
  const Icon = tab.icon;
  return (
    <div style={{ textAlign: 'center', padding: '40px 10px', color: 'var(--color-text-faint)' }}>
      <Icon size={26} />
      <p style={{ fontSize: 12.5, marginTop: 10 }}>
        {tab.label} will appear here once Phase {tab.phase} is built.
      </p>
    </div>
  );
}
