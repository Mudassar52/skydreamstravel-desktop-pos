import { useNavigate } from 'react-router-dom';
import { MoonStar, Users, Package, BedDouble, ShieldCheck, CalendarClock, CalendarRange } from 'lucide-react';
import PlaneGlyph from './PlaneGlyph.jsx';
import { Clouds, AirlineLogo, RouteLine } from './UpcomingFlights.jsx';
import { parseAirport, countdownLabel, fmtDate, daysBetween } from '../utils/travelDisplay.js';
import './upcoming.css';

const nightsOf = (g) => {
  const stay = (Number(g.makkah_nights) || 0) + (Number(g.madinah_nights) || 0);
  return stay || daysBetween(g.departure_date, g.return_date);
};

function visaTone(status) {
  const s = String(status || '').toLowerCase();
  if (/(approved|issued|done|complete)/.test(s)) return { bg: 'var(--color-success-bg)', fg: 'var(--color-success)' };
  if (/(reject|refus|cancel)/.test(s)) return { bg: 'var(--color-danger-bg)', fg: 'var(--color-danger)' };
  return { bg: 'var(--color-warning-bg)', fg: 'var(--color-warning)' };
}

function UmrahHero({ g, onOpen }) {
  const hasFlight = !!(g.departure_airport || g.arrival_airport);
  const from = parseAirport(g.departure_airport);
  const to = parseAirport(g.arrival_airport);
  const nights = nightsOf(g);
  const tone = visaTone(g.visa_status);
  return (
    <div className="up-hero" onClick={onOpen} role="button">
      <Clouds />
      <div className="up-hero-top">
        <AirlineLogo airline={g.airline} Fallback={MoonStar} />
        <div className="up-airline">
          {g.group_name}
          <span>{g.package_name || 'Umrah group'}{g.flight_number ? ` · ${g.flight_number}` : ''}</span>
        </div>
        <span className="up-pill"><CalendarClock size={13} />{countdownLabel(g.departure_date)}</span>
      </div>

      <div className="up-route">
        <div className="up-place">
          <div className="code">{hasFlight ? from.code : fmtDate(g.departure_date, false)}</div>
          <div className="city">{hasFlight ? (from.name || 'Departure') : 'Departure'}</div>
          <div className="when">{hasFlight ? `${fmtDate(g.departure_date, false)}${g.departure_time ? ` · ${g.departure_time}` : ''}` : fmtDate(g.departure_date)}</div>
        </div>
        <RouteLine caption={nights ? `${nights} nights` : 'Umrah'} />
        <div className="up-place right">
          <div className="code">{hasFlight ? to.code : fmtDate(g.return_date, false)}</div>
          <div className="city">{hasFlight ? (to.name || 'Arrival') : 'Return'}</div>
          <div className="when">{hasFlight ? `Returns ${fmtDate(g.return_date, false)}` : fmtDate(g.return_date)}</div>
        </div>
      </div>

      <div className="up-perf" />
      <div className="up-meta">
        <div><Users size={14} /> Pilgrims <strong>{g.total_passengers || 0}</strong></div>
        <div><BedDouble size={14} /> Makkah <strong>{g.makkah_nights || '—'}</strong> · Madinah <strong>{g.madinah_nights || '—'}</strong></div>
        <div>
          <ShieldCheck size={14} /> Visa
          <strong style={{ background: tone.bg, color: tone.fg, padding: '2px 9px', borderRadius: 999 }}>{g.visa_status || 'Pending'}</strong>
        </div>
      </div>
    </div>
  );
}

function UmrahRow({ g, onOpen }) {
  return (
    <div className="up-row" onClick={onOpen} role="button">
      <div className="up-logo sm"><MoonStar size={16} /></div>
      <div className="who">
        {g.group_name}
        <span>{g.package_name || 'Umrah group'}</span>
      </div>
      <div className="up-mini">
        <span>{fmtDate(g.departure_date, false)}</span>
        <span className="mini-line"><PlaneGlyph size={16} /></span>
        <span>{fmtDate(g.return_date, false)}</span>
      </div>
      <div className="end">
        <strong>{g.total_passengers || 0} pax</strong>
        {countdownLabel(g.departure_date)}
      </div>
    </div>
  );
}

export default function UpcomingUmrah({ groups = [], error }) {
  const navigate = useNavigate();
  const [next, ...rest] = groups;
  return (
    <div className="card up-panel umrah">
      <div className="up-head">
        <div className="up-head-icon"><MoonStar size={18} /></div>
        <div>
          <h3>Upcoming Umrah Groups</h3>
          <small>{error ? 'Could not load groups' : !groups.length ? 'Nothing scheduled' : groups[0].is_past ? 'No upcoming groups — showing latest' : `${groups.length} group${groups.length > 1 ? 's' : ''} departing soon`}</small>
        </div>
        <button type="button" className="up-viewall" onClick={() => navigate('/umrah')}>View all</button>
      </div>

      {next ? (
        <>
          <UmrahHero g={next} onOpen={() => navigate('/umrah')} />
          {rest.length > 0 && (
            <>
              <div className="up-sub">Next after this</div>
              <div className="up-list">
                {rest.map((g) => <UmrahRow key={g.id} g={g} onOpen={() => navigate('/umrah')} />)}
              </div>
            </>
          )}
          {rest.length === 0 && <div className="up-bottom-pad" />}
        </>
      ) : (
        <div className="up-empty"><CalendarRange size={26} /><div>{error || 'No Umrah groups added yet. Add one from the Umrah page.'}</div></div>
      )}
    </div>
  );
}
