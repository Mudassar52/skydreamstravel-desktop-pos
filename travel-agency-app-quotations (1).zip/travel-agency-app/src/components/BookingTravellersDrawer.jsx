import { useEffect, useState } from 'react';
import { X, Trash2, UserPlus } from 'lucide-react';

const COUNTRIES = ['Saudi Arabia', 'UAE', 'Turkey', 'Malaysia', 'UK', 'USA', 'Schengen', 'Other'];
const EMPTY = { full_name: '', relationship: 'Spouse', gender: '', date_of_birth: '', nationality: '', passport_number: '', passport_expiry_date: '' };

/**
 * Everyone travelling on a booking (family / group members). The booking itself stays under ONE lead customer
 * (who is invoiced and pays); the other members are travellers attached here, with passport details, and they
 * are printed on the hotel / transport vouchers and shown in the Booking Dossier.
 */
export default function BookingTravellersDrawer({ booking, onClose }) {
  const [members, setMembers] = useState([]);
  const [known, setKnown] = useState([]);       // travellers already saved under this customer
  const [relationships, setRelationships] = useState([]);
  const [pick, setPick] = useState('');
  const [form, setForm] = useState(EMPTY);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [visa, setVisa] = useState({ country: 'Saudi Arabia', visa_type: 'Umrah', include_lead: true });
  const [visaMsg, setVisaMsg] = useState('');

  async function reload() {
    const [m, k] = await Promise.all([
      window.api.travellers.bookings.list(booking.id),
      window.api.travellers.listByCustomer(booking.customer_id)
    ]);
    if (m.ok) setMembers(m.data);
    if (k.ok) setKnown(k.data);
  }
  useEffect(() => {
    reload();
    window.api.travellers.relationships().then((r) => { if (r.ok) setRelationships(r.data); });
  }, [booking.id]);

  const onBooking = new Set(members.map((m) => m.id));
  const available = known.filter((t) => !onBooking.has(t.id));
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function addExisting() {
    if (!pick) return;
    setBusy(true); setError('');
    const res = await window.api.travellers.bookings.add(booking.id, Number(pick), null);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setPick(''); reload();
  }

  async function addNew() {
    if (!form.full_name.trim()) return setError('Traveller name is required.');
    setBusy(true); setError('');
    const created = await window.api.travellers.create({ ...form, customer_id: booking.customer_id });
    if (!created.ok) { setBusy(false); return setError(created.error); }
    const res = await window.api.travellers.bookings.add(booking.id, created.data.id, null);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setForm(EMPTY); setShowForm(false); reload();
  }

  async function remove(membershipId) {
    await window.api.travellers.bookings.remove(membershipId);
    reload();
  }

  async function createVisas() {
    setError(''); setVisaMsg('');
    if (!visa.country.trim()) return setError('Country is required for the visa applications.');
    setBusy(true);
    const res = await window.api.visa.createForBooking(booking.id, visa);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setVisaMsg(`${res.data.created} visa application${res.data.created === 1 ? '' : 's'} created${res.data.skipped ? `, ${res.data.skipped} already existed` : ''}. Track them on the Visa page.`);
  }

  const expected = Number(booking.number_of_passengers || 0);
  const total = members.length + 1; // + the lead customer
  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <strong>Travellers — {booking.booking_code}</strong>
          <button className="icon-btn" onClick={onClose}><X size={15} /></button>
        </div>
        <div className="drawer-body">
          <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', marginTop: 0 }}>
            Booking is under <strong>{booking.customer_name}</strong> (lead / payer). Add the other family or group members here — their names and passports
            appear on the hotel and transport vouchers and in the Booking Dossier.
          </p>
          <div className="member-row">
            <div>
              <div>{booking.customer_name} <span className="member-meta">· Lead (booking holder)</span></div>
            </div>
          </div>
          {members.map((m) => (
            <div className="member-row" key={m.membership_id}>
              <div>
                <div>{m.full_name}</div>
                <div className="member-meta">
                  {[m.relationship, m.passport_number && `Passport ${m.passport_number}`, m.passport_expiry_date && `exp ${m.passport_expiry_date}`].filter(Boolean).join(' · ')}
                </div>
              </div>
              <button className="icon-btn" title="Remove from booking" onClick={() => remove(m.membership_id)}><Trash2 size={14} /></button>
            </div>
          ))}
          <p style={{ fontSize: 12.5, margin: '10px 0', color: expected && total !== expected ? 'var(--color-warning, #B54708)' : 'var(--color-text-muted)' }}>
            {total} traveller{total === 1 ? '' : 's'} listed{expected ? ` of ${expected} passenger${expected === 1 ? '' : 's'} on this booking` : ''}
            {expected && total !== expected ? ' — numbers do not match yet.' : '.'}
          </p>

          {error && <div className="login-error" style={{ marginBottom: 8 }}>{error}</div>}

          {available.length > 0 && (
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <select className="field-input" value={pick} onChange={(e) => setPick(e.target.value)}>
                <option value="">Add a saved family member…</option>
                {available.map((t) => <option key={t.id} value={t.id}>{t.full_name}{t.relationship ? ` (${t.relationship})` : ''}</option>)}
              </select>
              <button className="btn btn-secondary btn-sm" disabled={!pick || busy} onClick={addExisting}>Add</button>
            </div>
          )}

          {!showForm ? (
            <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}><UserPlus size={13} /> New traveller</button>
          ) : (
            <div className="card" style={{ padding: 12 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <input className="field-input" style={{ gridColumn: '1 / -1' }} placeholder="Full name (as on passport) *" value={form.full_name} onChange={set('full_name')} />
                <select className="field-input" value={form.relationship} onChange={set('relationship')}>
                  {(relationships.length ? relationships : ['Spouse', 'Child', 'Parent', 'Sibling', 'Other']).map((r) => <option key={r}>{r}</option>)}
                </select>
                <select className="field-input" value={form.gender} onChange={set('gender')}>
                  <option value="">Gender</option><option>Male</option><option>Female</option>
                </select>
                <input className="field-input" type="date" title="Date of birth" value={form.date_of_birth} onChange={set('date_of_birth')} />
                <input className="field-input" placeholder="Nationality" value={form.nationality} onChange={set('nationality')} />
                <input className="field-input" placeholder="Passport number" value={form.passport_number} onChange={set('passport_number')} />
                <input className="field-input" type="date" title="Passport expiry" value={form.passport_expiry_date} onChange={set('passport_expiry_date')} />
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button className="btn btn-primary btn-sm" disabled={busy} onClick={addNew}>Save &amp; add to booking</button>
                <button className="btn btn-secondary btn-sm" onClick={() => { setShowForm(false); setForm(EMPTY); setError(''); }}>Cancel</button>
              </div>
            </div>
          )}

          <div style={{ marginTop: 22, paddingTop: 14, borderTop: '1px solid var(--color-border, #E4E7EC)' }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 6 }}>Visa applications for everyone</div>
            <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)', margin: '0 0 8px' }}>
              Creates one visa application per person on this booking (status “Documents Pending”). People who already have one for this country are skipped.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <input className="field-input" list="visa-countries" placeholder="Country" value={visa.country} onChange={(e) => setVisa((v) => ({ ...v, country: e.target.value }))} />
              <datalist id="visa-countries">{COUNTRIES.map((c) => <option key={c} value={c} />)}</datalist>
              <input className="field-input" placeholder="Visa type (e.g. Umrah)" value={visa.visa_type} onChange={(e) => setVisa((v) => ({ ...v, visa_type: e.target.value }))} />
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, margin: '8px 0' }}>
              <input type="checkbox" checked={visa.include_lead} onChange={(e) => setVisa((v) => ({ ...v, include_lead: e.target.checked }))} />
              Include {booking.customer_name} (lead)
            </label>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={createVisas}>Create visa applications</button>
            {visaMsg && <p style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>{visaMsg}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
