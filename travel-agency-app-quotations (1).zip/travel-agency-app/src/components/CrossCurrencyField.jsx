import Field from './Field.jsx';

/**
 * Shown only when the money moves through a bank/cash account whose currency differs from the document it settles
 * (e.g. a USD invoice paid into a PKR account): asks for the amount that REALLY moved through the account, in the
 * account's currency. Returns null when no extra figure is needed.
 */
export function isCross(docCurrency, account) {
  const a = account && account.currency ? String(account.currency).toUpperCase() : '';
  const d = docCurrency ? String(docCurrency).toUpperCase() : '';
  return !!(a && d && a !== d);
}

export default function CrossCurrencyField({ docCurrency, account, label, value, onChange }) {
  if (!isCross(docCurrency, account)) return null;
  const acc = String(account.currency).toUpperCase();
  return (
    <Field label={`${label} (${acc}) *`} full>
      <input type="number" step="any" className="field-input" value={value} onChange={(e) => onChange(e.target.value)} />
      <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 4 }}>
        This is in {String(docCurrency).toUpperCase()} but the account holds {acc}. Enter what actually moved through the account;
        the difference from the booked exchange rate is recorded as exchange gain/loss.
      </div>
    </Field>
  );
}
