// Top-down airplane silhouette pointing right (lucide's own Plane icon points
// diagonally, which looks wrong on a left-to-right route line).
export default function PlaneGlyph({ size = 22, className, style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} style={style} aria-hidden="true">
      <path d="M22 12c0-.9-.8-1.6-1.8-1.6h-4.6L10.6 2.5H8.3l2.5 7.9H6.6L4.9 8H3.2l1 4-1 4h1.7l1.7-2.4h4.2l-2.5 7.9h2.3l5-7.9h4.6c1 0 1.8-.7 1.8-1.6z" />
    </svg>
  );
}
