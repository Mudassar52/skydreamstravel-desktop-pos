import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['electron/**/*.test.js'],
    testTimeout: 15000,
    // Test files are CommonJS (matching the rest of electron/), and
    // Vitest's package is ESM-only, so require('vitest') doesn't work from
    // them. `globals: true` injects describe/it/expect/vi as globals
    // instead, which CJS files can use without an import statement.
    globals: true,
    // Each test file gets its own module registry, so the db.js singleton
    // doesn't leak a database connection from one test file into another.
    isolate: true
  }
});
