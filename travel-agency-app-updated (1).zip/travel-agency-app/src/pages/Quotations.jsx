import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { Plus, Pencil, Trash2, ArrowRightCircle, ChevronLeft, ChevronRight, RotateCcw, X, Eye, FileDown, Printer } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import PreviewPane from '../components/PreviewPane.jsx';
import { flowOf, INFO_FIELDS, PAX, newHotel, hotelNights, itemsToFlow, flowToItems } from './quotationFlow.js';
import './customers.css';
import './quotations.css';

const PAGE_SIZE = 15;

// Fallbacks so the screen still works if the meta call is slow; the real lists come from quotationService.meta().
const FALLBACK_META = {
  statuses: ['Draft', 'Sent', 'Accepted', 'Rejected', 'Expired', 'Converted'],
  types: ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transport', 'Custom Package'],
  travelClasses: ['Economy', 'Business', 'First Class'],
  categories: ['Flight', 'Hotel', 'Visa', 'Transport', 'Package', 'Other'],
  currencies: ['PKR', 'SAR', 'USD', 'AED', 'GBP', 'EUR'],
  sentVia: ['WhatsApp', 'Email', 'Printed', 'Other']
};
const UNITS = ['Person', 'Room', 'Night', 'Ticket', 'Vehicle', 'Package', 'Other'];
const DEFAULT_UNIT = { Flight: 'Ticket', Hotel: 'Room', Visa: 'Person', Transport: 'Vehicle', Package: 'Person', Other: 'Other' };

const num = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
const r2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const fmt = (n, cur = 'PKR') => `${cur} ${num(n).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
const pad = (n) => String(n).padStart(2, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayStr = () => isoDate(new Date());
const plusDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return isoDate(d); };
const nowLocal = () => { const d = new Date(); return `${isoDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const nightsBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);

const pillTone = (s) => (s === 'Rejected' || s === 'Expired' ? 'off' : 'on');

export default function Quotations() {
  const { can, hasCapability } = useAuth();
  const canSeeCost = hasCapability('view_profit');
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [type, setType] = useState('All');
  const [search, setSearch] = useState('');
  const [meta, setMeta] = useState(FALLBACK_META);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [reviseTarget, setReviseTarget] = useState(null);
  const [viewId, setViewId] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.quotations.meta().then((res) => res.ok && setMeta({ ...FALLBACK_META, ...res.data })); }, []);

  const load = useCallback(async () => {
    const res = await window.api.quotations.list({ search, status, type, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); setError(''); } else setError(res.error);
  }, [search, status, type, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status, type]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3500); }

  async function confirmDelete() {
    const res = await window.api.quotations.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Quotation deleted.'); load(); }
    setDeleteTarget(null);
  }

  async function confirmRevise() {
    const res = await window.api.quotations.revise(reviseTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${reviseTarget.quotation_number} is now Rev ${res.data.revision_number} (Draft).`); load(); }
    setReviseTarget(null);
  }

  async function convert(q) {
    const res = await window.api.quotations.convertToBooking(q.id);
    if (!res.ok) return setError(res.error);
    flash(res.data.alreadyConverted ? 'Already converted.' : `Converted to booking #${res.data.bookingId}.`);
    load();
  }

  const today = todayStr();
  const colCount = canSeeCost ? 9 : 8;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Quotations</h1>
          <p>{total.toLocaleString()} quotation{total === 1 ? '' : 's'}</p>
        </div>
        {can('quotations', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}><Plus size={15} /> New Quotation</button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <input placeholder="Search quotation #, customer, phone, destination..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 160 }} value={type} onChange={(e) => setType(e.target.value)}>
          <option value="All">All types</option>
          {meta.types.map((t) => <option key={t}>{t}</option>)}
        </select>
        <select className="field-input" style={{ width: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All statuses</option>
          {meta.statuses.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card qt-card" style={{ padding: 0 }}>
        <table className="data-table qt-table">
          <thead>
            <tr>
              <th>Quotation #</th><th>Customer</th><th>Trip</th><th>Travel Dates</th>
              <th>Total</th>{canSeeCost && <th>Exp. Profit</th>}<th>Valid Until</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((q) => {
              const overdue = q.valid_until && q.valid_until < today && ['Draft', 'Sent'].includes(q.status);
              const c = q.currency || 'PKR';
              return (
                <tr key={q.id}>
                  <td>
                    <strong>{q.quotation_number}</strong>
                    {q.revision_number > 0 && <span className="qt-rev">Rev {q.revision_number}</span>}
                    <span className="qt-sub">{q.quotation_date || ''}</span>
                  </td>
                  <td>{q.customer_name}{q.customer_phone && <span className="qt-sub">{q.customer_phone}</span>}</td>
                  <td>{q.destination || '—'}<span className="qt-sub">{q.quotation_type || '—'}</span></td>
                  <td>
                    {q.travel_date_from ? <>{q.travel_date_from}<span className="qt-sub">to {q.travel_date_to || '—'}</span></> : '—'}
                  </td>
                  <td className="qt-nowrap">{fmt(q.selling_price, c)}{num(q.advance_required) > 0 && <span className="qt-sub">Advance {fmt(q.advance_required, c)}</span>}</td>
                  {canSeeCost && <td className="qt-nowrap">{q.expected_profit == null ? '—' : fmt(q.expected_profit, c)}</td>}
                  <td className={`qt-nowrap${overdue ? ' qt-overdue' : ''}`}>{q.valid_until || '—'}</td>
                  <td><span className={`status-pill ${pillTone(q.status)}`}>{q.status}</span></td>
                  <td>
                    <div className="qt-actions">
                      <button className="icon-btn" title="View" onClick={() => setViewId(q.id)}><Eye size={14} /></button>
                      {['Accepted', 'Sent'].includes(q.status) && can('quotations', 'edit') && (
                        <button className="icon-btn" title="Convert to Booking" onClick={() => convert(q)}><ArrowRightCircle size={14} /></button>
                      )}
                      {q.status !== 'Converted' && can('quotations', 'edit') && (
                        <button className="icon-btn" title="Create revision" onClick={() => setReviseTarget(q)}><RotateCcw size={14} /></button>
                      )}
                      {q.status !== 'Converted' && can('quotations', 'edit') && (
                        <button className="icon-btn" title="Edit" onClick={() => { setEditingId(q.id); setFormOpen(true); }}><Pencil size={14} /></button>
                      )}
                      {q.status !== 'Converted' && can('quotations', 'delete') && (
                        <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(q)}><Trash2 size={14} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {rows.length === 0 && <tr><td colSpan={colCount} className="empty-row">No quotations found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {viewId && (
        <QuotationViewModal
          quotationId={viewId} canSeeCost={canSeeCost}
          onClose={() => setViewId(null)}
          onEdit={can('quotations', 'edit') ? (id) => { setViewId(null); setEditingId(id); setFormOpen(true); } : null}
        />
      )}

      {formOpen && (
        <QuotationFormModal
          quotationId={editingId} meta={meta} canSeeCost={canSeeCost}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete quotation" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.quotation_number}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}

      {reviseTarget && (
        <Modal title="Create revision" onClose={() => setReviseTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)', lineHeight: 1.55 }}>
            Start <strong>Rev {(reviseTarget.revision_number || 0) + 1}</strong> of <strong>{reviseTarget.quotation_number}</strong>?
            The quotation number stays the same, its status goes back to <strong>Draft</strong> and the sent details are cleared so you can edit and send it again.
            The previous total is kept in the audit log.
          </p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setReviseTarget(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={confirmRevise}>Create revision</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------------------------------------------------
// Read-only view
// ---------------------------------------------------------------------------------------------------------------------

const UMRAH_LABELS = {
  makkah_hotel: 'Makkah hotel', madinah_hotel: 'Madinah hotel', room_type: 'Room type', makkah_nights: 'Makkah nights',
  madinah_nights: 'Madinah nights', transport_type: 'Transport', visa_details: 'Visa', ziyarat: 'Ziyarat'
};

function Info({ label, children, wide }) {
  return (
    <div className={`qt-info${wide ? ' wide' : ''}`}>
      <span>{label}</span>
      <div>{children === undefined || children === null || children === '' ? '—' : children}</div>
    </div>
  );
}

function QuotationViewModal({ quotationId, canSeeCost, onClose, onEdit }) {
  const [q, setQ] = useState(null);
  const [error, setError] = useState('');
  const [previewHtml, setPreviewHtml] = useState(null);
  const [busy, setBusy] = useState(false);

  async function handlePreview() {
    setBusy(true); setError('');
    const res = await window.api.quotations.preview(quotationId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setPreviewHtml(res.data);
  }
  async function handlePdf() {
    setBusy(true); setError('');
    const res = await window.api.quotations.generatePdf(quotationId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) setError(`Saved to ${res.data.filePath}`);
  }
  async function handlePrint() {
    setBusy(true); setError('');
    const res = await window.api.quotations.print(quotationId);
    setBusy(false);
    if (!res.ok) setError(res.error);
  }

  useEffect(() => {
    window.api.quotations.get(quotationId).then((res) => (res.ok ? setQ(res.data) : setError(res.error)));
  }, [quotationId]);

  const c = q ? (q.currency || 'PKR') : 'PKR';
  const title = q ? `${q.quotation_number}${q.revision_number > 0 ? ` · Rev ${q.revision_number}` : ''}` : 'Quotation';

  return (
    <Modal title={title} onClose={onClose} width={960}>
      {error && <div className="login-error">{error}</div>}
      {!q && !error && <p style={{ fontSize: 13 }}>Loading…</p>}
      {q && (
        <div className="qt-form">
          <div className="qt-view-head">
            <span className={`status-pill ${pillTone(q.status)}`}>{q.status}</span>
            <span className="qt-sub" style={{ margin: 0 }}>
              {q.quotation_type || 'Custom Package'} · dated {q.quotation_date || '—'}
              {q.converted_booking_code ? ` · converted to ${q.converted_booking_code}` : ''}
            </span>
          </div>

          <div className="qt-section">Basic Information</div>
          <div className="qt-grid c4">
            <Info label="Customer">{q.customer_name}</Info>
            <Info label="Phone / WhatsApp">{q.customer_phone}</Info>
            <Info label="Inquiry reference">{q.lead_code}</Info>
            <Info label="Booking reference">{q.booking_code}</Info>
            <Info label="Prepared by">{q.prepared_by_name}</Info>
          </div>

          <div className="qt-section">Travel Details</div>
          <div className="qt-grid c4">
            <Info label="Departure city">{q.departure_city}</Info>
            <Info label="Destination">{q.destination}</Info>
            <Info label="Departure date">{q.travel_date_from}</Info>
            <Info label="Return date">{q.travel_date_to}</Info>
            <Info label="Nights">{q.total_nights}</Info>
            <Info label="Travellers">{`${q.adults || 0} adult${q.adults === 1 ? '' : 's'}, ${q.children || 0} child${q.children === 1 ? '' : 'ren'}, ${q.infants || 0} infant${q.infants === 1 ? '' : 's'}`}</Info>
            <Info label="Travel class">{q.travel_class}</Info>
            <Info label="Special requirements / notes" wide>{q.notes}</Info>
          </div>

          <div className="qt-section">Package &amp; Services</div>
          <table className="data-table qt-view-items">
            <thead>
              <tr><th>Service</th><th>Date</th><th>Qty</th><th>Unit price</th><th>Discount</th>{canSeeCost && <th>Unit cost</th>}<th>Line total</th></tr>
            </thead>
            <tbody>
              {(q.items || []).map((it) => (
                <tr key={it.id}>
                  <td>
                    <strong>{it.name}</strong>
                    <span className="qt-sub">{it.category}{it.description ? ` · ${it.description}` : ''}</span>
                    {Object.keys(it.details || {}).length > 0 && (
                      <span className="qt-sub">{Object.entries(it.details).map(([k, v]) => `${UMRAH_LABELS[k] || k}: ${v}`).join(' · ')}</span>
                    )}
                  </td>
                  <td className="qt-nowrap">{it.service_date || '—'}</td>
                  <td className="qt-nowrap">{it.quantity}{it.unit ? ` ${it.unit}` : ''}</td>
                  <td className="qt-nowrap">{fmt(it.unit_price, c)}</td>
                  <td className="qt-nowrap">{num(it.discount) ? fmt(it.discount, c) : '—'}</td>
                  {canSeeCost && <td className="qt-nowrap">{it.cost_price == null ? '—' : fmt(it.cost_price, c)}</td>}
                  <td className="qt-nowrap"><strong>{fmt(it.line_total, c)}</strong></td>
                </tr>
              ))}
              {(q.items || []).length === 0 && <tr><td colSpan={canSeeCost ? 7 : 6} className="empty-row">No service rows (older quotation).</td></tr>}
            </tbody>
          </table>

          <div className="qt-section">Pricing &amp; Payment Terms</div>
          <div className="qt-pricing">
            <div className="qt-grid c2">
              <Info label="Currency">{c}</Info>
              <Info label="Overall discount">{q.discount_type === 'percent' ? `${q.discount_value}% (${fmt(q.discount, c)})` : fmt(q.discount, c)}</Info>
              <Info label="Payment terms" wide>{q.terms}</Info>
            </div>
            <div>
              <div className="qt-summary">
                <div className="qt-summary-line"><span>Subtotal</span><span>{fmt(q.subtotal, c)}</span></div>
                <div className="qt-summary-line muted"><span>Overall discount</span><span>− {fmt(q.discount, c)}</span></div>
                <div className="qt-summary-line muted"><span>Taxes / additional charges</span><span>+ {fmt(q.tax, c)}</span></div>
                <div className="qt-summary-line total"><span>Final Quotation Total</span><span>{fmt(q.selling_price, c)}</span></div>
                <div className="qt-summary-line muted"><span>Advance required</span><span>{fmt(q.advance_required, c)}</span></div>
                <div className="qt-summary-line"><span>Payment due / remaining</span><span>{fmt(q.balance_due, c)}</span></div>
              </div>
              {canSeeCost && q.cost != null && (
                <div className="qt-internal">
                  <strong>Internal only — not shown to the customer</strong>
                  <div className="qt-summary-line"><span>Cost price</span><span>{fmt(q.cost, c)}</span></div>
                  <div className="qt-summary-line"><span>Expected profit</span><span>{q.expected_profit == null ? '—' : fmt(q.expected_profit, c)}</span></div>
                </div>
              )}
            </div>
          </div>

          <div className="qt-section">Validity &amp; Status</div>
          <div className="qt-grid c4">
            <Info label="Valid until">{q.valid_until}</Info>
            <Info label="Status">{q.status}</Info>
            <Info label="Sent via">{q.sent_via}</Info>
            <Info label="Sent date & time">{q.sent_at ? q.sent_at.replace('T', ' ') : ''}</Info>
            <Info label="Customer response" wide>{q.customer_response}</Info>
            <Info label="Internal notes" wide>{q.internal_notes}</Info>
          </div>

          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={onClose}>Close</button>
            <button className="btn btn-secondary" disabled={busy} onClick={handlePreview}><Eye size={14} /> Preview</button>
            <button className="btn btn-secondary" disabled={busy} onClick={handlePdf}><FileDown size={14} /> Generate PDF</button>
            <button className="btn btn-secondary" disabled={busy} onClick={handlePrint}><Printer size={14} /> Print</button>
            {onEdit && q.status !== 'Converted' && <button className="btn btn-primary" onClick={() => onEdit(q.id)}><Pencil size={14} /> Edit</button>}
          </div>
        </div>
      )}
      {previewHtml && <PreviewPane title={`Quotation ${q?.quotation_number || ''}`} html={previewHtml} busy={busy} onClose={() => setPreviewHtml(null)} onSave={handlePdf} onPrint={handlePrint} />}
    </Modal>
  );
}

// ---------------------------------------------------------------------------------------------------------------------
// Form
// ---------------------------------------------------------------------------------------------------------------------

let rowCounter = 0;
const newRow = (over = {}) => ({
  key: `r${++rowCounter}`, id: null, category: 'Package', name: '', description: '', service_date: '',
  quantity: 1, unit: 'Person', unit_price: 0, discount: 0, cost_price: 0, details: {}, showDetails: false, ...over
});

const emptyForm = () => ({
  quotation_number: '', customer_id: '', customer_label: '', customer_phone: '', lead_id: '', booking_id: '',
  quotation_type: 'Umrah', quotation_date: todayStr(),
  departure_city: '', destination: '', travel_date_from: '', travel_date_to: '', total_nights: '',
  adults: 1, children: 0, infants: 0, travel_class: '', notes: '', agent_name: '',
  currency: 'PKR', discount_type: 'amount', discount_value: 0, tax: 0, advance_required: 0, terms: '',
  valid_until: plusDays(7), status: 'Draft', sent_via: '', sent_at: '', customer_response: '', internal_notes: '',
  revision_number: 0, prepared_by_name: '', flight_images: { main: null, departure: null, return: null },
  hotels: [], info: {}, pax: {}, packageName: '', packageId: '', items: []
});

/** A fresh type starts with the hotel rows / price row that type needs (nothing already typed is thrown away). */
function withTypeDefaults(state, type) {
  const flow = flowOf(type);
  const next = { ...state };
  if (flow.hotels && !next.hotels.length) next.hotels = flow.hotels.map((c) => newHotel(c));
  if (flow.pricing === 'rows' && !next.items.length) next.items = [newRow({ category: flow.rowCategory, unit: DEFAULT_UNIT[flow.rowCategory] || 'Other' })];
  return next;
}

/** Shrinks a chosen picture (max 1600px wide, JPEG) so quotations stay light, and returns a data URI. */
function readImage(file) {
  return new Promise((resolve, reject) => {
    if (!file || !/^image\//.test(file.type)) return reject(new Error('Please choose an image file.'));
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the image.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Could not open the image.'));
      img.onload = () => {
        const scale = Math.min(1, 1600 / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale); canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.86));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/** The first picture found on the clipboard (a Win+Shift+S screenshot, a copied image...) or null. */
function clipboardImage(clipboardData) {
  const items = (clipboardData && clipboardData.items) || [];
  for (const it of items) {
    if (it.kind === 'file' && /^image\//.test(it.type)) return it.getAsFile();
  }
  return null;
}

function ImageSlot({ label, hint, value, onChange, onError, active, onActivate }) {
  const inputRef = useRef(null);
  async function accept(file) {
    try { onChange(await readImage(file)); } catch (err) { onError(err.message); }
  }
  async function pick(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (file) accept(file);
  }
  // "Paste" button: read the clipboard directly (works when the browser allows it; Ctrl+V always works).
  async function pasteFromClipboard() {
    onActivate();
    try {
      const entries = await navigator.clipboard.read();
      for (const entry of entries) {
        const type = entry.types.find((t) => /^image\//.test(t));
        if (type) return accept(await entry.getType(type));
      }
      onError('Clipboard mein koi image nahi hai. Pehle Windows + Shift + S se screenshot lein.');
    } catch (_) {
      onError('Is box ko click karke Ctrl + V dabayein (clipboard se seedha paste).');
    }
  }
  return (
    <div onMouseEnter={onActivate} onFocus={onActivate}
      style={{ border: active ? '2px solid var(--color-primary, #0f766e)' : '1px dashed var(--color-border, #c9ced6)', borderRadius: 8, padding: active ? 9 : 10 }}>
      <div style={{ fontWeight: 600, fontSize: 13 }}>{label}</div>
      <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginBottom: 8 }}>{hint}</div>
      <div tabIndex={0} onClick={onActivate} title="Click karke Ctrl + V dabayein"
        style={{ minHeight: 90, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f6f7f9', borderRadius: 6, marginBottom: 8, overflow: 'hidden', outline: 'none', cursor: 'pointer' }}>
        {value
          ? <img src={value} alt={label} style={{ maxWidth: '100%', maxHeight: 180 }} />
          : <span style={{ fontSize: 12, color: '#8a8f94', textAlign: 'center', padding: 8 }}>{active ? 'Screenshot lein (Win + Shift + S) phir Ctrl + V dabayein' : 'Khali box - PDF mein bhi khali aayega'}</span>}
      </div>
      <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={pick} />
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <button type="button" className="btn btn-secondary btn-sm" onClick={pasteFromClipboard}>Paste screenshot</button>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => inputRef.current && inputRef.current.click()}>{value ? 'Change file' : 'Upload file'}</button>
        {value && <button type="button" className="btn btn-secondary btn-sm" onClick={() => onChange(null)}>Remove</button>}
      </div>
    </div>
  );
}


function QuotationFormModal({ quotationId, meta, canSeeCost, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState(() => withTypeDefaults({ ...emptyForm(), prepared_by_name: user?.fullName || '' }, 'Umrah'));
  const [loading, setLoading] = useState(!!quotationId);
  const [refs, setRefs] = useState({ bookings: [], leads: [] });
  const [pkgOptions, setPkgOptions] = useState([]);
  const [touchedImages, setTouchedImages] = useState({});
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const errorRef = useRef(null);

  // Existing quotation -> fill the form. Hotels, included services and traveller prices go to their own sections;
  // every other row stays a normal service row (older quotations without rows get one row carrying their old price).
  useEffect(() => {
    if (!quotationId) return;
    window.api.quotations.get(quotationId).then((res) => {
      if (!res.ok) { setError(res.error); setLoading(false); return; }
      const q = res.data;
      const flow = itemsToFlow(q.items || [], { travelFrom: q.travel_date_from || '' });
      const legacy = !(q.items || []).length;
      const rows = legacy
        ? [newRow({ name: q.destination ? `${q.destination} package` : 'Package', unit_price: q.selling_price || 0 })]
        : flow.rows.map((it) => newRow({
            id: it.id, category: it.category, name: it.name, description: it.description || '', service_date: it.service_date || '',
            quantity: it.quantity, unit: it.unit || 'Person', unit_price: it.unit_price, discount: it.discount,
            cost_price: it.cost_price ?? 0, details: it.details || {}
          }));
      setForm({
        ...emptyForm(),
        ...Object.fromEntries(Object.keys(emptyForm()).filter((k) => q[k] !== undefined && q[k] !== null).map((k) => [k, q[k]])),
        customer_label: q.customer_name,
        lead_id: q.lead_id || '', booking_id: q.booking_id || '',
        discount_type: legacy ? 'amount' : (q.discount_type || 'amount'),
        discount_value: legacy ? 0 : (q.discount_value ?? 0),
        tax: legacy ? 0 : (q.tax ?? 0),
        sent_at: q.sent_at || '', total_nights: q.total_nights ?? '',
        flight_images: q.flight_images || { main: null, departure: null, return: null },
        hotels: flow.hotels, info: flow.info, pax: flow.pax, packageName: flow.packageName, packageId: flow.packageId,
        items: rows
      });
      setLoading(false);
    });
  }, [quotationId]);

  // The two optional reference dropdowns follow the chosen customer.
  useEffect(() => {
    if (!form.customer_id) { setRefs({ bookings: [], leads: [] }); return; }
    let active = true;
    window.api.quotations.referenceOptions({ customer_id: form.customer_id }).then((res) => { if (active && res.ok) setRefs(res.data); });
    return () => { active = false; };
  }, [form.customer_id]);

  // Saved packages feed the name suggestions of the package name box (silently empty if this role cannot view Packages).
  useEffect(() => {
    window.api.packages.options().then((res) => res.ok && setPkgOptions(res.data));
  }, []);

  useEffect(() => { if (error && errorRef.current) errorRef.current.scrollIntoView({ block: 'nearest' }); }, [error]);

  const set = (f, v) => setForm((s) => ({ ...s, [f]: v }));
  const setImage = (slot, value) => {
    setForm((s) => ({ ...s, flight_images: { ...s.flight_images, [slot]: value } }));
    setTouchedImages((t) => ({ ...t, [slot]: true }));
  };
  // Win+Shift+S then Ctrl+V: the picture goes to the box under the mouse / last clicked, then the cursor moves
  // on to the next empty box (Itinerary -> Departure -> Return) so three screenshots can be pasted one after another.
  const [activeSlot, setActiveSlot] = useState('main');
  const imagesRef = useRef(form.flight_images);
  imagesRef.current = form.flight_images;
  const flightsVisible = flowOf(form.quotation_type).flights;
  useEffect(() => {
    if (!flightsVisible) return undefined;
    async function onPaste(e) {
      const tag = (e.target && e.target.tagName) || '';
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || (e.target && e.target.isContentEditable)) return; // normal text paste
      const file = clipboardImage(e.clipboardData);
      if (!file) return;
      e.preventDefault();
      try {
        const data = await readImage(file);
        setImage(activeSlot, data);
        const order = ['main', 'departure', 'return'];
        const next = order.find((slot) => slot !== activeSlot && !imagesRef.current[slot]);
        if (next) setActiveSlot(next);
        setError('');
      } catch (err) { setError(err.message); }
    }
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [flightsVisible, activeSlot]);
  const pickType = (type) => setForm((s) => withTypeDefaults({ ...s, quotation_type: type }, type));

  function pickCustomer(id, label, customer) {
    setForm((s) => ({
      ...s, customer_id: id, customer_label: label,
      customer_phone: customer ? (customer.whatsapp || customer.phone || '') : s.customer_phone,
      lead_id: '', booking_id: ''
    }));
  }

  function pickLead(id) {
    const lead = refs.leads.find((l) => String(l.id) === String(id));
    setForm((s) => ({
      ...s, lead_id: id,
      destination: s.destination || (lead && lead.destination) || '',
      travel_date_from: s.travel_date_from || (lead && lead.travel_date) || ''
    }));
  }

  function setDate(field, value) {
    setForm((s) => {
      const next = { ...s, [field]: value };
      if (next.travel_date_from && next.travel_date_to) {
        const n = nightsBetween(next.travel_date_from, next.travel_date_to);
        if (n >= 0) next.total_nights = n;
      }
      return next;
    });
  }

  function setStatus(value) {
    setForm((s) => ({ ...s, status: value, sent_at: value === 'Sent' && !s.sent_at ? nowLocal() : s.sent_at }));
  }

  // ---- hotels, included services, traveller prices ---------------------------------------------------------------
  function setHotel(i, patch) {
    setForm((s) => {
      const hotels = s.hotels.map((h, k) => (k === i ? { ...h, ...patch } : h));
      // The next hotel starts the day this one ends (only when it has no date yet).
      if (patch.check_out && hotels[i + 1] && !hotels[i + 1].check_in) hotels[i + 1] = { ...hotels[i + 1], check_in: patch.check_out };
      return { ...s, hotels };
    });
  }
  const addHotel = () => setForm((s) => ({ ...s, hotels: [...s.hotels, newHotel(s.hotels.length === 1 && s.hotels[0].city === 'Makkah' ? 'Madinah' : '')] }));
  const removeHotel = (i) => setForm((s) => ({ ...s, hotels: s.hotels.filter((_, k) => k !== i) }));
  const setInfo = (k, v) => setForm((s) => ({ ...s, info: { ...s.info, [k]: v } }));
  const setPax = (label, patch) => setForm((s) => ({ ...s, pax: { ...s.pax, [label]: { ...(s.pax[label] || {}), ...patch } } }));
  function setPackageName(value) {
    const pkg = pkgOptions.find((p) => p.package_name === value);
    setForm((s) => {
      const next = { ...s, packageName: value, packageId: pkg ? pkg.id : '' };
      if (pkg && (pkg.currency || 'PKR') === s.currency && !num((s.pax.Adult || {}).price)) next.pax = { ...s.pax, Adult: { ...(s.pax.Adult || {}), price: pkg.selling_price || 0 } };
      return next;
    });
  }

  // ---- ordinary service rows --------------------------------------------------------------------------------------
  function setRow(key, patch) {
    setForm((s) => ({ ...s, items: s.items.map((r) => (r.key === key ? { ...r, ...patch } : r)) }));
  }
  function setCategory(key, category) { setRow(key, { category, unit: DEFAULT_UNIT[category] || 'Other' }); }
  const flow = flowOf(form.quotation_type);
  const rowsMode = flow.pricing === 'rows';
  const addRow = () => setForm((s) => ({ ...s, items: [...s.items, newRow(rowsMode ? { category: flow.rowCategory, unit: DEFAULT_UNIT[flow.rowCategory] } : { category: 'Other', unit: 'Other', quantity: 1 })] }));
  const removeRow = (key) => setForm((s) => ({ ...s, items: (rowsMode && s.items.length <= 1) ? s.items : s.items.filter((r) => r.key !== key) }));

  const counts = { adults: num(form.adults), children: num(form.children), infants: num(form.infants) };
  const flowState = { hotels: form.hotels, info: form.info, pax: form.pax, packageName: form.packageName, packageId: form.packageId, rows: form.items };
  const flowRows = useMemo(
    () => flowToItems(form.quotation_type, flowState, counts),
    [form.quotation_type, form.hotels, form.info, form.pax, form.packageName, form.packageId, form.items, form.adults, form.children, form.infants]
  );

  // Live totals for the summary box (the saved figures are always recomputed by the server).
  const totals = useMemo(() => {
    const lines = flowRows.map((r) => Math.max(0, num(r.quantity) * num(r.unit_price) - num(r.discount)));
    const subtotal = r2(lines.reduce((a, b) => a + b, 0));
    const discount = form.discount_type === 'percent' ? r2((subtotal * num(form.discount_value)) / 100) : r2(num(form.discount_value));
    const tax = num(form.tax);
    const finalTotal = r2(subtotal - discount + tax);
    const advance = num(form.advance_required);
    const cost = r2(flowRows.reduce((a, r) => a + num(r.quantity) * num(r.cost_price), 0));
    const hasCost = flowRows.some((r) => num(r.cost_price) > 0);
    return { lines, subtotal, discount, tax, finalTotal, advance, remaining: r2(finalTotal - advance), cost, profit: hasCost ? r2(finalTotal - cost) : null };
  }, [flowRows, form.discount_type, form.discount_value, form.tax, form.advance_required]);

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (!form.customer_id) return setError('Please select a customer.');
    if (form.items.some((r) => !String(r.name).trim())) return setError('Every service row needs a service / package name.');
    if (!flowRows.some((r) => num(r.unit_price) > 0)) {
      return setError(flow.pricing === 'pax' ? 'Enter the price per person (and set the number of travellers).' : 'Add at least one service row with a price.');
    }
    if (totals.discount > totals.subtotal) return setError('Overall discount cannot be more than the subtotal.');
    if (totals.advance > totals.finalTotal) return setError('Advance required cannot be more than the quotation total.');

    const payload = {
      customer_id: form.customer_id, customer_phone: form.customer_phone,
      lead_id: form.lead_id || null, booking_id: form.booking_id || null,
      quotation_type: form.quotation_type, quotation_date: form.quotation_date,
      departure_city: form.departure_city, destination: form.destination,
      travel_date_from: form.travel_date_from, travel_date_to: form.travel_date_to,
      total_nights: form.total_nights === '' ? null : form.total_nights,
      adults: form.adults, children: form.children, infants: form.infants,
      travel_class: form.travel_class, notes: form.notes, agent_name: form.agent_name,
      currency: form.currency, discount_type: form.discount_type, discount_value: form.discount_value, tax: form.tax,
      advance_required: form.advance_required, terms: form.terms,
      flight_images: Object.fromEntries(Object.keys(touchedImages).map((slot) => [slot, form.flight_images[slot] || null])),
      valid_until: form.valid_until, status: form.status, sent_via: form.sent_via, sent_at: form.sent_at,
      customer_response: form.customer_response, internal_notes: form.internal_notes,
      items: flowRows.map((r) => ({
        id: r.id, category: r.category, name: r.name, description: r.description, service_date: r.service_date,
        quantity: r.quantity, unit: r.unit, unit_price: r.unit_price, discount: r.discount,
        // Without View Profit the screen never had the cost, so it sends none - the server keeps what is stored.
        ...(canSeeCost ? { cost_price: r.cost_price } : {}),
        details: r.details
      }))
    };

    setSaving(true);
    const res = quotationId ? await window.api.quotations.update(quotationId, payload) : await window.api.quotations.create(payload);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(quotationId ? 'Quotation updated.' : 'Quotation created.');
  }

  const cur = form.currency;
  const rowOffset = flowRows.length - form.items.length; // ordinary rows are always last in flowRows

  const renderRow = (r, i) => (
    <div className="qt-row" key={r.key}>
      <div className="qt-row-top">
        <Field label="Category">
          <select className="field-input" value={r.category} onChange={(e) => setCategory(r.key, e.target.value)}>
            {meta.categories.map((c) => <option key={c}>{c}</option>)}
          </select>
        </Field>
        <Field label="Service Name *">
          <input className="field-input" value={r.name} onChange={(e) => setRow(r.key, { name: e.target.value })} placeholder="e.g. Travel insurance" />
        </Field>
        <Field label="Service Date"><input type="date" className="field-input" value={r.service_date} onChange={(e) => setRow(r.key, { service_date: e.target.value })} /></Field>
        <button type="button" className="icon-btn" title="Remove row" disabled={rowsMode && form.items.length === 1} onClick={() => removeRow(r.key)}><X size={14} /></button>
      </div>
      <textarea className="field-input" rows={1} placeholder="Description / service details" value={r.description} onChange={(e) => setRow(r.key, { description: e.target.value })} />
      <div className={`qt-row-nums${canSeeCost ? ' with-cost' : ''}`}>
        <Field label="Quantity"><input type="number" min="0" step="any" className="field-input" value={r.quantity} onChange={(e) => setRow(r.key, { quantity: e.target.value })} /></Field>
        <Field label="Unit">
          <select className="field-input" value={r.unit} onChange={(e) => setRow(r.key, { unit: e.target.value })}>
            {UNITS.map((u) => <option key={u}>{u}</option>)}
          </select>
        </Field>
        <Field label={`Unit Selling Price (${cur})`}><input type="number" min="0" step="any" className="field-input" value={r.unit_price} onChange={(e) => setRow(r.key, { unit_price: e.target.value })} /></Field>
        <Field label="Item Discount"><input type="number" min="0" step="any" className="field-input" value={r.discount} onChange={(e) => setRow(r.key, { discount: e.target.value })} /></Field>
        {canSeeCost && <Field label="Unit Cost (internal)"><input type="number" min="0" step="any" className="field-input" value={r.cost_price} onChange={(e) => setRow(r.key, { cost_price: e.target.value })} /></Field>}
        <Field label="Line Total"><div className="qt-line-total">{fmt(totals.lines[rowOffset + i], cur)}</div></Field>
      </div>
    </div>
  );

  return (
    <Modal title={quotationId ? `Edit Quotation ${form.quotation_number || ''}` : 'New Quotation'} onClose={onClose} width={1040}>
      {loading ? <p style={{ fontSize: 13 }}>Loading…</p> : (
        <form className="qt-form" onSubmit={submit}>
          {/* 1. Type - decides which sections the rest of the form shows */}
          <div className="qt-section">1. Quotation Type <small>Pehle type chunein - neeche sirf usi ke sections aayenge.</small></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {meta.types.map((t) => {
              const f = flowOf(t); const on = form.quotation_type === t;
              return (
                <button key={t} type="button" onClick={() => pickType(t)}
                  style={{ textAlign: 'left', padding: '9px 12px', borderRadius: 8, cursor: 'pointer', border: on ? '2px solid var(--color-primary, #0f766e)' : '1px solid var(--color-border, #cfd4da)', background: on ? 'var(--color-primary-soft, #e6f4f1)' : 'transparent' }}>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>{f.label}</div>
                  <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{f.hint}</div>
                </button>
              );
            })}
          </div>

          {/* 2. Basic information */}
          <div className="qt-section">2. Basic Information</div>
          <div className="qt-grid c3">
            <Field label="Quotation Number"><input className="field-input qt-readonly" disabled value={form.quotation_number || 'Auto-generated on save'} /></Field>
            <Field label="Quotation Date"><input type="date" className="field-input" value={form.quotation_date} onChange={(e) => set('quotation_date', e.target.value)} /></Field>
            <Field label="Agent Name (printed on the PDF)"><input className="field-input" value={form.agent_name || ''} onChange={(e) => set('agent_name', e.target.value)} placeholder="e.g. Muhammad Fahad" /></Field>
            <div className="qt-span2">
              <Field label="Customer *">
                <CustomerSearchSelect value={form.customer_id} valueLabel={form.customer_label} onChange={pickCustomer} />
              </Field>
            </div>
            <Field label="Phone / WhatsApp"><input className="field-input" value={form.customer_phone} onChange={(e) => set('customer_phone', e.target.value)} placeholder="Filled from the customer" /></Field>
            <Field label="Inquiry Reference (optional)">
              <select className="field-input" value={form.lead_id} disabled={!form.customer_id} onChange={(e) => pickLead(e.target.value)}>
                <option value="">{form.customer_id ? (refs.leads.length ? 'None' : 'No inquiries for this customer') : 'Select a customer first'}</option>
                {refs.leads.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
                {form.lead_id && !refs.leads.some((l) => String(l.id) === String(form.lead_id)) && <option value={form.lead_id}>Inquiry #{form.lead_id}</option>}
              </select>
            </Field>
            <Field label="Booking Reference (optional)">
              <select className="field-input" value={form.booking_id} disabled={!form.customer_id} onChange={(e) => set('booking_id', e.target.value)}>
                <option value="">{form.customer_id ? (refs.bookings.length ? 'None' : 'No bookings for this customer') : 'Select a customer first'}</option>
                {refs.bookings.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
                {form.booking_id && !refs.bookings.some((b) => String(b.id) === String(form.booking_id)) && <option value={form.booking_id}>Booking #{form.booking_id}</option>}
              </select>
            </Field>
            <Field label="Prepared By"><input className="field-input qt-readonly" disabled value={form.prepared_by_name || '—'} /></Field>
          </div>

          {/* 3. Travel details */}
          <div className="qt-section">3. Travel Details</div>
          <div className="qt-grid c4">
            <Field label="Departure City"><input className="field-input" value={form.departure_city} onChange={(e) => set('departure_city', e.target.value)} /></Field>
            <Field label="Destination"><input className="field-input" value={form.destination} onChange={(e) => set('destination', e.target.value)} /></Field>
            <Field label="Departure Date"><input type="date" className="field-input" value={form.travel_date_from} onChange={(e) => setDate('travel_date_from', e.target.value)} /></Field>
            <Field label="Return Date"><input type="date" className="field-input" min={form.travel_date_from || undefined} value={form.travel_date_to} onChange={(e) => setDate('travel_date_to', e.target.value)} /></Field>
            <Field label="Total Nights / Duration"><input type="number" min="0" className="field-input" value={form.total_nights} onChange={(e) => set('total_nights', e.target.value)} placeholder="From the dates" /></Field>
            <Field label="Adults"><input type="number" min="0" className="field-input" value={form.adults} onChange={(e) => set('adults', e.target.value)} /></Field>
            <Field label="Children"><input type="number" min="0" className="field-input" value={form.children} onChange={(e) => set('children', e.target.value)} /></Field>
            <Field label="Infants"><input type="number" min="0" className="field-input" value={form.infants} onChange={(e) => set('infants', e.target.value)} /></Field>
            {flow.flights && (
              <Field label="Travel Class (flights)">
                <select className="field-input" value={form.travel_class} onChange={(e) => set('travel_class', e.target.value)}>
                  <option value="">Not applicable</option>
                  {meta.travelClasses.map((c) => <option key={c}>{c}</option>)}
                </select>
              </Field>
            )}
            <div className="qt-span-all" style={{ gridColumn: 'span 3' }}>
              <Field label="Special Requirements / Notes"><textarea className="field-input" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
            </div>
          </div>

          {/* Hotels */}
          {flow.hotels && (
            <>
              <div className="qt-section">Hotels <small>Har hotel ki detail - PDF ke Hotels table mein aayegi. Hotel ka alag price nahi, price neeche package mein hota hai.</small></div>
              <datalist id="qt-cities"><option value="Makkah" /><option value="Madinah" /><option value="Jeddah" /><option value="Mina" /></datalist>
              {form.hotels.map((h, i) => (
                <div className="qt-row" key={i}>
                  <div className="qt-grid c4">
                    <Field label="City"><input className="field-input" list="qt-cities" value={h.city} onChange={(e) => setHotel(i, { city: e.target.value })} /></Field>
                    <div style={{ gridColumn: 'span 2' }}><Field label="Hotel Name *"><input className="field-input" value={h.name} onChange={(e) => setHotel(i, { name: e.target.value })} placeholder="e.g. Emaar Al Khalil 3 Star" /></Field></div>
                    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-end' }}>
                      <button type="button" className="icon-btn" title="Remove hotel" onClick={() => removeHotel(i)}><X size={14} /></button>
                    </div>
                    <Field label="Check In"><input type="date" className="field-input" value={h.check_in} onChange={(e) => setHotel(i, { check_in: e.target.value })} /></Field>
                    <Field label="Check Out"><input type="date" className="field-input" min={h.check_in || undefined} value={h.check_out} onChange={(e) => setHotel(i, { check_out: e.target.value })} /></Field>
                    <Field label="Nights"><input className="field-input qt-readonly" disabled value={hotelNights(h) || '—'} /></Field>
                    <Field label="Rooms"><input type="number" min="1" className="field-input" value={h.rooms} onChange={(e) => setHotel(i, { rooms: e.target.value })} /></Field>
                    <Field label="Room Type"><input className="field-input" value={h.room_type} onChange={(e) => setHotel(i, { room_type: e.target.value })} placeholder="e.g. Double Room" /></Field>
                    <Field label="Meals"><input className="field-input" value={h.meal_plan} onChange={(e) => setHotel(i, { meal_plan: e.target.value })} placeholder="e.g. Room Only" /></Field>
                    <div style={{ gridColumn: 'span 2' }}><Field label="Distance"><input className="field-input" value={h.distance} onChange={(e) => setHotel(i, { distance: e.target.value })} placeholder="e.g. 5 mins walk to Haram" /></Field></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-secondary qt-add-row" onClick={addHotel}><Plus size={14} /> Add hotel</button>
            </>
          )}

          {/* Included services (transport / ziyarat / visa) */}
          {flow.info.length > 0 && (
            <>
              <div className="qt-section">Included Services <small>Jo cheezein package mein shamil hain - PDF mein alag section ban jayegi. Khali chhor dein to nahi aayegi.</small></div>
              <div className="qt-grid c2">
                {flow.info.flatMap((g) => INFO_FIELDS[g]).map(([k, label]) => (
                  <Field key={k} label={label}><input className="field-input" value={form.info[k] || ''} onChange={(e) => setInfo(k, e.target.value)} /></Field>
                ))}
              </div>
            </>
          )}

          {/* Flight itinerary pictures */}
          {flow.flights && (
            <>
              <div className="qt-section">Flight Itinerary <small>Windows + Shift + S se screenshot lein, box select karke Ctrl + V dabayein (ya file upload karein). Koi data likhna nahi.</small></div>
              <div className="qt-grid c3">
                <ImageSlot label="Flight Itinerary" hint="Page 1 ka bara box" value={form.flight_images.main} onChange={(v) => setImage('main', v)} onError={setError} active={activeSlot === 'main'} onActivate={() => setActiveSlot('main')} />
                <ImageSlot label="Departure" hint="Page 2 - jaane ki flight" value={form.flight_images.departure} onChange={(v) => setImage('departure', v)} onError={setError} active={activeSlot === 'departure'} onActivate={() => setActiveSlot('departure')} />
                <ImageSlot label="Return" hint="Page 2 - wapsi ki flight" value={form.flight_images.return} onChange={(v) => setImage('return', v)} onError={setError} active={activeSlot === 'return'} onActivate={() => setActiveSlot('return')} />
              </div>
            </>
          )}

          {/* Price: per traveller (package types) or service rows */}
          {flow.pricing === 'pax' ? (
            <>
              <div className="qt-section">Package Price <small>Har traveller ki per-person price likhein. Count upar Travel Details (Adults / Children / Infants) se aata hai.</small></div>
              <datalist id="qt-package-names">{pkgOptions.map((p) => <option key={p.id} value={p.package_name} />)}</datalist>
              <Field label={`${flow.packageLabel} (PDF mein title)`}>
                <input className="field-input" list="qt-package-names" value={form.packageName} onChange={(e) => setPackageName(e.target.value)} placeholder={flow.defaultName ? flow.defaultName : 'Saved package chunein ya naam likhein, e.g. 3&4 Star 7 Nights Umrah Package'} />
              </Field>
              <table className="qt-pax" style={{ width: '100%', marginTop: 8, borderCollapse: 'collapse', fontSize: 13 }}>
                <thead><tr style={{ textAlign: 'left', fontSize: 11, textTransform: 'uppercase', color: 'var(--color-text-muted)' }}>
                  <th style={{ padding: 6 }}>Traveller</th><th style={{ padding: 6 }}>Count</th><th style={{ padding: 6 }}>Per Person Price ({cur})</th>
                  {canSeeCost && <th style={{ padding: 6 }}>Per Person Cost (internal)</th>}<th style={{ padding: 6, textAlign: 'right' }}>Amount</th>
                </tr></thead>
                <tbody>
                  {PAX.map(([label, countKey]) => {
                    const count = counts[countKey]; const p = form.pax[label] || {};
                    return (
                      <tr key={label} style={{ opacity: count > 0 ? 1 : 0.45 }}>
                        <td style={{ padding: 6, fontWeight: 600 }}>{label}</td>
                        <td style={{ padding: 6 }}>{count}</td>
                        <td style={{ padding: 6 }}><input type="number" min="0" step="any" className="field-input" disabled={count <= 0} value={p.price ?? ''} onChange={(e) => setPax(label, { price: e.target.value })} /></td>
                        {canSeeCost && <td style={{ padding: 6 }}><input type="number" min="0" step="any" className="field-input" disabled={count <= 0} value={p.cost ?? ''} onChange={(e) => setPax(label, { cost: e.target.value })} /></td>}
                        <td style={{ padding: 6, textAlign: 'right', fontWeight: 600 }}>{fmt(count * num(p.price), cur)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="qt-section" style={{ marginTop: 14 }}>Additional Charges <small>Optional - jaise insurance, extra baggage, service fee.</small></div>
              <div className="qt-rows">{form.items.map(renderRow)}</div>
              <button type="button" className="btn btn-secondary qt-add-row" onClick={addRow}><Plus size={14} /> Add extra charge</button>
            </>
          ) : (
            <>
              <div className="qt-section">Services &amp; Prices <small>Har service ki ek row. Line total = quantity × unit price − item discount.</small></div>
              <div className="qt-rows">{form.items.map(renderRow)}</div>
              <button type="button" className="btn btn-secondary qt-add-row" onClick={addRow}><Plus size={14} /> Add service row</button>
            </>
          )}

          {/* Pricing & payment terms */}
          <div className="qt-section">Pricing &amp; Payment Terms</div>
          <div className="qt-pricing">
            <div className="qt-grid c2">
              <Field label="Currency">
                <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
                  {meta.currencies.map((c) => <option key={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Overall Discount">
                <div className="qt-split">
                  <select className="field-input" value={form.discount_type} onChange={(e) => set('discount_type', e.target.value)}>
                    <option value="amount">Amount</option>
                    <option value="percent">Percent %</option>
                  </select>
                  <input type="number" min="0" step="any" className="field-input" value={form.discount_value} onChange={(e) => set('discount_value', e.target.value)} />
                </div>
              </Field>
              <Field label="Taxes / Additional Charges"><input type="number" min="0" step="any" className="field-input" value={form.tax} onChange={(e) => set('tax', e.target.value)} /></Field>
              <Field label="Advance Required"><input type="number" min="0" step="any" className="field-input" value={form.advance_required} onChange={(e) => set('advance_required', e.target.value)} /></Field>
              <div className="qt-span-all">
                <Field label="Payment Terms"><textarea className="field-input" rows={2} value={form.terms} onChange={(e) => set('terms', e.target.value)} placeholder="e.g. 50% advance at confirmation, balance 14 days before departure" /></Field>
              </div>
            </div>

            <div>
              <div className="qt-summary">
                <div className="qt-summary-line"><span>Subtotal</span><span>{fmt(totals.subtotal, cur)}</span></div>
                <div className="qt-summary-line muted"><span>Overall discount{form.discount_type === 'percent' ? ` (${num(form.discount_value)}%)` : ''}</span><span>− {fmt(totals.discount, cur)}</span></div>
                <div className="qt-summary-line muted"><span>Taxes / additional charges</span><span>+ {fmt(totals.tax, cur)}</span></div>
                <div className="qt-summary-line total"><span>Final Quotation Total</span><span>{fmt(totals.finalTotal, cur)}</span></div>
                <div className="qt-summary-line muted"><span>Advance required</span><span>{fmt(totals.advance, cur)}</span></div>
                <div className="qt-summary-line"><span>Payment due / remaining</span><span>{fmt(totals.remaining, cur)}</span></div>
              </div>
              {canSeeCost && (
                <div className="qt-internal">
                  <strong>Internal only — not shown to the customer</strong>
                  <div className="qt-summary-line"><span>Cost price</span><span>{fmt(totals.cost, cur)}</span></div>
                  <div className="qt-summary-line">
                    <span>Expected profit</span>
                    <span>{totals.profit == null ? 'Enter unit costs to see it' : `${fmt(totals.profit, cur)}${totals.finalTotal > 0 ? ` (${r2((totals.profit / totals.finalTotal) * 100)}%)` : ''}`}</span>
                  </div>
                </div>
              )}
              <p className="qt-note">Saving a quotation does not receive any money. Advance and remaining are proposed payment terms only — record actual payments in Payments.</p>
            </div>
          </div>

          {/* 5. Validity & status */}
          <div className="qt-section">Quotation Validity &amp; Status</div>
          <div className="qt-grid c4">
            <Field label="Valid Until"><input type="date" className="field-input" min={form.quotation_date || undefined} value={form.valid_until} onChange={(e) => set('valid_until', e.target.value)} /></Field>
            <Field label="Quotation Status">
              <select className="field-input" value={form.status} onChange={(e) => setStatus(e.target.value)}>
                {meta.statuses.filter((s) => s !== 'Converted').map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Sent Via">
              <select className="field-input" value={form.sent_via} onChange={(e) => set('sent_via', e.target.value)}>
                <option value="">Not sent</option>
                {meta.sentVia.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Sent Date & Time"><input type="datetime-local" className="field-input" value={form.sent_at} onChange={(e) => set('sent_at', e.target.value)} /></Field>
            <Field label="Revision Number"><input className="field-input qt-readonly" disabled value={form.revision_number > 0 ? `Rev ${form.revision_number}` : 'Original (Rev 0)'} /></Field>
            <div style={{ gridColumn: 'span 3' }}>
              <Field label="Customer Response"><textarea className="field-input" rows={2} value={form.customer_response} onChange={(e) => set('customer_response', e.target.value)} placeholder="What the customer said about this quotation" /></Field>
            </div>
            <div className="qt-span-all">
              <Field label="Internal Notes (staff only)"><textarea className="field-input" rows={2} value={form.internal_notes} onChange={(e) => set('internal_notes', e.target.value)} /></Field>
            </div>
          </div>

          <div className="qt-footer">
            {error && <div className="login-error" ref={errorRef} style={{ marginBottom: 10 }}>{error}</div>}
            <div className="modal-actions" style={{ marginTop: 0 }}>
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Quotation'}</button>
            </div>
          </div>
        </form>
      )}
    </Modal>
  );
}
