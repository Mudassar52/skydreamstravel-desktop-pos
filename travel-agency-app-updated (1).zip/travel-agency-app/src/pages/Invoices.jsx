import { useEffect, useState, useCallback } from 'react';
import { Plus, Search, Eye, Pencil, Trash2, ChevronLeft, ChevronRight, FileDown, Printer, Copy, Ban, X, Wallet, Undo2, ArrowUp, ArrowDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import PreviewPane from '../components/PreviewPane.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import DateRangeFilter from '../components/DateRangeFilter.jsx';
import SavedFiltersBar from '../components/SavedFiltersBar.jsx';
import { formatMoney, INVOICE_CURRENCIES } from '../utils/currency.js';
import './customers.css';

const PAGE_SIZE = 15;
const STATUSES = ['Unpaid', 'Partially Paid', 'Paid', 'Cancelled'];
const STATUS_TONE = { Unpaid: 'off', 'Partially Paid': 'off', Paid: 'on', Cancelled: 'off' };
const DATE_FIELDS = [
  { value: 'invoice_date', label: 'Invoice Date' },
  { value: 'due_date', label: 'Due Date' },
  { value: 'created_at', label: 'Created Date' }
];
const money = (n, cur) => formatMoney(n, cur);

export default function Invoices() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [dateFilter, setDateFilter] = useState({ preset: '', from: '', to: '', dateField: 'invoice_date' });
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [viewingId, setViewingId] = useState(null);
  const [fromBookingOpen, setFromBookingOpen] = useState(false);
  const [draft, setDraft] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const load = useCallback(async () => {
    const res = await window.api.invoices.list({
      search, status, page, pageSize: PAGE_SIZE,
      dateField: dateFilter.dateField, dateFrom: dateFilter.from || null, dateTo: dateFilter.to || null
    });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, page, dateFilter]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status, dateFilter]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3500); }

  async function confirmDelete() {
    const res = await window.api.invoices.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${deleteTarget.invoice_number} deleted.`); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Invoices</h1>
          <p>{total.toLocaleString()} total invoice{total === 1 ? '' : 's'}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {can('invoices', 'create') && (
            <button className="btn btn-secondary" onClick={() => setFromBookingOpen(true)}>From Booking</button>
          )}
          {can('invoices', 'create') && (
            <button className="btn btn-primary" onClick={() => { setEditingId(null); setDraft(null); setFormOpen(true); }}>
              <Plus size={15} /> New Invoice
            </button>
          )}
        </div>
      </div>

      <div className="customers-toolbar" style={{ flexWrap: 'wrap', rowGap: 10 }}>
        <div className="global-search" style={{ width: 300 }}>
          <Search size={15} />
          <input placeholder="Search invoice # or customer..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 170 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <DateRangeFilter value={dateFilter} onChange={setDateFilter} dateFieldOptions={DATE_FIELDS} />
      </div>

      <div style={{ marginBottom: 14 }}>
        <SavedFiltersBar
          module="invoices"
          currentFilter={{ search, status, dateFilter }}
          onApply={(f) => { setSearch(f.search || ''); setStatus(f.status || 'All'); setDateFilter(f.dateFilter || { preset: '', from: '', to: '', dateField: 'invoice_date' }); }}
        />
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Invoice #</th><th>Customer</th><th>Date</th><th>Total</th><th>Balance Due</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((inv) => (
              <tr key={inv.id}>
                <td><button className="link-cell" onClick={() => setViewingId(inv.id)}>{inv.invoice_number}</button></td>
                <td>{inv.customer_name}</td>
                <td>{inv.invoice_date?.slice(0, 10)}</td>
                <td>{money(inv.total, inv.currency)}</td>
                <td>{money(inv.remaining_amount, inv.currency)}</td>
                <td><span className={`status-pill ${STATUS_TONE[inv.status] || 'off'}`}>{inv.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="View" onClick={() => setViewingId(inv.id)}><Eye size={14} /></button>
                  {can('invoices', 'edit') && inv.status !== 'Cancelled' && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(inv.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('invoices', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(inv)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="empty-row">No invoices found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <InvoiceFormModal
          invoiceId={editingId}
          draft={draft}
          onClose={() => { setFormOpen(false); setDraft(null); }}
          onSaved={(msg, id) => { setFormOpen(false); setDraft(null); flash(msg); load(); if (id) setViewingId(id); }}
        />
      )}

      {viewingId && (
        <InvoiceDetailDrawer
          invoiceId={viewingId}
          onClose={() => setViewingId(null)}
          onChanged={(msg) => { flash(msg); load(); }}
          onEdit={() => { setEditingId(viewingId); setViewingId(null); setFormOpen(true); }}
        />
      )}

      {fromBookingOpen && (
        <FromBookingModal
          onClose={() => setFromBookingOpen(false)}
          onDraft={(d) => { setFromBookingOpen(false); setDraft(d); setEditingId(null); setFormOpen(true); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete invoice" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.invoice_number}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
function FromBookingModal({ onClose, onDraft }) {
  const [options, setOptions] = useState([]);
  const [bookingId, setBookingId] = useState('');
  const [mode, setMode] = useState('lump');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.bookings.options().then((res) => { if (res.ok) setOptions(res.data); }); }, []);

  async function submit(e) {
    e.preventDefault();
    if (!bookingId) return setError('Please select a booking.');
    setSaving(true);
    const res = await window.api.invoices.draftFromBooking(Number(bookingId), { mode });
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onDraft(res.data);
  }

  return (
    <Modal title="Create Invoice from Booking" onClose={onClose}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <Field label="Booking">
          <select className="field-input" value={bookingId} onChange={(e) => setBookingId(e.target.value)}>
            <option value="">— Select a booking —</option>
            {options.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
          </select>
        </Field>
        <p style={{ fontSize: 12, color: 'var(--color-text-muted)', margin: '4px 0 10px' }}>
          Booking ke travellers, flights, hotel (room / meal / nights), visa, transport aur ziyarat khud alag-alag section mein aa jayenge. Save karne se pehle aap kuch bhi badal sakte hain.
        </p>
        <Field label="Price kaise dikhana hai">
          <label style={{ display: 'flex', gap: 6, fontSize: 13, marginBottom: 6 }}>
            <input type="radio" checked={mode === 'lump'} onChange={() => setMode('lump')} /> Ek hi total price (package line par)
          </label>
          <label style={{ display: 'flex', gap: 6, fontSize: 13 }}>
            <input type="radio" checked={mode === 'itemised'} onChange={() => setMode('itemised')} /> Har service ka alag price (booking ki service prices se)
          </label>
        </Field>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Preparing…' : 'Prepare Invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------------
const normalizeItem = (it) => ({ title: '', description: '', quantity: 1, unit_price: '', ...it, show_price: it.show_price === 0 || it.show_price === false ? 0 : 1 });
const EMPTY_ITEM = { title: '', description: '', quantity: 1, unit_price: '', show_price: 1 };
const TEXT_ITEM = { title: '', description: '', quantity: 1, unit_price: '', show_price: 0 };
const PAY_METHODS = ['Bank Transfer', 'Cash', 'Card', 'Online Transfer', 'Cheque'];
const today = () => new Date().toISOString().slice(0, 10);
const EMPTY = {
  customer_id: '', customer_label: '', booking_id: '', invoice_date: today(), due_date: '', due_label: 'On Receipt',
  currency: 'PKR', discount: 0, tax: 0, paid_amount: 0, notes: '', terms: '', payment_lines: [],
  items: [{ ...EMPTY_ITEM }]
};

function InvoiceFormModal({ invoiceId, draft, onClose, onSaved }) {
  const [form, setForm] = useState(draft ? { ...EMPTY, ...draft, items: draft.items.map(normalizeItem) } : EMPTY);
  const [agents, setAgents] = useState([]);
  const [bookingOptions, setBookingOptions] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.agents.options().then((res) => { if (res.ok) setAgents(res.data); });
    window.api.bookings.options().then((res) => { if (res.ok) setBookingOptions(res.data); });
    // New invoice: start in the agency's default currency (a booking draft already carries its own).
    if (!invoiceId) {
      if (!draft) {
        window.api.settings.getAll().then((res) => {
          if (res.ok && res.data.default_currency) setForm((s) => ({ ...s, currency: res.data.default_currency }));
        });
      }
      return;
    }
    window.api.invoices.get(invoiceId).then((res) => {
      if (!res.ok) return;
      let lines = [];
      try { lines = JSON.parse(res.data.payment_lines || '[]'); } catch (_) { lines = []; }
      const manualSum = lines.reduce((sum, l) => sum + Number(l.amount || 0), 0);
      setForm({
        ...EMPTY, ...res.data,
        other_paid: Math.max(Number(res.data.paid_amount || 0) - manualSum, 0),
        customer_label: res.data.customer_name,
        invoice_date: (res.data.invoice_date || '').slice(0, 10),
        due_label: res.data.due_label || '',
        currency: res.data.currency || 'PKR',
        payment_lines: lines.map((l) => ({ ...l, date: (l.date || '').slice(0, 10) })),
        items: res.data.items.length
          ? res.data.items.map((it) => ({ ...it, title: it.title || '', show_price: it.show_price === 0 ? 0 : 1 }))
          : [{ ...EMPTY_ITEM }]
      });
    });
  }, [invoiceId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }
  async function refillFromBooking(mode) {
    if (!form.booking_id) return setError('Pehle booking select karein.');
    if (!window.confirm('Items, payments aur agent booking ke data se dobara bhar diye jayenge. Aapke likhe huay items badal jayenge. Continue?')) return;
    const res = await window.api.invoices.draftFromBooking(Number(form.booking_id), { mode });
    if (!res.ok) return setError(res.error);
    setError('');
    setForm((s) => ({
      ...s, currency: res.data.currency, agent_name: res.data.agent_name || s.agent_name,
      items: res.data.items.map(normalizeItem), payment_lines: res.data.payment_lines, other_paid: 0
    }));
  }
  function setItem(idx, f, v) {
    setForm((s) => ({ ...s, items: s.items.map((it, i) => (i === idx ? { ...it, [f]: v } : it)) }));
  }
  function addItem(base = EMPTY_ITEM) { setForm((s) => ({ ...s, items: [...s.items, { ...base }] })); }
  function removeItem(idx) { setForm((s) => ({ ...s, items: s.items.filter((_, i) => i !== idx) })); }
  function moveItem(idx, dir) {
    setForm((s) => {
      const j = idx + dir;
      if (j < 0 || j >= s.items.length) return s;
      const items = [...s.items];
      [items[idx], items[j]] = [items[j], items[idx]];
      return { ...s, items };
    });
  }
  function setPay(idx, f, v) {
    setForm((s) => ({ ...s, payment_lines: s.payment_lines.map((p, i) => (i === idx ? { ...p, [f]: v } : p)) }));
  }
  function addPay() {
    setForm((s) => ({ ...s, payment_lines: [...s.payment_lines, { label: 'Bank Transfer', date: today(), amount: '' }] }));
  }
  function removePay(idx) { setForm((s) => ({ ...s, payment_lines: s.payment_lines.filter((_, i) => i !== idx) })); }

  const cur = form.currency;
  const lineTotal = (it) => (it.show_price === 0 ? 0 : Number(it.quantity || 0) * Number(it.unit_price || 0));
  const subtotal = form.items.reduce((sum, it) => sum + lineTotal(it), 0);
  const total = Math.max(subtotal - Number(form.discount || 0) + Number(form.tax || 0), 0);
  const payLinesSum = form.payment_lines.reduce((sum, p) => sum + Number(p.amount || 0), 0);
  const hasPayLines = payLinesSum > 0;
  // With payment lines, the lines are the paid amount (anything recorded on the Payments screen stays on top).
  const paid = hasPayLines ? payLinesSum + Number(form.other_paid || 0) : Number(form.paid_amount || 0);
  const remaining = total - paid;

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    setSaving(true);
    const payload = { ...form, payment_lines: form.payment_lines.filter((p) => Number(p.amount) > 0) };
    const res = invoiceId ? await window.api.invoices.update(invoiceId, payload) : await window.api.invoices.create(payload);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(invoiceId ? 'Invoice updated.' : `Invoice ${res.data.invoiceNumber} created.`, invoiceId || res.data.id);
  }

  return (
    <Modal title={invoiceId ? 'Edit Invoice' : 'New Invoice'} onClose={onClose} width={820}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer (Bill To) *" full>
            <CustomerSearchSelect
              value={form.customer_id}
              valueLabel={form.customer_label}
              onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))}
            />
          </Field>
          <Field label="Booking (optional)">
            <div style={{ display: 'flex', gap: 6 }}>
              <select className="field-input" value={form.booking_id || ''} onChange={(e) => set('booking_id', e.target.value)}>
                <option value="">— No booking —</option>
                {bookingOptions.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
              </select>
              <button type="button" className="btn btn-secondary btn-sm" title="Booking ka data items mein bhar do" onClick={() => refillFromBooking('lump')}>Fill</button>
            </div>
          </Field>
          <Field label="Agent Name (header mein dikhega)">
            <input className="field-input" list="agent-names" value={form.agent_name || ''} onChange={(e) => set('agent_name', e.target.value)} placeholder="Agent ka naam likhein ya chunein" />
            <datalist id="agent-names">{agents.map((a) => <option key={a.id} value={a.name} />)}</datalist>
          </Field>
          <Field label="Invoice Date"><input type="date" className="field-input" value={form.invoice_date || ''} onChange={(e) => set('invoice_date', e.target.value)} /></Field>
          <Field label="Currency">
            <select className="field-input" value={form.currency} onChange={(e) => set('currency', e.target.value)}>
              {INVOICE_CURRENCIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Due (text on invoice)">
            <input className="field-input" value={form.due_label || ''} onChange={(e) => set('due_label', e.target.value)} placeholder="On Receipt" />
          </Field>
          <Field label="Due Date (optional)"><input type="date" className="field-input" value={form.due_date || ''} onChange={(e) => set('due_date', e.target.value)} /></Field>
        </div>

        <div className="form-section-title" style={{ marginTop: 18 }}>Invoice Items</div>
        <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', margin: '0 0 10px' }}>
          Har item ka apna heading aur description likhein. Price on rakhen to Rate/Qty/Amount PDF mein dikhenge; price band
          karein to sirf text dikhega (jaise Hotel Details). Aap sab kuch ek item mein likh kar sirf ek total price bhi daal sakte hain.
        </p>
        {form.items.map((it, idx) => {
          const shown = it.show_price !== 0;
          return (
            <div key={idx} className="card" style={{ padding: 12, marginBottom: 10 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <input className="field-input" style={{ flex: 1, fontWeight: 600 }} placeholder="Heading (e.g. 3 Person Umrah Package)"
                  value={it.title} onChange={(e) => setItem(idx, 'title', e.target.value)} />
                <button type="button" className="icon-btn" title="Move up" disabled={idx === 0} onClick={() => moveItem(idx, -1)}><ArrowUp size={14} /></button>
                <button type="button" className="icon-btn" title="Move down" disabled={idx === form.items.length - 1} onClick={() => moveItem(idx, 1)}><ArrowDown size={14} /></button>
                {form.items.length > 1 && <button type="button" className="icon-btn" title="Remove item" onClick={() => removeItem(idx)}><X size={14} /></button>}
              </div>
              <textarea className="field-input" rows={6} style={{ width: '100%', resize: 'vertical', marginBottom: 8 }}
                placeholder={'Description - jo chahein likhein, har line alag (flights, visa, transport, hotel details...)'}
                value={it.description} onChange={(e) => setItem(idx, 'description', e.target.value)} />
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <label style={{ fontSize: 12.5, display: 'flex', gap: 6, alignItems: 'center' }}>
                  <input type="checkbox" checked={shown} onChange={(e) => setItem(idx, 'show_price', e.target.checked ? 1 : 0)} />
                  Price dikhao
                </label>
                {shown && (
                  <>
                    <input type="number" step="any" className="field-input" style={{ width: 140 }} placeholder={`Rate (${cur})`} value={it.unit_price} onChange={(e) => setItem(idx, 'unit_price', e.target.value)} />
                    <input type="number" step="any" className="field-input" style={{ width: 90 }} placeholder="Qty" value={it.quantity} onChange={(e) => setItem(idx, 'quantity', e.target.value)} />
                    <span style={{ marginLeft: 'auto', fontSize: 13, fontWeight: 600 }}>Amount: {money(lineTotal(it), cur)}</span>
                  </>
                )}
              </div>
            </div>
          );
        })}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => addItem(EMPTY_ITEM)}><Plus size={13} /> Add Service (with price)</button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => addItem(TEXT_ITEM)}><Plus size={13} /> Add Text Block (no price)</button>
        </div>

        <div className="form-section-title">Payments Received</div>
        {form.payment_lines.map((p, idx) => (
          <div key={idx} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
            <input className="field-input" style={{ flex: 2 }} list="pay-methods" placeholder="Method (e.g. Bank Transfer)" value={p.label} onChange={(e) => setPay(idx, 'label', e.target.value)} />
            <input type="date" className="field-input" style={{ flex: 1.5 }} value={p.date || ''} onChange={(e) => setPay(idx, 'date', e.target.value)} />
            <input type="number" step="any" className="field-input" style={{ flex: 1.5 }} placeholder={`Amount (${cur})`} value={p.amount} onChange={(e) => setPay(idx, 'amount', e.target.value)} />
            <button type="button" className="icon-btn" onClick={() => removePay(idx)}><X size={14} /></button>
          </div>
        ))}
        <datalist id="pay-methods">{PAY_METHODS.map((m) => <option key={m} value={m} />)}</datalist>
        <button type="button" className="btn btn-secondary btn-sm" onClick={addPay} style={{ marginBottom: 12 }}><Plus size={13} /> Add Payment</button>
        {!hasPayLines && (
          <div className="form-grid">
            <Field label={`Paid Amount (${cur}) - ya upar payment lines add karein`}>
              <input type="number" step="any" className="field-input" value={form.paid_amount} onChange={(e) => set('paid_amount', e.target.value)} />
            </Field>
          </div>
        )}

        <div className="form-grid" style={{ marginTop: 12 }}>
          <Field label={`Discount (${cur})`}><input type="number" step="any" className="field-input" value={form.discount} onChange={(e) => set('discount', e.target.value)} /></Field>
          <Field label={`Tax (${cur})`}><input type="number" step="any" className="field-input" value={form.tax} onChange={(e) => set('tax', e.target.value)} /></Field>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
          <Field label="Terms & Conditions" full><textarea className="field-input" rows={2} value={form.terms || ''} onChange={(e) => set('terms', e.target.value)} /></Field>
        </div>

        <div className="totals" style={{ marginTop: 6 }}>
          <div className="row"><span>Subtotal</span><span>{money(subtotal, cur)}</span></div>
          <div className="row"><span>Total</span><span>{money(total, cur)}</span></div>
          <div className="row"><span>Paid</span><span>{money(paid, cur)}</span></div>
          <div className="row grand"><span>Balance Due</span><span>{money(remaining, cur)}</span></div>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : invoiceId ? 'Save Changes' : 'Create Invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------------
function InvoiceDetailDrawer({ invoiceId, onClose, onChanged, onEdit }) {
  const { can } = useAuth();
  const [invoice, setInvoice] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.invoices.get(invoiceId);
    if (res.ok) setInvoice(res.data);
  }
  useEffect(() => { reload(); }, [invoiceId]);

  const [previewHtml, setPreviewHtml] = useState(null);
  async function handlePreview() {
    setBusy(true); setError('');
    const res = await window.api.invoices.preview(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    setPreviewHtml(res.data);
  }

  async function handlePdf() {
    setBusy(true); setError('');
    const res = await window.api.invoices.generatePdf(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    if (res.data.saved) onChanged(`Saved to ${res.data.filePath}`);
  }

  async function handlePrint() {
    setBusy(true); setError('');
    const res = await window.api.invoices.print(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
  }

  async function handleDuplicate() {
    setBusy(true); setError('');
    const res = await window.api.invoices.duplicate(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    onChanged(`Duplicated as ${res.data.invoiceNumber}.`);
    onClose();
  }

  async function handleCancel() {
    setBusy(true); setError('');
    const res = await window.api.invoices.cancel(invoiceId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    onChanged('Invoice cancelled.');
    reload();
  }

  if (!invoice) return null;

  return (
    <div className="drawer-backdrop" onClick={onClose}>
      <div className="drawer-panel" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <div>
            <h2 style={{ fontSize: 17 }}>{invoice.invoice_number}</h2>
            <span className={`status-pill ${STATUS_TONE[invoice.status] || 'off'}`} style={{ marginTop: 6, display: 'inline-block' }}>{invoice.status}</span>
          </div>
        </div>
        <div className="drawer-body">
          {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 18 }}>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePreview}><Eye size={13} /> Preview</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePdf}><FileDown size={13} /> Generate PDF</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handlePrint}><Printer size={13} /> Print</button>
            <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handleDuplicate}><Copy size={13} /> Duplicate</button>
            {can('invoices', 'edit') && invoice.status !== 'Cancelled' && (
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={onEdit}><Pencil size={13} /> Edit</button>
            )}
            {can('invoices', 'edit') && invoice.status !== 'Cancelled' && (
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={handleCancel}><Ban size={13} /> Cancel Invoice</button>
            )}
          </div>

          <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 18 }}>
            <MiniStat label="Total" value={money(invoice.total, invoice.currency)} />
            <MiniStat label="Paid" value={money(invoice.paid_amount, invoice.currency)} />
            <MiniStat label="Balance Due" value={money(invoice.remaining_amount, invoice.currency)} />
          </div>

          <InfoRow label="Customer" value={invoice.customer_name} />
          <InfoRow label="Booking Reference" value={invoice.booking_code} />
          <InfoRow label="Invoice Date" value={invoice.invoice_date?.slice(0, 10)} />
          <InfoRow label="Due Date" value={invoice.due_date} />

          <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Line Items</h3>
          {invoice.items.map((it) => (
            <div className="info-row" key={it.id}>
              <span>{it.title || it.description}{it.show_price === 0 ? '' : ` × ${it.quantity}`}</span>
              <span>{it.show_price === 0 ? '' : money(it.line_total, invoice.currency)}</span>
            </div>
          ))}

          {invoice.status !== 'Cancelled' && (
            <ApplyAdvancePanel invoice={invoice} onApplied={() => { reload(); onChanged('Advance applied.'); }} />
          )}

          {invoice.notes && (
            <>
              <h3 style={{ fontSize: 13, margin: '18px 0 8px' }}>Notes</h3>
              <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{invoice.notes}</p>
            </>
          )}
        </div>
      </div>
      {previewHtml && <PreviewPane title={`Invoice ${invoice.invoice_number}`} html={previewHtml} busy={busy} onClose={() => setPreviewHtml(null)} onSave={handlePdf} onPrint={handlePrint} />}
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="card" style={{ padding: '12px 14px' }}>
      <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{value}</div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="info-row">
      <span>{label}</span>
      <span>{value || '—'}</span>
    </div>
  );
}

// Customer Advance System (master prompt section 16): shows the customer's
// unapplied standalone advances and lets the user allocate part or all of
// one to this invoice, plus what has already been applied, with the option
// to reverse an application. All amounts come from window.api.advances.*.
function ApplyAdvancePanel({ invoice, onApplied }) {
  const [available, setAvailable] = useState(null);
  const [applied, setApplied] = useState(null);
  const [amounts, setAmounts] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const [av, ap] = await Promise.all([
      window.api.advances.available(invoice.customer_id),
      window.api.advances.applicationsForInvoice(invoice.id)
    ]);
    if (av.ok) setAvailable(av.data);
    if (ap.ok) setApplied(ap.data);
  }, [invoice.customer_id, invoice.id]);
  useEffect(() => { load(); }, [load]);

  async function apply(paymentId) {
    const amount = Number(amounts[paymentId]);
    if (!(amount > 0)) return setError('Enter an amount greater than zero.');
    setBusy(true); setError('');
    const res = await window.api.advances.applyToInvoice({ paymentId, invoiceId: invoice.id, amount });
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
    onApplied();
  }

  async function reverse(applicationId) {
    setBusy(true); setError('');
    const res = await window.api.advances.reverseApplication(applicationId);
    setBusy(false);
    if (!res.ok) return setError(res.error);
    await load();
    onApplied();
  }

  if (!available || !applied) return null;
  if (available.rows.length === 0 && applied.length === 0) return null;

  return (
    <div style={{ marginTop: 18 }}>
      <h3 style={{ fontSize: 13, margin: '0 0 8px', display: 'flex', alignItems: 'center', gap: 6 }}><Wallet size={14} /> Customer Advance</h3>
      {error && <div className="login-error" style={{ marginBottom: 8 }}>{error}</div>}

      {available.rows.length > 0 && invoice.remaining_amount > 0 && (
        <div className="card" style={{ padding: '10px 14px', marginBottom: 10 }}>
          <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginBottom: 8 }}>
            Available advance for this customer: {money(available.total_available, invoice.currency)}
          </p>
          {available.rows.map((a) => (
            <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, flex: 1 }}>{a.payment_date?.slice(0, 10)} — {a.reference || `Advance #${a.id}`} ({money(a.available, invoice.currency)} available)</span>
              <input className="field-input" type="number" style={{ width: 110 }} placeholder="Amount"
                value={amounts[a.id] || ''} onChange={(e) => setAmounts((s) => ({ ...s, [a.id]: e.target.value }))} />
              <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => apply(a.id)}>Apply</button>
            </div>
          ))}
        </div>
      )}

      {applied.length > 0 && (
        <div className="card" style={{ padding: '10px 14px' }}>
          <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginBottom: 8 }}>Applied to this invoice</p>
          {applied.map((a) => (
            <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, flex: 1 }}>{a.applied_at?.slice(0, 10)} — {money(a.amount, invoice.currency)} from advance #{a.payment_id}</span>
              <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => reverse(a.id)}><Undo2 size={12} /> Reverse</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
