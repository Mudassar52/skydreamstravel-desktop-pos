import { useEffect, useState } from 'react';
import { Save, Upload, X, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Field from '../components/Field.jsx';
import './customers.css';

const CURRENCIES = ['PKR', 'USD', 'SAR', 'AED', 'GBP', 'EUR'];

export default function Settings() {
  const { can } = useAuth();
  const [form, setForm] = useState(null);
  const [images, setImages] = useState({ logo: '', signature: '', stamp: '' });
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function reload() {
    const res = await window.api.settings.getAll();
    if (res.ok) {
      setForm({
        agency_name: '', agency_address: '', agency_phone: '', agency_whatsapp: '', agency_email: '', agency_website: '', company_number: '',
        business_info: '', bank_details: '', default_currency: 'PKR', invoice_prefix: 'INV-', invoice_next_number: '1001',
        tax_rate: '', terms_conditions: '', logo_width: '', logo_height: '',
        ...res.data
      });
      setImages({ logo: res.data.logo || '', signature: res.data.signature || '', stamp: res.data.stamp || '' });
    }
  }
  useEffect(() => { reload(); }, []);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function save() {
    setSaving(true);
    setError('');
    const res = await window.api.settings.setMany(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    flash('Settings saved.');
  }

  async function uploadImage(field) {
    const res = await window.api.settings.uploadImage(field);
    if (!res.ok) return setError(res.error);
    if (res.data.updated) {
      setImages((s) => ({ ...s, [field]: res.data.dataUri }));
      flash('Image updated.');
    }
  }

  async function removeImage(field) {
    const res = await window.api.settings.removeImage(field);
    if (!res.ok) return setError(res.error);
    setImages((s) => ({ ...s, [field]: '' }));
  }

  if (!form) return null;
  const readOnly = !can('settings', 'edit');

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Settings</h1>
          <p>Agency information used throughout the app and on generated invoices.</p>
        </div>
        {!readOnly && (
          <button className="btn btn-primary" onClick={save} disabled={saving}><Save size={15} /> {saving ? 'Saving…' : 'Save Settings'}</button>
        )}
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error">{error}</div>}

      <div className="card" style={{ padding: '18px 22px', marginBottom: 18 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 14 }}>Agency Information</h3>
        <div className="form-grid">
          <Field label="Agency Name"><input className="field-input" disabled={readOnly} value={form.agency_name} onChange={(e) => set('agency_name', e.target.value)} /></Field>
          <Field label="Company Number (shown on invoices)"><input className="field-input" disabled={readOnly} value={form.company_number || ''} onChange={(e) => set('company_number', e.target.value)} placeholder="e.g. 16008918" /></Field>
          <Field label="Website"><input className="field-input" disabled={readOnly} value={form.agency_website} onChange={(e) => set('agency_website', e.target.value)} /></Field>
          <Field label="Phone"><input className="field-input" disabled={readOnly} value={form.agency_phone} onChange={(e) => set('agency_phone', e.target.value)} /></Field>
          <Field label="WhatsApp"><input className="field-input" disabled={readOnly} value={form.agency_whatsapp} onChange={(e) => set('agency_whatsapp', e.target.value)} /></Field>
          <Field label="Email"><input className="field-input" disabled={readOnly} value={form.agency_email} onChange={(e) => set('agency_email', e.target.value)} /></Field>
          <Field label="Address" full><input className="field-input" disabled={readOnly} value={form.agency_address} onChange={(e) => set('agency_address', e.target.value)} /></Field>
          <Field label="Business Information" full><textarea className="field-input" rows={2} disabled={readOnly} value={form.business_info} onChange={(e) => set('business_info', e.target.value)} /></Field>
        </div>
      </div>

      <div className="card" style={{ padding: '18px 22px', marginBottom: 18 }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 14 }}>Invoice & Currency Settings</h3>
        <div className="form-grid">
          <Field label="Default Currency">
            <select className="field-input" disabled={readOnly} value={form.default_currency} onChange={(e) => set('default_currency', e.target.value)}>
              {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Invoice Prefix"><input className="field-input" disabled={readOnly} value={form.invoice_prefix} onChange={(e) => set('invoice_prefix', e.target.value)} /></Field>
          <Field label="Next Invoice Number"><input type="number" className="field-input" disabled={readOnly} value={form.invoice_next_number} onChange={(e) => set('invoice_next_number', e.target.value)} /></Field>
          <Field label="Tax Rate (%, optional)"><input type="number" className="field-input" disabled={readOnly} value={form.tax_rate} onChange={(e) => set('tax_rate', e.target.value)} /></Field>
          <Field label="Bank Details" full><textarea className="field-input" rows={3} disabled={readOnly} value={form.bank_details} onChange={(e) => set('bank_details', e.target.value)} placeholder="Bank name, account title, account number, IBAN..." /></Field>
          <Field label="Terms & Conditions" full><textarea className="field-input" rows={3} disabled={readOnly} value={form.terms_conditions} onChange={(e) => set('terms_conditions', e.target.value)} placeholder="Default terms shown on invoices when none are set per-invoice." /></Field>
        </div>
      </div>

      <div className="card" style={{ padding: '18px 22px' }}>
        <h3 style={{ fontSize: 13.5, marginBottom: 14 }}>Branding</h3>
        <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginBottom: 14 }}>
          Used automatically by the default invoice template (and available as tokens for any custom template you build).
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 16 }}>
          <Field label="Invoice Logo Width (px)">
            <input className="field-input" type="number" min="10" max="600" disabled={readOnly} value={form.logo_width} onChange={(e) => set('logo_width', e.target.value)} placeholder="Auto (default)" />
          </Field>
          <Field label="Invoice Logo Height (px)">
            <input className="field-input" type="number" min="10" max="600" disabled={readOnly} value={form.logo_height} onChange={(e) => set('logo_height', e.target.value)} placeholder="Auto (default)" />
          </Field>
          <div>
            <label className="field-label">Logo Size Preview</label>
            <div style={{ border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', padding: 10, minHeight: 60, display: 'flex', alignItems: 'center', overflow: 'auto' }}>
              {images.logo ? (
                <img src={images.logo} alt="Logo preview" style={
                  (form.logo_width || form.logo_height)
                    ? { width: form.logo_width ? `${form.logo_width}px` : 'auto', height: form.logo_height ? `${form.logo_height}px` : 'auto', objectFit: 'contain' }
                    : { maxHeight: 56, maxWidth: 200, objectFit: 'contain' }
                } />
              ) : <span style={{ fontSize: 12, color: 'var(--color-text-faint)' }}>Upload a logo to preview</span>}
            </div>
          </div>
        </div>
        <p style={{ fontSize: 11.5, color: 'var(--color-text-muted)', margin: '-6px 0 14px' }}>
          Leave both blank to keep the current invoice logo size. Width and height can be changed independently (10–600 px). Only the logo size changes; the invoice layout and design are untouched.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          <ImageField label="Logo" value={images.logo} onUpload={() => uploadImage('logo')} onRemove={() => removeImage('logo')} readOnly={readOnly} />
          <ImageField label="Signature" value={images.signature} onUpload={() => uploadImage('signature')} onRemove={() => removeImage('signature')} readOnly={readOnly} />
          <ImageField label="Stamp" value={images.stamp} onUpload={() => uploadImage('stamp')} onRemove={() => removeImage('stamp')} readOnly={readOnly} />
        </div>
      </div>
    </div>
  );
}

function ImageField({ label, value, onUpload, onRemove, readOnly }) {
  return (
    <div>
      <label className="field-label">{label}</label>
      <div style={{
        border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', padding: 14,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, minHeight: 100, justifyContent: 'center'
      }}>
        {value ? (
          <img src={value} alt={label} style={{ maxHeight: 70, maxWidth: '100%', objectFit: 'contain' }} />
        ) : (
          <ImageIcon size={22} color="var(--color-text-faint)" />
        )}
        {!readOnly && (
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn btn-secondary btn-sm" onClick={onUpload}><Upload size={12} /> {value ? 'Replace' : 'Upload'}</button>
            {value && <button className="icon-btn" onClick={onRemove}><X size={13} /></button>}
          </div>
        )}
      </div>
    </div>
  );
}
