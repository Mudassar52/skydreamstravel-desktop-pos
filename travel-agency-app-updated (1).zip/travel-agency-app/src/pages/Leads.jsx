import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, Eye, ArrowRightCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import LeadServiceFields, { SERVICE_TYPES, summarizeLeadDetails } from '../components/LeadServiceFields.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;
const STAGE_TONE = { New: 'on', Contacted: 'on', Qualified: 'on', 'Quotation Sent': 'on', Negotiation: 'on', Converted: 'on', Lost: 'off' };

export default function Leads() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('All');
  const [search, setSearch] = useState('');
  const [pipeline, setPipeline] = useState([]);
  const [stages, setStages] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { window.api.leads.stages().then((res) => res.ok && setStages(res.data)); }, []);

  const load = useCallback(async () => {
    const res = await window.api.leads.list({ search, status, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
    const pipe = await window.api.leads.pipeline();
    if (pipe.ok) setPipeline(pipe.data);
  }, [search, status, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.leads.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash('Lead deleted.'); load(); }
    setDeleteTarget(null);
  }

  async function convert(lead) {
    const res = await window.api.leads.convertToCustomer(lead.id);
    if (!res.ok) return setError(res.error);
    flash(res.data.alreadyConverted ? 'Lead was already converted.' : `Converted to customer #${res.data.customerId}.`);
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Leads</h1>
          <p>{total.toLocaleString()} lead{total === 1 ? '' : 's'}</p>
        </div>
        {can('leads', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus size={15} /> Add Lead
          </button>
        )}
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, marginBottom: 18 }}>
        {pipeline.map((p) => (
          <button
            key={p.stage}
            className="card"
            style={{ padding: '10px 12px', textAlign: 'left', cursor: 'pointer', border: status === p.stage ? '1.5px solid var(--color-primary)' : undefined }}
            onClick={() => setStatus(status === p.stage ? 'All' : p.stage)}
          >
            <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{p.stage}</div>
            <div style={{ fontSize: 17, fontWeight: 700 }}>{p.count}</div>
            <div style={{ fontSize: 10.5, color: 'var(--color-text-faint)' }}>{money(p.totalValue)}</div>
          </button>
        ))}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <input placeholder="Search name, phone, email, destination..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 180 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All stages</option>
          {stages.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Name</th><th>Service</th><th>Destination</th><th>Source</th><th>Agent</th><th>Est. Budget</th><th>Priority</th><th>Stage</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((l) => (
              <tr key={l.id}>
                <td><strong>{l.full_name}</strong><div style={{ fontSize: 11, color: 'var(--color-text-faint)' }}>{l.phone || l.email || ''}</div></td>
                <td>{l.service_type || '—'}</td>
                <td>{l.destination || '—'}</td>
                <td>{l.source || '—'}</td>
                <td>{l.agent_name || '—'}</td>
                <td>{money(l.estimated_value)}</td>
                <td>{l.priority}</td>
                <td><span className={`status-pill ${STAGE_TONE[l.status] || 'on'}`}>{l.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="View details" onClick={() => setViewing(l)}><Eye size={14} /></button>
                  {l.status !== 'Converted' && can('leads', 'edit') && (
                    <button className="icon-btn" title="Convert to Customer" onClick={() => convert(l)}><ArrowRightCircle size={14} /></button>
                  )}
                  {can('leads', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(l.id); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('leads', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(l)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="empty-row">No leads found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <LeadFormModal leadId={editingId} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {viewing && (
        <LeadViewModal
          lead={viewing}
          canEdit={can('leads', 'edit')}
          onClose={() => setViewing(null)}
          onEdit={() => { setEditingId(viewing.id); setViewing(null); setFormOpen(true); }}
        />
      )}

      {deleteTarget && (
        <Modal title="Delete lead" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.full_name}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY = {
  full_name: '', phone: '', email: '', source: '', destination: '', travel_date: '',
  service_type: '', agent_id: '', estimated_value: 0, status: 'New', priority: 'Medium', notes: '', details: {}
};

// Traveller info is common to every service type; everything else is dropped when the service type changes.
const COMMON_DETAIL_KEYS = ['travel_month', 'date_flexibility', 'passports', 'passport_country', 'adults', 'children', 'infants', 'ages'];
const pickCommon = (d = {}) => Object.fromEntries(Object.entries(d).filter(([k]) => COMMON_DETAIL_KEYS.includes(k)));

function LeadFormModal({ leadId, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [stages, setStages] = useState([]);
  const [priorities, setPriorities] = useState([]);
  const [agents, setAgents] = useState([]);
  const [activities, setActivities] = useState([]);
  const [noteText, setNoteText] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    window.api.leads.stages().then((res) => res.ok && setStages(res.data));
    window.api.leads.priorities().then((res) => res.ok && setPriorities(res.data));
    window.api.agents.options({ includeInactive: true }).then((res) => res.ok && setAgents(res.data));
  }, []);
  useEffect(() => {
    if (!leadId) return;
    window.api.leads.get(leadId).then((res) => { if (res.ok) { setForm({ ...EMPTY, ...res.data, details: res.data.details || {} }); setActivities(res.data.activities); } });
  }, [leadId]);

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }
  function setServiceType(v) { setForm((s) => ({ ...s, service_type: v, details: pickCommon(s.details) })); }

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    const res = leadId ? await window.api.leads.update(leadId, form) : await window.api.leads.create(form);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(leadId ? 'Lead updated.' : 'Lead added.');
  }

  async function addNote() {
    if (!noteText.trim()) return;
    const res = await window.api.leads.addNote(leadId, noteText.trim());
    if (res.ok) {
      const fresh = await window.api.leads.get(leadId);
      if (fresh.ok) setActivities(fresh.data.activities);
      setNoteText('');
    }
  }

  return (
    <Modal title={leadId ? 'Edit Lead' : 'Add Lead'} onClose={onClose} width={720}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Name *" full><input className="field-input" value={form.full_name} onChange={(e) => set('full_name', e.target.value)} /></Field>
          <Field label="Phone"><input className="field-input" value={form.phone || ''} onChange={(e) => set('phone', e.target.value)} /></Field>
          <Field label="Email"><input className="field-input" value={form.email || ''} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="Source"><input className="field-input" value={form.source || ''} onChange={(e) => set('source', e.target.value)} placeholder="e.g. Facebook, Referral" /></Field>
          <Field label="Destination"><input className="field-input" value={form.destination || ''} onChange={(e) => set('destination', e.target.value)} /></Field>
          <Field label="Service Type">
            <select className="field-input" value={form.service_type || ''} onChange={(e) => setServiceType(e.target.value)}>
              <option value="">Select service type</option>
              {SERVICE_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Agent Name">
            <select className="field-input" value={form.agent_id || ''} onChange={(e) => set('agent_id', e.target.value)}>
              <option value="">No agent</option>
              {agents.map((a) => <option key={a.id} value={a.id}>{a.name}{a.agent_code ? ` (${a.agent_code})` : ''}{a.status === 'Inactive' ? ' - inactive' : ''}</option>)}
            </select>
          </Field>
          <Field label="Estimated Budget"><input type="number" min="0" className="field-input" value={form.estimated_value} onChange={(e) => set('estimated_value', e.target.value)} placeholder="Customer's budget" /></Field>
          <Field label="Stage">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              {stages.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Priority">
            <select className="field-input" value={form.priority} onChange={(e) => set('priority', e.target.value)}>
              {priorities.map((p) => <option key={p}>{p}</option>)}
            </select>
          </Field>
          <LeadServiceFields serviceType={form.service_type} details={form.details} onChange={(d) => set('details', d)} travelDate={form.travel_date} onTravelDateChange={(v) => set('travel_date', v)} />
          <div className="form-section-title">Other</div>
          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Lead'}</button>
        </div>
      </form>

      {leadId && (
        <div style={{ marginTop: 18, borderTop: '1px solid var(--color-border)', paddingTop: 14 }}>
          <h3 style={{ fontSize: 13, marginBottom: 8 }}>Activity History</h3>
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <input className="field-input" placeholder="Add a note..." value={noteText} onChange={(e) => setNoteText(e.target.value)} />
            <button type="button" className="btn btn-secondary btn-sm" onClick={addNote}>Add</button>
          </div>
          {activities.map((a) => (
            <div className="info-row" key={a.id}>
              <span>{a.activity_type} — {a.description}</span>
              <span style={{ fontSize: 11 }}>{a.created_at?.slice(0, 16).replace('T', ' ')}</span>
            </div>
          ))}
          {activities.length === 0 && <p style={{ fontSize: 12, color: 'var(--color-text-faint)' }}>No activity yet.</p>}
        </div>
      )}
    </Modal>
  );
}

function LeadViewModal({ lead, canEdit, onClose, onEdit }) {
  const rows = summarizeLeadDetails(lead.details || {});
  const base = [
    ['Lead #', lead.lead_code], ['Phone', lead.phone], ['Email', lead.email], ['Source', lead.source],
    ['Service type', lead.service_type], ['Destination', lead.destination], ['Travel date', lead.travel_date],
    ['Estimated budget', money(lead.estimated_value)], ['Stage', lead.status], ['Priority', lead.priority], ['Agent', lead.agent_name]
  ];
  const Row = ([label, value]) => (
    <div className="info-row" key={label}><span>{label}</span><span style={{ textAlign: 'right' }}>{value || '—'}</span></div>
  );
  return (
    <Modal title={lead.full_name} onClose={onClose} width={620}>
      {base.map(Row)}
      {rows.length > 0 && <h3 style={{ fontSize: 13, margin: '18px 0 6px' }}>{lead.service_type ? `${lead.service_type} enquiry details` : 'Enquiry details'}</h3>}
      {rows.map(Row)}
      {lead.notes && (
        <>
          <h3 style={{ fontSize: 13, margin: '18px 0 6px' }}>Notes</h3>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{lead.notes}</p>
        </>
      )}
      <div className="modal-actions">
        <button className="btn btn-secondary" onClick={onClose}>Close</button>
        {canEdit && <button className="btn btn-primary" onClick={onEdit}><Pencil size={13} /> Edit</button>}
      </div>
    </Modal>
  );
}
