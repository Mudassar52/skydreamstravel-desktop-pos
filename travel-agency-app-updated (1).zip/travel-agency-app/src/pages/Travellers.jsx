import { useEffect, useState, useCallback } from 'react';
import { UserSquare2, Pencil, Trash2, X, UserPlus, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import './customers.css';

const PAGE_SIZE = 15;

export default function Travellers() {
  const { can } = useAuth();
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null); // { customerId } | { travellerId } | null (new)
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await window.api.travellers.groups.list({ search, page, pageSize: PAGE_SIZE });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }
  const label = (g) => g.customer_name || g.members[0]?.full_name || 'Traveller';

  async function confirmDelete() {
    // delete every traveller in the group (the service refuses any that are still used elsewhere)
    let failed = '';
    for (const m of deleteTarget.members) {
      const bookingLinks = await window.api.travellers.get(m.id);
      if (bookingLinks.ok && bookingLinks.data.bookings.length) { failed = 'Remove the travellers from their bookings first (Edit → untick the bookings).'; break; }
      const res = await window.api.travellers.delete(m.id);
      if (!res.ok) { failed = res.error; break; }
    }
    if (failed) setError(failed); else { flash(`${label(deleteTarget)} deleted.`); setError(''); }
    setDeleteTarget(null);
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Travellers</h1>
          <p>{total.toLocaleString()} customer{total === 1 ? '' : 's'} with travellers — one entry per customer, all their travellers inside</p>
        </div>
        {can('travellers', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <UserSquare2 size={15} /> Add Traveller
          </button>
        )}
      </div>

      <div className="customers-toolbar">
        <div className="global-search" style={{ width: 320 }}>
          <input placeholder="Search customer, traveller or passport number..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Customer</th><th>Travellers</th><th>Bookings</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((g) => (
              <tr key={g.key}>
                <td style={{ verticalAlign: 'top' }}><strong>{label(g)}</strong><div style={{ fontSize: 11, color: 'var(--color-text-faint)' }}>{g.members.length} traveller{g.members.length === 1 ? '' : 's'}</div></td>
                <td>
                  {g.members.map((m) => (
                    <div key={m.id} style={{ padding: '2px 0' }}>
                      {m.full_name}
                      <span style={{ fontSize: 11.5, color: 'var(--color-text-muted)' }}>
                        {' '}· {[m.relationship, m.passport_number && `Passport ${m.passport_number}`, m.passport_expiry_date && `exp ${m.passport_expiry_date}`].filter(Boolean).join(' · ')}
                      </span>
                    </div>
                  ))}
                </td>
                <td style={{ verticalAlign: 'top' }}>{g.bookings.length ? g.bookings.map((b) => b.booking_code).join(', ') : '—'}</td>
                <td className="row-actions" style={{ verticalAlign: 'top' }}>
                  {can('travellers', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditing(g.customer_id ? { customerId: g.customer_id } : { travellerId: g.traveller_id }); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('travellers', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(g)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={4} className="empty-row">No travellers found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <TravellerFormModal target={editing} onClose={() => setFormOpen(false)} onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }} />
      )}

      {deleteTarget && (
        <Modal title="Delete travellers" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{label(deleteTarget)}</strong> and all {deleteTarget.members.length} traveller{deleteTarget.members.length === 1 ? '' : 's'} inside? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const EMPTY_MEMBER = {
  full_name: '', relationship: 'Self', date_of_birth: '', gender: '', nationality: '',
  passport_number: '', passport_issue_date: '', passport_expiry_date: '', visa_status: '', notes: ''
};

function TravellerFormModal({ target, onClose, onSaved }) {
  const isEdit = !!target;
  const [customerId, setCustomerId] = useState(target?.customerId || '');
  const [customerLabel, setCustomerLabel] = useState('');
  const [members, setMembers] = useState([{ ...EMPTY_MEMBER, _key: 0 }]);
  const [removedIds, setRemovedIds] = useState([]);
  const [bookings, setBookings] = useState([]);       // the customer's bookings
  const [bookingIds, setBookingIds] = useState([]);   // ticked = travellers appear on that booking
  const [relationships, setRelationships] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { window.api.travellers.relationships().then((res) => res.ok && setRelationships(res.data)); }, []);

  // Load the whole group (edit), or just the customer's existing travellers + bookings (new entry for a customer)
  useEffect(() => {
    if (!customerId && !target?.travellerId) { setBookings([]); return; }
    window.api.travellers.groups.get(target?.travellerId ? { travellerId: target.travellerId } : { customerId }).then((res) => {
      if (!res.ok) return setError(res.error);
      const d = res.data;
      if (d.customer) setCustomerLabel(d.customer.full_name);
      setBookings(d.available_bookings);
      setBookingIds(d.linked_booking_ids);
      setRemovedIds([]);
      setMembers(d.members.length ? d.members.map((m, i) => ({ ...EMPTY_MEMBER, ...m, _key: i })) : [{ ...EMPTY_MEMBER, _key: 0 }]);
    });
  }, [customerId, target?.travellerId]);

  const setMember = (i, f, v) => setMembers((ms) => ms.map((m, idx) => (idx === i ? { ...m, [f]: v } : m)));
  const addMember = () => setMembers((ms) => [...ms, { ...EMPTY_MEMBER, relationship: 'Spouse', _key: Date.now() }]);
  function removeMember(i) {
    const m = members[i];
    if (m.id) setRemovedIds((r) => [...r, m.id]);
    setMembers((ms) => ms.filter((_, idx) => idx !== i));
  }
  const toggleBooking = (id) => setBookingIds((b) => (b.includes(id) ? b.filter((x) => x !== id) : [...b, id]));

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (!customerId) return setError('Please select a customer.');
    if (!members.length) return setError('Add at least one traveller.');
    setSaving(true);
    const res = await window.api.travellers.groups.save({
      customer_id: customerId,
      members: members.map(({ _key, ...m }) => m),
      removed_ids: removedIds,
      booking_ids: bookingIds
    });
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(isEdit ? 'Travellers updated.' : 'Travellers saved.');
  }

  return (
    <Modal title={isEdit ? 'Edit Traveller' : 'Add Traveller'} onClose={onClose} width={720}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            {isEdit
              ? <input className="field-input" value={customerLabel} disabled />
              : <CustomerSearchSelect value={customerId} valueLabel={customerLabel} onChange={(id, label) => { setCustomerId(id); setCustomerLabel(label); }} />}
          </Field>
          <Field label="Booking (travellers will show on the selected booking)" full>
            {!customerId ? (
              <div style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>Select a customer first.</div>
            ) : bookings.length === 0 ? (
              <div style={{ fontSize: 12.5, color: 'var(--color-text-muted)' }}>This customer has no bookings yet.</div>
            ) : (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                {bookings.map((b) => (
                  <label key={b.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5 }}>
                    <input type="checkbox" checked={bookingIds.includes(b.id)} onChange={() => toggleBooking(b.id)} />
                    {b.booking_code} · {b.booking_type}{b.departure_date ? ` · ${b.departure_date}` : ''}
                  </label>
                ))}
              </div>
            )}
          </Field>
        </div>

        {members.map((m, i) => (
          <div className="card" style={{ padding: 12, marginTop: 12 }} key={m.id || m._key}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <strong style={{ fontSize: 13 }}>Traveller {i + 1}</strong>
              {members.length > 1 && <button type="button" className="icon-btn" title="Remove traveller" onClick={() => removeMember(i)}><X size={14} /></button>}
            </div>
            <div className="form-grid">
              <Field label="Full Name *" full><input className="field-input" value={m.full_name} onChange={(e) => setMember(i, 'full_name', e.target.value)} /></Field>
              <Field label="Relationship">
                <select className="field-input" value={m.relationship || ''} onChange={(e) => setMember(i, 'relationship', e.target.value)}>
                  {relationships.map((r) => <option key={r}>{r}</option>)}
                </select>
              </Field>
              <Field label="Gender">
                <select className="field-input" value={m.gender || ''} onChange={(e) => setMember(i, 'gender', e.target.value)}>
                  <option value="">—</option><option>Male</option><option>Female</option><option>Other</option>
                </select>
              </Field>
              <Field label="Date of Birth"><input type="date" className="field-input" value={m.date_of_birth || ''} onChange={(e) => setMember(i, 'date_of_birth', e.target.value)} /></Field>
              <Field label="Nationality"><input className="field-input" value={m.nationality || ''} onChange={(e) => setMember(i, 'nationality', e.target.value)} /></Field>
              <Field label="Passport Number"><input className="field-input" value={m.passport_number || ''} onChange={(e) => setMember(i, 'passport_number', e.target.value)} /></Field>
              <Field label="Visa Status"><input className="field-input" value={m.visa_status || ''} onChange={(e) => setMember(i, 'visa_status', e.target.value)} /></Field>
              <Field label="Passport Issue Date"><input type="date" className="field-input" value={m.passport_issue_date || ''} onChange={(e) => setMember(i, 'passport_issue_date', e.target.value)} /></Field>
              <Field label="Passport Expiry Date"><input type="date" className="field-input" value={m.passport_expiry_date || ''} onChange={(e) => setMember(i, 'passport_expiry_date', e.target.value)} /></Field>
              <Field label="Notes" full><textarea className="field-input" rows={1} value={m.notes || ''} onChange={(e) => setMember(i, 'notes', e.target.value)} /></Field>
            </div>
          </div>
        ))}

        <button type="button" className="btn btn-secondary btn-sm" style={{ marginTop: 12 }} onClick={addMember}><UserPlus size={13} /> Add another traveller</button>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save Travellers'}</button>
        </div>
      </form>
    </Modal>
  );
}
