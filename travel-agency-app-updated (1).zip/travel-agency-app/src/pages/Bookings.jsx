import { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Plus, Search, Eye, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import Modal from '../components/Modal.jsx';
import Field from '../components/Field.jsx';
import CustomerSearchSelect from '../components/CustomerSearchSelect.jsx';
import DateRangeFilter from '../components/DateRangeFilter.jsx';
import SavedFiltersBar from '../components/SavedFiltersBar.jsx';
import './customers.css';

const PAGE_SIZE = 15;
const TYPES = ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transportation', 'Custom'];
const STATUSES = ['Inquiry', 'Pending', 'Confirmed', 'Cancelled', 'Completed'];
const STATUS_TONE = { Inquiry: 'off', Pending: 'off', Confirmed: 'on', Completed: 'on', Cancelled: 'off' };
const DATE_FIELDS = [
  { value: 'booking_date', label: 'Booking Date' },
  { value: 'departure_date', label: 'Travel Date' },
  { value: 'created_at', label: 'Created Date' }
];
const money = (n) => `Rs. ${Number(n || 0).toLocaleString('en-PK')}`;

export default function Bookings() {
  const { can } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [type, setType] = useState('All');
  const [dateFilter, setDateFilter] = useState({ preset: '', from: '', to: '', dateField: 'booking_date' });
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [prefillPackage, setPrefillPackage] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  useEffect(() => {
    if (location.state?.openAdd) {
      setEditingId(null);
      setPrefillPackage(location.state.packageId ? { packageId: location.state.packageId, packageType: location.state.packageType } : null);
      setFormOpen(true);
      navigate(location.pathname, { replace: true, state: {} });
    }
    if (location.state?.destination) {
      setSearch(location.state.destination);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  const load = useCallback(async () => {
    const res = await window.api.bookings.list({
      search, status, type, page, pageSize: PAGE_SIZE,
      dateField: dateFilter.dateField, dateFrom: dateFilter.from || null, dateTo: dateFilter.to || null
    });
    if (res.ok) { setRows(res.data.rows); setTotal(res.data.total); } else setError(res.error);
  }, [search, status, type, page, dateFilter]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [search, status, type, dateFilter]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function flash(msg) { setNotice(msg); setTimeout(() => setNotice(''), 3000); }

  async function confirmDelete() {
    const res = await window.api.bookings.delete(deleteTarget.id);
    if (!res.ok) setError(res.error); else { flash(`${deleteTarget.booking_code} deleted.`); load(); }
    setDeleteTarget(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Bookings</h1>
          <p>{total.toLocaleString()} total booking{total === 1 ? '' : 's'}</p>
        </div>
        {can('bookings', 'create') && (
          <button className="btn btn-primary" onClick={() => { setEditingId(null); setPrefillPackage(null); setFormOpen(true); }}>
            <Plus size={15} /> New Booking
          </button>
        )}
      </div>

      <div className="customers-toolbar" style={{ flexWrap: 'wrap', rowGap: 10 }}>
        <div className="global-search" style={{ width: 280 }}>
          <Search size={15} />
          <input placeholder="Search booking code or customer..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="field-input" style={{ width: 160 }} value={type} onChange={(e) => setType(e.target.value)}>
          <option value="All">All types</option>
          {TYPES.map((t) => <option key={t}>{t}</option>)}
        </select>
        <select className="field-input" style={{ width: 160 }} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="All">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <DateRangeFilter value={dateFilter} onChange={setDateFilter} dateFieldOptions={DATE_FIELDS} />
      </div>

      <div style={{ marginBottom: 14 }}>
        <SavedFiltersBar
          module="bookings"
          currentFilter={{ search, status, type, dateFilter }}
          onApply={(f) => { setSearch(f.search || ''); setStatus(f.status || 'All'); setType(f.type || 'All'); setDateFilter(f.dateFilter || { preset: '', from: '', to: '', dateField: 'booking_date' }); }}
        />
      </div>

      {notice && <div className="inline-notice">{notice}</div>}
      {error && <div className="login-error" style={{ margin: '0 0 12px' }}>{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr><th>Booking #</th><th>Customer</th><th>Type</th><th>Travellers</th><th>Departure</th><th>Total</th><th>Outstanding</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((b) => (
              <tr key={b.id}>
                <td><button className="link-cell" onClick={() => navigate(`/bookings/${b.id}/360`)}>{b.booking_code}</button></td>
                <td>{b.customer_name}</td>
                <td>{b.booking_type}</td>
                <td title={b.traveller_names || ''}>{b.travellers_count ? `${b.travellers_count} — ${b.traveller_names}` : '—'}</td>
                <td>{b.departure_date || '—'}</td>
                <td>{money(b.total_price)}</td>
                <td>{money(b.remaining_amount)}</td>
                <td><span className={`status-pill ${STATUS_TONE[b.status] || 'off'}`}>{b.status}</span></td>
                <td className="row-actions">
                  <button className="icon-btn" title="Open Complete Travel Dossier" onClick={() => navigate(`/bookings/${b.id}/360`)}><Eye size={14} /></button>
                  {can('bookings', 'edit') && (
                    <button className="icon-btn" title="Edit" onClick={() => { setEditingId(b.id); setPrefillPackage(null); setFormOpen(true); }}><Pencil size={14} /></button>
                  )}
                  {can('bookings', 'delete') && (
                    <button className="icon-btn" title="Delete" onClick={() => setDeleteTarget(b)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="empty-row">No bookings found.</td></tr>}
          </tbody>
        </table>
        <div className="pagination">
          <span>Page {page} of {totalPages}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="icon-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft size={14} /></button>
            <button className="icon-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>

      {formOpen && (
        <BookingFormModal
          bookingId={editingId}
          prefillPackage={prefillPackage}
          onClose={() => setFormOpen(false)}
          onSaved={(msg) => { setFormOpen(false); flash(msg); load(); }}
        />
      )}



      {deleteTarget && (
        <Modal title="Delete booking" onClose={() => setDeleteTarget(null)}>
          <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>Delete <strong>{deleteTarget.booking_code}</strong>? This can't be undone.</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
            <button className="btn btn-primary" style={{ background: 'var(--color-danger)' }} onClick={confirmDelete}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
const EMPTY = {
  customer_id: '', customer_label: '', booking_type: 'Umrah', reference_id: '', package_id: '',
  departure_date: '', return_date: '', number_of_passengers: 1, total_price: '',
  paid_amount: '', status: 'Inquiry', notes: '', agent_id: ''
};
const PACKAGE_BOOKING_TYPES = ['Umrah', 'Hajj', 'Tour', 'Custom'];

function BookingFormModal({ bookingId, prefillPackage, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [refOptions, setRefOptions] = useState([]);
  const [packageOptions, setPackageOptions] = useState([]);
  const [linkedPackageName, setLinkedPackageName] = useState('');
  const [agents, setAgents] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  // Agents feed the optional "Agent" dropdown. A user who can't see agents just gets an empty list (field hidden).
  useEffect(() => { window.api.agents.options({ includeInactive: true }).then((res) => { if (res.ok) setAgents(res.data); }); }, []);

  useEffect(() => {
    if (bookingId) {
      window.api.bookings.get(bookingId).then((res) => {
        if (res.ok) {
          setForm({
            ...EMPTY, ...res.data,
            customer_label: res.data.customer_name,
            reference_id: res.data.reference_id || ''
          });
          if (res.data.package_snapshot) {
            try { setLinkedPackageName(JSON.parse(res.data.package_snapshot).package_name); } catch { /* ignore */ }
          }
        }
      });
    } else if (prefillPackage?.packageId) {
      setForm((s) => ({ ...s, booking_type: prefillPackage.packageType || s.booking_type, package_id: prefillPackage.packageId }));
    }
  }, [bookingId, prefillPackage]);

  useEffect(() => {
    window.api.bookings.referenceOptions(form.booking_type).then((res) => { if (res.ok) setRefOptions(res.data); });
    if (!bookingId && PACKAGE_BOOKING_TYPES.includes(form.booking_type)) {
      window.api.bookings.packageOptions(form.booking_type).then((res) => { if (res.ok) setPackageOptions(res.data); });
    } else {
      setPackageOptions([]);
    }
  }, [form.booking_type, bookingId]);

  // Selecting a package fills in the destination/dates/price for you - the
  // Package -> Booking Connection described in the spec - without wiping out
  // anything the user already typed by hand.
  function selectPackage(packageId) {
    setForm((s) => {
      const next = { ...s, package_id: packageId };
      const pkg = packageOptions.find((p) => p.id === packageId);
      if (pkg) {
        if (!next.destination) next.destination = pkg.destination || '';
        if (!next.departure_date) next.departure_date = pkg.departure_date || '';
        if (!next.return_date) next.return_date = pkg.return_date || '';
        if (!next.total_price) next.total_price = pkg.selling_price || '';
      }
      return next;
    });
  }

  function set(f, v) { setForm((s) => ({ ...s, [f]: v })); }

  async function submit(e) {
    e.preventDefault();
    if (!form.customer_id) return setError('Please select a customer.');
    setSaving(true);
    const payload = { ...form, package_id: form.package_id || null, agent_id: form.agent_id || null };
    const res = bookingId ? await window.api.bookings.update(bookingId, payload) : await window.api.bookings.create(payload);
    setSaving(false);
    if (!res.ok) return setError(res.error);
    onSaved(bookingId ? 'Booking updated.' : `Booking ${res.data.bookingCode || ''} created.`);
  }

  const showReference = !form.package_id && (refOptions.length > 0 || ['Umrah', 'Hajj', 'Tour'].includes(form.booking_type));
  const remaining = Number(form.total_price || 0) - Number(form.paid_amount || 0);

  return (
    <Modal title={bookingId ? 'Edit Booking' : 'New Booking'} onClose={onClose} width={560}>
      {error && <div className="login-error" style={{ marginBottom: 12 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="Customer *" full>
            <CustomerSearchSelect
              value={form.customer_id}
              valueLabel={form.customer_label}
              onChange={(id, label) => setForm((s) => ({ ...s, customer_id: id, customer_label: label }))}
            />
          </Field>

          <Field label="Booking Type">
            <select className="field-input" value={form.booking_type} disabled={!!bookingId && !!form.package_id} onChange={(e) => set('booking_type', e.target.value)}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>

          {bookingId ? (
            form.package_id && (
              <Field label="Package"><input className="field-input" value={linkedPackageName || `#${form.package_id}`} disabled style={{ background: 'var(--color-bg)', color: 'var(--color-text-muted)' }} /></Field>
            )
          ) : (
            !!packageOptions.length && (
              <Field label="Select Package" full>
                <select className="field-input" value={form.package_id || ''} onChange={(e) => selectPackage(e.target.value ? Number(e.target.value) : '')}>
                  <option value="">— No package (build manually) —</option>
                  {packageOptions.map((p) => (
                    <option key={p.id} value={p.id}>{p.package_name} {p.duration ? `· ${p.duration}` : ''} · {money(p.selling_price)}</option>
                  ))}
                </select>
                {form.package_id && (
                  <p style={{ fontSize: 11.5, color: 'var(--color-text-faint)', marginTop: 4 }}>
                    Flights, visa, hotels, transport and other services from this package will be created automatically and linked to this booking.
                  </p>
                )}
              </Field>
            )
          )}

          {showReference && (
            <Field label="Legacy Reference (optional)">
              <select className="field-input" value={form.reference_id || ''} onChange={(e) => set('reference_id', e.target.value ? Number(e.target.value) : '')}>
                <option value="">— None —</option>
                {refOptions.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
              </select>
            </Field>
          )}

          <Field label="Departure Date"><input type="date" className="field-input" value={form.departure_date || ''} onChange={(e) => set('departure_date', e.target.value)} /></Field>
          <Field label="Return Date"><input type="date" className="field-input" value={form.return_date || ''} onChange={(e) => set('return_date', e.target.value)} /></Field>
          <Field label="Number of Passengers"><input type="number" min="1" className="field-input" value={form.number_of_passengers} onChange={(e) => set('number_of_passengers', e.target.value)} /></Field>
          <Field label="Status">
            <select className="field-input" value={form.status} onChange={(e) => set('status', e.target.value)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>

          <Field label="Total Price (Rs.)"><input type="number" className="field-input" value={form.total_price} onChange={(e) => set('total_price', e.target.value)} /></Field>
          <Field label="Paid Amount (Rs.)"><input type="number" className="field-input" value={form.paid_amount} onChange={(e) => set('paid_amount', e.target.value)} /></Field>
          <Field label="Remaining (auto)" full>
            <input className="field-input" value={money(remaining)} disabled style={{ background: 'var(--color-bg)', color: 'var(--color-text-muted)' }} />
          </Field>

          {agents.length > 0 && (
            <Field label="Agent (optional)" full>
              <select className="field-input" value={form.agent_id || ''} onChange={(e) => set('agent_id', e.target.value)}>
                <option value="">No agent</option>
                {agents.map((a) => <option key={a.id} value={a.id}>{a.agent_code} - {a.name}{a.status === 'Inactive' ? ' (inactive)' : ''}</option>)}
              </select>
              {form.agent_id && <div style={{ fontSize: 11.5, color: 'var(--color-text-muted)', marginTop: 4 }}>A Pending commission is created automatically at the agent's rate. Manage it under Partners › Commissions.</div>}
            </Field>
          )}

          <Field label="Notes" full><textarea className="field-input" rows={2} value={form.notes || ''} onChange={(e) => set('notes', e.target.value)} /></Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : bookingId ? 'Save Changes' : 'Create Booking'}</button>
        </div>
      </form>
    </Modal>
  );
}
