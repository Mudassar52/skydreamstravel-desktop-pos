// What the quotation form shows for each quotation type, and how the guided sections (hotels, included services,
// traveller prices) are turned into / read back from the stored service rows. Pure functions - no React here.

export const FLOWS = {
  Umrah: { label: 'Umrah', hint: 'Hotels, transport, ziyarat, visa, flights', hotels: ['Makkah', 'Madinah'], info: ['transport', 'ziyarat', 'visa'], flights: true, pricing: 'pax', primary: 'Package', packageLabel: 'Umrah package name' },
  Hajj: { label: 'Hajj', hint: 'Hotels, transport, visa, flights', hotels: ['Makkah', 'Madinah'], info: ['transport', 'ziyarat', 'visa'], flights: true, pricing: 'pax', primary: 'Package', packageLabel: 'Hajj package name' },
  Tour: { label: 'Tour', hint: 'Hotels, transport, flights', hotels: [''], info: ['transport', 'visa'], flights: true, pricing: 'pax', primary: 'Package', packageLabel: 'Tour package name' },
  Flight: { label: 'Flight', hint: 'Flight pictures + ticket price per traveller', hotels: null, info: [], flights: true, pricing: 'pax', primary: 'Flight', packageLabel: 'Ticket description', defaultName: 'Flight Tickets' },
  Hotel: { label: 'Hotel', hint: 'Hotel stay only', hotels: [''], info: [], flights: false, pricing: 'rows', rowCategory: 'Hotel' },
  Visa: { label: 'Visa', hint: 'Visa service per traveller', hotels: null, info: ['visa'], flights: false, pricing: 'pax', primary: 'Visa', packageLabel: 'Visa service', defaultName: 'Visa Service' },
  Transport: { label: 'Transport', hint: 'Transport / transfers only', hotels: null, info: ['transport'], flights: false, pricing: 'rows', rowCategory: 'Transport' },
  'Custom Package': { label: 'Custom', hint: 'Mix anything - you add every line yourself', hotels: [], info: ['transport', 'ziyarat', 'visa'], flights: true, pricing: 'rows', rowCategory: 'Package' }
};
export const flowOf = (type) => FLOWS[type] || FLOWS['Custom Package'];

export const INFO_FIELDS = {
  transport: [['transport_type', 'Transport type (e.g. 4 Seater Van)'], ['transport_route', 'Transport route (e.g. Jeddah Airport to Makkah Hotel ...)']],
  ziyarat: [['ziyarat', 'Ziyarat (e.g. Makkah & Madinah Ziyarat)']],
  visa: [['visa_details', 'Visa details (e.g. 3 Person Umrah Visas on Indian Passport)']]
};
const INFO_KEYS = Object.values(INFO_FIELDS).flat().map((f) => f[0]);
const LEGACY_KEYS = ['makkah_hotel', 'madinah_hotel', 'makkah_nights', 'madinah_nights', 'makkah_checkin', 'makkah_checkout', 'madinah_checkin', 'madinah_checkout',
  'makkah_distance', 'madinah_distance', 'room_type', 'rooms', 'meal_plan', ...INFO_KEYS];

export const PAX = [['Adult', 'adults'], ['Child', 'children'], ['Infant', 'infants']];
const paxBucket = (t) => (/infant/i.test(t || '') ? 'Infant' : /child|youth/i.test(t || '') ? 'Child' : 'Adult');

export const newHotel = (city = '') => ({ city, name: '', check_in: '', check_out: '', room_type: '', rooms: 1, meal_plan: '', distance: '' });

const addDays = (iso, n) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!m) return '';
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3] + n)).toISOString().slice(0, 10);
};
export const hotelNights = (h) => {
  const a = Date.parse(h.check_in); const b = Date.parse(h.check_out);
  return Number.isFinite(a) && Number.isFinite(b) && b > a ? Math.round((b - a) / 86400000) : 0;
};

/**
 * Stored service rows -> the guided form state.
 *  - zero-priced Hotel rows (and the old per-row Umrah details) become the hotels list,
 *  - transport / ziyarat / visa text is collected into `info`,
 *  - rows tagged with a traveller type become the per-person prices,
 *  - every other row stays a normal service row exactly as saved (so old quotations keep their totals).
 */
export function itemsToFlow(items, { travelFrom = '' } = {}) {
  const hotels = []; const info = {}; const pax = {}; const rows = [];
  let packageName = ''; let packageId = '';
  let cursor = travelFrom;
  for (const it of items || []) {
    const d = { ...(it.details || {}) };
    INFO_KEYS.forEach((k) => { if (d[k] && !info[k]) info[k] = d[k]; });
    for (const city of ['Makkah', 'Madinah']) {
      const key = city.toLowerCase();
      if (!d[`${key}_hotel`]) continue;
      let inD = d[`${key}_checkin`] || cursor; const n = Number(d[`${key}_nights`]) || 0;
      let outD = d[`${key}_checkout`] || (inD && n ? addDays(inD, n) : '');
      if (outD) cursor = outD;
      hotels.push({ city, name: d[`${key}_hotel`], check_in: inD || '', check_out: outD || '', room_type: d.room_type || '', rooms: Number(d.rooms) || 1, meal_plan: d.meal_plan || '', distance: d[`${key}_distance`] || '' });
    }
    if (it.category === 'Hotel' && !(Number(it.unit_price) > 0)) {
      hotels.push({ city: d.city || '', name: it.name, check_in: d.check_in || it.service_date || '', check_out: d.check_out || '', room_type: d.room_type || '', rooms: Number(d.rooms) || Number(it.quantity) || 1, meal_plan: d.meal_plan || '', distance: d.distance || '' });
      continue;
    }
    if (d.pax_type) {
      const b = paxBucket(d.pax_type);
      if (!pax[b]) pax[b] = { price: it.unit_price, cost: it.cost_price ?? 0, id: it.id || null };
      if (!packageName) packageName = it.name;
      if (d.package_id && !packageId) packageId = d.package_id;
      continue;
    }
    // A normal service row: drop the facts that now live in the guided sections so they are not saved twice.
    LEGACY_KEYS.forEach((k) => delete d[k]);
    delete d.package_id;
    rows.push({ ...it, details: d });
  }
  return { hotels, info, pax, rows, packageName, packageId };
}

/** The guided form state -> the service rows sent to the server. */
export function flowToItems(type, state, counts) {
  const flow = flowOf(type);
  const out = [];
  const infoOut = {};
  (flow.info || []).forEach((g) => INFO_FIELDS[g].forEach(([k]) => { if (String(state.info[k] || '').trim()) infoOut[k] = state.info[k]; }));

  if (flow.pricing === 'pax') {
    let first = true;
    for (const [label, countKey] of PAX) {
      const qty = Number(counts[countKey]) || 0;
      if (qty <= 0) continue;
      const p = state.pax[label] || {};
      out.push({
        id: p.id || undefined, category: flow.primary, name: (state.packageName || '').trim() || flow.defaultName || `${flow.label} Package`,
        quantity: qty, unit: 'Person', unit_price: Number(p.price) || 0, discount: 0, cost_price: Number(p.cost) || 0,
        details: { pax_type: label, ...(first && state.packageId ? { package_id: state.packageId } : {}) }
      });
      first = false;
    }
  }
  if (flow.hotels) {
    for (const h of state.hotels) {
      if (!String(h.name || '').trim()) continue;
      out.push({
        category: 'Hotel', name: h.name.trim(), quantity: Number(h.rooms) || 1, unit: 'Room', unit_price: 0, discount: 0, cost_price: 0,
        service_date: h.check_in || '', details: { city: h.city, check_in: h.check_in, check_out: h.check_out, room_type: h.room_type, rooms: h.rooms, meal_plan: h.meal_plan, distance: h.distance }
      });
    }
  }
  for (const r of state.rows || []) out.push({ ...r, details: { ...(r.details || {}) } });
  // The included-services text rides on the first row (the printed quotation reads it from there).
  if (out.length && Object.keys(infoOut).length) out[0].details = { ...(out[0].details || {}), ...infoOut };
  return out;
}

/** Line totals shown in the form, mirroring what the server computes. */
export function lineTotals(type, state, counts) {
  return flowToItems(type, state, counts).map((r) => Math.max(0, (Number(r.quantity) || 0) * (Number(r.unit_price) || 0) - (Number(r.discount) || 0)));
}
