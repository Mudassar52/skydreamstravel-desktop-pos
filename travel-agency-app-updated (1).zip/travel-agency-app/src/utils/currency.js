// Same rules as electron/services/moneyFormat.js (kept in sync by hand - renderer can't require Node files).
const SYMBOLS = { PKR: 'Rs. ', GBP: '£', USD: '$', EUR: '€', SAR: 'SAR ', AED: 'AED ' };
export const INVOICE_CURRENCIES = ['PKR', 'GBP', 'USD', 'EUR', 'SAR', 'AED'];

export function formatMoney(amount, currency = 'PKR') {
  const code = String(currency || 'PKR').toUpperCase();
  const n = Number(amount || 0);
  const prefix = SYMBOLS[code] !== undefined ? SYMBOLS[code] : `${code} `;
  if (code === 'PKR') return `${prefix}${n.toLocaleString('en-PK')}`;
  return `${prefix}${n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
