const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

let db = null;

/**
 * Opens (creating if needed) the SQLite database inside the given
 * userData directory, and applies the schema. Safe to call multiple
 * times - CREATE TABLE IF NOT EXISTS makes this idempotent.
 */
function initDatabase(userDataPath) {
  const dbDir = path.join(userDataPath, 'database');
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  const dbPath = path.join(dbDir, 'agency.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Must run BEFORE schema.sql: an old/incompatible table with the same name would make
  // the schema's CREATE INDEX fail ("no such column") and stop the whole app from starting.
  repairLegacyTables();

  const schemaPath = path.join(__dirname, 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf-8');
  db.exec(schema);

  addMissingColumns();
  migrateQuotationStatuses();
  backfillDocumentCurrencies();
  ensurePostMigrationIndexes();
  seedDefaults();
  migrateLegacyPackages();

  return db;
}

/**
 * Repairs tables left over from an older/different build whose columns don't match the current schema.
 * CREATE TABLE IF NOT EXISTS skips an existing table, so the schema's indexes then fail on missing columns.
 * The old table is renamed (never deleted) so its data stays recoverable, and the schema recreates it fresh.
 * Safe on every startup: a table that already has the right columns is left untouched.
 */
function repairLegacyTables() {
  const requiredColumns = {
    exchange_rates: ['from_currency', 'to_currency', 'rate', 'effective_date']
  };
  for (const [table, required] of Object.entries(requiredColumns)) {
    const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
    if (cols.length === 0) continue; // table doesn't exist yet - schema.sql will create it
    if (required.every((c) => cols.includes(c))) continue;
    // Indexes follow the renamed table, so drop the ones the schema will recreate under the same name.
    for (const idx of db.prepare(`PRAGMA index_list(${table})`).all()) {
      if (!idx.name.startsWith('sqlite_autoindex')) db.exec(`DROP INDEX IF EXISTS "${idx.name}"`);
    }
    let backup = `${table}_old_backup`;
    for (let i = 2; db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?").get(backup); i++) {
      backup = `${table}_old_backup${i}`;
    }
    db.exec(`ALTER TABLE ${table} RENAME TO ${backup}`);
    console.warn(`[db] Table "${table}" had an outdated structure; renamed to "${backup}" and recreated.`);
  }
}

/**
 * Column-level migrations for tables that existed before Phase 19.
 * SQLite's `ALTER TABLE ... ADD COLUMN` has no `IF NOT EXISTS` on the
 * better-sqlite3 version this app targets, so each column is checked via
 * PRAGMA table_info first. Safe to call on every startup - a database that
 * already has the column is left untouched.
 */
function addMissingColumns() {
  const columnAdditions = {
    follow_ups: [
      // Free-typed or auto-filled contact info, so a follow-up can be sent to someone who is
      // not (yet) a customer, plus what the follow-up is about and when to remind.
      "contact_name TEXT",
      "contact_phone TEXT",
      "purpose TEXT",
      "contact_method TEXT",
      "reminder_time TEXT"
    ],
    hajj_groups: [
      "total_seats INTEGER DEFAULT 0"
    ],
    leads: [
      // Service-specific enquiry details (passport country, travellers + ages, Makkah/Madinah hotel
      // preferences, visa/flight/transport specifics...) stored as JSON, keyed by the lead's service_type.
      "details TEXT",
      // Which (external) agent from the Agents module brought / is handling this enquiry.
      "agent_id INTEGER REFERENCES agents(id)"
    ],
    customers: [
      "postcode TEXT",
      "customer_source TEXT",
      "salesperson_id INTEGER REFERENCES users(id)",
      "customer_type TEXT DEFAULT 'Individual'"
    ],
    bookings: [
      "destination TEXT",
      "sales_agent_id INTEGER REFERENCES users(id)",
      "operations_agent_id INTEGER REFERENCES users(id)",
      // Central package integration (Phase 20): a booking created from a
      // central package records which package it came from, plus a frozen
      // JSON snapshot of that package + its components at booking time, so
      // later edits to the master package never silently change a booking
      // that was already sold.
      "package_id INTEGER REFERENCES packages(id)",
      "package_snapshot TEXT",
      // Agents & Commissions (Phase 21): which agent (if any) brought this booking.
      "agent_id INTEGER REFERENCES agents(id)",
      // Booking-level currency (falls back to the package's, then the
      // agency default) so Customer 360 / reports can filter by currency.
      "currency TEXT"
    ],
    packages: [
      // Which product line this central package belongs to - Umrah / Hajj /
      // Tour / Custom. Existing rows (created before this column existed)
      // default to 'Custom' so they keep showing up in the generic list.
      "package_type TEXT NOT NULL DEFAULT 'Custom'",
      "departure_date TEXT",
      "return_date TEXT",
      "number_of_days INTEGER",
      // Umrah/Hajj packages mirror themselves into the legacy umrah_packages/
      // hajj_packages tables (see packageService.syncLegacyMirror) purely so
      // the existing Groups/Pilgrims features - which still store
      // group.package_id against those legacy tables - keep working without
      // their own foreign keys having to change. The mirror is an
      // implementation detail; package editing always happens on this
      // central row.
      "legacy_mirror_table TEXT",
      "legacy_mirror_id INTEGER"
    ],
    package_components: [
      // Which supplier fulfils this specific line item (a hotel component's
      // supplier is rarely the same as the flight component's supplier).
      "supplier_id INTEGER REFERENCES suppliers(id)"
    ],
    // package_component_id is traceability only ("which package line item
    // produced this row") - a package's components are freely rebuilt on
    // every edit (see packageService.update), so this must not block that
    // with a FK error, nor cascade-delete a booking's own service rows.
    // ON DELETE SET NULL lets the link simply go blank; the booking's own
    // package_snapshot already keeps the frozen historical detail.
    flights: [
      "cost REAL DEFAULT 0",
      "selling_price REAL DEFAULT 0",
      "baggage TEXT",
      "seat TEXT",
      "booking_reference TEXT",
      "supplier_id INTEGER REFERENCES suppliers(id)",
      "package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL"
    ],
    hotels: [
      "location_type TEXT",
      "room_number TEXT",
      "bed_type TEXT",
      "meal_plan TEXT",
      "number_of_guests INTEGER DEFAULT 1",
      "confirmation_number TEXT",
      "status TEXT DEFAULT 'Confirmed'",
      "supplier_id INTEGER REFERENCES suppliers(id)",
      "package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL"
    ],
    transportation: [
      "transport_type TEXT",
      "supplier_id INTEGER REFERENCES suppliers(id)",
      "package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL"
    ],
    visa_applications: [
      "traveller_id INTEGER REFERENCES travellers(id)",
      "visa_number TEXT",
      "passport_number TEXT",
      "issue_date TEXT",
      "cost REAL DEFAULT 0",
      "selling_price REAL DEFAULT 0",
      "supplier_id INTEGER REFERENCES suppliers(id)",
      "package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL"
    ],
    other_services: [
      "package_component_id INTEGER REFERENCES package_components(id) ON DELETE SET NULL"
    ],
    payments: [
      "account_type TEXT",
      "account_id INTEGER",
      // Phase 21b: the currency the amount is in (see electron/services/documentCurrency.js).
      "currency TEXT",
      // Phase 21c: the amount that actually moved through the bank/cash account when its currency differs from the
      // invoice/booking's (NULL = same as `amount`).
      "received_amount REAL"
    ],
    supplier_payments: [
      "account_amount REAL"
    ],
    invoices: [
      "currency TEXT",
      // Free-form invoice layout (RMT-style): "On Receipt" style due text and the manual payment lines
      // (JSON array of {label, date, amount}) shown under the TOTAL on the printed invoice.
      "due_label TEXT",
      "payment_lines TEXT",
      // Agent who brought the booking - printed in the invoice header.
      "agent_name TEXT"
    ],
    invoice_items: [
      // Each line can be a bold heading + multi-line description; price cells can be hidden
      // for plain text blocks (e.g. "Hotel Details") that only describe what is included.
      "title TEXT",
      "show_price INTEGER NOT NULL DEFAULT 1"
    ],
    quotations: [
      // Full quotation form: header, travel, pricing/payment terms, validity and status tracking.
      // (Existing columns reused: travel_date_from = departure date, travel_date_to = return date, notes = special
      // requirements, terms = payment terms, selling_price = FINAL total, cost = internal total cost,
      // created_by = prepared by, lead_id = inquiry reference.)
      "quotation_date TEXT",
      "quotation_type TEXT DEFAULT 'Custom Package'",
      "booking_id INTEGER REFERENCES bookings(id)",
      "customer_phone TEXT",
      "departure_city TEXT",
      "total_nights INTEGER",
      "adults INTEGER DEFAULT 1",
      "children INTEGER DEFAULT 0",
      "infants INTEGER DEFAULT 0",
      "travel_class TEXT",
      "subtotal REAL DEFAULT 0",
      "discount_type TEXT DEFAULT 'amount'",
      "discount_value REAL DEFAULT 0",
      "advance_required REAL DEFAULT 0",
      "balance_due REAL DEFAULT 0",
      "expected_profit REAL",
      "valid_until TEXT",
      "sent_via TEXT",
      "sent_at TEXT",
      "customer_response TEXT",
      "internal_notes TEXT",
      "revision_number INTEGER DEFAULT 0",
      // Agent shown on the printed quotation next to the passenger name.
      "agent_name TEXT"
    ],
    expenses: [
      "account_type TEXT",
      "account_id INTEGER"
    ]
  };

  for (const [table, columns] of Object.entries(columnAdditions)) {
    const existing = new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name));
    for (const columnDef of columns) {
      const columnName = columnDef.split(' ')[0];
      if (!existing.has(columnName)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`);
      }
    }
  }
}

/** Quotation status 'Approved' was renamed 'Accepted'. Idempotent; also gives old rows a quotation date. */
function migrateQuotationStatuses() {
  db.exec(`UPDATE quotations SET status = 'Accepted' WHERE status = 'Approved'`);
  db.exec(`UPDATE quotations SET quotation_date = date(created_at) WHERE quotation_date IS NULL`);
  db.exec(`UPDATE quotations SET subtotal = selling_price, balance_due = selling_price
             WHERE COALESCE(subtotal, 0) = 0 AND selling_price > 0 AND NOT EXISTS (SELECT 1 FROM quotation_items i WHERE i.quotation_id = quotations.id)`);
}

/**
 * Phase 21b: older invoices/payments have no currency. Give them their booking's currency where one is known so the
 * books can convert them. Only rows still NULL are touched, so it is safe on every startup. A payment is left NULL when
 * the account it went through holds a DIFFERENT currency than its invoice/booking (an old mixed-currency entry) - it keeps
 * being treated as the account's currency, exactly as before.
 */
function backfillDocumentCurrencies() {
  const cur = require('../../electron/services/documentCurrency');
  db.exec(`UPDATE invoices SET currency = (
             SELECT COALESCE(NULLIF(bk.currency, ''), NULLIF(pk.currency, '')) FROM bookings bk LEFT JOIN packages pk ON pk.id = bk.package_id
             WHERE bk.id = invoices.booking_id)
           WHERE currency IS NULL AND booking_id IS NOT NULL`);
  const rows = db.prepare('SELECT id, invoice_id, booking_id, account_type, account_id FROM payments WHERE currency IS NULL').all();
  const upd = db.prepare('UPDATE payments SET currency = ? WHERE id = ?');
  for (const p of rows) {
    const inv = p.invoice_id ? db.prepare('SELECT currency, booking_id FROM invoices WHERE id = ?').get(p.invoice_id) : null;
    const docCur = (inv && inv.currency) || cur.bookingCurrency(db, p.booking_id || (inv && inv.booking_id));
    if (!docCur) continue;
    const accCur = cur.accountCurrency(db, p.account_type, p.account_id);
    if (accCur && accCur !== docCur) continue;
    upd.run(docCur, p.id);
  }
}

/**
 * Indexes on columns that only exist once addMissingColumns() has run (they
 * can't be declared in schema.sql, which executes before it). supplier360
 * Service's SERVICE_ROWS union filters each of these five booking-service
 * tables by supplier_id on every Supplier 360 dossier / Supplier Report view,
 * so they're worth indexing. CREATE INDEX IF NOT EXISTS - safe to run on every
 * startup against a database from any earlier phase.
 */
function ensurePostMigrationIndexes() {
  const statements = [
    'CREATE INDEX IF NOT EXISTS idx_flights_supplier ON flights(supplier_id)',
    'CREATE INDEX IF NOT EXISTS idx_hotels_supplier ON hotels(supplier_id)',
    'CREATE INDEX IF NOT EXISTS idx_visa_supplier ON visa_applications(supplier_id)',
    'CREATE INDEX IF NOT EXISTS idx_transportation_supplier ON transportation(supplier_id)',
    'CREATE INDEX IF NOT EXISTS idx_other_services_supplier ON other_services(supplier_id)'
  ];
  for (const sql of statements) db.exec(sql);
}

/**
 * One-time (idempotent) backfill: Umrah/Hajj packages created before the
 * central Package Management module existed live only in the legacy
 * umrah_packages/hajj_packages tables. This copies each one into the
 * central `packages` (+ package_components) table, tagged with
 * legacy_mirror_table/legacy_mirror_id, so it appears in the unified
 * Packages page and can be selected when creating a Booking - without
 * touching the legacy row itself, so the existing Groups/Pilgrims features
 * (which still store group.package_id against the legacy tables) keep
 * working untouched. Safe to run on every startup: a legacy row that
 * already has a mirror is skipped.
 */
function migrateLegacyPackages() {
  const alreadyMirrored = (table, id) =>
    db.prepare('SELECT 1 FROM packages WHERE legacy_mirror_table = ? AND legacy_mirror_id = ?').get(table, id);

  const insertPackage = db.prepare(
    `INSERT INTO packages (
      package_name, package_type, destination, departure_date, return_date, number_of_days,
      description, supplier_cost, selling_price, currency, status, legacy_mirror_table, legacy_mirror_id
    ) VALUES (@package_name, @package_type, @destination, @departure_date, @return_date, @number_of_days,
      @description, @supplier_cost, @selling_price, 'PKR', 'Active', @legacy_mirror_table, @legacy_mirror_id)`
  );
  const insertComponent = db.prepare(
    `INSERT INTO package_components (package_id, component_type, description, cost, selling_price)
     VALUES (?, ?, ?, 0, 0)`
  );

  for (const p of db.prepare('SELECT * FROM umrah_packages').all()) {
    if (alreadyMirrored('umrah_packages', p.id)) continue;
    const packageId = insertPackage.run({
      package_name: p.package_name,
      package_type: 'Umrah',
      destination: null,
      departure_date: p.departure_date,
      return_date: p.return_date,
      number_of_days: p.number_of_days || null,
      description: p.description,
      supplier_cost: p.package_cost || 0,
      selling_price: p.selling_price || 0,
      legacy_mirror_table: 'umrah_packages',
      legacy_mirror_id: p.id
    }).lastInsertRowid;

    if (p.flight_included) insertComponent.run(packageId, 'Flight', null);
    if (p.visa_included) insertComponent.run(packageId, 'Visa', null);
    if (p.hotel_included) {
      if (p.makkah_hotel) insertComponent.run(packageId, 'Makkah Hotel', p.makkah_hotel);
      if (p.madinah_hotel) insertComponent.run(packageId, 'Madinah Hotel', p.madinah_hotel);
      if (!p.makkah_hotel && !p.madinah_hotel) insertComponent.run(packageId, 'Other Hotels', null);
    }
    if (p.transport_included) insertComponent.run(packageId, 'Intercity Transport', p.transport_details);
    if (p.food_included) insertComponent.run(packageId, 'Food', null);
    if (p.ziyarat_included) insertComponent.run(packageId, 'Ziyarat', null);
  }

  for (const p of db.prepare('SELECT * FROM hajj_packages').all()) {
    if (alreadyMirrored('hajj_packages', p.id)) continue;
    const packageId = insertPackage.run({
      package_name: p.package_name,
      package_type: 'Hajj',
      destination: null,
      departure_date: p.departure_date,
      return_date: p.return_date,
      number_of_days: null,
      description: p.description,
      supplier_cost: p.package_cost || 0,
      selling_price: p.selling_price || 0,
      legacy_mirror_table: 'hajj_packages',
      legacy_mirror_id: p.id
    }).lastInsertRowid;

    if (p.makkah_hotel) insertComponent.run(packageId, 'Hotel', p.makkah_hotel);
    if (p.madinah_hotel) insertComponent.run(packageId, 'Hotel', p.madinah_hotel);
  }
}

function seedDefaults() {
  const roleCount = db.prepare('SELECT COUNT(*) AS c FROM roles').get().c;
  if (roleCount === 0) {
    const insertRole = db.prepare('INSERT INTO roles (name, description) VALUES (?, ?)');
    insertRole.run('Admin', 'Full access to all modules');
    insertRole.run('Manager', 'Operational access, limited settings');
    insertRole.run('Staff', 'Day to day data entry access');
  }

  const categoryCount = db.prepare('SELECT COUNT(*) AS c FROM expense_categories').get().c;
  if (categoryCount === 0) {
    const insertCat = db.prepare('INSERT INTO expense_categories (name) VALUES (?)');
    ['Flight', 'Hotel', 'Visa', 'Transport', 'Food', 'Staff', 'Office', 'Marketing', 'Other']
      .forEach((name) => insertCat.run(name));
  }

  const settingsCount = db.prepare('SELECT COUNT(*) AS c FROM settings').get().c;
  if (settingsCount === 0) {
    const insertSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
    insertSetting.run('agency_name', 'Your Travel Agency');
    insertSetting.run('default_currency', 'PKR');
    insertSetting.run('invoice_prefix', 'INV-');
    insertSetting.run('invoice_next_number', '1001');
  }
}

function getDb() {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

/**
 * Releases the SQLite file handle - needed before overwriting agency.db
 * during a restore (Windows keeps an exclusive lock on open files).
 * initDatabase() must be called again afterward to reopen it.
 */
function closeDatabase() {
  if (db) {
    db.close();
    db = null;
  }
}

module.exports = { initDatabase, getDb, closeDatabase, backfillDocumentCurrencies };
