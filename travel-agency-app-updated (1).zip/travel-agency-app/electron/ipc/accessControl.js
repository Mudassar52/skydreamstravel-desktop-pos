/**
 * Server-side permission enforcement for every IPC channel (Phase 21).
 *
 * Each channel name ("payments:void", "customers:list", ...) is mapped to
 *   - a permission MODULE (the same keys the Staff & Users matrix edits),
 *   - an ACTION (view / create / edit / delete) taken from the verb at the end of the channel name,
 *   - and, for exports and profit figures, a global CAPABILITY (export_reports / view_profit).
 * The guard in handlers.js runs this before the handler does anything.
 *
 * Rules that deliberately mirror how the screens already behaved, so nothing that worked before breaks:
 *   - "Workflow" verbs available to anyone who can add records in a module (mark done, add a note, convert a lead,
 *     apply an advance, duplicate/create-from-booking) need CREATE. Cancel / reverse / rename / set-default / restore
 *     need EDIT. Delete / remove / void need DELETE.
 *   - Adding a passenger to a group needs CREATE; taking one off needs EDIT.
 *   - Lists of bank/cash accounts, agents and users that feed a dropdown on another screen are readable by anyone
 *     who can create the records that dropdown belongs to.
 *   - Settings are readable by every signed-in user (the app needs currency/branding everywhere); changing them needs
 *     Settings EDIT. Saved filters and notifications are personal and open to every signed-in user.
 *
 * What a permitted call may SEE (profit/cost figures inside dossiers, search results) is filtered on the way out by
 * redaction.js. The dedicated profit:* channels and every export are enforced here.
 */
const { PERMISSION_MODULES } = require('../services/permissionModules');

const LABELS = Object.fromEntries(PERMISSION_MODULES.map((m) => [m.key, m.label]));

const PUBLIC = new Set(['auth:login', 'auth:logout']);

// prefix -> module key (or a special marker). Longest prefix wins.
const PREFIX_MODULE = {
  'dashboard:': 'dashboard',
  'calendar:': 'travel_calendar',
  'customer360:': 'customers',
  'supplier360:': 'suppliers',
  'package360:': 'packages',
  'bookingDossier:': 'bookings',
  'vouchers:': 'bookings',
  'customers:': 'customers',
  'umrah:': 'umrah',
  'hajj:': 'hajj',
  'tours:': 'tours',
  'bookings:': 'bookings',
  'bookings:upcomingTravel': 'upcoming_travel',
  'flights:': 'flights',
  'hotels:': 'hotels',
  'visa:': 'visa',
  'transportation:': 'transportation',
  'invoiceTemplates:': 'invoice_templates',
  'invoices:': 'invoices',
  'payments:': 'payments',
  'advances:': 'payments',
  'refunds:': 'refunds',
  'ledger:': 'ledger',
  'expenses:': 'expenses',
  'documents:': 'documents',
  'reports:': 'reports',
  'customReports:': 'reports',
  'reportHistory:': 'reports',
  'reportTemplates:': 'reports',
  'auditLogs:': 'audit_logs',
  'suppliers:': 'suppliers',
  'supplierLedger:': 'supplier_ledger',
  'supplierAdvances:': 'supplier_payments',
  'supplierInvoices:': 'supplier_invoices',
  'supplierPayments:': 'supplier_payments',
  'supplierReports:': 'supplier_reports',
  'accounting:': 'accounting',
  'leads:': 'leads',
  'travellers:': 'travellers',
  'followups:': 'followups',
  'quotations:': 'quotations',
  'packages:': 'packages',
  'otherServices:': 'other_services',
  'tasks:': 'tasks',
  'deadlines:': 'deadlines',
  'users:': 'staff',
  'roles:': 'staff',
  'permissions:': 'staff',
  'capabilities:': 'staff',
  'backup:': 'backup',
  'exchangeRates:': 'exchange_rates',
  'agents:': 'agents',
  'commissions:': 'commissions',
  'financialStatements:': 'financial_statements',
  'periodLock:': 'financial_statements'
};

// Open to every signed-in user (personal or app-wide, non-sensitive).
const AUTH_ONLY_PREFIXES = ['search:', 'savedFilters:', 'notifications:', 'reportExport:'];
const AUTH_ONLY_CHANNELS = new Set(['settings:getAll']);

const CAPABILITY_PREFIXES = {
  'ledger:': 'export_reports', 'supplierLedger:': 'export_reports', 'supplierReports:': 'export_reports', 'reports:': 'export_reports',
  'customReports:': 'export_reports', 'financialStatements:': 'export_reports'
};
const EXPORT_VERBS = new Set(['exportPdf', 'exportCsv', 'exportExcel', 'print']);

const DELETE_VERBS = new Set(['delete', 'remove', 'void']);
const CREATE_VERBS = new Set(['create', 'add', 'upload', 'generate', 'duplicate', 'createFromBooking', 'createForBooking', 'convertToCustomer', 'convertToBooking', 'applyToInvoice', 'addNote', 'markStatus', 'record', 'deposit', 'withdraw', 'transfer']);
const EDIT_VERBS = new Set(['save', 'update', 'cancel', 'rename', 'setDefault', 'reverseApplication', 'reverse', 'revise', 'reversePayment', 'resetPassword', 'setMany', 'uploadImage', 'removeImage', 'setAutoEnabled', 'restore', 'relaunch', 'chooseFolder', 'create_backup', 'approve', 'pay', 'setManualLock', 'closeYear', 'reopenLastClose']);

// Dropdown feeders: channel -> [ [module, action], ... ] ANY of which is enough.
const LENIENT_LOOKUPS = {
  'bankAccounts:list': [['bank_accounts', 'view'], ['payments', 'create'], ['expenses', 'create'], ['refunds', 'create'], ['supplier_payments', 'create'], ['commissions', 'edit']],
  'cashAccounts:list': [['cash_accounts', 'view'], ['payments', 'create'], ['expenses', 'create'], ['refunds', 'create'], ['supplier_payments', 'create'], ['commissions', 'edit']],
  'agents:options': [['agents', 'view'], ['bookings', 'create'], ['bookings', 'edit'], ['commissions', 'create'], ['leads', 'create'], ['leads', 'edit']],
  'exchangeRates:getRate': [['exchange_rates', 'view'], ['bookings', 'view'], ['payments', 'view']]
};

function longestPrefixModule(channel) {
  let best = null;
  for (const p of Object.keys(PREFIX_MODULE)) {
    if (channel.startsWith(p) && (!best || p.length > best.length)) best = p;
  }
  return best ? PREFIX_MODULE[best] : null;
}

function actionFor(channel) {
  const verb = channel.slice(channel.lastIndexOf(':') + 1);
  const isMembership = /:(passengers|pilgrims|travellers):/.test(channel) || channel.startsWith('travellers:bookings:');
  if (isMembership) return verb === 'remove' ? 'edit' : verb.startsWith('add') ? 'create' : 'view';
  // Report history/templates: Managers (create+edit, no delete) manage their own saved reports today.
  if (channel.startsWith('reportHistory:') || channel.startsWith('reportTemplates:')) {
    if (verb === 'remove') return 'edit';
    if (verb === 'create' || verb === 'record') return 'create';
    return 'view';
  }
  if (channel.startsWith('commissions:')) {
    if (verb === 'create') return 'create';
    if (verb === 'update' || verb === 'approve' || verb === 'pay' || verb === 'reversePayment' || verb === 'cancel') return 'edit';
    return 'view';
  }
  if (DELETE_VERBS.has(verb)) return 'delete';
  if (CREATE_VERBS.has(verb)) return 'create';
  if (EDIT_VERBS.has(verb)) return 'edit';
  return 'view';
}

/** Which module(s) an accounts:* call touches - it depends on the Bank/Cash type passed in. */
function accountModules(channel, args) {
  const mod = (t) => (t === 'Bank' ? 'bank_accounts' : t === 'Cash' ? 'cash_accounts' : null);
  const verb = channel.slice(channel.lastIndexOf(':') + 1);
  const a0 = args[0];
  let types = [];
  if (verb === 'get' || verb === 'update' || verb === 'delete' || verb === 'create') types = [a0];
  else if (verb === 'deposit' || verb === 'withdraw') types = [a0 && a0.account_type];
  else if (verb === 'transfer') types = [a0 && a0.from_type, a0 && a0.to_type];
  const mods = types.map(mod);
  if (!mods.length || mods.some((m) => !m)) return null; // malformed -> deny
  return [...new Set(mods)];
}

/**
 * Describes what a channel requires. Returns:
 *   { public: true } | { authOnly: true } | { any: [[module, action], ...] } | { all: [[module, action], ...], capability? } | null (unmapped)
 */
function requirementFor(channel, args = []) {
  if (PUBLIC.has(channel)) return { public: true };
  if (AUTH_ONLY_CHANNELS.has(channel)) return { authOnly: true };
  if (LENIENT_LOOKUPS[channel]) return { any: LENIENT_LOOKUPS[channel] };
  if (channel.startsWith('accounts:')) {
    const mods = accountModules(channel, args);
    if (!mods) return { deny: 'That request was not understood.' };
    const action = actionFor(channel);
    // Adding an account is a create; moving money in/out/between accounts is an edit of those accounts.
    const verb = channel.slice(channel.lastIndexOf(':') + 1);
    const needed = verb === 'deposit' || verb === 'withdraw' || verb === 'transfer' ? 'edit' : action;
    return { all: mods.map((m) => [m, needed]) };
  }
  if (channel.startsWith('bankAccounts:') || channel.startsWith('cashAccounts:')) return null; // only the lenient list above exists
  if (AUTH_ONLY_PREFIXES.some((p) => channel.startsWith(p))) {
    if (channel.startsWith('reportExport:')) return { authOnly: true, capability: 'export_reports' };
    return { authOnly: true };
  }
  if (channel.startsWith('profit:')) return { all: [['expenses', 'view']], capability: 'view_profit' };
  if (channel.startsWith('settings:')) return { all: [['settings', 'edit']] };
  if (channel.startsWith('backup:')) {
    const verb = channel.slice(channel.lastIndexOf(':') + 1);
    return { all: [['backup', verb === 'getInfo' || verb === 'getConfig' ? 'view' : 'edit']] };
  }
  const module = longestPrefixModule(channel);
  if (!module) return null;
  const req = { all: [[module, actionFor(channel)]] };
  const verb = channel.slice(channel.lastIndexOf(':') + 1);
  const capPrefix = Object.keys(CAPABILITY_PREFIXES).find((p) => channel.startsWith(p));
  if (capPrefix && EXPORT_VERBS.has(verb)) req.capability = CAPABILITY_PREFIXES[capPrefix];
  return req;
}

const ACTION_WORDS = { view: 'view', create: 'add to', edit: 'change', delete: 'delete from' };

/**
 * Returns null when allowed, otherwise the message to send back to the screen.
 * `user` is what sessionService.current() returns (or null).
 */
function authorize(channel, args, user) {
  const req = requirementFor(channel, args);
  if (req === null) return `Access to "${channel}" is not configured.`; // fail closed: an unmapped channel is never open
  if (req.public) return null;
  if (!user) return 'Your session has ended. Please sign in again.';
  if (req.deny) return req.deny;
  const can = (m, a) => !!(user.permissions && user.permissions[m] && user.permissions[m][a]);
  if (req.any && !req.any.some(([m, a]) => can(m, a))) return 'You do not have permission to use this.';
  if (req.all) {
    for (const [m, a] of req.all) {
      if (!can(m, a)) return `You do not have permission to ${ACTION_WORDS[a]} ${LABELS[m] || m}.`;
    }
  }
  if (req.capability && !(user.capabilities && user.capabilities[req.capability])) {
    return req.capability === 'export_reports' ? 'Your role is not allowed to export reports.' : 'Your role is not allowed to see profit figures.';
  }
  return null;
}

module.exports = { requirementFor, authorize, actionFor, PUBLIC };
