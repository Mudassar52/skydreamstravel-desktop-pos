const { getDb } = require('../../src/database/db');

const STAGES = ['New', 'Contacted', 'Qualified', 'Quotation Sent', 'Negotiation', 'Converted', 'Lost'];
const PRIORITIES = ['Low', 'Medium', 'High'];

const LEAD_FIELDS = [
  'full_name', 'phone', 'email', 'source', 'destination', 'travel_date',
  'service_type', 'assigned_agent_id', 'agent_id', 'estimated_value', 'status', 'priority', 'notes', 'details'
];

const SERVICE_TYPES = ['Umrah', 'Hajj', 'Visa', 'Tour', 'Flight', 'Hotel', 'Transportation'];

/** The customer's nationality = the first passport country on the enquiry (or the older single passport_country). */
function nationalityFromDetails(d) {
  const first = (d.passports || []).find((p) => p && p.country && p.country.trim());
  return (first ? first.country.trim() : (d.passport_country || '').trim()) || null;
}

/** `details` arrives from the UI as an object; it is stored as JSON text. */
function serializeDetails(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'string') return value;
  return JSON.stringify(value);
}

function parseDetails(value) {
  if (!value) return {};
  try { const parsed = JSON.parse(value); return parsed && typeof parsed === 'object' ? parsed : {}; } catch { return {}; }
}

function validate(payload) {
  if (!payload.full_name || !payload.full_name.trim()) throw new Error('Lead name is required.');
  if (payload.status && !STAGES.includes(payload.status)) throw new Error('Invalid lead status.');
  if (payload.priority && !PRIORITIES.includes(payload.priority)) throw new Error('Invalid lead priority.');
}

function validatePartial(payload) {
  if (payload.full_name !== undefined && !payload.full_name.trim()) throw new Error('Lead name is required.');
  if (payload.status && !STAGES.includes(payload.status)) throw new Error('Invalid lead status.');
  if (payload.priority && !PRIORITIES.includes(payload.priority)) throw new Error('Invalid lead priority.');
}

function nextLeadCode(db) {
  const last = db.prepare('SELECT lead_code FROM leads ORDER BY id DESC LIMIT 1').get();
  let nextNum = 1;
  if (last?.lead_code) {
    const match = last.lead_code.match(/(\d+)$/);
    if (match) nextNum = Number(match[1]) + 1;
  }
  return `LD-${String(nextNum).padStart(6, '0')}`;
}

function logActivity(db, leadId, activityType, description, createdBy = null) {
  db.prepare(
    `INSERT INTO lead_activities (lead_id, activity_type, description, created_by) VALUES (?, ?, ?, ?)`
  ).run(leadId, activityType, description, createdBy || null);
}

function list({ search = '', status = 'All', priority = 'All', assignedAgentId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(l.full_name LIKE @q OR l.phone LIKE @q OR l.email LIKE @q OR l.destination LIKE @q OR l.lead_code LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') { conditions.push('l.status = @status'); params.status = status; }
  if (priority && priority !== 'All') { conditions.push('l.priority = @priority'); params.priority = priority; }
  if (assignedAgentId) { conditions.push('l.assigned_agent_id = @assignedAgentId'); params.assignedAgentId = assignedAgentId; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM leads l ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT l.*, COALESCE(ag.name, u.full_name) AS agent_name
       FROM leads l LEFT JOIN users u ON u.id = l.assigned_agent_id
       LEFT JOIN agents ag ON ag.id = l.agent_id
       ${where} ORDER BY l.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows: rows.map((r) => ({ ...r, details: parseDetails(r.details) })), total, page, pageSize };
}

/** Every stage with its lead count and total estimated value - the pipeline view. */
function pipeline() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT status, COUNT(*) AS count, COALESCE(SUM(estimated_value),0) AS total_value
       FROM leads GROUP BY status`
    )
    .all();
  return STAGES.map((stage) => {
    const found = rows.find((r) => r.status === stage);
    return { stage, count: found ? found.count : 0, totalValue: found ? found.total_value : 0 };
  });
}

function get(id) {
  const db = getDb();
  const lead = db
    .prepare(`SELECT l.*, COALESCE(ag.name, u.full_name) AS agent_name FROM leads l LEFT JOIN users u ON u.id = l.assigned_agent_id LEFT JOIN agents ag ON ag.id = l.agent_id WHERE l.id = ?`)
    .get(id);
  if (!lead) throw new Error('Lead not found.');
  const activities = db.prepare('SELECT * FROM lead_activities WHERE lead_id = ? ORDER BY id DESC').all(id);
  return { ...lead, details: parseDetails(lead.details), activities };
}

function create(payload) {
  validate(payload);
  const db = getDb();

  const tx = db.transaction(() => {
    const code = nextLeadCode(db);
    const params = { lead_code: code };
    for (const f of LEAD_FIELDS) params[f] = payload[f] ?? null;
    if (!params.status) params.status = 'New';
    if (!params.priority) params.priority = 'Medium';
    params.estimated_value = Number(payload.estimated_value || 0);
    params.agent_id = payload.agent_id ? Number(payload.agent_id) : null;
    params.details = serializeDetails(payload.details);

    const cols = ['lead_code', ...LEAD_FIELDS];
    const result = db.prepare(`INSERT INTO leads (${cols.join(', ')}) VALUES (${cols.map((c) => `@${c}`).join(', ')})`).run(params);
    const leadId = result.lastInsertRowid;

    logActivity(db, leadId, 'Note', `Lead "${payload.full_name}" (${code}) created`);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Lead Created', 'lead', ?, ?)`
    ).run(leadId, `Lead "${payload.full_name}" (${code}) created`);

    return leadId;
  });

  return { id: tx() };
}

function update(id, payload) {
  validatePartial(payload);
  const db = getDb();
  const existing = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
  if (!existing) throw new Error('Lead not found.');

  const tx = db.transaction(() => {
    const params = { id };
    const sets = [];
    for (const f of LEAD_FIELDS) {
      if (payload[f] !== undefined) {
        sets.push(`${f} = @${f}`);
        params[f] = f === 'estimated_value' ? Number(payload[f] || 0) : f === 'agent_id' ? (payload[f] ? Number(payload[f]) : null) : f === 'details' ? serializeDetails(payload[f]) : payload[f];
      }
    }
    sets.push("updated_at = datetime('now')");
    db.prepare(`UPDATE leads SET ${sets.join(', ')} WHERE id = @id`).run(params);

    if (payload.status && payload.status !== existing.status) {
      logActivity(db, id, 'StatusChange', `Status changed from "${existing.status}" to "${payload.status}"`);
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Lead Updated', 'lead', ?, ?)`
    ).run(id, `Lead #${id} updated`);
  });
  tx();

  return { success: true };
}

function addNote(id, note, createdBy = null) {
  const db = getDb();
  const lead = db.prepare('SELECT id FROM leads WHERE id = ?').get(id);
  if (!lead) throw new Error('Lead not found.');
  logActivity(db, id, 'Note', note, createdBy);
  return { success: true };
}

/**
 * Converts a lead into a customer record, reusing its contact details
 * (Section 57: no duplicate data entry). If the lead is already linked to
 * a customer, returns that customer instead of creating a duplicate.
 */
function convertToCustomer(id) {
  const db = getDb();
  const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
  if (!lead) throw new Error('Lead not found.');
  if (lead.converted_customer_id) return { customerId: lead.converted_customer_id, alreadyConverted: true };

  const tx = db.transaction(() => {
    const result = db
      .prepare(`INSERT INTO customers (full_name, phone, email, customer_source, nationality, notes) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(lead.full_name, lead.phone, lead.email, lead.source, nationalityFromDetails(parseDetails(lead.details)), `Converted from lead ${lead.lead_code}`);
    const customerId = result.lastInsertRowid;

    db.prepare(`UPDATE leads SET status = 'Converted', converted_customer_id = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(customerId, id);

    logActivity(db, id, 'Conversion', `Converted to customer #${customerId}`);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Lead Converted', 'lead', ?, ?)`
    ).run(id, `Lead ${lead.lead_code} converted to customer #${customerId}`);

    return customerId;
  });

  return { customerId: tx(), alreadyConverted: false };
}

function remove(id) {
  const db = getDb();
  const lead = db.prepare('SELECT lead_code, full_name FROM leads WHERE id = ?').get(id);
  if (!lead) throw new Error('Lead not found.');
  db.prepare('DELETE FROM leads WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'lead', ?, ?)`
  ).run(id, `Lead "${lead.full_name}" (${lead.lead_code}) deleted`);
  return { success: true };
}

module.exports = { STAGES, PRIORITIES, SERVICE_TYPES, list, pipeline, get, create, update, addNote, convertToCustomer, remove };
