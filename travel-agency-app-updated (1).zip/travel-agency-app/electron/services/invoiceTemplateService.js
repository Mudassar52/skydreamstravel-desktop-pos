const { getDb } = require('../../src/database/db');
const { AVAILABLE_TOKENS } = require('./templateEngine');

// A plain, professional starting design. This is deliberately just the
// seeded default, not "the" invoice theme - anyone can add more templates
// from the Invoice Templates screen and set a different one as default
// without touching any other part of the app.
const DEFAULT_HTML = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4; margin: 16mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #16233F; font-size: 12px; margin: 0; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1E4FA3; padding-bottom: 14px; margin-bottom: 20px; }
  .agency-name { font-size: 19px; font-weight: 700; color: #1E4FA3; margin-bottom: 4px; }
  .muted { color: #5B6B8C; }
  .invoice-title { text-align: right; }
  .invoice-title h1 { font-size: 22px; margin: 0 0 6px; color: #1E4FA3; letter-spacing: 0.04em; }
  .section-title { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.05em; color: #8B97B3; margin: 18px 0 6px; font-weight: 700; }
  table { width: 100%; border-collapse: collapse; margin-top: 6px; }
  th, td { padding: 8px 10px; border-bottom: 1px solid #E4E9F2; text-align: left; }
  th { background: #EAF1FC; color: #1E4FA3; text-transform: uppercase; font-size: 10px; letter-spacing: 0.03em; }
  td.num, th.num { text-align: right; }
  .totals { width: 260px; margin-left: auto; margin-top: 14px; }
  .totals .row { display: flex; justify-content: space-between; padding: 4px 0; }
  .totals .grand { font-weight: 700; font-size: 14px; border-top: 2px solid #1E4FA3; padding-top: 8px; margin-top: 4px; }
  .footer { margin-top: 36px; font-size: 10.5px; color: #8B97B3; border-top: 1px solid #E4E9F2; padding-top: 10px; }
</style>
</head>
<body>
  <div class="header">
    <div>
      <div class="agency-name">{{agency_name}}</div>
      <div class="muted">{{agency_address}}</div>
      <div class="muted">{{agency_phone}} &middot; {{agency_email}}</div>
    </div>
    <div class="invoice-title">
      {{{logo_html}}}
      <h1>INVOICE</h1>
      <div>{{invoice_number}}</div>
      <div class="muted">Date: {{invoice_date}}</div>
      <div class="muted">Due: {{due_date}}</div>
    </div>
  </div>

  <div class="section-title">Bill To</div>
  <div>{{customer_name}}</div>
  <div class="muted">{{customer_phone}}</div>
  <div class="muted">{{customer_email}}</div>
  <div class="muted">{{customer_address}}</div>

  <div class="section-title">Booking Reference</div>
  <div class="muted">{{booking_reference}}</div>

  <table>
    <thead>
      <tr><th>Description</th><th class="num">Qty</th><th class="num">Unit Price</th><th class="num">Line Total</th></tr>
    </thead>
    <tbody>
      {{{line_items_html}}}
    </tbody>
  </table>

  <div class="totals">
    <div class="row"><span>Subtotal</span><span>{{subtotal}}</span></div>
    <div class="row"><span>Discount</span><span>{{discount}}</span></div>
    <div class="row"><span>Tax</span><span>{{tax}}</span></div>
    <div class="row grand"><span>Total</span><span>{{total}}</span></div>
    <div class="row"><span>Paid</span><span>{{paid_amount}}</span></div>
    <div class="row"><span>Balance Due</span><span>{{remaining_amount}}</span></div>
  </div>

  <div class="section-title">Notes</div>
  <div class="muted">{{notes}}</div>

  <div class="section-title">Terms &amp; Conditions</div>
  <div class="muted">{{terms}}</div>

  <div class="section-title">Bank Details</div>
  <div class="muted">{{bank_details}}</div>

  <div style="display:flex; justify-content:flex-end; gap:24px; margin-top:24px; align-items:flex-end;">
    {{{signature_html}}}
    {{{stamp_html}}}
  </div>

  <div class="footer">{{agency_name}} &middot; {{agency_website}}</div>
</body>
</html>`;

const RMT_HTML = `<!doctype html>
<!-- rmt-v2 -->
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body { font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; color: #3d3d3d; font-size: 12.5px; line-height: 1.55; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .rmt-invoice { position: relative; border-top: 7px solid #2b2b2b; padding: 11mm 13mm 14mm; }
  .head { display: grid; grid-template-columns: 62mm 1fr 44mm; column-gap: 8mm; align-items: start; padding-bottom: 7mm; border-bottom: 1px solid #c3d0dc; }
  .logo-cell { padding-top: 14mm; }
  .agency-name { font-size: 19px; font-weight: 700; line-height: 1.3; text-transform: uppercase; color: #3d3d3d; margin-bottom: 8px; }
  .agency-line { font-size: 12.5px; margin-bottom: 4px; word-break: break-word; }
  .agency-line a { color: #3b82f6; text-decoration: underline; }
  .meta { text-align: right; }
  .meta .k { font-size: 10.5px; font-weight: 700; letter-spacing: .02em; text-transform: uppercase; margin-top: 12px; }
  .meta .k:first-child { margin-top: 0; }
  .meta .v { font-size: 13px; color: #555; margin-top: 2px; }
  .bill { padding: 6mm 0 5mm; }
  .bill .k { font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .02em; margin-bottom: 7px; }
  .bill .name { font-size: 18px; font-weight: 600; margin-bottom: 7px; }
  .bill .line { font-size: 12.5px; margin-bottom: 3px; }
  table.items { width: 100%; border-collapse: collapse; margin-top: 3mm; }
  table.items thead { display: table-header-group; }
  table.items th { font-size: 10.5px; text-transform: uppercase; letter-spacing: .02em; font-weight: 700; padding: 9px 0; border-top: 2px solid #1f1f1f; border-bottom: 2px solid #1f1f1f; text-align: left; }
  table.items th.num, table.items td.num { text-align: right; white-space: nowrap; vertical-align: top; }
  table.items th.num { padding-left: 14px; }
  table.items td { padding: 12px 0 8px; vertical-align: top; }
  table.items td.num { padding-left: 14px; }
  table.items td.desc { width: 62%; padding-right: 10px; }
  table.items tr.item { page-break-inside: auto; }
  table.items tbody { border-bottom: 1px solid #b9b9b9; }
  .item-title { font-weight: 700; font-size: 13px; color: #1f1f1f; padding-left: 8px; border-left: 3px solid #b01c2e; margin-bottom: 4px; }
  .item-body { white-space: pre-wrap; padding-left: 11px; }
  .item-body b { font-weight: 600; color: #222; }
  table.items tr.item.text td { border-top: 1px solid #ececec; }
  table.items tr.item:first-child td { border-top: none; }
  .totals { width: 52%; margin-left: auto; margin-top: 4mm; page-break-inside: avoid; }
  .tot-row { display: flex; justify-content: space-between; padding: 9px 0; font-size: 12.5px; }
  .tot-row.total span:first-child { font-size: 10.5px; font-weight: 700; letter-spacing: .02em; }
  .pay-row { display: flex; justify-content: space-between; padding: 8px 12px 8px 12px; }
  .pay-label { font-size: 11.5px; }
  .pay-sub { font-size: 12.5px; color: #8a8a8a; }
  .pay-amt { font-size: 12.5px; }
  .right { text-align: right; }
  .balance { border-top: 1px solid #b9b9b9; border-bottom: 1px solid #b9b9b9; margin-top: 6px; padding: 10px 0 12px; text-align: right; }
  .balance-label { font-size: 10.5px; font-weight: 700; letter-spacing: .02em; }
  .balance-amt { font-size: 17px; font-weight: 600; margin-top: 6px; }
  .extra { margin-top: 9mm; page-break-inside: avoid; }
  .extra .k { font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .02em; margin-bottom: 4px; color: #3d3d3d; }
  .extra .t { font-size: 12px; color: #555; }
  .sign { display: flex; justify-content: flex-end; gap: 24px; align-items: flex-end; margin-top: 8mm; }
  .cancelled-mark { position: absolute; top: 95mm; left: 0; right: 0; text-align: center; font-size: 84px; font-weight: 800; color: rgba(200, 30, 30, .13); transform: rotate(-24deg); letter-spacing: 8px; pointer-events: none; }
</style>
</head>
<body>
<div class="rmt-invoice">
  {{{cancelled_html}}}
  <div class="head">
    <div class="logo-cell">{{{logo_html}}}</div>
    <div>
      <div class="agency-name">{{agency_name}}</div>
      <div class="agency-line">Company Number: {{company_number}}</div>
      <div class="agency-line">{{{agency_address_html}}}</div>
      <div class="agency-line">{{agency_phone}}</div>
      <div class="agency-line"><a>{{agency_website}}</a></div>
      <div class="agency-line">{{agency_email}}</div>
    </div>
    <div class="meta">
      <div class="k">Invoice</div><div class="v">{{invoice_number}}</div>
      <div class="k">Date</div><div class="v">{{invoice_date_pretty}}</div>
      <div class="k">Due</div><div class="v">{{due_text}}</div>
      {{{booking_meta_html}}}
      {{{agent_meta_html}}}
      <div class="k">Balance Due</div><div class="v">{{currency}} {{remaining_amount}}</div>
    </div>
  </div>

  <div class="bill">
    <div class="k">Bill To</div>
    <div class="name">{{customer_name}}</div>
    <div class="line">{{customer_phone}}</div>
    <div class="line">{{customer_email}}</div>
    <div class="line">{{customer_address}}</div>
  </div>

  <table class="items">
    <thead><tr><th>Description</th><th class="num">Rate</th><th class="num">Qty</th><th class="num">Amount</th></tr></thead>
    <tbody>
      {{{invoice_items_html}}}
    </tbody>
  </table>

  <div class="totals">
    {{{totals_html}}}
  </div>

  {{{notes_block_html}}}
  {{{terms_block_html}}}
  {{{bank_block_html}}}

  <div class="sign">{{{signature_html}}}{{{stamp_html}}}</div>
</div>
</body>
</html>`;

function ensureDefaultTemplate() {
  const db = getDb();
  const count = db.prepare('SELECT COUNT(*) AS c FROM invoice_templates').get().c;
  if (count === 0) {
    db.prepare(
      `INSERT INTO invoice_templates (template_name, is_default, status, config_json) VALUES (?, 1, 'Active', ?)`
    ).run('Default Template', JSON.stringify({ html: RMT_HTML }));
  }
}

/**
 * One-time upgrade for databases created before the Royal-Manchester-style invoice: adds that design as a template
 * and makes it the default (only if the current default is still the untouched built-in one). Existing invoices
 * keep the template they were created with, so nothing already issued changes. Runs once (flag in settings).
 */
function installRmtTemplate() {
  const db = getDb();
  const settingsService = require('./settingsService');
  // Our own RMT design is refreshed when a newer version ships (templates without the current marker only).
  const stale = db.prepare("SELECT id FROM invoice_templates WHERE config_json LIKE '%rmt-invoice%' AND config_json NOT LIKE '%rmt-v2%'").all();
  for (const row of stale) {
    db.prepare('UPDATE invoice_templates SET config_json = ? WHERE id = ?').run(JSON.stringify({ html: RMT_HTML }), row.id);
  }
  if (settingsService.get('rmt_template_installed', '') === '1') return;
  const hasIt = db.prepare("SELECT COUNT(*) AS c FROM invoice_templates WHERE config_json LIKE '%rmt-invoice%'").get().c > 0;
  if (!hasIt) {
    const result = db
      .prepare(`INSERT INTO invoice_templates (template_name, is_default, status, config_json) VALUES (?, 0, 'Active', ?)`)
      .run('Royal Manchester Style', JSON.stringify({ html: RMT_HTML }));
    const current = db.prepare('SELECT template_name FROM invoice_templates WHERE is_default = 1').get();
    if (!current || current.template_name === 'Default Template') setDefault(result.lastInsertRowid);
  }
  settingsService.set('rmt_template_installed', '1');
}

function list() {
  const db = getDb();
  return db.prepare('SELECT id, template_name, is_default, status, created_at FROM invoice_templates ORDER BY is_default DESC, created_at DESC').all();
}

function get(id) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM invoice_templates WHERE id = ?').get(id);
  if (!row) throw new Error('Template not found.');
  const config = JSON.parse(row.config_json);
  return { ...row, html: config.html };
}

function getDefault() {
  const db = getDb();
  const row = db.prepare('SELECT * FROM invoice_templates WHERE is_default = 1 LIMIT 1').get();
  if (!row) throw new Error('No default invoice template is set.');
  const config = JSON.parse(row.config_json);
  return { ...row, html: config.html };
}

function validate(payload) {
  if (!payload.template_name || !payload.template_name.trim()) throw new Error('Template name is required.');
  if (!payload.html || !payload.html.trim()) throw new Error('Template HTML cannot be empty.');
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const result = db
    .prepare(`INSERT INTO invoice_templates (template_name, is_default, status, config_json) VALUES (?, 0, ?, ?)`)
    .run(payload.template_name, payload.status || 'Active', JSON.stringify({ html: payload.html }));

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Template Created', 'invoice_template', ?, ?)`
  ).run(result.lastInsertRowid, `Template "${payload.template_name}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM invoice_templates WHERE id = ?').get(id);
  if (!existing) throw new Error('Template not found.');
  db.prepare(`UPDATE invoice_templates SET template_name = ?, status = ?, config_json = ? WHERE id = ?`)
    .run(payload.template_name, payload.status || 'Active', JSON.stringify({ html: payload.html }), id);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Template Updated', 'invoice_template', ?, ?)`
  ).run(id, `Template "${payload.template_name}" updated`);

  return { success: true };
}

function setDefault(id) {
  const db = getDb();
  const tx = db.transaction((templateId) => {
    db.prepare('UPDATE invoice_templates SET is_default = 0').run();
    db.prepare('UPDATE invoice_templates SET is_default = 1 WHERE id = ?').run(templateId);
  });
  tx(id);
  return { success: true };
}

function remove(id) {
  const db = getDb();
  const row = db.prepare('SELECT is_default FROM invoice_templates WHERE id = ?').get(id);
  if (!row) throw new Error('Template not found.');
  if (row.is_default) throw new Error('Cannot delete the default template. Set another template as default first.');
  const inUse = db.prepare('SELECT COUNT(*) AS c FROM invoices WHERE template_id = ?').get(id).c;
  if (inUse > 0) throw new Error('This template is used by existing invoices and cannot be deleted.');
  db.prepare('DELETE FROM invoice_templates WHERE id = ?').run(id);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'invoice_template', ?, ?)`
  ).run(id, `Invoice template #${id} deleted`);
  return { success: true };
}

module.exports = { ensureDefaultTemplate, installRmtTemplate, list, get, getDefault, create, update, setDefault, remove, AVAILABLE_TOKENS };
