// A template is just an HTML string with tokens. This engine's only job is
// substitution - it knows nothing about invoices, customers, or bookings.
// That separation is what lets new invoice designs be added later without
// touching the invoice/customer/payment/ledger code (per the project spec).

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Replaces {{token}} (HTML-escaped) and {{{token}}} (raw, for pre-rendered
 * HTML fragments like the line-items table body) with values from `data`.
 * Missing keys render as an empty string rather than throwing, so a
 * template built for a future field doesn't break on older data.
 */
function renderTemplate(html, data) {
  let out = html.replace(/\{\{\{\s*([\w.]+)\s*\}\}\}/g, (_, key) => {
    const v = data[key];
    return v !== undefined && v !== null ? String(v) : '';
  });
  out = out.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, key) => {
    const v = data[key];
    return v !== undefined && v !== null ? escapeHtml(String(v)) : '';
  });
  return out;
}

// Shown in the Invoice Templates editor so someone building a new design
// knows what's available to them.
const AVAILABLE_TOKENS = [
  { token: '{{agency_name}}', description: 'Agency name' },
  { token: '{{agency_address}}', description: 'Agency address' },
  { token: '{{agency_phone}}', description: 'Agency phone' },
  { token: '{{agency_whatsapp}}', description: 'Agency WhatsApp number' },
  { token: '{{agency_email}}', description: 'Agency email' },
  { token: '{{agency_website}}', description: 'Agency website' },
  { token: '{{company_number}}', description: 'Company registration number (Settings)' },
  { token: '{{{agency_address_html}}}', description: 'Agency address with line breaks kept — triple braces' },
  { token: '{{invoice_date_pretty}}', description: 'Invoice date as 10 Sept 2026' },
  { token: '{{due_text}}', description: 'Due text typed on the invoice (e.g. On Receipt) or the due date' },
  { token: '{{currency}}', description: 'Invoice currency code (GBP, PKR...)' },
  { token: '{{{invoice_items_html}}}', description: 'Pre-rendered rows: heading + description | Rate | Qty | Amount — triple braces' },
  { token: '{{{totals_html}}}', description: 'TOTAL, payments and BALANCE DUE block — triple braces' },
  { token: '{{{payments_html}}}', description: 'Only the payment lines — triple braces' },
  { token: '{{{notes_block_html}}}', description: 'Notes section with heading, only when notes exist — triple braces' },
  { token: '{{{terms_block_html}}}', description: 'Terms section with heading, only when terms exist — triple braces' },
  { token: '{{{bank_block_html}}}', description: 'Bank details section with heading, only when set — triple braces' },
  { token: '{{{notes_html}}}', description: 'Notes with line breaks kept — triple braces' },
  { token: '{{{terms_html}}}', description: 'Terms with line breaks kept — triple braces' },
  { token: '{{{bank_details_html}}}', description: 'Bank details with line breaks kept — triple braces' },
  { token: '{{{cancelled_html}}}', description: 'CANCELLED watermark when the invoice is cancelled — triple braces' },
  { token: '{{invoice_number}}', description: 'Invoice number' },
  { token: '{{invoice_date}}', description: 'Invoice date' },
  { token: '{{due_date}}', description: 'Due date' },
  { token: '{{customer_name}}', description: "Customer's full name" },
  { token: '{{customer_phone}}', description: "Customer's phone" },
  { token: '{{customer_email}}', description: "Customer's email" },
  { token: '{{customer_address}}', description: "Customer's address" },
  { token: '{{booking_reference}}', description: 'Linked booking code, if any' },
  { token: '{{{line_items_html}}}', description: 'Pre-rendered <tr> rows for the line-items table — triple braces (unescaped HTML)' },
  { token: '{{subtotal}}', description: 'Subtotal, formatted' },
  { token: '{{discount}}', description: 'Discount, formatted' },
  { token: '{{tax}}', description: 'Tax, formatted' },
  { token: '{{total}}', description: 'Total, formatted' },
  { token: '{{paid_amount}}', description: 'Amount paid, formatted' },
  { token: '{{remaining_amount}}', description: 'Balance due, formatted' },
  { token: '{{status}}', description: 'Invoice status' },
  { token: '{{notes}}', description: 'Invoice notes' },
  { token: '{{terms}}', description: 'Terms & conditions text' },
  { token: '{{bank_details}}', description: 'Bank details text' },
  { token: '{{{logo_html}}}', description: "Agency logo as an <img> tag (size follows Settings > Branding width/height), empty if none is set — triple braces" },
  { token: '{{{signature_html}}}', description: "Signature image as an <img> tag, empty if none is set — triple braces" },
  { token: '{{{stamp_html}}}', description: "Stamp image as an <img> tag, empty if none is set — triple braces" }
];

// ---- Logo sizing (Phase 2 upgrade) ---------------------------------------
// The administrator can set logo width and height independently (Settings >
// Branding). When neither is set the output is byte-for-byte the original
// style ("max-height:56px;max-width:200px"), so existing invoices look exactly
// as before. When one or both are set, the explicit values win.
const LOGO_MIN = 10;
const LOGO_MAX = 600;

/** Returns a whole number of px within range, or null when blank. Throws on junk. */
function normalizeLogoDimension(value, label = 'Logo size') {
  if (value === undefined || value === null || String(value).trim() === '') return null;
  const n = Number(String(value).trim());
  if (!Number.isFinite(n) || n <= 0) throw new Error(`${label} must be a positive number.`);
  if (n < LOGO_MIN || n > LOGO_MAX) throw new Error(`${label} must be between ${LOGO_MIN} and ${LOGO_MAX} px.`);
  return Math.round(n);
}

function buildLogoHtml(settings = {}) {
  if (!settings.logo) return '';
  let w = null;
  let h = null;
  try { w = normalizeLogoDimension(settings.logo_width); } catch (_) { w = null; }
  try { h = normalizeLogoDimension(settings.logo_height); } catch (_) { h = null; }
  let style;
  if (w === null && h === null) {
    style = 'max-height:56px;max-width:200px;object-fit:contain;';
  } else {
    const parts = [];
    parts.push(w !== null ? `width:${w}px;` : 'width:auto;');
    parts.push(h !== null ? `height:${h}px;` : 'height:auto;');
    parts.push('object-fit:contain;');
    style = parts.join('');
  }
  return `<img src="${settings.logo}" style="${style}" />`;
}

module.exports = { renderTemplate, escapeHtml, AVAILABLE_TOKENS, buildLogoHtml, normalizeLogoDimension, LOGO_MIN, LOGO_MAX };
