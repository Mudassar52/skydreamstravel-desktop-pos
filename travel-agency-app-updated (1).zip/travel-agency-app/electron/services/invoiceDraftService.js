const { getDb } = require('../../src/database/db');
const bookingDossier = require('./bookingDossierService');
const documentCurrency = require('./documentCurrency');

// Builds a ready-to-edit invoice (items, payments, agent) from a booking's real data: who is travelling, flights,
// hotels (room / meal / nights), visa, transport and ziyarat. Nothing is saved here - the invoice form opens with
// this draft so the user can change any line before saving.

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
function d(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value || ''));
  return m ? `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}` : String(value || '');
}
const clean = (v) => (v === undefined || v === null ? '' : String(v).trim());
const join = (parts, sep = ' | ') => parts.filter(Boolean).join(sep);
const pair = (label, value) => (clean(value) ? `${label}: ${clean(value)}` : '');
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

function ageOn(dob, onDate) {
  const b = new Date(dob);
  const ref = onDate ? new Date(onDate) : new Date();
  if (Number.isNaN(b.getTime()) || Number.isNaN(ref.getTime())) return null;
  let age = ref.getFullYear() - b.getFullYear();
  if (ref.getMonth() < b.getMonth() || (ref.getMonth() === b.getMonth() && ref.getDate() < b.getDate())) age -= 1;
  return age;
}

function travellerType(t, departure) {
  const age = t.date_of_birth ? ageOn(t.date_of_birth, departure) : null;
  if (age !== null) return age < 2 ? 'Infant' : age < 12 ? 'Child' : 'Adult';
  return /child/i.test(t.relationship || '') ? 'Child' : 'Adult';
}

function countLabel(types) {
  const c = { Adult: 0, Child: 0, Infant: 0 };
  types.forEach((t) => { c[t] += 1; });
  return ['Adult', 'Child', 'Infant'].filter((k) => c[k] > 0).map((k) => `${c[k]} ${k}`).join(' + ');
}

function travellersBlock(list, departure) {
  if (!list.length) return null;
  const types = list.map((t) => travellerType(t, departure));
  const lines = list.map((t, i) => `${i + 1}. ${t.full_name} (${types[i]}${t.relationship && t.relationship.toLowerCase() !== types[i].toLowerCase() ? `, ${t.relationship}` : ''})`);
  return { text: lines.join('\n'), summary: countLabel(types), count: list.length };
}

function flightsBlock(rows) {
  if (!rows.length) return null;
  const blocks = rows.map((f, i) => {
    const route = join([clean(f.departure_airport), clean(f.arrival_airport)], ' → ');
    const dep = join([d(f.departure_date), clean(f.departure_time)], ', ');
    const arr = join([d(f.arrival_date), clean(f.arrival_time)], ', ');
    const when = join([dep, arr], ' → ');
    return [
      `${i + 1}. ${join([clean(f.airline), clean(f.flight_number)], ' ')}`.trim(),
      join([route, when]),
      join([pair('Class', f.class), pair('Baggage', f.baggage), pair('Seat', f.seat), pair('PNR', f.pnr)]),
      clean(f.notes) && clean(f.notes) !== clean(f.flight_number) ? pair('Note', f.notes) : ''
    ].filter(Boolean).map((l, k) => (k === 0 ? l : `    ${l}`)).join('\n');
  });
  return { text: blocks.join('\n\n'), count: rows.length };
}

function hotelsBlock(rows) {
  if (!rows.length) return null;
  const blocks = rows.map((h) => [
    `${clean(h.city) ? `${clean(h.city)} Hotel` : 'Hotel'}: ${clean(h.hotel_name)}`,
    join([pair('Check in', d(h.check_in)), pair('Check out', d(h.check_out)), pair('Nights', h.number_of_nights)]),
    join([pair('Rooms', h.number_of_rooms), pair('Room Type', h.room_type), pair('Bed', h.bed_type), pair('Meal', h.meal_plan), pair('Guests', h.number_of_guests)]),
    pair('Location', h.address),
    clean(h.notes) && clean(h.notes) !== clean(h.hotel_name) ? pair('Note', h.notes) : ''
  ].filter(Boolean).join('\n'));
  return { text: blocks.join('\n\n'), count: rows.length };
}

function visaBlock(rows, travellerNames) {
  if (!rows.length) return null;
  const lines = rows.map((v, i) => `${i + 1}. ${join([join([clean(v.visa_type), 'Visa'], ' '), clean(v.country)])}` +
    (travellerNames.get(v.traveller_id) ? ` | Traveller: ${travellerNames.get(v.traveller_id)}` : ''));
  return { text: lines.join('\n'), count: rows.length };
}

function transportBlock(rows) {
  if (!rows.length) return null;
  const lines = rows.map((t, i) => {
    const route = clean(t.pickup_location) && clean(t.drop_location) ? `${clean(t.pickup_location)} → ${clean(t.drop_location)}` : clean(t.pickup_location) || clean(t.drop_location);
    return `${i + 1}. ${join([clean(t.vehicle), route, join([d(t.pickup_date), clean(t.pickup_time)], ', ')])}`;
  });
  return { text: lines.join('\n') };
}

function servicesBlock(rows) {
  if (!rows.length) return null;
  return { text: rows.map((o, i) => `${i + 1}. ${join([clean(o.description) || clean(o.service_type), d(o.service_date)])}`).join('\n') };
}

const sumPrice = (rows) => round2(rows.reduce((s, r) => s + Number(r.selling_price || 0), 0));

/**
 * mode 'lump'     -> the package line carries the whole booking price; every component is a text block.
 * mode 'itemised' -> each component shows its own price; the package line keeps only what is left over (if any).
 */
function buildDraft(bookingId, { mode = 'lump' } = {}) {
  const db = getDb();
  const head = bookingDossier.header(bookingId);
  const people = bookingDossier.travellers(bookingId);
  const flights = bookingDossier.flights(bookingId);
  const hotels = bookingDossier.hotels(bookingId);
  const visas = bookingDossier.visa(bookingId);
  const transport = bookingDossier.transport(bookingId);
  const others = bookingDossier.ziyarat(bookingId);
  const ziyarat = others.filter((o) => /ziyarat|ziarat/i.test(o.service_type || ''));
  const otherServices = others.filter((o) => !/ziyarat|ziarat/i.test(o.service_type || ''));

  const b = db.prepare('SELECT * FROM bookings WHERE id = ?').get(bookingId);
  const agent = b.agent_id ? db.prepare('SELECT name FROM agents WHERE id = ?').get(b.agent_id) : null;
  const currency = documentCurrency.forInvoice(db, { bookingId });

  const trav = travellersBlock(people, head.departure_date);
  const headcount = (trav && trav.count) || head.number_of_passengers || 1;
  const typeLabel = /umrah|hajj/i.test(head.booking_type) ? head.booking_type : (head.package_snapshot && head.package_snapshot.package_name) || head.booking_type;
  const packageName = /umrah|hajj/i.test(head.booking_type) ? `${headcount} Person ${typeLabel} Package` : `${headcount} Person ${typeLabel}`;

  const nightsByCity = hotels.filter((h) => Number(h.number_of_nights) > 0)
    .map((h) => `${h.number_of_nights} Nights${clean(h.city) ? ` ${clean(h.city)}` : ''}`);
  const totalNights = hotels.reduce((s, h) => s + Number(h.number_of_nights || 0), 0);
  const pkgLines = [
    totalNights ? `${totalNights} Nights ${typeLabel} Package${nightsByCity.length > 1 ? ` (${nightsByCity.join(' & ')})` : ''}` : '',
    head.departure_date || head.return_date ? `Travel Dates: ${join([d(head.departure_date), d(head.return_date)], ' to ')}` : '',
    trav ? `Package Cost For: ${trav.summary}` : ''
  ].filter(Boolean);

  const prices = {
    flights: sumPrice(flights), hotels: sumPrice(hotels), visa: sumPrice(visas),
    transport: sumPrice(transport), ziyarat: sumPrice(ziyarat), other: sumPrice(otherServices)
  };
  const itemised = mode === 'itemised';
  const componentTotal = round2(Object.values(prices).reduce((s, v) => s + v, 0));
  const leftover = itemised ? Math.max(round2(head.total_price - componentTotal), 0) : head.total_price;

  const items = [{
    title: packageName, description: pkgLines.join('\n'), quantity: 1,
    unit_price: leftover, show_price: !itemised || leftover > 0 ? 1 : 0
  }];
  const add = (title, block, price) => {
    if (!block) return;
    items.push({ title, description: block.text, quantity: 1, unit_price: itemised ? price : 0, show_price: itemised && price > 0 ? 1 : 0 });
  };
  if (trav) items.push({ title: `Travellers (${trav.summary})`, description: trav.text, quantity: 1, unit_price: 0, show_price: 0 });
  const names = new Map(people.map((p) => [p.id, p.full_name]));
  add(flights.length ? `${flights.length} Flight${flights.length > 1 ? 's' : ''}` : '', flightsBlock(flights), prices.flights);
  add('Hotel Details', hotelsBlock(hotels), prices.hotels);
  add('Visa', visaBlock(visas, names), prices.visa);
  add('Transport', transportBlock(transport), prices.transport);
  add('Ziyarat', servicesBlock(ziyarat), prices.ziyarat);
  add('Other Services', servicesBlock(otherServices), prices.other);

  // Payments already taken against this booking become payment lines (anything not itemised is kept as one line).
  const pays = db.prepare("SELECT payment_date, payment_method, amount FROM payments WHERE booking_id = ? AND payment_type != 'Refund' ORDER BY payment_date, id").all(bookingId);
  const payment_lines = pays.map((p) => ({ label: p.payment_method || 'Payment', date: String(p.payment_date || '').slice(0, 10), amount: round2(p.amount) }));
  const rest = round2(Number(b.paid_amount || 0) - payment_lines.reduce((s, l) => s + l.amount, 0));
  if (rest > 0.005) payment_lines.push({ label: 'Payment received', date: '', amount: rest });

  return {
    customer_id: head.customer.id, customer_label: head.customer.full_name, booking_id: bookingId,
    booking_code: head.booking_code, currency, agent_name: agent ? agent.name : '',
    items, payment_lines
  };
}

module.exports = { buildDraft };
