const { getDb } = require('../../src/database/db');
const quotationService = require('./quotationService');
const settingsService = require('./settingsService');
const { escapeHtml, buildLogoHtml } = require('./templateEngine');
const { formatMoney } = require('./moneyFormat');

// Customer-facing quotation PDF (Umrah / Hajj / tour packages). Everything is built from the saved quotation:
// header + passenger strip, flight itinerary (departure / return), hotels table, transport, ziyarat, visas,
// package price with the grand total, then company policies. Cost price and profit are NEVER printed.

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
const DEFAULT_POLICIES = [
  'Bookings are non-changeable. Any requested modification is at the discretion of the supplier and may incur a service fee plus any supplier-imposed costs.',
  'This package is valid for the duration stated. Flight reservations made with passenger names are held only for a limited time until ticketed.',
  'If any of the included services are cancelled or unavailable due to circumstances beyond our control, we will endeavour to provide an alternative of similar category and quality.',
  'By booking this package you acknowledge that you have read, understood and agree to abide by these terms and conditions. If you need any further assistance, please do not hesitate to contact us.'
];
const DEFAULT_NOTE = 'Prices are not guaranteed until the tickets are issued and may change after the validity period.';

const esc = escapeHtml;
const clean = (v) => (v === undefined || v === null ? '' : String(v).trim());
const nl = (t) => esc(t).replace(/\r?\n/g, '<br>');

function pretty(value, withYear = true) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value || ''));
  if (!m) return clean(value);
  return `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]}${withYear ? ` ${m[1]}` : ''}`;
}
function addDays(iso, days) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  if (!m) return '';
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + days));
  return d.toISOString().slice(0, 10);
}
function nightsBetween(a, b) {
  const x = Date.parse(a); const y = Date.parse(b);
  return Number.isFinite(x) && Number.isFinite(y) && y > x ? Math.round((y - x) / 86400000) : null;
}
const cap = (s) => clean(s).replace(/\b\w/g, (c) => c.toUpperCase());

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(clean(hex));
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const mixWhite = (rgb, amount) => `rgb(${rgb.map((c) => Math.round(c + (255 - c) * amount)).join(',')})`;
const darken = (rgb, amount) => `rgb(${rgb.map((c) => Math.round(c * (1 - amount))).join(',')})`;

const ICON = {
  plane: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/></svg>',
  bed: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 19V6M3 15h18v4M21 15v-3a3 3 0 0 0-3-3h-7v6"/><circle cx="7" cy="11" r="1.6"/></svg>',
  car: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 16h14v-4l-2-4H7l-2 4v4zM5 12h14"/><circle cx="8" cy="17.5" r="1.5"/><circle cx="16" cy="17.5" r="1.5"/></svg>',
  visa: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.6-1.6 5.4-1.6 6 0M14 10h4M14 14h4"/></svg>',
  mosque: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v2M7 12a5 5 0 0 1 10 0M5 21V12h14v9M10 21v-4a2 2 0 0 1 4 0v4"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h16M14 6l6 6-6 6"/></svg>'
};

/** Components of the central package an item was picked from (only used to fill what the quotation itself leaves empty). */
function packageParts(db, item) {
  const id = Number(item.details && item.details.package_id);
  if (!id) return {};
  const rows = db.prepare('SELECT component_type, description FROM package_components WHERE package_id = ? ORDER BY id').all(id);
  const by = (re) => rows.filter((r) => re.test(r.component_type || '') && clean(r.description)).map((r) => clean(r.description));
  return { flights: by(/flight/i), hotels: by(/hotel/i), transport: by(/transport/i), ziyarat: by(/zi?yarat/i), visa: by(/visa/i) };
}

function buildModel(q) {
  const db = getDb();
  const items = q.items || [];
  const detailOf = (it) => it.details || {};

  // ---- Hotels ---------------------------------------------------------------------------------------------------
  const hotels = [];
  let cursor = q.travel_date_from || '';
  const umrah = items.filter((it) => it.category !== 'Hotel').map(detailOf);
  const pick = (k) => { const hit = umrah.find((d) => clean(d[k])); return hit ? clean(hit[k]) : ''; };
  for (const city of ['Makkah', 'Madinah']) {
    const key = city.toLowerCase();
    const name = pick(`${key}_hotel`);
    if (!name) continue;
    const nights = Number(pick(`${key}_nights`)) || 0;
    let inD = pick(`${key}_checkin`); let outD = pick(`${key}_checkout`);
    if (!inD && cursor) inD = cursor;
    if (!outD && inD && nights) outD = addDays(inD, nights);
    if (outD) cursor = outD;
    hotels.push({
      city, name, in: inD, out: outD, nights: nights || nightsBetween(inD, outD) || '',
      rooms: Number(pick('rooms')) || 1, room: pick('room_type'), meal: pick('meal_plan'), distance: pick(`${key}_distance`)
    });
  }
  items.filter((it) => it.category === 'Hotel').forEach((it) => {
    const d = detailOf(it);
    hotels.push({
      city: cap(d.city), name: it.name, in: d.check_in || it.service_date || '', out: d.check_out || '',
      nights: nightsBetween(d.check_in || it.service_date, d.check_out) || '', rooms: Number(d.rooms) || Number(it.quantity) || 1,
      room: clean(d.room_type), meal: clean(d.meal_plan), distance: clean(d.distance)
    });
  });

  // ---- Transport / Ziyarat / Visa ---------------------------------------------------------------------------------
  const text = { transport: [], ziyarat: [], visa: [] };
  const transportTypes = [];
  items.forEach((it) => {
    const d = detailOf(it);
    if (clean(d.transport_type)) transportTypes.push(clean(d.transport_type));
    if (clean(d.transport_route)) text.transport.push(clean(d.transport_route));
    if (clean(d.ziyarat)) text.ziyarat.push(clean(d.ziyarat));
    if (clean(d.visa_details)) text.visa.push(clean(d.visa_details));
    if (it.category === 'Transport') text.transport.push([it.name, clean(it.description)].filter(Boolean).join(' - '));
    if (it.category === 'Visa') text.visa.push([it.name, clean(it.description)].filter(Boolean).join(' - '));
    if (it.category !== 'Package' && /zi?yarat/i.test(`${it.name} ${it.description || ''}`) && !clean(d.ziyarat)) {
      text.ziyarat.push([it.name, clean(it.description)].filter(Boolean).join(' - '));
    }
  });
  // Whatever the quotation did not spell out is taken from the central package the row was picked from.
  for (const it of items.filter((x) => x.category === 'Package')) {
    const parts = packageParts(db, it);
    if (!text.transport.length && !transportTypes.length) text.transport.push(...(parts.transport || []));
    if (!text.ziyarat.length) text.ziyarat.push(...(parts.ziyarat || []));
    if (!text.visa.length) text.visa.push(...(parts.visa || []));
    if (!hotels.length) (parts.hotels || []).forEach((h) => hotels.push({ city: '', name: h, in: '', out: '', nights: '', rooms: 1, room: '', meal: '', distance: '' }));
  }

  return { hotels, text, transportTypes };
}

function render(q, model) {
  const settings = settingsService.getAll();
  const cur = q.currency || 'PKR';
  const m = (n) => formatMoney(n, cur);
  const rgb = hexToRgb(settings.quotation_accent) || hexToRgb('#0f766e');
  const accent = `rgb(${rgb.join(',')})`;
  const accentDark = darken(rgb, 0.28);
  const accentSoft = mixWhite(rgb, 0.9);
  const accentLine = mixWhite(rgb, 0.72);
  const gold = '#b8892b';

  const packageItem = (q.items || []).find((it) => it.category === 'Package') || (q.items || []).find((it) => it.details && it.details.pax_type);
  const adults = Number(q.adults || 0); const kids = Number(q.children || 0); const inf = Number(q.infants || 0);
  const people = adults + kids + inf;
  const paxText = [adults ? `${adults} Adult${adults > 1 ? 's' : ''}` : '', kids ? `${kids} Child${kids > 1 ? 'ren' : ''}` : '', inf ? `${inf} Infant${inf > 1 ? 's' : ''}` : ''].filter(Boolean).join(' + ');

  const nightsBy = model.hotels.filter((h) => Number(h.nights) > 0).map((h) => `${h.nights} Nights ${h.city || 'Hotel'}`.trim());
  const totalNights = q.total_nights || model.hotels.reduce((s, h) => s + (Number(h.nights) || 0), 0) || '';
  const title = packageItem ? packageItem.name : `${q.quotation_type || 'Custom Package'}${q.destination ? ` - ${q.destination}` : ''}`;
  const subtitle = [
    totalNights ? `${totalNights} Nights Package${nightsBy.length > 1 ? ` ( ${nightsBy.join(' & ')} )` : ''}` : '',
    people ? `for ${people} ${people === 1 ? 'person' : 'persons'}` : ''
  ].filter(Boolean).join(' ');

  const metaLine = [
    q.departure_city ? `From ${q.departure_city}` : '',
    q.travel_date_from ? `${pretty(q.travel_date_from)}${q.travel_date_to ? ` - ${pretty(q.travel_date_to)}` : ''}` : '',
    paxText, q.travel_class
  ].filter(Boolean).map(esc).join('  &middot;  ');

  // ---- Flight itinerary: empty framed boxes that hold the screenshots uploaded on the quotation -----------------------
  const imgs = q.flight_images || {};
  const box = (slot, cls) => `<div class="fbox ${cls}">${imgs[slot] ? `<img src="${imgs[slot]}" alt="">` : ''}</div>`;
  // Flight pictures belong to the types that travel by air (or any quotation that actually has a picture uploaded).
  const showFlights = ['Umrah', 'Hajj', 'Tour', 'Flight', 'Custom Package'].includes(q.quotation_type) || Object.values(imgs).some(Boolean);
  const flightsHtml = !showFlights ? '' : `<div class="section"><div class="sec-title">${ICON.plane}<span>Flight Itinerary</span></div>${box('main', 'main')}</div>`;
  const legsHtml = !showFlights ? '' : `<div class="section"><div class="sec-title">${ICON.arrow}<span>Departure</span></div>${box('departure', 'leg')}</div>
    <div class="section"><div class="sec-title">${ICON.arrow}<span>Return</span></div>${box('return', 'leg')}</div>`;

  // ---- Hotels -----------------------------------------------------------------------------------------------------
  let hotelsHtml = '';
  if (model.hotels.length) {
    const byCity = {};
    model.hotels.forEach((h) => { const c = h.city || 'Hotel'; byCity[c] = (byCity[c] || 0) + (Number(h.rooms) || 1); });
    const roomsLine = Object.entries(byCity).map(([c, n]) => `${n} Room${n > 1 ? 's' : ''} in ${c}`).join(' &amp; ');
    const distances = model.hotels.filter((h) => h.distance).map((h) => `${esc(h.city || 'Hotel')} hotel at ${esc(h.distance)}`).join(' &amp; ');
    hotelsHtml = `<div class="section"><div class="sec-title">${ICON.bed}<span>Hotels</span><small>( ${roomsLine} )</small></div>
      ${distances ? `<div class="note-line">${distances}</div>` : ''}
      <table class="grid"><thead><tr><th>#</th><th>City</th><th>Hotel Name</th><th>Check In</th><th>Check Out</th><th>Nights</th><th>Room Type</th><th>Meals</th></tr></thead><tbody>
      ${model.hotels.map((h, i) => `<tr><td class="c">${i + 1}</td><td><span class="city">${esc((h.city || '-').toUpperCase())}</span></td><td class="b">${esc(h.name)}</td>
        <td class="c">${esc(pretty(h.in) || '-')}</td><td class="c">${esc(pretty(h.out) || '-')}</td><td class="c">${esc(h.nights || '-')}</td>
        <td class="c">${esc(`${h.rooms} ${h.room || 'Room'}`)}</td><td class="c">${esc(h.meal || '-')}</td></tr>`).join('')}
      </tbody></table></div>`;
  }

  // ---- Transport / Ziyarat / Visa ---------------------------------------------------------------------------------
  const info = (icon, label, head, lines) => `<div class="irow"><div class="ibadge">${icon}</div><div class="ibody"><div class="ititle">${label}${head ? ` <span>${esc(head)}</span>` : ''}</div>${
    lines.length ? `<div class="itext">${lines.map((l) => `<div>${esc(l)}</div>`).join('')}</div>` : ''}</div></div>`;
  const blocks = [];
  if (model.transportTypes.length || model.text.transport.length) {
    blocks.push(info(ICON.car, 'Transport', model.transportTypes.length ? `( ${[...new Set(model.transportTypes)].join(', ')} ) included all the way` : 'included', model.text.transport));
  }
  if (model.text.ziyarat.length) blocks.push(info(ICON.mosque, 'Ziyarat', 'included', model.text.ziyarat));
  if (model.text.visa.length) blocks.push(info(ICON.visa, 'Visas', 'included', model.text.visa));
  const servicesHtml = blocks.length ? `<div class="section"><div class="sec-title"><span>Included Services</span></div>${blocks.join('')}</div>` : '';

  // ---- Price ------------------------------------------------------------------------------------------------------
  // Informational rows (a flight leg, a hotel line...) with no price of their own are described above, not priced here.
  const priced = (q.items || []).filter((it) => it.category === 'Package' || Number(it.line_total) > 0 || Number(it.unit_price) > 0);
  const rows = (priced.length ? priced : q.items || []).map((it) => {
    const d = it.details || {};
    const label = d.pax_type ? `${esc(cap(d.pax_type))} <span class="mute">- ${esc(it.name)}</span>` : esc(it.name);
    return `<tr><td>${label}${it.description && !['Flight', 'Hotel', 'Visa', 'Transport'].includes(it.category) ? `<div class="mute">${esc(String(it.description).split('\n')[0])}</div>` : ''}</td>
      <td class="c">${esc(it.quantity)}${it.unit ? ` ${esc(it.unit)}` : ''}</td><td class="r">${esc(m(it.unit_price))}</td>
      <td class="r">${Number(it.discount) ? `-${esc(m(it.discount))}` : '-'}</td><td class="r b">${esc(m(it.line_total))}</td></tr>`;
  }).join('');
  const sumLines = [
    Number(q.discount) > 0 || Number(q.tax) > 0 ? `<div class="sl"><span>Subtotal</span><span>${esc(m(q.subtotal))}</span></div>` : '',
    Number(q.discount) > 0 ? `<div class="sl"><span>Discount</span><span>-${esc(m(q.discount))}</span></div>` : '',
    Number(q.tax) > 0 ? `<div class="sl"><span>Taxes / charges</span><span>+${esc(m(q.tax))}</span></div>` : '',
    Number(q.advance_required) > 0 ? `<div class="sl"><span>Advance to confirm</span><span>${esc(m(q.advance_required))}</span></div><div class="sl"><span>Balance after advance</span><span>${esc(m(q.balance_due))}</span></div>` : ''
  ].join('');
  const priceHtml = `<div class="section keep"><div class="sec-title"><span>Package Price</span></div>
    <table class="grid price"><thead><tr><th>Description</th><th>Qty</th><th>Price</th><th>Discount</th><th>Amount</th></tr></thead><tbody>${rows}</tbody></table>
    <table class="total-bar"><tr>
      <td class="tb-left"><div class="tc-label">GRAND TOTAL</div><div class="tc-cur">${esc(cur)}${people > 1 ? ` &middot; for ${people} persons` : ''}</div></td>
      <td class="tb-sums">${sumLines}</td>
      <td class="tb-amount">${esc(m(q.selling_price))}</td></tr></table></div>`;

  const noteBlocks = [
    q.terms ? `<div class="box"><div class="box-t">Payment Terms</div><div>${nl(q.terms)}</div></div>` : '',
    q.notes ? `<div class="box"><div class="box-t">Special Notes</div><div>${nl(q.notes)}</div></div>` : ''
  ].join('');

  // ---- Policies ---------------------------------------------------------------------------------------------------
  const policies = clean(settings.quotation_policies) ? settings.quotation_policies.split(/\r?\n/).map(clean).filter(Boolean) : DEFAULT_POLICIES;
  const validity = [q.valid_until ? `This quotation is valid until ${pretty(q.valid_until)}.` : '', clean(settings.quotation_note) || DEFAULT_NOTE].filter(Boolean).join(' ');

  const phone = [settings.agency_phone, settings.agency_whatsapp].filter(Boolean).join('  |  ');
  const css = `
  @page { size: A4; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body { font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; color: #2b2f33; font-size: 12px; line-height: 1.5; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .page { padding: 10mm 12mm 10mm; }
  .top { display: flex; align-items: center; gap: 7mm; padding-bottom: 5mm; border-bottom: 2px solid ${accent}; }
  .top .logo { flex: 0 0 34mm; }
  .top .agency { flex: 1; font-size: 10.5px; color: #555; }
  .top .agency h1 { margin: 0 0 2px; font-size: 16px; color: #222; text-transform: uppercase; letter-spacing: .02em; }
  .top .qt { text-align: right; }
  .top .qt .word { font-size: 22px; font-weight: 800; letter-spacing: .12em; color: ${accent}; }
  .top .qt .num { font-size: 12px; font-weight: 600; }
  .top .qt .small { font-size: 10.5px; color: #666; }
  .strip { display: flex; margin-top: 5mm; border-bottom: 1px solid #d9dde1; padding-bottom: 3mm; }
  .strip > div { flex: 1; }
  .strip .k { font-size: 9.5px; text-transform: uppercase; letter-spacing: .08em; color: #7b8086; font-weight: 700; }
  .strip .v { font-size: 13px; font-weight: 600; margin-top: 1px; }
  .hero { margin-top: 4mm; }
  .hero .t { font-size: 16px; font-weight: 800; color: #222; }
  .hero .s { font-size: 12px; color: #555; }
  .hero .m { font-size: 11px; color: #777; margin-top: 2px; }
  .section { margin-top: 5mm; page-break-inside: avoid; }
  .sec-title { display: flex; align-items: center; gap: 7px; color: ${accent}; border-bottom: 1px solid ${accentLine}; padding-bottom: 3px; font-size: 13px; font-weight: 800; letter-spacing: .05em; text-transform: uppercase; }
  .sec-title small { font-size: 10.5px; font-weight: 600; text-transform: none; color: #666; letter-spacing: 0; margin-left: 4px; }
  .note-line { font-size: 11px; color: #555; margin: 4px 0 0; }
  .fbox { margin-top: 3mm; border: 1.5px solid #3a3f44; border-radius: 4px; overflow: hidden; text-align: center; }
  .fbox.main { min-height: 52mm; }
  .fbox.leg { min-height: 78mm; }
  .fbox img { display: block; max-width: 100%; max-height: 120mm; margin: 0 auto; }
  .fbox.main img { max-height: 90mm; }
  table.grid { width: 100%; border-collapse: collapse; margin-top: 3mm; font-size: 11.5px; }
  table.grid th { background: #f3f4f6; color: #444; text-transform: uppercase; font-size: 9.5px; letter-spacing: .05em; padding: 6px 8px; border: 1px solid #d3d7db; }
  table.grid td { padding: 6px 8px; border: 1px solid #d3d7db; vertical-align: top; }
  td.c, th.c { text-align: center; } td.r, th.r { text-align: right; } td.b { font-weight: 700; }
  .city { color: ${accent}; font-weight: 800; font-size: 10.5px; letter-spacing: .05em; }
  .mute { color: #7b8086; font-size: 10.5px; }
  .irow { display: flex; gap: 9px; margin-top: 3mm; align-items: flex-start; }
  .ibadge { flex: 0 0 28px; height: 28px; border-radius: 50%; background: ${accentSoft}; color: ${accent}; display: flex; align-items: center; justify-content: center; }
  .ititle { font-weight: 800; text-transform: uppercase; letter-spacing: .04em; font-size: 11.5px; color: #222; }
  .ititle span { text-transform: none; letter-spacing: 0; font-weight: 600; color: #444; }
  .itext { font-size: 11.5px; color: #444; }
  table.total-bar { width: 100%; border-collapse: collapse; margin-top: 3mm; border: 2px solid ${accent}; }
  table.total-bar td { padding: 9px 12px; vertical-align: middle; }
  .tb-left { width: 32%; }
  .tb-sums { width: 30%; font-size: 10.5px; color: #555; border-left: 1px solid ${accentLine}; border-right: 1px solid ${accentLine}; }
  .tb-amount { text-align: right; font-size: 24px; font-weight: 800; white-space: nowrap; color: ${accent}; }
  .tc-label { font-size: 12px; font-weight: 800; letter-spacing: .14em; color: #222; }
  .tc-cur { font-size: 10.5px; color: #777; margin-top: 1px; }
  .sl { display: flex; justify-content: space-between; padding: 1px 0; }
  .box { margin-top: 3mm; border-left: 3px solid ${accent}; background: #f7f8f9; padding: 6px 10px; font-size: 11.5px; page-break-inside: avoid; }
  .box-t { font-weight: 800; text-transform: uppercase; font-size: 10px; letter-spacing: .06em; color: #555; margin-bottom: 1px; }
  .policies { margin-top: 6mm; border: 1px solid #d3d7db; page-break-inside: avoid; }
  .policies .ph { background: ${accent}; color: #fff; text-align: center; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; padding: 5px; font-size: 11.5px; }
  .policies ul { margin: 0; padding: 7px 14px 5px 28px; font-size: 11px; color: #444; }
  .policies li { margin-bottom: 3px; }
  .valid { border-top: 1px solid #d3d7db; color: #b3261e; font-size: 10.5px; font-weight: 600; padding: 6px 12px; text-align: center; }
  .foot { text-align: center; margin-top: 5mm; font-size: 10.5px; color: #888; }
  `;

  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(q.quotation_number)}</title><style>${css}</style></head><body>
  <div class="page"><div class="top">
    <div class="logo">${buildLogoHtml(settings)}</div>
    <div class="agency"><h1>${esc(settings.agency_name || 'Your Travel Agency')}</h1>
      ${settings.agency_address ? `<div>${nl(settings.agency_address)}</div>` : ''}
      ${phone ? `<div>${esc(phone)}</div>` : ''}
      ${[settings.agency_email, settings.agency_website].filter(Boolean).length ? `<div>${esc([settings.agency_email, settings.agency_website].filter(Boolean).join('  |  '))}</div>` : ''}</div>
    <div class="qt"><div class="word">QUOTATION</div><div class="num">${esc(q.quotation_number)}${q.revision_number > 0 ? ` &middot; Rev ${esc(q.revision_number)}` : ''}</div>
      <div class="small">Date: ${esc(pretty(q.quotation_date))}</div>${q.valid_until ? `<div class="small">Valid until: ${esc(pretty(q.valid_until))}</div>` : ''}</div>
  </div>
  <div class="body">
    <div class="strip">
      <div><div class="k">Passenger Name</div><div class="v">${esc(q.customer_name)}</div></div>
      <div><div class="k">Agent Name</div><div class="v">${esc(q.agent_name || q.prepared_by_name || '-')}</div></div>
      <div><div class="k">Contact</div><div class="v">${esc(q.customer_phone || '-')}</div></div>
      <div><div class="k">Date</div><div class="v">${esc(pretty(q.quotation_date))}</div></div>
    </div>
    <div class="hero"><div class="t">${esc(title)}</div>${subtitle ? `<div class="s">${esc(subtitle)}</div>` : ''}${metaLine ? `<div class="m">${metaLine}</div>` : ''}</div>
    ${flightsHtml}
    ${hotelsHtml}
    ${servicesHtml}
    ${priceHtml}
    ${legsHtml}
    ${noteBlocks}
    <div class="policies"><div class="ph">Company Policies</div><ul>${policies.map((p) => `<li>${esc(p.replace(/^\*+\s*/, ''))}</li>`).join('')}</ul><div class="valid">${esc(validity)}</div></div>
    <div class="foot">Thank you for choosing <b>${esc(settings.agency_name || 'us')}</b>${settings.agency_website ? ` &middot; ${esc(settings.agency_website)}` : ''}</div>
  </div></div></body></html>`;
}

function buildQuotationHtml(id) {
  const q = quotationService.get(id);
  return render(q, buildModel(q));
}

module.exports = { buildQuotationHtml, buildModel };
