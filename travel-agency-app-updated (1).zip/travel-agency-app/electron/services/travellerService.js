const { getDb } = require('../../src/database/db');

const RELATIONSHIPS = ['Self', 'Spouse', 'Child', 'Parent', 'Sibling', 'Other'];

const TRAVELLER_FIELDS = [
  'customer_id', 'full_name', 'relationship', 'date_of_birth', 'gender', 'nationality',
  'passport_number', 'passport_issue_date', 'passport_expiry_date', 'visa_status', 'notes'
];

function validate(payload) {
  if (!payload.full_name || !payload.full_name.trim()) throw new Error('Traveller name is required.');
  if (payload.passport_issue_date && payload.passport_expiry_date) {
    if (new Date(payload.passport_expiry_date) < new Date(payload.passport_issue_date)) {
      throw new Error('Passport expiry date cannot be before the issue date.');
    }
  }
}

function list({ search = '', customerId = null, page = 1, pageSize = 25 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(t.full_name LIKE @q OR t.passport_number LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (customerId) { conditions.push('t.customer_id = @customerId'); params.customerId = customerId; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS c FROM travellers t ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;

  const rows = db
    .prepare(
      `SELECT t.*, c.full_name AS customer_name,
        (SELECT COUNT(*) FROM booking_travellers bt WHERE bt.traveller_id = t.id) AS bookings_count
       FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id
       ${where} ORDER BY t.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const traveller = db
    .prepare(`SELECT t.*, c.full_name AS customer_name FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id WHERE t.id = ?`)
    .get(id);
  if (!traveller) throw new Error('Traveller not found.');

  const bookings = db
    .prepare(
      `SELECT b.id, b.booking_code, b.booking_type, b.status, b.departure_date
       FROM booking_travellers bt JOIN bookings b ON b.id = bt.booking_id
       WHERE bt.traveller_id = ? ORDER BY b.created_at DESC`
    )
    .all(id);

  return { ...traveller, bookings };
}

function listByCustomer(customerId) {
  const db = getDb();
  return db.prepare('SELECT * FROM travellers WHERE customer_id = ? ORDER BY full_name').all(customerId);
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const params = {};
  for (const f of TRAVELLER_FIELDS) params[f] = payload[f] ?? null;

  const result = db
    .prepare(`INSERT INTO travellers (${TRAVELLER_FIELDS.join(', ')}) VALUES (${TRAVELLER_FIELDS.map((f) => `@${f}`).join(', ')})`)
    .run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Traveller Created', 'traveller', ?, ?)`
  ).run(result.lastInsertRowid, `Traveller "${payload.full_name}" created`);

  return { id: result.lastInsertRowid };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id FROM travellers WHERE id = ?').get(id);
  if (!existing) throw new Error('Traveller not found.');

  const params = { id };
  const sets = [];
  for (const f of TRAVELLER_FIELDS) {
    if (payload[f] !== undefined) { sets.push(`${f} = @${f}`); params[f] = payload[f]; }
  }
  sets.push("updated_at = datetime('now')");
  db.prepare(`UPDATE travellers SET ${sets.join(', ')} WHERE id = @id`).run(params);

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Traveller Updated', 'traveller', ?, ?)`
  ).run(id, `Traveller #${id} updated`);

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const linked = db.prepare('SELECT COUNT(*) AS c FROM booking_travellers WHERE traveller_id = ?').get(id).c;
  if (linked > 0) throw new Error('This traveller is linked to existing bookings and cannot be deleted.');
  const traveller = db.prepare('SELECT full_name FROM travellers WHERE id = ?').get(id);
  db.prepare('DELETE FROM travellers WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'traveller', ?, ?)`
  ).run(id, `Traveller "${traveller?.full_name || id}" deleted`);
  return { success: true };
}

function addToBooking(bookingId, travellerId, notes) {
  const db = getDb();
  const exists = db.prepare('SELECT id FROM booking_travellers WHERE booking_id = ? AND traveller_id = ?').get(bookingId, travellerId);
  if (exists) throw new Error('This traveller is already on that booking.');
  const result = db.prepare('INSERT INTO booking_travellers (booking_id, traveller_id, notes) VALUES (?, ?, ?)').run(bookingId, travellerId, notes || null);
  return { id: result.lastInsertRowid };
}

function removeFromBooking(membershipId) {
  const db = getDb();
  const m = db.prepare('SELECT booking_id, traveller_id FROM booking_travellers WHERE id = ?').get(membershipId);
  db.transaction(() => {
    if (m) {
      // keep the booking's flights / hotel stays consistent: someone no longer on the booking can't stay on them
      db.prepare('DELETE FROM flight_travellers WHERE traveller_id = ? AND flight_id IN (SELECT id FROM flights WHERE booking_id = ?)').run(m.traveller_id, m.booking_id);
      db.prepare('DELETE FROM hotel_guests WHERE traveller_id = ? AND hotel_id IN (SELECT id FROM hotels WHERE booking_id = ?)').run(m.traveller_id, m.booking_id);
    }
    db.prepare('DELETE FROM booking_travellers WHERE id = ?').run(membershipId);
  })();
  return { success: true };
}

function listForBooking(bookingId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT bt.id AS membership_id, t.* FROM booking_travellers bt
       JOIN travellers t ON t.id = bt.traveller_id
       WHERE bt.booking_id = ? ORDER BY t.full_name`
    )
    .all(bookingId);
}


// ---------------------------------------------------------------------------
// Grouped view: ONE entry per customer, with all of that customer's travellers inside it.
// Each person is still stored as its own `travellers` row (flights / hotels / visas / quotations all
// point at individual travellers), but the Travellers page shows and edits them as one group.
// A traveller with no linked customer is shown as a group of one.
// ---------------------------------------------------------------------------
const MEMBER_FIELDS = TRAVELLER_FIELDS.filter((f) => f !== 'customer_id');

function groupBookings(db, memberIds) {
  if (!memberIds.length) return [];
  return db
    .prepare(
      `SELECT DISTINCT b.id, b.booking_code, b.booking_type, b.status, b.departure_date
       FROM booking_travellers bt JOIN bookings b ON b.id = bt.booking_id
       WHERE bt.traveller_id IN (${memberIds.map(() => '?').join(',')}) ORDER BY b.id DESC`
    )
    .all(...memberIds);
}

function listGroups({ search = '', page = 1, pageSize = 15 } = {}) {
  const db = getDb();
  const params = {};
  let where = '';
  if (search && search.trim()) {
    where = `WHERE (t.full_name LIKE @q OR t.passport_number LIKE @q OR c.full_name LIKE @q)`;
    params.q = `%${search.trim()}%`;
  }
  const groupKey = `CASE WHEN t.customer_id IS NULL THEN 'T' || t.id ELSE 'C' || t.customer_id END`;
  const total = db
    .prepare(`SELECT COUNT(DISTINCT ${groupKey}) AS c FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id ${where}`)
    .get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const keys = db
    .prepare(
      `SELECT ${groupKey} AS gkey, MIN(t.customer_id) AS customer_id, MIN(t.id) AS first_id, MAX(t.created_at) AS last_created
       FROM travellers t LEFT JOIN customers c ON c.id = t.customer_id ${where}
       GROUP BY gkey ORDER BY last_created DESC, first_id DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  const rows = keys.map((k) => {
    const members = k.customer_id
      ? db.prepare('SELECT * FROM travellers WHERE customer_id = ? ORDER BY id').all(k.customer_id)
      : db.prepare('SELECT * FROM travellers WHERE id = ?').all(k.first_id);
    const customer = k.customer_id ? db.prepare('SELECT id, full_name FROM customers WHERE id = ?').get(k.customer_id) : null;
    const bookings = groupBookings(db, members.map((m) => m.id));
    return {
      key: k.gkey,
      customer_id: k.customer_id || null,
      traveller_id: k.customer_id ? null : k.first_id,
      customer_name: customer ? customer.full_name : null,
      members,
      bookings
    };
  });
  return { rows, total, page, pageSize };
}

/** Everything the group form needs: the customer, all their travellers, their bookings and which are linked. */
function getGroup({ customerId = null, travellerId = null } = {}) {
  const db = getDb();
  let members;
  let customer = null;
  if (customerId) {
    customer = db.prepare('SELECT id, full_name FROM customers WHERE id = ?').get(customerId);
    if (!customer) throw new Error('Customer not found.');
    members = db.prepare('SELECT * FROM travellers WHERE customer_id = ? ORDER BY id').all(customerId);
  } else {
    members = db.prepare('SELECT * FROM travellers WHERE id = ?').all(travellerId);
    if (!members.length) throw new Error('Traveller not found.');
  }
  const available = customerId
    ? db.prepare('SELECT id, booking_code, booking_type, status, departure_date FROM bookings WHERE customer_id = ? ORDER BY id DESC').all(customerId)
    : [];
  const linked = groupBookings(db, members.map((m) => m.id));
  return { customer, members, available_bookings: available, linked_booking_ids: linked.map((b) => b.id) };
}

function bookingsForCustomer(customerId) {
  const db = getDb();
  return db.prepare('SELECT id, booking_code, booking_type, status, departure_date FROM bookings WHERE customer_id = ? ORDER BY id DESC').all(customerId);
}

/**
 * Saves a customer's whole traveller group in one go.
 *   payload = { customer_id, members: [{ id?, full_name, ...fields }], removed_ids: [], booking_ids: [] }
 * - members with an id are updated, the rest are created under the customer
 * - removed_ids are taken off their bookings and deleted
 * - booking_ids = the customer's bookings the travellers should appear on (others of the customer are unlinked)
 */
function saveGroup(payload) {
  const customerId = Number(payload.customer_id);
  if (!customerId) throw new Error('Please select a customer.');
  const members = Array.isArray(payload.members) ? payload.members : [];
  if (!members.length) throw new Error('Add at least one traveller.');
  members.forEach(validate);
  const bookingIds = (payload.booking_ids || []).map(Number);
  const removedIds = (payload.removed_ids || []).map(Number);

  const db = getDb();
  if (!db.prepare('SELECT id FROM customers WHERE id = ?').get(customerId)) throw new Error('Customer not found.');
  const customerBookingIds = bookingsForCustomer(customerId).map((b) => b.id);
  for (const id of bookingIds) {
    if (!customerBookingIds.includes(id)) throw new Error('A selected booking does not belong to this customer.');
  }

  const tx = db.transaction(() => {
    // 1. removals
    for (const id of removedIds) {
      const t = db.prepare('SELECT id, full_name, customer_id FROM travellers WHERE id = ?').get(id);
      if (!t || t.customer_id !== customerId) continue;
      for (const m of db.prepare('SELECT id FROM booking_travellers WHERE traveller_id = ?').all(id)) removeFromBooking(m.id);
      try { remove(id); } catch (e) {
        throw new Error(`"${t.full_name}" is used elsewhere (visa, quotation, etc.) and cannot be removed.`);
      }
    }
    // 2. create / update members
    const ids = [];
    for (const m of members) {
      const data = { customer_id: customerId };
      for (const f of MEMBER_FIELDS) data[f] = m[f] === '' ? null : m[f];
      if (m.id) {
        const own = db.prepare('SELECT customer_id FROM travellers WHERE id = ?').get(m.id);
        if (!own || own.customer_id !== customerId) throw new Error('Traveller does not belong to this customer.');
        update(m.id, data);
        ids.push(Number(m.id));
      } else {
        ids.push(create({ ...data, full_name: m.full_name }).id);
      }
    }
    // 3. booking links: every member on every selected booking; unselected bookings of this customer unlinked
    for (const bId of customerBookingIds) {
      const wanted = bookingIds.includes(bId);
      for (const tId of ids) {
        const link = db.prepare('SELECT id FROM booking_travellers WHERE booking_id = ? AND traveller_id = ?').get(bId, tId);
        if (wanted && !link) addToBooking(bId, tId, null);
        if (!wanted && link) removeFromBooking(link.id);
      }
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Traveller Group Saved', 'customer', ?, ?)`
    ).run(customerId, `${ids.length} traveller(s) saved for customer #${customerId}`);
    return ids;
  });
  return { ids: tx() };
}

module.exports = {
  listGroups, getGroup, saveGroup, bookingsForCustomer,
  RELATIONSHIPS, list, get, listByCustomer, create, update, remove,
  addToBooking, removeFromBooking, listForBooking
};
