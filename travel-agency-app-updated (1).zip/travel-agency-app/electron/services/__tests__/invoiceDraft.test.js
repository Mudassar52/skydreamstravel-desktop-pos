const fs = require('fs');
const { freshDb } = require('./testUtils');
const { getDb } = require('../../../src/database/db');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const travellerService = require('../travellerService');
const agentService = require('../agentService');
const paymentService = require('../paymentService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const invoiceDraftService = require('../invoiceDraftService');
const settingsService = require('../settingsService');

// "From Booking": the invoice fills itself from the booking's real data, one section per component.
describe('invoice draft from a booking', () => {
  let cust; let booking;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    settingsService.setMany({
      agency_name: 'Royal Manchester Travels Limited', company_number: '16008918',
      agency_address: 'T/A Royal Manchester, 55 Peel Street,\nRochdale, England,\nManchester\nOL12 6PN',
      agency_phone: '+441614640811', agency_email: 'sales@royalmanchestertravels.co.uk', agency_website: 'https://royalmanchestertravels.co.uk/'
    });
    cust = customerService.create({ full_name: 'Mr. Haleem Hussain', phone: '07404659702' }).id;
    const agent = agentService.create({ name: 'Ali Raza Travels', commission_type: 'Percentage', commission_value: 5 }).id;
    booking = bookingService.create({
      customer_id: cust, booking_type: 'Umrah', total_price: 3670, status: 'Confirmed', agent_id: agent,
      departure_date: '2026-10-04', return_date: '2026-10-12', number_of_passengers: 3
    }).id;
    const db = getDb();
    db.prepare('UPDATE bookings SET currency = ? WHERE id = ?').run('GBP', booking);
    db.prepare(`INSERT INTO hotels (booking_id, hotel_name, city, check_in, check_out, room_type, number_of_rooms, number_of_nights, meal_plan, number_of_guests, selling_price)
                VALUES (?, 'Astoneast Taiba 4 star', 'Madinah', '2026-10-04', '2026-10-07', 'Triple', 1, 3, 'Room Only', 3, 900)`).run(booking);
    db.prepare(`INSERT INTO hotels (booking_id, hotel_name, city, check_in, check_out, room_type, number_of_rooms, number_of_nights, meal_plan, number_of_guests, selling_price)
                VALUES (?, 'Al Ebba Makkah 4 star', 'Makkah', '2026-10-07', '2026-10-12', 'Triple', 1, 5, 'Room Only', 3, 1400)`).run(booking);
    db.prepare(`INSERT INTO flights (booking_id, airline, flight_number, departure_airport, arrival_airport, departure_date, departure_time, baggage, class, selling_price)
                VALUES (?, 'Pegasus Airline', 'PC 1', 'MAN', 'MED', '2026-10-04', '09:30', '20 Kg + 7 Kg', 'Economy', 800)`).run(booking);
    db.prepare(`INSERT INTO visa_applications (customer_id, booking_id, country, visa_type, selling_price) VALUES (?, ?, 'Saudi Arabia', 'Umrah', 300)`).run(cust, booking);
    db.prepare(`INSERT INTO transportation (booking_id, vehicle, pickup_location, drop_location, selling_price) VALUES (?, '4 seater car', 'Madinah Airport', 'Madinah Hotel', 120)`).run(booking);
    db.prepare(`INSERT INTO other_services (service_type, booking_id, customer_id, description, selling_price) VALUES ('Ziyarat', ?, ?, 'Madinah & Makkah Ziyarat (4 seater car)', 150)`).run(booking, cust);
    [['Haleem Hussain', 'Self', '1985-03-02'], ['Spouse Hussain', 'Spouse', '1988-01-01'], ['Little Hussain', 'Child', '2018-05-05']].forEach(([n, r, dob]) => {
      const t = travellerService.create({ full_name: n, customer_id: cust, relationship: r, date_of_birth: dob }).id;
      travellerService.addToBooking(booking, t, null);
    });
    paymentService.create({ customer_id: cust, booking_id: booking, amount: 1700, payment_method: 'Bank Transfer', payment_type: 'Advance' });
  });

  it('puts every component in its own section with room / meal / nights spelled out', () => {
    const draft = invoiceDraftService.buildDraft(booking);
    const byTitle = Object.fromEntries(draft.items.map((i) => [i.title, i]));
    expect(draft.agent_name).toBe('Ali Raza Travels');
    expect(draft.currency).toBe('GBP');
    expect(draft.items[0].title).toBe('3 Person Umrah Package');
    expect(draft.items[0].description).toContain('8 Nights Umrah Package (3 Nights Madinah & 5 Nights Makkah)');
    expect(draft.items[0].description).toContain('Package Cost For: 2 Adult + 1 Child');
    expect(draft.items[0].unit_price).toBe(3670);
    expect(byTitle['Travellers (2 Adult + 1 Child)'].description).toContain('2. Little Hussain (Child)');
    expect(byTitle['1 Flight'].description).toContain('MAN → MED');
    expect(byTitle['1 Flight'].description).toContain('Baggage: 20 Kg + 7 Kg');
    const hotel = byTitle['Hotel Details'].description;
    expect(hotel).toContain('Madinah Hotel: Astoneast Taiba 4 star');
    expect(hotel).toContain('Check in: 4 Oct 2026 | Check out: 7 Oct 2026 | Nights: 3');
    expect(hotel).toContain('Rooms: 1 | Room Type: Triple | Meal: Room Only | Guests: 3');
    expect(byTitle.Visa.description).toContain('Umrah Visa | Saudi Arabia');
    expect(byTitle.Transport.description).toContain('4 seater car | Madinah Airport → Madinah Hotel');
    expect(byTitle.Ziyarat.description).toContain('Madinah & Makkah Ziyarat');
    // one lump price: only the package line shows a price
    expect(draft.items.filter((i) => i.show_price)).toHaveLength(1);
    expect(draft.payment_lines).toEqual([expect.objectContaining({ label: 'Bank Transfer', amount: 1700 })]);
  });

  it('itemised mode shows each service price and keeps only the remainder on the package line', () => {
    const draft = invoiceDraftService.buildDraft(booking, { mode: 'itemised' });
    const priced = draft.items.filter((i) => i.show_price).reduce((s, i) => s + i.unit_price, 0);
    expect(priced).toBe(3670);
    expect(draft.items.find((i) => i.title === 'Hotel Details').unit_price).toBe(2300);
    expect(draft.items[0].unit_price).toBe(3670 - (2300 + 800 + 300 + 120 + 150));
  });

  it('saves as an invoice and prints agent, booking ref and the sections', () => {
    const draft = invoiceDraftService.buildDraft(booking);
    const { id } = invoiceService.create({ ...draft, invoice_date: '2026-09-10', due_label: 'On Receipt' });
    const inv = invoiceService.get(id);
    expect(inv.agent_name).toBe('Ali Raza Travels');
    expect(inv.total).toBe(3670);
    expect(inv.paid_amount).toBe(1700);
    const html = invoiceService.buildInvoiceHtml(id);
    fs.writeFileSync('/tmp/rmt-booking-invoice.html', html);
    expect(html).toContain('Agent');
    expect(html).toContain('Ali Raza Travels');
    expect(html).toContain('Booking Ref');
    expect(html).toContain('<b>Meal:</b> Room Only');
    expect(html).toContain('Hotel Details');
  });
});
