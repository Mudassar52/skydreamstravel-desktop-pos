const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const quotationService = require('../quotationService');
const doc = require('../quotationDocumentService');

// The quotation form is driven by the chosen type (src/pages/quotationFlow.js): each type shows only its own
// sections, and the guided sections are stored as ordinary service rows.
describe('quotation type flows', () => {
  let flowMod; let cust;
  beforeAll(async () => { flowMod = await import('../../../src/pages/quotationFlow.js'); });
  beforeEach(() => { freshDb(); cust = customerService.create({ full_name: 'Tom Pantom', phone: '07700 900123' }).id; });

  const umrahState = () => ({
    packageName: '3&4 Star 7 Nights Umrah Package', packageId: '',
    pax: { Adult: { price: 1020, cost: 800 }, Child: { price: 228, cost: 150 } },
    hotels: [
      { city: 'Makkah', name: 'Emaar Al Khalil 3 Star', check_in: '2026-01-27', check_out: '2026-01-31', room_type: 'Double Room', rooms: 1, meal_plan: 'Room Only', distance: '5 mins walk' },
      { city: 'Madinah', name: 'Zowar International 4 Star', check_in: '2026-01-31', check_out: '2026-02-03', room_type: 'Double Room', rooms: 1, meal_plan: 'Room Only', distance: '3 mins walk' }
    ],
    info: { transport_type: '4 Seater Van', transport_route: 'Jeddah Airport to Makkah Hotel', ziyarat: 'Makkah & Madinah Ziyarat', visa_details: '3 Person Umrah Visas', ignored: 'x' },
    rows: []
  });

  it('shows the right sections per type', () => {
    const { FLOWS, flowOf } = flowMod;
    expect(FLOWS.Umrah.hotels).toEqual(['Makkah', 'Madinah']);
    expect(FLOWS.Umrah.info).toEqual(['transport', 'ziyarat', 'visa']);
    expect(flowOf('Flight')).toMatchObject({ hotels: null, info: [], flights: true, pricing: 'pax' });
    expect(flowOf('Visa')).toMatchObject({ hotels: null, info: ['visa'], flights: false });
    expect(flowOf('Hotel')).toMatchObject({ pricing: 'rows', flights: false });
    expect(flowOf('Something else').pricing).toBe('rows'); // unknown -> custom
  });

  it('turns the guided Umrah form into rows: a price row per traveller type, zero-priced hotel rows, info on the first row', () => {
    const items = flowMod.flowToItems('Umrah', umrahState(), { adults: 2, children: 1, infants: 0 });
    expect(items.map((i) => `${i.category}:${i.quantity}x${i.unit_price}`)).toEqual(['Package:2x1020', 'Package:1x228', 'Hotel:1x0', 'Hotel:1x0']);
    expect(items[0].details).toMatchObject({ pax_type: 'Adult', transport_type: '4 Seater Van', ziyarat: 'Makkah & Madinah Ziyarat', visa_details: '3 Person Umrah Visas' });
    expect(items[0].details.ignored).toBeUndefined();
    expect(items[1].details).toEqual({ pax_type: 'Child' });
    expect(items[2].details).toMatchObject({ city: 'Makkah', check_in: '2026-01-27', check_out: '2026-01-31', meal_plan: 'Room Only', distance: '5 mins walk' });
    expect(flowMod.lineTotals('Umrah', umrahState(), { adults: 2, children: 1, infants: 0 }).reduce((a, b) => a + b, 0)).toBe(2268);
  });

  it('a Flight or Visa quotation carries no hotels and no foreign sections', () => {
    const st = { ...umrahState(), packageName: '' };
    const flight = flowMod.flowToItems('Flight', st, { adults: 1, children: 0, infants: 0 });
    expect(flight).toHaveLength(1);
    expect(flight[0]).toMatchObject({ category: 'Flight', name: 'Flight Tickets' });
    expect(flight[0].details.transport_type).toBeUndefined();
    const visa = flowMod.flowToItems('Visa', st, { adults: 1, children: 0, infants: 0 });
    expect(visa[0]).toMatchObject({ category: 'Visa', name: 'Visa Service' });
    expect(visa[0].details.visa_details).toBe('3 Person Umrah Visas');
    expect(visa[0].details.transport_type).toBeUndefined();
  });

  it('saves, reloads and round-trips through the real service', () => {
    const counts = { adults: 2, children: 1, infants: 0 };
    const items = flowMod.flowToItems('Umrah', umrahState(), counts);
    const { id } = quotationService.create({ customer_id: cust, quotation_type: 'Umrah', currency: 'GBP', adults: 2, children: 1, infants: 0, travel_date_from: '2026-01-27', items });
    const q = quotationService.get(id);
    expect(q.selling_price).toBe(2268);
    const back = flowMod.itemsToFlow(q.items, { travelFrom: q.travel_date_from });
    expect(back.packageName).toBe('3&4 Star 7 Nights Umrah Package');
    expect(back.pax.Adult.price).toBe(1020);
    expect(back.pax.Child.price).toBe(228);
    expect(back.hotels.map((h) => [h.city, h.name, h.check_in, h.check_out])).toEqual([
      ['Makkah', 'Emaar Al Khalil 3 Star', '2026-01-27', '2026-01-31'], ['Madinah', 'Zowar International 4 Star', '2026-01-31', '2026-02-03']]);
    expect(back.info).toMatchObject({ transport_type: '4 Seater Van', visa_details: '3 Person Umrah Visas' });
    expect(back.rows).toEqual([]);
    // saving what was loaded gives the same rows again
    const again = flowMod.flowToItems('Umrah', { ...back, rows: back.rows }, counts);
    expect(again.map((i) => `${i.category}:${i.quantity}x${i.unit_price}`)).toEqual(items.map((i) => `${i.category}:${i.quantity}x${i.unit_price}`));
  });

  it('keeps an old quotation\'s rows and total, moving its Umrah details into the guided sections', () => {
    const { id } = quotationService.create({
      customer_id: cust, quotation_type: 'Umrah', currency: 'PKR', adults: 3, travel_date_from: '2026-01-27',
      items: [{ category: 'Package', name: 'Old Umrah package', quantity: 1, unit: 'Package', unit_price: 500000,
        details: { makkah_hotel: 'Old Makkah Hotel', makkah_nights: 4, madinah_hotel: 'Old Madinah Hotel', madinah_nights: 3, room_type: 'Triple', transport_type: 'Coaster' } }]
    });
    const q = quotationService.get(id);
    const back = flowMod.itemsToFlow(q.items, { travelFrom: q.travel_date_from });
    expect(back.hotels.map((h) => [h.city, h.name, h.check_in, h.check_out])).toEqual([
      ['Makkah', 'Old Makkah Hotel', '2026-01-27', '2026-01-31'], ['Madinah', 'Old Madinah Hotel', '2026-01-31', '2026-02-03']]);
    expect(back.info.transport_type).toBe('Coaster');
    expect(back.pax).toEqual({});
    expect(back.rows).toHaveLength(1);
    expect(back.rows[0]).toMatchObject({ name: 'Old Umrah package', unit_price: 500000 });
    expect(back.rows[0].details.makkah_hotel).toBeUndefined(); // not saved twice
    const resaved = flowMod.flowToItems('Umrah', back, { adults: 3, children: 0, infants: 0 });
    expect(resaved.filter((r) => r.unit_price > 0).reduce((s, r) => s + r.quantity * r.unit_price, 0)).toBe(500000);
  });

  it('prints each type with only its own sections', () => {
    const make = (type, extra) => quotationService.create({ customer_id: cust, quotation_type: type, currency: 'GBP', adults: 1, items: flowMod.flowToItems(type, { ...umrahState(), ...extra }, { adults: 1, children: 0, infants: 0 }) }).id;
    const umrah = doc.buildQuotationHtml(make('Umrah', {}));
    expect(umrah).toContain('Emaar Al Khalil 3 Star');
    expect(umrah).toContain('4 Seater Van');
    expect(umrah).toContain('Flight Itinerary');
    const flight = doc.buildQuotationHtml(make('Flight', { packageName: '' }));
    expect(flight).toContain('Flight Itinerary');
    expect(flight).toContain('Flight Tickets');
    expect(flight).not.toContain('Emaar Al Khalil');
    expect(flight).not.toContain('4 Seater Van');
    const visa = doc.buildQuotationHtml(make('Visa', { packageName: '' }));
    expect(visa).toContain('3 Person Umrah Visas');
    expect(visa).not.toContain('Flight Itinerary');
    expect(visa).not.toContain('Departure');
    expect(visa).not.toContain('Emaar Al Khalil');
  });
});
