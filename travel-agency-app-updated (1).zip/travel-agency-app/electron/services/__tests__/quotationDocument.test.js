const fs = require('fs');
const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const quotationService = require('../quotationService');
const settingsService = require('../settingsService');
const doc = require('../quotationDocumentService');

// Customer-facing quotation PDF: same sections as the agency's paper format, built from the saved quotation.
describe('quotation document', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    settingsService.setMany({
      agency_name: 'Sky Dreams Travel', agency_address: '272 Bath Street, Glasgow, Scotland, G2 4JR',
      agency_email: 'sales@skydreamstravel.co.uk', agency_website: 'www.skydreamstravel.co.uk'
    });
    cust = customerService.create({ full_name: 'Tom Pantom', phone: '07700 900123' }).id;
  });

  const make = (extra = {}) => quotationService.create({
    customer_id: cust, customer_phone: '07700 900123', agent_name: 'Muhammad Fahad', quotation_type: 'Umrah', currency: 'GBP',
    quotation_date: '2026-04-19', valid_until: '2026-04-20', departure_city: 'Glasgow',
    travel_date_from: '2026-01-27', travel_date_to: '2026-02-03', adults: 2, children: 1, infants: 0,
    items: [
      {
        category: 'Package', name: '3&4 Star Umrah Package', quantity: 2, unit: 'Person', unit_price: 1020, cost_price: 800,
        details: {
          pax_type: 'Adult', makkah_hotel: 'Emaar Al Khalil 3 Star', makkah_nights: 4, madinah_hotel: 'Zowar International 4 Star', madinah_nights: 3,
          makkah_distance: '5 mins walk', madinah_distance: '3 mins walk', room_type: 'Double Room', meal_plan: 'Room Only',
          transport_type: '4 Seater Van', transport_route: 'Jeddah Airport to Makkah Hotel & Makkah Hotel to Madinah Hotel & Madinah Hotel to Jeddah Airport',
          ziyarat: 'Makkah & Madinah Ziyarat', visa_details: '3 Person Umrah Visas on Indian Passport'
        }
      },
      { category: 'Package', name: '3&4 Star Umrah Package', quantity: 1, unit: 'Person', unit_price: 228, cost_price: 150, details: { pax_type: 'Youth' } }
    ],
    terms: '50% advance at confirmation, balance 14 days before departure', advance_required: 500, ...extra
  }).id;

  it('prints every section with the quotation data and never leaks cost or profit', () => {
    const id = make();
    const html = doc.buildQuotationHtml(id);
    fs.writeFileSync('/tmp/quotation.html', html);
    expect(html).toContain('QUOTATION');
    expect(html).toContain('Tom Pantom');
    expect(html).toContain('Muhammad Fahad');
    expect(html).toContain('Flight Itinerary');
    expect(html).toContain('class="fbox main"></div>'); // empty box when no picture
    expect(html).toContain('class="fbox leg"></div>');
    expect(html).toContain('Departure');
    expect(html).toContain('Return');
    expect(html).toContain('Emaar Al Khalil 3 Star');
    expect(html).toContain('Zowar International 4 Star');
    expect(html).toContain('27 Jan 2026');   // Makkah check in = departure date
    expect(html).toContain('31 Jan 2026');   // Makkah check out = + 4 nights, Madinah check in
    expect(html).toContain('3 Feb 2026');
    expect(html).toContain('1 Room in Makkah &amp; 1 Room in Madinah');
    expect(html).toContain('Makkah hotel at 5 mins walk');
    expect(html).toContain('4 Seater Van');
    expect(html).toContain('Makkah &amp; Madinah Ziyarat');
    expect(html).toContain('3 Person Umrah Visas on Indian Passport');
    expect(html).toContain('£2,268.00');
    expect(html).toContain('2 Adults + 1 Child');
    expect(html).toContain('4 Nights Makkah');
    expect(html).toContain('Company Policies');
    expect(html).toContain('Valid until: 20 Apr 2026');
    expect(html).not.toContain('£800'); // unit cost
    expect(html).not.toContain('£150');
    expect(html).not.toMatch(/profit/i);
  });

  it('shows a clean placeholder when no flight is entered, and fills transport/ziyarat/visa from the central package', () => {
    const { getDb } = require('../../../src/database/db');
    const db = getDb();
    const pkg = db.prepare("INSERT INTO packages (package_name, selling_price, currency) VALUES ('Economy Umrah', 900, 'GBP')").run().lastInsertRowid;
    const add = db.prepare('INSERT INTO package_components (package_id, component_type, description) VALUES (?, ?, ?)');
    add.run(pkg, 'Transport', 'Private car on all transfers');
    add.run(pkg, 'Ziyarat', 'Madinah ziyarat');
    add.run(pkg, 'Visa', 'Umrah visa included');
    const id = quotationService.create({
      customer_id: cust, currency: 'GBP', quotation_type: 'Umrah', adults: 1,
      items: [{ category: 'Package', name: 'Economy Umrah', quantity: 1, unit: 'Person', unit_price: 900, details: { package_id: pkg } }]
    }).id;
    const html = doc.buildQuotationHtml(id);
    expect(html).toContain('Private car on all transfers');
    expect(html).toContain('Madinah ziyarat');
    expect(html).toContain('Umrah visa included');
    expect(html).not.toContain('<table class="grid"><thead><tr><th>#</th>'); // no hotel table without hotels
  });

  it('puts the uploaded flight pictures in their boxes, validates them, and keeps untouched slots', () => {
    const png = 'data:image/png;base64,iVBORw0KGgo=';
    const id = make({ flight_images: { main: png, departure: png } });
    let q = quotationService.get(id);
    expect(q.flight_images).toEqual({ main: png, departure: png, return: null });
    let html = doc.buildQuotationHtml(id);
    expect(html).toContain(`<div class="fbox main"><img src="${png}"`);
    expect(html).toContain(`<div class="fbox leg"><img src="${png}"`);
    expect(html).toContain('class="fbox leg"></div>'); // return still empty
    // update: only the touched slot changes; null removes a picture
    quotationService.update(id, { flight_images: { return: png, main: null } });
    q = quotationService.get(id);
    expect(q.flight_images).toEqual({ main: null, departure: png, return: png });
    expect(() => quotationService.update(id, { flight_images: { main: 'data:text/html;base64,AAAA' } })).toThrow(/PNG, JPG or WEBP/);
    expect(quotationService.list({}).rows[0].flight_images).toBeUndefined(); // list stays light
  });

  it('uses the colour and policies from Settings', () => {
    settingsService.setMany({ quotation_accent: '#7c2d12', quotation_policies: 'Custom policy one\nCustom policy two', quotation_note: 'Custom bottom note' });
    const html = doc.buildQuotationHtml(make());
    expect(html).toContain('rgb(124,45,18)');
    expect(html).toContain('Custom policy two');
    expect(html).toContain('Custom bottom note');
  });
});
