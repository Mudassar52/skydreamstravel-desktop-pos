const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const bookingService = require('../bookingService');
const travellerService = require('../travellerService');
const leadService = require('../leadService');
const agentService = require('../agentService');
const voucherService = require('../voucherService');

describe('grouped travellers: one entry per customer', () => {
  it('saves several travellers under one customer, links them to the selected booking, and lists them as one group', () => {
    freshDb();
    const cust = customerService.create({ full_name: 'Ahmed Khan' }).id;
    const b1 = bookingService.create({ customer_id: cust, booking_type: 'Umrah', total_price: 1000, number_of_passengers: 3, status: 'Confirmed' }).id;
    const b2 = bookingService.create({ customer_id: cust, booking_type: 'Tour', total_price: 500, number_of_passengers: 2, status: 'Confirmed' }).id;

    travellerService.saveGroup({
      customer_id: cust,
      members: [{ full_name: 'Ahmed Khan', relationship: 'Self', passport_number: 'P1' }, { full_name: 'Ayesha Khan', relationship: 'Spouse', passport_number: 'P2' }],
      booking_ids: [b1]
    });

    const groups = travellerService.listGroups();
    expect(groups.total).toBe(1);
    expect(groups.rows[0].members.map((m) => m.full_name)).toEqual(['Ahmed Khan', 'Ayesha Khan']);
    expect(groups.rows[0].bookings.map((b) => b.id)).toEqual([b1]);
    expect(bookingService.list({}).rows.find((r) => r.id === b1).travellers_count).toBe(2);

    // edit: rename one, add one, move everyone to booking 2
    const g = travellerService.getGroup({ customerId: cust });
    expect(g.linked_booking_ids).toEqual([b1]);
    const [a, w] = g.members;
    travellerService.saveGroup({
      customer_id: cust,
      members: [a, { ...w, full_name: 'Ayesha A. Khan' }, { full_name: 'Bilal Khan', relationship: 'Child' }],
      booking_ids: [b2]
    });
    const after = travellerService.getGroup({ customerId: cust });
    expect(after.members).toHaveLength(3);
    expect(after.members.some((m) => m.full_name === 'Ayesha A. Khan')).toBe(true);
    expect(after.linked_booking_ids).toEqual([b2]);
    expect(travellerService.listForBooking(b1)).toHaveLength(0);
    expect(travellerService.listForBooking(b2)).toHaveLength(3);
    expect(travellerService.listGroups().total).toBe(1);

    // remove one member
    travellerService.saveGroup({ customer_id: cust, members: after.members.slice(0, 2), removed_ids: [after.members[2].id], booking_ids: [b2] });
    expect(travellerService.getGroup({ customerId: cust }).members).toHaveLength(2);
    expect(travellerService.listForBooking(b2)).toHaveLength(2);
  });

  it('rejects a booking that belongs to another customer', () => {
    freshDb();
    const c1 = customerService.create({ full_name: 'A' }).id;
    const c2 = customerService.create({ full_name: 'B' }).id;
    const other = bookingService.create({ customer_id: c2, booking_type: 'Umrah', total_price: 1, number_of_passengers: 1, status: 'Confirmed' }).id;
    expect(() => travellerService.saveGroup({ customer_id: c1, members: [{ full_name: 'X' }], booking_ids: [other] })).toThrow(/does not belong/);
  });
});

describe('lead agent', () => {
  it('stores and returns the agent name on a lead', () => {
    freshDb();
    const agent = agentService.create({ name: 'Zubair Travels', commission_type: 'Percentage', commission_value: 5 }).id;
    const lead = leadService.create({ full_name: 'Lead One', agent_id: String(agent) }).id;
    expect(leadService.get(lead).agent_name).toBe('Zubair Travels');
    expect(leadService.list().rows[0].agent_name).toBe('Zubair Travels');
    leadService.update(lead, { agent_id: '' });
    expect(leadService.get(lead).agent_name).toBeNull();
  });
});
