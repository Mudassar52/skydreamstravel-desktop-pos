const fs = require('fs');
const { freshDb } = require('./testUtils');
const customerService = require('../customerService');
const invoiceTemplateService = require('../invoiceTemplateService');
const invoiceService = require('../invoiceService');
const settingsService = require('../settingsService');
const paymentService = require('../paymentService');
const { getDb } = require('../../../src/database/db');

// Free-form invoice (Royal Manchester style): heading + multi-line description per item, optional price cells,
// typed payment lines, own currency, editable invoice date and "On Receipt" style due text.
describe('free-form invoice', () => {
  let cust;
  beforeEach(() => {
    freshDb();
    invoiceTemplateService.ensureDefaultTemplate();
    settingsService.setMany({
      agency_name: 'Royal Manchester Travels Limited', company_number: '16008918',
      agency_address: 'T/A Royal Manchester, 55 Peel Street,\nRochdale, England,\nManchester\nOL12 6PN',
      agency_phone: '+441614640811', agency_email: 'sales@royalmanchestertravels.co.uk',
      agency_website: 'https://royalmanchestertravels.co.uk/'
    });
    cust = customerService.create({ full_name: 'Mr. Haleem Hussain', phone: '07404659702', email: 'Haleemhussain00@gmail.com' }).id;
  });

  const sample = () => ({
    customer_id: cust, currency: 'GBP', invoice_date: '2026-09-10', due_label: 'On Receipt',
    items: [
      { title: '3 Person Umrah Package', description: '8 Nights umrah Package + Pakistan Tickets\n\n3 Flights:\nPegasus Airline Flight Man to Med ( 1 Stop)', quantity: 1, unit_price: 3670 },
      { title: '', description: 'Hotel Details:\nMadinah hotel Astoneast Taiba 4 star', show_price: 0 }
    ],
    payment_lines: [
      { label: 'Bank Transfer', date: '2026-09-05', amount: 1700 },
      { label: 'Bank Transfer', date: '2026-09-15', amount: 1970 }
    ]
  });

  it('prices only the items that show a price, and settles the invoice from the payment lines', () => {
    const { id } = invoiceService.create(sample());
    const inv = invoiceService.get(id);
    expect(inv.total).toBe(3670);
    expect(inv.paid_amount).toBe(3670);
    expect(inv.remaining_amount).toBe(0);
    expect(inv.status).toBe('Paid');
    expect(inv.currency).toBe('GBP');
    expect(inv.invoice_date.slice(0, 10)).toBe('2026-09-10');
    expect(inv.items[0].title).toBe('3 Person Umrah Package');
    expect(inv.items[1].show_price).toBe(0);
    expect(inv.items[1].line_total).toBe(0);
  });

  it('a text-only item needs no price, but an item with neither heading nor description is rejected', () => {
    expect(() => invoiceService.create({ customer_id: cust, items: [{ description: 'Only text', show_price: 0 }, { description: 'Priced', quantity: 1, unit_price: 5 }] })).not.toThrow();
    expect(() => invoiceService.create({ customer_id: cust, items: [{ title: '', description: '  ', quantity: 1, unit_price: 5 }] })).toThrow(/needs a description/i);
  });

  it('prints the RMT-style invoice with heading, rate/qty/amount, payments and balance in GBP', () => {
    const { id } = invoiceService.create(sample());
    const html = invoiceService.buildInvoiceHtml(id);
    fs.writeFileSync('/tmp/rmt-invoice.html', html);
    expect(html).toContain('Company Number: 16008918');
    expect(html).toContain('Rochdale, England,<br>Manchester<br>OL12 6PN');
    expect(html).toContain('10 Sept 2026');
    expect(html).toContain('On Receipt');
    expect(html).toContain('3 Person Umrah Package');
    expect(html).toContain('£3,670.00');
    expect(html).toContain('-£1,700.00');
    expect(html).toContain('5 Sept 2026');
    expect(html).toContain('-£1,970.00');
    expect(html).toContain('GBP £0.00');
    expect(html).toContain('Hotel Details:');
  });

  it('keeps payments recorded elsewhere when the payment lines are edited', () => {
    const { id } = invoiceService.create({ ...sample(), payment_lines: [{ label: 'Bank Transfer', date: '2026-09-05', amount: 1000 }] });
    paymentService.create({ customer_id: cust, invoice_id: id, amount: 500, payment_method: 'Cash', payment_type: 'Partial' });
    expect(invoiceService.get(id).paid_amount).toBe(1500);
    const before = invoiceService.get(id);
    invoiceService.update(id, { ...sample(), payment_lines: [{ label: 'Bank Transfer', date: '2026-09-05', amount: 1200 }] });
    const after = invoiceService.get(id);
    expect(before.paid_amount).toBe(1500);
    expect(after.paid_amount).toBe(1700);
    const html = invoiceService.buildInvoiceHtml(id);
    expect(html).toContain('-£1,200.00');
    expect(html).toContain('-£500.00');
  });

  it('duplicates headings, hidden prices, currency and due text', () => {
    const { id } = invoiceService.create(sample());
    const copy = invoiceService.get(invoiceService.duplicate(id).id);
    expect(copy.currency).toBe('GBP');
    expect(copy.due_label).toBe('On Receipt');
    expect(copy.items[0].title).toBe('3 Person Umrah Package');
    expect(copy.items[1].show_price).toBe(0);
    expect(copy.paid_amount).toBe(0);
  });

  it('adds the RMT design on an existing database only once and keeps old templates', () => {
    getDb().prepare("UPDATE invoice_templates SET config_json = ? WHERE is_default = 1").run(JSON.stringify({ html: '<html>old {{invoice_number}}</html>' }));
    invoiceTemplateService.installRmtTemplate();
    invoiceTemplateService.installRmtTemplate();
    const list = invoiceTemplateService.list();
    expect(list).toHaveLength(2);
    expect(invoiceTemplateService.getDefault().template_name).toBe('Royal Manchester Style');
  });
});
