const { getDb } = require('../../src/database/db');
const periodLock = require('./periodLockService');
const documentCurrency = require('./documentCurrency');
const settingsService = require('./settingsService');
const invoiceTemplateService = require('./invoiceTemplateService');
const ledgerService = require('./ledgerService');
const { renderTemplate, escapeHtml, buildLogoHtml } = require('./templateEngine');
const { formatMoney } = require('./moneyFormat');

const STATUSES = ['Unpaid', 'Partially Paid', 'Paid', 'Cancelled'];

function money(n, currency = 'PKR') {
  return formatMoney(n, currency);
}

// An item with its price switched off is a plain text block (e.g. "Hotel Details") - it carries no amount.
function priceShown(item) {
  return !(item.show_price === 0 || item.show_price === false || item.show_price === '0');
}

function lineAmount(item) {
  return priceShown(item) ? Number(item.quantity || 1) * Number(item.unit_price || 0) : 0;
}

/** Manual payment lines typed on the invoice form: [{label, date, amount}] - label e.g. "Bank Transfer". */
function normalizePaymentLines(lines) {
  if (!Array.isArray(lines)) return [];
  return lines
    .map((l) => ({ label: String(l.label || '').trim(), date: String(l.date || '').trim(), amount: Number(l.amount || 0) }))
    .filter((l) => l.amount > 0);
}

function parsePaymentLines(json) {
  if (!json) return [];
  try { return normalizePaymentLines(JSON.parse(json)); } catch (_) { return []; }
}

function sumLines(lines) {
  return lines.reduce((sum, l) => sum + l.amount, 0);
}

/**
 * Paid amount for a saved invoice. When payment lines are typed on the form, they ARE the manual part of the paid
 * amount; anything recorded elsewhere (Payments screen, applied advances) is kept on top of it.
 */
function resolvePaid(payload, existing) {
  const lines = normalizePaymentLines(payload.payment_lines);
  if (!lines.length) return Number(payload.paid_amount || 0);
  const oldManual = existing ? sumLines(parsePaymentLines(existing.payment_lines)) : 0;
  const base = existing ? Math.max(Number(existing.paid_amount || 0) - oldManual, 0) : 0;
  return base + sumLines(lines);
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
/** '2026-09-10' / '2026-09-10 12:00:00' -> '10 Sept 2026'. Anything else is shown as typed. */
function prettyDate(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value || ''));
  if (!m) return String(value || '');
  return `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}`;
}

function nextInvoiceNumber() {
  const prefix = settingsService.get('invoice_prefix', 'INV-');
  const nextNum = parseInt(settingsService.get('invoice_next_number', '1001'), 10) || 1001;
  settingsService.set('invoice_next_number', String(nextNum + 1));
  return `${prefix}${nextNum}`;
}

function computeTotals(items, discount = 0, tax = 0) {
  const subtotal = items.reduce((sum, it) => sum + lineAmount(it), 0);
  const total = Math.max(subtotal - Number(discount || 0) + Number(tax || 0), 0);
  return { subtotal, total };
}

function deriveStatus(total, paid, requestedStatus) {
  if (requestedStatus === 'Cancelled') return 'Cancelled';
  if (paid <= 0) return 'Unpaid';
  if (paid >= total) return 'Paid';
  return 'Partially Paid';
}

function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!Array.isArray(payload.items) || payload.items.length === 0) {
    throw new Error('Add at least one line item.');
  }
  for (const item of payload.items) {
    const hasText = (item.description && String(item.description).trim()) || (item.title && String(item.title).trim());
    if (!hasText) throw new Error('Each line item needs a description (or a heading).');
    if (priceShown(item)) {
      if (Number(item.quantity) <= 0) throw new Error('Quantity must be greater than zero.');
      if (Number(item.unit_price) < 0) throw new Error('Unit price cannot be negative.');
    }
  }
  if (Number(payload.discount || 0) < 0) throw new Error('Discount cannot be negative.');
  if (Number(payload.tax || 0) < 0) throw new Error('Tax cannot be negative.');
  if (Number(payload.paid_amount || 0) < 0) throw new Error('Paid amount cannot be negative.');
  if (Array.isArray(payload.payment_lines) && payload.payment_lines.some((l) => Number(l.amount || 0) < 0)) {
    throw new Error('Payment amounts cannot be negative.');
  }
}

function list({ search = '', status = 'All', dateField = 'invoice_date', dateFrom = null, dateTo = null, page = 1, pageSize = 15 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push('(i.invoice_number LIKE @q OR c.full_name LIKE @q)');
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') {
    conditions.push('i.status = @status');
    params.status = status;
  }
  const validDateFields = ['invoice_date', 'due_date', 'created_at'];
  const col = validDateFields.includes(dateField) ? dateField : 'invoice_date';
  if (dateFrom) { conditions.push(`date(i.${col}) >= date(@dateFrom)`); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push(`date(i.${col}) <= date(@dateTo)`); params.dateTo = dateTo; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM invoices i JOIN customers c ON c.id = i.customer_id ${where}`).get(params).c;
  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT i.*, c.full_name AS customer_name
       FROM invoices i JOIN customers c ON c.id = i.customer_id
       ${where}
       ORDER BY i.created_at DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const invoice = db
    .prepare(
      `SELECT i.*, c.full_name AS customer_name, c.phone AS customer_phone, c.email AS customer_email, c.address AS customer_address,
              b.booking_code
       FROM invoices i
       JOIN customers c ON c.id = i.customer_id
       LEFT JOIN bookings b ON b.id = i.booking_id
       WHERE i.id = ?`
    )
    .get(id);
  if (!invoice) throw new Error('Invoice not found.');

  const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY id').all(id);
  return { ...invoice, items };
}

function saveItems(db, invoiceId, items) {
  db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(invoiceId);
  const insert = db.prepare(
    'INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, line_total, title, show_price) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  for (const item of items) {
    const shown = priceShown(item);
    const lineTotal = lineAmount(item);
    insert.run(
      invoiceId,
      item.description || '',
      Number(item.quantity || 1),
      shown ? Number(item.unit_price || 0) : 0,
      lineTotal,
      item.title && String(item.title).trim() ? String(item.title).trim() : null,
      shown ? 1 : 0
    );
  }
}

function create(payload) {
  validate(payload);
  const db = getDb();
  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(payload.customer_id);
  if (!customer) throw new Error('Selected customer does not exist.');
  periodLock.assertOpen(null, 'This invoice');

  const { subtotal, total } = computeTotals(payload.items, payload.discount, payload.tax);
  const paid = resolvePaid(payload, null);
  if (paid > total) throw new Error('Paid amount cannot exceed the total.');
  if (payload.invoice_date) periodLock.assertOpen(payload.invoice_date, 'This invoice');

  const invoiceNumber = nextInvoiceNumber();
  const template = invoiceTemplateService.getDefault();

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO invoices (
          invoice_number, invoice_date, due_date, customer_id, booking_id, template_id,
          subtotal, discount, tax, total, paid_amount, remaining_amount, status, notes, terms, currency,
          due_label, payment_lines, agent_name
        ) VALUES (@invoice_number, COALESCE(@invoice_date, datetime('now')), @due_date, @customer_id, @booking_id, @template_id,
          @subtotal, @discount, @tax, @total, @paid_amount, @remaining_amount, @status, @notes, @terms, @currency,
          @due_label, @payment_lines, @agent_name)`
      )
      .run({
        invoice_number: invoiceNumber,
        invoice_date: payload.invoice_date || null,
        due_label: payload.due_label ? String(payload.due_label).trim() : null,
        agent_name: payload.agent_name ? String(payload.agent_name).trim() : null,
        payment_lines: JSON.stringify(normalizePaymentLines(payload.payment_lines)),
        due_date: payload.due_date || null,
        customer_id: payload.customer_id,
        booking_id: payload.booking_id || null,
        template_id: template.id,
        subtotal,
        discount: Number(payload.discount || 0),
        tax: Number(payload.tax || 0),
        total,
        paid_amount: paid,
        remaining_amount: total - paid,
        status: deriveStatus(total, paid, payload.status),
        notes: payload.notes || null,
        terms: payload.terms || null,
        currency: documentCurrency.forInvoice(db, { bookingId: payload.booking_id, explicit: payload.currency })
      });

    saveItems(db, result.lastInsertRowid, payload.items);

    if (total > 0) {
      ledgerService.addEntry(db, {
        customer_id: payload.customer_id,
        description: `Invoice ${invoiceNumber}`,
        invoice_id: result.lastInsertRowid,
        debit: total
      });
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Created', 'invoice', ?, ?)`
    ).run(result.lastInsertRowid, `Invoice ${invoiceNumber} created`);

    return result.lastInsertRowid;
  });

  const id = tx();
  return { id, invoiceNumber };
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!existing) throw new Error('Invoice not found.');
  periodLock.assertOpen(existing.invoice_date, `Invoice ${existing.invoice_number}`);
  if (existing.status === 'Cancelled' && payload.status !== 'Cancelled') {
    throw new Error('This invoice is cancelled. Create a new invoice instead of reactivating it.');
  }

  const { subtotal, total } = computeTotals(payload.items, payload.discount, payload.tax);
  const paid = resolvePaid(payload, existing);
  if (paid > total) throw new Error('Paid amount cannot exceed the total.');
  if (payload.invoice_date) periodLock.assertOpen(payload.invoice_date, `Invoice ${existing.invoice_number}`);
  // The currency can only change while nothing has been recorded in it (a real payment fixes the currency).
  const hasPayments = db.prepare('SELECT COUNT(*) AS c FROM payments WHERE invoice_id = ?').get(id).c > 0;
  const currency = payload.currency && !hasPayments ? String(payload.currency).toUpperCase() : existing.currency;

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE invoices SET
        invoice_date = COALESCE(@invoice_date, invoice_date), due_label = @due_label, payment_lines = @payment_lines, agent_name = @agent_name,
        currency = @currency,
        due_date = @due_date, customer_id = @customer_id, booking_id = @booking_id,
        subtotal = @subtotal, discount = @discount, tax = @tax, total = @total,
        paid_amount = @paid_amount, remaining_amount = @remaining_amount, status = @status,
        notes = @notes, terms = @terms, updated_at = datetime('now')
       WHERE id = @id`
    ).run({
      id,
      invoice_date: payload.invoice_date || null,
      due_label: payload.due_label ? String(payload.due_label).trim() : null,
      agent_name: payload.agent_name ? String(payload.agent_name).trim() : null,
      payment_lines: JSON.stringify(normalizePaymentLines(payload.payment_lines)),
      currency,
      due_date: payload.due_date || null,
      customer_id: payload.customer_id,
      booking_id: payload.booking_id || null,
      subtotal,
      discount: Number(payload.discount || 0),
      tax: Number(payload.tax || 0),
      total,
      paid_amount: paid,
      remaining_amount: total - paid,
      status: deriveStatus(total, paid, payload.status),
      notes: payload.notes || null,
      terms: payload.terms || null
    });
    saveItems(db, id, payload.items);
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Updated', 'invoice', ?, ?)`
    ).run(id, `Invoice #${id} updated`);
  });
  tx();

  return { success: true };
}

function cancel(id) {
  const db = getDb();
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!invoice) throw new Error('Invoice not found.');
  periodLock.assertOpen(invoice.invoice_date, `Invoice ${invoice.invoice_number}`);

  const tx = db.transaction(() => {
    db.prepare(`UPDATE invoices SET status = 'Cancelled', updated_at = datetime('now') WHERE id = ?`).run(id);
    if (invoice.remaining_amount > 0) {
      // Nets out the still-outstanding portion of this invoice's debit so
      // the customer's balance reflects that it's no longer owed.
      ledgerService.addEntry(db, {
        customer_id: invoice.customer_id,
        description: `Invoice ${invoice.invoice_number} cancelled`,
        invoice_id: id,
        credit: invoice.remaining_amount
      });
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Invoice Cancelled', 'invoice', ?, ?)`
    ).run(id, `Invoice #${id} cancelled`);
  });
  tx();

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!invoice) throw new Error('Invoice not found.');
  periodLock.assertOpen(invoice.invoice_date, `Invoice ${invoice.invoice_number}`);
  if (invoice.paid_amount > 0) {
    throw new Error('This invoice has recorded payments and cannot be deleted. Cancel it instead.');
  }
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(id);
    db.prepare('DELETE FROM invoices WHERE id = ?').run(id);
    if (invoice.status !== 'Cancelled' && invoice.total > 0) {
      // Reverses the original debit entry - the invoice never existed.
      ledgerService.addEntry(db, {
        customer_id: invoice.customer_id,
        description: `Invoice ${invoice.invoice_number} deleted`,
        credit: invoice.total
      });
    }
    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'invoice', ?, ?)`
    ).run(id, `Invoice ${invoice.invoice_number} deleted`);
  });
  tx();
  return { success: true };
}

function duplicate(id) {
  const original = get(id);
  return create({
    customer_id: original.customer_id,
    booking_id: original.booking_id,
    discount: original.discount,
    tax: original.tax,
    paid_amount: 0,
    status: 'Unpaid',
    notes: original.notes,
    terms: original.terms,
    currency: original.currency,
    due_label: original.due_label,
    agent_name: original.agent_name,
    items: original.items.map((it) => ({
      title: it.title, description: it.description, quantity: it.quantity, unit_price: it.unit_price, show_price: it.show_price
    }))
  });
}

function createFromBooking(bookingId) {
  const db = getDb();
  const booking = db
    .prepare(
      `SELECT b.*, c.full_name AS customer_name FROM bookings b JOIN customers c ON c.id = b.customer_id WHERE b.id = ?`
    )
    .get(bookingId);
  if (!booking) throw new Error('Booking not found.');

  return create({
    customer_id: booking.customer_id,
    booking_id: booking.id,
    paid_amount: booking.paid_amount,
    status: undefined,
    items: [
      {
        description: `${booking.booking_type} Booking — ${booking.booking_code}`,
        quantity: 1,
        unit_price: booking.total_price
      }
    ]
  });
}

// ------------------------------------------------------------- PDF/print
function nl2br(text) {
  return escapeHtml(text || '').replace(/\r?\n/g, '<br>');
}

/** Payments shown under TOTAL: typed lines, then real Payments-screen entries, then any other paid amount (applied advances). */
function collectPaymentRows(invoice) {
  const db = getDb();
  const manual = parsePaymentLines(invoice.payment_lines);
  const recorded = db
    .prepare('SELECT payment_date, payment_method, amount FROM payments WHERE invoice_id = ? ORDER BY payment_date, id')
    .all(invoice.id)
    .map((p) => ({ label: p.payment_method || 'Payment', date: p.payment_date, amount: Number(p.amount || 0) }));
  const rows = [...manual, ...recorded];
  const other = Number(invoice.paid_amount || 0) - sumLines(rows);
  if (other > 0.005) rows.push({ label: 'Advance / other payment', date: '', amount: other });
  return rows;
}

/** Makes the "Label:" parts of free text bold (line start, or after " | "), e.g. "Check in: 4 Oct | Nights: 3". Input is already escaped. */
function boldLabels(escaped) {
  return escaped.replace(/(^|\| |\n)( *)([A-Za-z][A-Za-z .\/&-]{0,24}):(?=\s)/g, (_, pre, sp, label) => `${pre}${sp}<b>${label}:</b>`);
}

function buildInvoiceHtml(id) {
  const invoice = get(id);
  const template = invoice.template_id ? invoiceTemplateService.get(invoice.template_id) : invoiceTemplateService.getDefault();
  const settings = settingsService.getAll();
  // Templates issued before multi-currency invoices always printed "Rs."; they keep doing so, byte for byte.
  // New-style templates (the RMT design, or any template containing <!-- multi-currency -->) print the invoice's own currency.
  const multiCurrency = /rmt-invoice|<!--\s*multi-currency\s*-->/.test(template.html);
  const cur = multiCurrency ? (invoice.currency || documentCurrency.baseCurrency()) : 'PKR';
  const m = (n) => money(n, cur);

  // Legacy 4-column rows (Description | Qty | Unit Price | Line Total). For an item with no heading and a visible
  // price this is byte-for-byte what older templates always received.
  const lineItemsHtml = invoice.items
    .map((it) => {
      const shown = priceShown(it);
      const desc = it.title
        ? `<strong>${escapeHtml(it.title)}</strong><br>${nl2br(it.description)}`
        : escapeHtml(it.description);
      return `<tr>
        <td>${desc}</td>
        <td class="num">${shown ? escapeHtml(it.quantity) : ''}</td>
        <td class="num">${shown ? escapeHtml(m(it.unit_price)) : ''}</td>
        <td class="num">${shown ? escapeHtml(m(it.line_total)) : ''}</td>
      </tr>`;
    })
    .join('');

  // RMT-style rows (Description | Rate | Qty | Amount): bold heading, free multi-line text, optional price cells.
  const invoiceItemsHtml = invoice.items
    .map((it) => {
      const shown = priceShown(it);
      return `<tr class="item${shown ? '' : ' text'}">
        <td class="desc">${it.title ? `<div class="item-title">${escapeHtml(it.title)}</div>` : ''}${it.description ? `<div class="item-body">${boldLabels(escapeHtml(it.description))}</div>` : ''}</td>
        <td class="num">${shown ? escapeHtml(m(it.unit_price)) : ''}</td>
        <td class="num">${shown ? escapeHtml(it.quantity) : ''}</td>
        <td class="num">${shown ? escapeHtml(m(it.line_total)) : ''}</td>
      </tr>`;
    })
    .join('');

  const payRows = collectPaymentRows(invoice);
  const paymentsHtml = payRows
    .map(
      (p) => `<div class="pay-row"><div><div class="pay-label">Payment</div><div class="pay-sub">${escapeHtml(p.label)}</div></div>
        <div class="right"><div class="pay-amt">-${escapeHtml(m(p.amount))}</div><div class="pay-sub">${escapeHtml(prettyDate(p.date))}</div></div></div>`
    )
    .join('');

  const adjustments = [];
  if (Number(invoice.discount) > 0 || Number(invoice.tax) > 0) {
    adjustments.push(`<div class="tot-row"><span>SUBTOTAL</span><span>${escapeHtml(m(invoice.subtotal))}</span></div>`);
    if (Number(invoice.discount) > 0) adjustments.push(`<div class="tot-row"><span>DISCOUNT</span><span>-${escapeHtml(m(invoice.discount))}</span></div>`);
    if (Number(invoice.tax) > 0) adjustments.push(`<div class="tot-row"><span>TAX</span><span>${escapeHtml(m(invoice.tax))}</span></div>`);
  }
  const totalsHtml = `${adjustments.join('')}
    <div class="tot-row total"><span>TOTAL</span><span>${escapeHtml(m(invoice.total))}</span></div>
    ${paymentsHtml}
    <div class="balance"><div class="balance-label">BALANCE DUE</div><div class="balance-amt">${escapeHtml(cur)} ${escapeHtml(m(invoice.remaining_amount))}</div></div>`;

  const dueText = invoice.due_label || prettyDate(invoice.due_date) || '';

  const data = {
    agency_name: settings.agency_name || 'Your Travel Agency',
    agency_address: settings.agency_address || '',
    agency_address_html: nl2br(settings.agency_address || ''),
    company_number: settings.company_number || '',
    agency_phone: settings.agency_phone || '',
    agency_whatsapp: settings.agency_whatsapp || '',
    agency_email: settings.agency_email || '',
    agency_website: settings.agency_website || '',
    invoice_number: invoice.invoice_number,
    invoice_date: invoice.invoice_date,
    invoice_date_pretty: prettyDate(invoice.invoice_date),
    due_date: invoice.due_date || '',
    due_text: dueText,
    agent_name: invoice.agent_name || '',
    agent_meta_html: invoice.agent_name ? `<div class="k">Agent</div><div class="v">${escapeHtml(invoice.agent_name)}</div>` : '',
    booking_meta_html: invoice.booking_code ? `<div class="k">Booking Ref</div><div class="v">${escapeHtml(invoice.booking_code)}</div>` : '',
    customer_name: invoice.customer_name,
    customer_phone: invoice.customer_phone || '',
    customer_email: invoice.customer_email || '',
    customer_address: invoice.customer_address || '',
    booking_reference: invoice.booking_code || '',
    line_items_html: lineItemsHtml,
    invoice_items_html: invoiceItemsHtml,
    totals_html: totalsHtml,
    payments_html: paymentsHtml,
    currency: cur,
    subtotal: m(invoice.subtotal),
    discount: m(invoice.discount),
    tax: m(invoice.tax),
    total: m(invoice.total),
    paid_amount: m(invoice.paid_amount),
    remaining_amount: m(invoice.remaining_amount),
    status: invoice.status,
    cancelled_html: invoice.status === 'Cancelled' ? '<div class="cancelled-mark">CANCELLED</div>' : '',
    notes: invoice.notes || '',
    notes_html: nl2br(invoice.notes || ''),
    terms: invoice.terms || settings.terms_conditions || '',
    terms_html: nl2br(invoice.terms || settings.terms_conditions || ''),
    notes_block_html: invoice.notes ? `<div class="extra"><div class="k">Notes</div><div class="t">${nl2br(invoice.notes)}</div></div>` : '',
    terms_block_html: (invoice.terms || settings.terms_conditions)
      ? `<div class="extra"><div class="k">Terms &amp; Conditions</div><div class="t">${nl2br(invoice.terms || settings.terms_conditions)}</div></div>` : '',
    bank_block_html: settings.bank_details
      ? `<div class="extra"><div class="k">Bank Details</div><div class="t">${nl2br(settings.bank_details)}</div></div>` : '',
    bank_details: settings.bank_details || '',
    bank_details_html: nl2br(settings.bank_details || ''),
    logo_html: buildLogoHtml(settings),
    signature_html: settings.signature ? `<img src="${settings.signature}" style="max-height:48px;" />` : '',
    stamp_html: settings.stamp ? `<img src="${settings.stamp}" style="max-height:70px;" />` : ''
  };

  return renderTemplate(template.html, data);
}

function listByCustomer(customerId) {
  const db = getDb();
  return db
    .prepare('SELECT id, invoice_number, total, paid_amount, remaining_amount, status, currency FROM invoices WHERE customer_id = ? ORDER BY created_at DESC')
    .all(customerId);
}

function listByBooking(bookingId) {
  const db = getDb();
  return db
    .prepare('SELECT id, invoice_number, total, paid_amount, remaining_amount, status FROM invoices WHERE booking_id = ? ORDER BY created_at DESC')
    .all(bookingId);
}

module.exports = {
  STATUSES,
  list,
  get,
  listByCustomer,
  listByBooking,
  create,
  update,
  cancel,
  remove,
  duplicate,
  createFromBooking,
  buildInvoiceHtml,
  prettyDate,
  deriveStatus
};
