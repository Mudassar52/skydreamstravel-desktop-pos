const { BrowserWindow, dialog } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');

async function renderToPdfBuffer(html) {
  const tmpFile = path.join(os.tmpdir(), `invoice-render-${Date.now()}-${Math.random().toString(36).slice(2)}.html`);
  fs.writeFileSync(tmpFile, html, 'utf-8');

  const win = new BrowserWindow({ show: false, webPreferences: { offscreen: true } });
  try {
    await win.loadFile(tmpFile);
    // A4, background colors/shading included (per Section 17 - print-friendly, dynamic data).
    const buffer = await win.webContents.printToPDF({ pageSize: 'A4', printBackground: true, preferCSSPageSize: true, margins: { marginType: 'none' } });
    return buffer;
  } finally {
    win.destroy();
    fs.unlink(tmpFile, () => {});
  }
}

/**
 * Renders the given HTML to PDF and lets the user pick where to save it
 * via the native Windows save dialog. Generic - used for invoices, reports
 * and vouchers alike; only the dialog title and suggested file name differ.
 */
async function savePdf(html, suggestedName, title = 'Save PDF') {
  const buffer = await renderToPdfBuffer(html);
  const result = await dialog.showSaveDialog({
    title,
    defaultPath: suggestedName,
    filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
  });
  if (result.canceled || !result.filePath) return { saved: false };
  fs.writeFileSync(result.filePath, buffer);
  return { saved: true, filePath: result.filePath };
}

async function saveInvoicePdf(html, suggestedName) {
  return savePdf(html, suggestedName, 'Save Invoice PDF');
}

/**
 * Sends the rendered HTML to the native Windows print dialog (Section 31).
 */
async function printHtml(html) {
  const tmpFile = path.join(os.tmpdir(), `invoice-print-${Date.now()}-${Math.random().toString(36).slice(2)}.html`);
  fs.writeFileSync(tmpFile, html, 'utf-8');

  const win = new BrowserWindow({ show: false });
  await win.loadFile(tmpFile);

  return new Promise((resolve) => {
    win.webContents.print({ silent: false, printBackground: true }, (success, errorType) => {
      win.destroy();
      fs.unlink(tmpFile, () => {});
      resolve({ success, errorType: success ? null : errorType });
    });
  });
}

module.exports = { renderToPdfBuffer, savePdf, saveInvoicePdf, printHtml };
