const { getDb } = require('../../src/database/db');
const commissionService = require('./commissionService');
const { makeMembershipService } = require('./membershipService');
const packageService = require('./packageService');
const flightService = require('./flightService');
const hotelService = require('./hotelService');
const visaService = require('./visaService');
const transportationService = require('./transportationService');
const otherServiceService = require('./otherServiceService');

const BOOKING_TYPES = ['Umrah', 'Hajj', 'Tour', 'Flight', 'Hotel', 'Visa', 'Transportation', 'Custom'];
const STATUSES = ['Inquiry', 'Pending', 'Confirmed', 'Cancelled', 'Completed'];

// Booking types that currently have a real package/reference table to pick
// from. The rest (Flight/Hotel/Visa/Transportation) get their own reference
// tables in Phase 7 - until then reference_id is simply left blank.
const REFERENCE_TABLES = {
  Umrah: { table: 'umrah_packages', labelCol: 'package_name' },
  Hajj: { table: 'hajj_packages', labelCol: 'package_name' },
  Tour: { table: 'tours', labelCol: 'tour_name' }
};

function validate(payload) {
  if (!payload.customer_id) throw new Error('A customer must be selected.');
  if (!payload.booking_type || !BOOKING_TYPES.includes(payload.booking_type)) {
    throw new Error('Please select a valid booking type.');
  }
  if (payload.status && !STATUSES.includes(payload.status)) {
    throw new Error('Please select a valid booking status.');
  }
  const total = Number(payload.total_price || 0);
  const paid = Number(payload.paid_amount || 0);
  if (total < 0 || paid < 0) throw new Error('Amounts cannot be negative.');
  if (paid > total) throw new Error('Paid amount cannot exceed the total price.');
  if (payload.departure_date && payload.return_date && new Date(payload.return_date) < new Date(payload.departure_date)) {
    throw new Error('Return date cannot be before the departure date.');
  }
}

function nextBookingCode(db) {
  const last = db.prepare("SELECT booking_code FROM bookings ORDER BY id DESC LIMIT 1").get();
  let nextNum = 1;
  if (last?.booking_code) {
    const match = last.booking_code.match(/(\d+)$/);
    if (match) nextNum = parseInt(match[1], 10) + 1;
  }
  return `BK-${String(nextNum).padStart(6, '0')}`;
}

function getReferenceOptions(type) {
  const ref = REFERENCE_TABLES[type];
  if (!ref) return [];
  const db = getDb();
  return db.prepare(`SELECT id, ${ref.labelCol} AS label FROM ${ref.table} ORDER BY ${ref.labelCol}`).all();
}

// ---------------------------------------------------------------------------
// Central package integration.
//
// A booking can be created directly from a central Package (Umrah/Hajj/Tour/
// Custom - see packageService). When it is, this:
//   1. freezes a JSON snapshot of the package + its components onto the
//      booking, so a later edit to the master package never silently
//      changes a booking that was already sold, and
//   2. auto-creates the matching booking-level service rows (flights,
//      visa, hotels, transportation, other services) so nobody has to
//      manually re-type the same package contents on every service page.
// ---------------------------------------------------------------------------

function packageOptions(packageType) {
  return packageService.optionsByType(packageType);
}

function buildPackageSnapshot(pkg) {
  return JSON.stringify({
    package_id: pkg.id,
    package_name: pkg.package_name,
    package_type: pkg.package_type,
    destination: pkg.destination,
    duration: pkg.duration,
    package_price: pkg.package_price,
    estimated_cost: pkg.estimated_cost,
    estimated_profit: pkg.estimated_profit,
    currency: pkg.currency,
    components: pkg.components.map((c) => ({
      component_type: c.component_type,
      description: c.description,
      cost: c.cost,
      selling_price: c.selling_price,
      supplier_id: c.supplier_id,
      supplier_name: c.supplier_name
    })),
    snapshotted_at: new Date().toISOString()
  });
}

// Creates one booking-level service row per package component, in whichever
// table that component type belongs to (see packageService.COMPONENT_TYPE_GROUPS).
// A component with no mapping, or a table-specific validation failure (e.g. a
// hotel component missing a name), is skipped rather than aborting the whole
// booking - operations staff can add the missing detail from the service's
// own page afterwards.
function createServicesFromPackage(bookingId, customerId, pkg) {
  const created = { flights: 0, hotels: 0, visa: 0, transportation: 0, otherServices: 0, skipped: [] };

  for (const comp of pkg.components) {
    const group = packageService.COMPONENT_TYPE_GROUPS[comp.component_type];
    if (!group) { created.skipped.push(comp.component_type); continue; }

    try {
      const shared = {
        booking_id: bookingId,
        supplier_id: comp.supplier_id || null,
        package_component_id: comp.id,
        notes: comp.description || null
      };

      if (group.table === 'flights') {
        flightService.create({
          ...shared,
          flight_number: comp.description || `${comp.component_type} (TBA)`,
          cost: comp.cost,
          selling_price: comp.selling_price,
          status: 'Pending'
        });
        created.flights += 1;
      } else if (group.table === 'hotels') {
        hotelService.create({
          ...shared,
          hotel_name: comp.description || comp.component_type,
          cost: comp.cost,
          selling_price: comp.selling_price
        });
        created.hotels += 1;
      } else if (group.table === 'visa_applications') {
        visaService.create({
          ...shared,
          customer_id: customerId,
          country: comp.description || 'To be confirmed',
          cost: comp.cost,
          selling_price: comp.selling_price,
          status: 'Documents Pending'
        });
        created.visa += 1;
      } else if (group.table === 'transportation') {
        transportationService.create({
          ...shared,
          pickup_location: comp.description || comp.component_type,
          cost: comp.cost,
          selling_price: comp.selling_price,
          status: 'Scheduled'
        });
        created.transportation += 1;
      } else if (group.table === 'other_services') {
        otherServiceService.create({
          ...shared,
          service_type: group.serviceType,
          customer_id: customerId,
          description: comp.description || comp.component_type,
          cost: comp.cost,
          selling_price: comp.selling_price
        });
        created.otherServices += 1;
      }
    } catch (err) {
      created.skipped.push(`${comp.component_type} (${err.message})`);
    }
  }

  return created;
}

function list({ search = '', status = 'All', type = 'All', destination = null, dateField = 'booking_date', dateFrom = null, dateTo = null, page = 1, pageSize = 15 } = {}) {
  const db = getDb();
  const conditions = [];
  const params = {};

  if (search && search.trim()) {
    conditions.push(`(b.booking_code LIKE @q OR c.full_name LIKE @q)`);
    params.q = `%${search.trim()}%`;
  }
  if (status && status !== 'All') {
    conditions.push('b.status = @status');
    params.status = status;
  }
  if (type && type !== 'All') {
    conditions.push('b.booking_type = @type');
    params.type = type;
  }
  if (destination) {
    conditions.push('b.destination LIKE @destination');
    params.destination = `%${destination}%`;
  }
  const validDateFields = ['booking_date', 'departure_date', 'return_date', 'created_at'];
  const col = validDateFields.includes(dateField) ? dateField : 'booking_date';
  if (dateFrom) { conditions.push(`date(b.${col}) >= date(@dateFrom)`); params.dateFrom = dateFrom; }
  if (dateTo) { conditions.push(`date(b.${col}) <= date(@dateTo)`); params.dateTo = dateTo; }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = db
    .prepare(`SELECT COUNT(*) AS c FROM bookings b JOIN customers c ON c.id = b.customer_id ${where}`)
    .get(params).c;

  const offset = (Math.max(1, page) - 1) * pageSize;
  const rows = db
    .prepare(
      `SELECT b.*, c.full_name AS customer_name,
        (SELECT COUNT(*) FROM booking_travellers bt WHERE bt.booking_id = b.id) AS travellers_count,
        (SELECT GROUP_CONCAT(t.full_name, ', ') FROM booking_travellers bt JOIN travellers t ON t.id = bt.traveller_id WHERE bt.booking_id = b.id) AS traveller_names
       FROM bookings b JOIN customers c ON c.id = b.customer_id
       ${where}
       ORDER BY b.created_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: pageSize, offset });

  return { rows, total, page, pageSize };
}

function get(id) {
  const db = getDb();
  const booking = db
    .prepare(
      `SELECT b.*, c.full_name AS customer_name, c.phone AS customer_phone
       FROM bookings b JOIN customers c ON c.id = b.customer_id WHERE b.id = ?`
    )
    .get(id);
  if (!booking) throw new Error('Booking not found.');

  let referenceLabel = null;
  const ref = REFERENCE_TABLES[booking.booking_type];
  if (ref && booking.reference_id) {
    const row = db.prepare(`SELECT ${ref.labelCol} AS label FROM ${ref.table} WHERE id = ?`).get(booking.reference_id);
    referenceLabel = row?.label || null;
  }

  return { ...booking, referenceLabel };
}

function listByCustomer(customerId) {
  const db = getDb();
  return db
    .prepare(`SELECT * FROM bookings WHERE customer_id = ? ORDER BY created_at DESC`)
    .all(customerId);
}

function create(payload) {
  // A package pre-fills booking_type/destination/dates when the caller
  // didn't set them explicitly, so validate() needs to see the merged
  // payload rather than the raw one.
  let pkg = null;
  if (payload.package_id) {
    pkg = packageService.getForBooking(payload.package_id);
    payload = {
      ...payload,
      booking_type: payload.booking_type || pkg.package_type,
      total_price: payload.total_price ?? pkg.package_price ?? 0
    };
    if (payload.booking_type !== pkg.package_type && pkg.package_type !== 'Custom') {
      throw new Error(`This package is a ${pkg.package_type} package and cannot be used for a ${payload.booking_type} booking.`);
    }
  }

  validate(payload);
  const db = getDb();

  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(payload.customer_id);
  if (!customer) throw new Error('Selected customer does not exist.');

  const total = Number(payload.total_price || 0);
  const paid = Number(payload.paid_amount || 0);
  const bookingCode = nextBookingCode(db);

  const tx = db.transaction(() => {
    const result = db
      .prepare(
        `INSERT INTO bookings (
          booking_code, customer_id, booking_type, reference_id, package_id, package_snapshot, destination,
          departure_date, return_date, number_of_passengers, total_price, paid_amount, remaining_amount, status, notes, agent_id
        ) VALUES (@booking_code, @customer_id, @booking_type, @reference_id, @package_id, @package_snapshot, @destination,
          @departure_date, @return_date, @number_of_passengers, @total_price, @paid_amount, @remaining_amount, @status, @notes, @agent_id)`
      )
      .run({
        booking_code: bookingCode,
        customer_id: payload.customer_id,
        booking_type: payload.booking_type,
        reference_id: payload.reference_id || null,
        package_id: pkg ? pkg.id : null,
        package_snapshot: pkg ? buildPackageSnapshot(pkg) : null,
        destination: payload.destination || (pkg && pkg.destination) || null,
        departure_date: payload.departure_date || (pkg && pkg.departure_date) || null,
        return_date: payload.return_date || (pkg && pkg.return_date) || null,
        number_of_passengers: payload.number_of_passengers || 1,
        total_price: total,
        paid_amount: paid,
        remaining_amount: total - paid,
        status: payload.status || 'Inquiry',
        notes: payload.notes || null,
        agent_id: payload.agent_id || null
      });

    const bookingId = result.lastInsertRowid;
    if (payload.agent_id) {
      if (!db.prepare('SELECT id FROM agents WHERE id = ?').get(payload.agent_id)) throw new Error('Selected agent does not exist.');
      commissionService.syncForBooking(db, bookingId);
    }

    db.prepare(
      `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Booking Created', 'booking', ?, ?)`
    ).run(bookingId, `Booking ${bookingCode} created` + (pkg ? ` from package "${pkg.package_name}"` : ''));

    let servicesCreated = null;
    if (pkg) {
      servicesCreated = createServicesFromPackage(bookingId, payload.customer_id, pkg);
      db.prepare(
        `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Booking Services Auto-Created', 'booking', ?, ?)`
      ).run(
        bookingId,
        `Flights:${servicesCreated.flights} Hotels:${servicesCreated.hotels} Visa:${servicesCreated.visa} ` +
          `Transport:${servicesCreated.transportation} Other:${servicesCreated.otherServices}` +
          (servicesCreated.skipped.length ? ` Skipped:${servicesCreated.skipped.join('; ')}` : '')
      );
    }

    return { id: bookingId, bookingCode, servicesCreated };
  });

  return tx();
}

function update(id, payload) {
  validate(payload);
  const db = getDb();
  const existing = db.prepare('SELECT id, agent_id FROM bookings WHERE id = ?').get(id);
  if (!existing) throw new Error('Booking not found.');

  // Older callers (and any screen that doesn't send agent_id) must not wipe the agent: only an explicit
  // agent_id key - including null/'' to clear it - changes it.
  const agentProvided = Object.prototype.hasOwnProperty.call(payload, 'agent_id');
  const nextAgent = agentProvided ? (payload.agent_id ? Number(payload.agent_id) : null) : existing.agent_id;
  if (nextAgent && !db.prepare('SELECT id FROM agents WHERE id = ?').get(nextAgent)) throw new Error('Selected agent does not exist.');

  const total = Number(payload.total_price || 0);
  const paid = Number(payload.paid_amount || 0);

  const tx = db.transaction(() => {
  db.prepare(
    `UPDATE bookings SET
      customer_id = @customer_id, booking_type = @booking_type, reference_id = @reference_id, destination = @destination,
      departure_date = @departure_date, return_date = @return_date,
      number_of_passengers = @number_of_passengers, total_price = @total_price,
      paid_amount = @paid_amount, remaining_amount = @remaining_amount, status = @status,
      notes = @notes, agent_id = @agent_id, updated_at = datetime('now')
     WHERE id = @id`
  ).run({
    id,
    agent_id: nextAgent,
    customer_id: payload.customer_id,
    booking_type: payload.booking_type,
    reference_id: payload.reference_id || null,
    destination: payload.destination || null,
    departure_date: payload.departure_date || null,
    return_date: payload.return_date || null,
    number_of_passengers: payload.number_of_passengers || 1,
    total_price: total,
    paid_amount: paid,
    remaining_amount: total - paid,
    status: payload.status || 'Inquiry',
    notes: payload.notes || null
  });

  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Booking Updated', 'booking', ?, ?)`
  ).run(id, `Booking #${id} updated`);

  commissionService.syncForBooking(db, id, { previousAgentId: existing.agent_id });
  });
  tx();

  return { success: true };
}

function remove(id) {
  const db = getDb();
  const invoiceCount = db.prepare('SELECT COUNT(*) AS c FROM invoices WHERE booking_id = ?').get(id).c;
  if (invoiceCount > 0) {
    throw new Error('This booking has invoices linked to it and cannot be deleted. Cancel it instead.');
  }
  const booking = db.prepare('SELECT booking_code FROM bookings WHERE id = ?').get(id);
  db.prepare('DELETE FROM bookings WHERE id = ?').run(id);
  db.prepare(
    `INSERT INTO audit_logs (action, record_type, record_id, description) VALUES ('Record Deleted', 'booking', ?, ?)`
  ).run(id, `Booking ${booking?.booking_code || id} deleted`);
  return { success: true };
}

const passengers = makeMembershipService('booking_passengers', 'booking_id', 'bookings', 'number_of_passengers');

function listOptions() {
  const db = getDb();
  return db
    .prepare(
      `SELECT b.id, b.booking_code, c.full_name AS customer_name
       FROM bookings b JOIN customers c ON c.id = b.customer_id
       ORDER BY b.created_at DESC LIMIT 200`
    )
    .all()
    .map((r) => ({ id: r.id, label: `${r.booking_code} — ${r.customer_name}` }));
}

/**
 * Bookings with a departure or return date inside a window - Section 49,
 * "Upcoming Travel" - with a one-line status roll-up per service area so
 * staff can see at a glance what's still outstanding for each trip.
 */
function upcomingTravel({ from, to } = {}) {
  const db = getDb();
  const range = { from: from || new Date().toISOString().slice(0, 10), to: to || '2999-12-31' };

  const rows = db
    .prepare(
      `SELECT b.*, c.full_name AS customer_name, c.phone AS customer_phone
       FROM bookings b JOIN customers c ON c.id = b.customer_id
       WHERE (b.departure_date BETWEEN @from AND @to) OR (b.return_date BETWEEN @from AND @to)
       ORDER BY b.departure_date ASC`
    )
    .all(range);

  const flightStatus = db.prepare("SELECT status FROM flights WHERE booking_id = ? ORDER BY id DESC LIMIT 1");
  const hotelExists = db.prepare("SELECT id FROM hotels WHERE booking_id = ? ORDER BY id DESC LIMIT 1");
  const visaStatus = db.prepare("SELECT status FROM visa_applications WHERE booking_id = ? ORDER BY id DESC LIMIT 1");
  const transportStatus = db.prepare("SELECT status FROM transportation WHERE booking_id = ? ORDER BY id DESC LIMIT 1");

  return rows.map((b) => ({
    ...b,
    flightStatus: flightStatus.get(b.id)?.status || 'Not booked',
    hotelStatus: hotelExists.get(b.id) ? 'Booked' : 'Not booked',
    visaStatus: visaStatus.get(b.id)?.status || 'Not started',
    transportStatus: transportStatus.get(b.id)?.status || 'Not booked'
  }));
}

module.exports = {
  BOOKING_TYPES,
  STATUSES,
  list,
  get,
  listByCustomer,
  create,
  update,
  remove,
  passengers,
  getReferenceOptions,
  packageOptions,
  listOptions,
  upcomingTravel
};
