// Formats an amount in a document's own currency (GBP -> "£3,670.00", PKR -> "Rs. 50,000").
// PKR keeps its original whole-rupee format so existing invoices/reports look exactly as before.
const SYMBOLS = { PKR: 'Rs. ', GBP: '£', USD: '$', EUR: '€', SAR: 'SAR ', AED: 'AED ' };

function formatMoney(amount, currency = 'PKR') {
  const code = String(currency || 'PKR').toUpperCase();
  const n = Number(amount || 0);
  const prefix = SYMBOLS[code] !== undefined ? SYMBOLS[code] : `${code} `;
  if (code === 'PKR') return `${prefix}${n.toLocaleString('en-PK')}`;
  return `${prefix}${n.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

module.exports = { formatMoney, SYMBOLS };
